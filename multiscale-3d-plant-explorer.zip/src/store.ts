import { create } from 'zustand';
import { NODE_MAP, canonicalPath, childrenOf, isSceneSwitch } from '@/data/nodes';
import { SPECIES, speciesById, type PlantParams, type Species } from '@/data/species';
import { rng } from '@/data/core';
import { JOURNEYS } from '@/data/molecules';

export type ViewLayer = 'normal' | 'cutaway' | 'xray' | 'transparent' | 'exploded';
export type Quality = 'ultra' | 'high' | 'balanced' | 'performance' | 'accessibility';
export type Representation = 'ballstick' | 'spacefill' | 'wire' | 'surface';
export type Dialog = null | 'builder' | 'compare' | 'settings' | 'help' | 'chemistry' | 'journeys' | 'tissues' | 'cells' | 'pathways' | 'bookmarks' | 'history' | 'provenance';
export type AppMode = 'observe' | 'experiment' | 'education';

export interface Bookmark { id: string; name: string; path: string[]; speciesId: string; camera?: number[]; created: number; }
export interface Measurement { id: string; a: [number, number, number]; b: [number, number, number]; meters: number; label: string; scene: string; }
export interface CameraRequest { type: 'reset' | 'focus' | 'restore'; partId?: string; camera?: number[]; nonce: number }

const LS = 'plantscape.v1.';
const load = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(LS + k); return v ? (JSON.parse(v) as T) : d; } catch { return d; } };
const save = (k: string, v: unknown) => { try { localStorage.setItem(LS + k, JSON.stringify(v)); } catch { /* ignore */ } };

export interface SavedSpecies { id: string; common: string; params: PlantParams; created: number }

interface State {
  speciesId: string; savedSpecies: SavedSpecies[]; paramOverrides: Partial<PlantParams>;
  growth: number; growthMode: boolean;
  path: string[]; selectedId: string | null; hoveredId: string | null;
  past: string[][]; future: string[][];
  viewLayer: ViewLayer; explode: number; focusMode: boolean;
  clip: { enabled: boolean; angle: number; tilt: number; offset: number };
  transport: boolean; photosynthesis: boolean; gasExchange: boolean; living: boolean; nutrients: boolean;
  lightAngle: number; lightIntensity: number; stomaAperture: number;
  measureActive: boolean; measurePoints: [number, number, number][]; measurements: Measurement[];
  compareA: string | null; compareB: string | null;
  representation: Representation; show2D: boolean; showHydrogens: boolean; colorBy: 'element' | 'chain' | 'residue'; proteinMode: 'atoms' | 'backbone'; dnaMode: 'ideal' | 'crystal';
  electron: { threshold: number; opacity: number; orbital: boolean };
  bookmarks: Bookmark[]; notes: Record<string, string>;
  quality: Quality; reducedMotion: boolean; highContrast: boolean; largeLabels: boolean; showLabels: boolean;
  presentation: boolean; mode: AppMode; leftOpen: boolean; rightOpen: boolean; dialog: Dialog; leftTab: 'tree' | 'library' | 'builder';
  journey: { id: string; step: number; playing: boolean } | null;
  transition: { label: string; sub: string; nonce: number } | null;
  cameraRequest: CameraRequest | null; cameraState: number[] | null;
  fovMeters: number; loading: string | null; toast: string | null; sceneNonce: number;
  zoomHint: null | { dir: 'in' | 'out'; progress: number };
  // actions
  setSpecies: (id: string) => void; setParams: (p: Partial<PlantParams>) => void; randomize: () => void; resetParams: () => void; saveSpecies: (name: string) => void; deleteSavedSpecies: (id: string) => void;
  setGrowth: (g: number) => void; set: (p: Partial<State>) => void;
  navigate: (id: string, opts?: { record?: boolean; select?: boolean }) => void; descend: () => void; ascend: () => void; back: () => void; forward: () => void; jumpLevel: (level: number) => void;
  select: (id: string | null) => void; hover: (id: string | null) => void;
  addMeasurePoint: (p: [number, number, number], metersPerUnit: number, sceneId: string) => void; clearMeasure: () => void;
  addBookmark: (name?: string) => void; removeBookmark: (id: string) => void; gotoBookmark: (b: Bookmark) => void; setNote: (id: string, text: string) => void;
  startJourney: (id: string) => void; journeyStep: (d: number) => void; stopJourney: () => void;
  requestCamera: (r: Omit<CameraRequest, 'nonce'>) => void; showToast: (t: string) => void;
}

export const useStore = create<State>((set, get) => ({
  speciesId: load('species', 'sunflower'), savedSpecies: load('savedSpecies', []), paramOverrides: load('params.' + load('species', 'sunflower'), {}),
  growth: 1, growthMode: false,
  path: ['plant'], selectedId: null, hoveredId: null, past: [], future: [],
  viewLayer: 'normal', explode: 0, focusMode: false,
  clip: { enabled: false, angle: 0, tilt: 0, offset: 0 },
  transport: false, photosynthesis: false, gasExchange: false, living: true, nutrients: false, lightAngle: 50, lightIntensity: 1, stomaAperture: 0.7,
  measureActive: false, measurePoints: [], measurements: [],
  compareA: null, compareB: null,
  representation: 'ballstick', show2D: false, showHydrogens: true, colorBy: 'element', proteinMode: 'atoms', dnaMode: 'ideal',
  electron: { threshold: 0.5, opacity: 0.5, orbital: false },
  bookmarks: load('bookmarks', []), notes: load('notes', {}),
  quality: load('quality', 'high'), reducedMotion: load('reducedMotion', typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches), highContrast: load('highContrast', false), largeLabels: load('largeLabels', false), showLabels: true,
  presentation: false, mode: 'observe', leftOpen: typeof window !== 'undefined' ? window.innerWidth > 900 : true, rightOpen: typeof window !== 'undefined' ? window.innerWidth > 1200 : true, dialog: null, leftTab: 'tree',
  journey: null, transition: null, cameraRequest: null, cameraState: null, fovMeters: 2, loading: null, toast: null, sceneNonce: 0, zoomHint: null,

  set: (p) => { set(p); for (const k of ['quality', 'reducedMotion', 'highContrast', 'largeLabels'] as const) if (k in p) save(k, (p as Record<string, unknown>)[k]); },
  setSpecies: (id) => {
    const saved = get().savedSpecies.find((s) => s.id === id);
    if (saved) { save('species', 'custom'); save('params.custom', saved.params); set({ speciesId: 'custom', paramOverrides: saved.params, path: ['plant'], selectedId: null, sceneNonce: get().sceneNonce + 1, transition: { label: saved.common, sub: 'saved procedural plant', nonce: Date.now() } }); get().requestCamera({ type: 'reset' }); return; }
    save('species', id);
    set({ speciesId: id, paramOverrides: load('params.' + id, {}), path: ['plant'], selectedId: null, sceneNonce: get().sceneNonce + 1, transition: { label: speciesById(id).common, sub: speciesById(id).scientific, nonce: Date.now() } });
    get().requestCamera({ type: 'reset' });
  },
  setParams: (p) => { const next = { ...get().paramOverrides, ...p }; save('params.' + get().speciesId, next); set({ paramOverrides: next }); },
  resetParams: () => { save('params.' + get().speciesId, {}); set({ paramOverrides: {} }); },
  randomize: () => {
    const seed = Math.floor(Math.random() * 1e6); const r = rng(seed); const base = speciesById(get().speciesId).params;
    get().setParams({ seed, height: +(base.height * (0.6 + r() * 0.9)).toFixed(2), stemThickness: +(base.stemThickness * (0.6 + r() * 0.9)).toFixed(4), branchCount: Math.round(base.branchCount * (0.5 + r())), leafCount: Math.round(Math.max(4, base.leafCount * (0.5 + r()))), leafSize: +(base.leafSize * (0.7 + r() * 0.7)).toFixed(3), leafAngle: Math.round(25 + r() * 50), rootSpread: +(base.rootSpread * (0.6 + r() * 0.9)).toFixed(2), flowerCount: Math.round(base.flowerCount * (0.5 + r())), fruitCount: Math.round(base.fruitCount * (0.4 + r() * 1.2)) });
  },
  saveSpecies: (name) => { const s: SavedSpecies = { id: 'saved-' + Date.now(), common: name || 'My plant', params: { ...speciesById(get().speciesId).params, ...get().paramOverrides }, created: Date.now() }; const list = [...get().savedSpecies, s]; save('savedSpecies', list); set({ savedSpecies: list }); get().showToast(`Saved "${s.common}"`); },
  deleteSavedSpecies: (id) => { const list = get().savedSpecies.filter((s) => s.id !== id); save('savedSpecies', list); set({ savedSpecies: list }); },
  setGrowth: (g) => set({ growth: Math.min(1, Math.max(0, g)) }),

  navigate: (id, opts = {}) => {
    const { record = true, select: sel = true } = opts;
    const node = NODE_MAP[id]; if (!node) return;
    const st = get(); const cur = NODE_MAP[st.path[st.path.length - 1]];
    let path: string[];
    const idx = st.path.indexOf(id);
    if (idx >= 0) path = st.path.slice(0, idx + 1);
    else if (cur && cur.children.includes(id)) path = [...st.path, id];
    else path = canonicalPath(id);
    const switching = isSceneSwitch(cur, node);
    const patch: Partial<State> = { path, selectedId: sel ? id : st.selectedId, measurePoints: [], journey: st.journey && !opts.record ? st.journey : st.journey };
    if (record && path.join('/') !== st.path.join('/')) { patch.past = [...st.past.slice(-60), st.path]; patch.future = []; }
    if (switching) { patch.sceneNonce = st.sceneNonce + 1; patch.transition = { label: node.name, sub: `${['WHOLE PLANT', 'ORGAN', 'TISSUE', 'CELL', 'ORGANELLE', 'MACROMOLECULE', 'MOLECULE', 'ATOM'][node.level] ?? ''} · ≈ ${fmt(node.scaleM)}`, nonce: Date.now() }; patch.explode = 0; }
    set(patch);
    get().requestCamera(switching ? { type: 'reset' } : { type: 'focus', partId: `${node.focusPart ?? node.id}|${node.id}` });
  },
  descend: () => {
    const st = get(); const cur = NODE_MAP[st.path[st.path.length - 1]]; if (!cur) return;
    const sp = speciesById(st.speciesId);
    const kids = childrenOf(cur.id, sp);
    let target: string | undefined;
    if (st.selectedId && st.selectedId !== cur.id && kids.some((k) => k.id === st.selectedId)) target = st.selectedId;
    else if (st.selectedId && NODE_MAP[st.selectedId] && cur.children.includes(st.selectedId)) target = st.selectedId;
    if (!target) target = cur.enterChild && kids.some((k) => k.id === cur.enterChild) ? cur.enterChild : kids.find((k) => isSceneSwitch(cur, k))?.id ?? kids[0]?.id;
    if (target) get().navigate(target); else get().showToast('Deepest level of this branch reached.');
  },
  ascend: () => { const p = get().path; if (p.length > 1) get().navigate(p[p.length - 2]); },
  back: () => { const st = get(); if (!st.past.length) return; const prev = st.past[st.past.length - 1]; set({ past: st.past.slice(0, -1), future: [st.path, ...st.future] }); get().navigate(prev[prev.length - 1], { record: false }); set({ path: prev }); },
  forward: () => { const st = get(); if (!st.future.length) return; const next = st.future[0]; set({ future: st.future.slice(1), past: [...st.past, st.path] }); get().navigate(next[next.length - 1], { record: false }); set({ path: next }); },
  jumpLevel: (level) => {
    const st = get(); const sp = speciesById(st.speciesId);
    const inPath = [...st.path].reverse().find((id) => NODE_MAP[id]?.level === level);
    if (inPath) return get().navigate(inPath);
    // walk down from current along enterChild to reach the level
    let cur = NODE_MAP[st.path[st.path.length - 1]]; let guard = 0;
    while (cur && cur.level < level && guard++ < 12) {
      const kids = childrenOf(cur.id, sp);
      const nxt = (cur.enterChild && kids.find((k) => k.id === cur.enterChild)) || kids.find((k) => k.level > cur!.level) || kids[0];
      if (!nxt) break; cur = nxt;
    }
    if (cur) get().navigate(cur.id);
  },
  select: (id) => set({ selectedId: id }),
  hover: (id) => set({ hoveredId: id }),
  addMeasurePoint: (p, metersPerUnit, sceneId) => {
    const pts = [...get().measurePoints, p];
    if (pts.length >= 2) {
      const [a, b] = pts; const d = Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]) * metersPerUnit;
      const m: Measurement = { id: 'm' + Date.now(), a, b, meters: d, label: fmt(d), scene: sceneId };
      set({ measurePoints: [], measurements: [...get().measurements.slice(-9), m] });
    } else set({ measurePoints: pts });
  },
  clearMeasure: () => set({ measurePoints: [], measurements: [] }),
  addBookmark: (name) => { const st = get(); const node = NODE_MAP[st.path[st.path.length - 1]]; const b: Bookmark = { id: 'b' + Date.now(), name: name || `${speciesById(st.speciesId).common} → ${node.name}`, path: st.path, speciesId: st.speciesId, camera: st.cameraState ?? undefined, created: Date.now() }; const list = [...st.bookmarks, b]; save('bookmarks', list); set({ bookmarks: list }); get().showToast('Bookmark saved'); },
  removeBookmark: (id) => { const list = get().bookmarks.filter((b) => b.id !== id); save('bookmarks', list); set({ bookmarks: list }); },
  gotoBookmark: (b) => { if (b.speciesId !== get().speciesId) get().setSpecies(b.speciesId); get().navigate(b.path[b.path.length - 1]); set({ path: b.path }); if (b.camera) setTimeout(() => get().requestCamera({ type: 'restore', camera: b.camera }), 50); },
  setNote: (id, text) => { const notes = { ...get().notes, [id]: text }; if (!text) delete notes[id]; save('notes', notes); set({ notes }); },
  startJourney: (id) => { const j = JOURNEYS.find((x) => x.id === id); if (!j) return; set({ journey: { id, step: 0, playing: true }, dialog: null }); get().navigate(j.steps[0].node); },
  journeyStep: (d) => { const st = get(); if (!st.journey) return; const j = JOURNEYS.find((x) => x.id === st.journey!.id)!; const step = st.journey.step + d; if (step < 0 || step >= j.steps.length) { set({ journey: null }); return; } set({ journey: { ...st.journey, step } }); get().navigate(j.steps[step].node); },
  stopJourney: () => set({ journey: null }),
  requestCamera: (r) => set({ cameraRequest: { ...r, nonce: Date.now() + Math.random() } }),
  showToast: (t) => { set({ toast: t }); setTimeout(() => { if (get().toast === t) set({ toast: null }); }, 2600); },
}));

function fmt(m: number) {
  const u: [number, string][] = [[1, 'm'], [1e-2, 'cm'], [1e-3, 'mm'], [1e-6, 'µm'], [1e-9, 'nm'], [1e-10, 'Å']];
  for (const [f, s] of u) { const v = m / f; if (v >= 1) return `${v >= 10 ? v.toFixed(0) : v.toFixed(1)} ${s}`; }
  return `${(m / 1e-10).toFixed(2)} Å`;
}

// selectors
export const useCurrentNode = () => useStore((s) => NODE_MAP[s.path[s.path.length - 1]]);
export const useSpecies = (): Species => useStore((s) => speciesById(s.speciesId));
export const useParams = (): PlantParams => { const sp = useSpecies(); const ov = useStore((s) => s.paramOverrides); return { ...sp.params, ...ov }; };
export const allSpeciesOptions = () => SPECIES;

export const QUALITY_PRESETS: Record<Quality, { dpr: [number, number]; shadows: boolean; segments: number; particles: number; instances: number; postfx: boolean; maxAtoms: number }> = {
  ultra: { dpr: [1, 2], shadows: true, segments: 32, particles: 1.5, instances: 1.5, postfx: true, maxAtoms: 80000 },
  high: { dpr: [1, 1.75], shadows: true, segments: 24, particles: 1, instances: 1, postfx: true, maxAtoms: 60000 },
  balanced: { dpr: [1, 1.25], shadows: false, segments: 16, particles: 0.6, instances: 0.7, postfx: false, maxAtoms: 40000 },
  performance: { dpr: [0.75, 1], shadows: false, segments: 10, particles: 0.3, instances: 0.4, postfx: false, maxAtoms: 20000 },
  accessibility: { dpr: [1, 1.25], shadows: false, segments: 16, particles: 0.2, instances: 0.6, postfx: false, maxAtoms: 30000 },
};
