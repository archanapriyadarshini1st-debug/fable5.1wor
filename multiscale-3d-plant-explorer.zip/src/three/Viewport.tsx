import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html, Line } from '@react-three/drei';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import { SceneCtx, partRegistry, type SceneInfo } from './core';
import PlantScene from './PlantScene';
import { RootScene, StemScene, LeafScene, StomaScene, FlowerScene, SeedScene, FruitScene, TissueScene } from './OrganScenes';
import { CellScene, ChloroplastScene, ThylakoidScene, MitochondrionScene, NucleusScene, MembraneScene, WallScene } from './CellScenes';
import { MoleculeScene, ProteinScene, DNAScene, RNAScene, AtomScene } from './MolecularScenes';
import { useStore, useCurrentNode, useParams, QUALITY_PRESETS } from '@/store';
import { proteinById } from '@/data/molecules';
import type { SciNode } from '@/data/core';
import type { PlantParams } from '@/data/species';

export function sceneInfoFor(node: SciNode, params: PlantParams): SceneInfo {
  const base = { id: `${node.scene}:${node.sceneParam ?? ''}` };
  switch (node.scene) {
    case 'plant': return { ...base, metersPerUnit: Math.max(0.3, params.height) / 8, defaultDistance: 15, minDistance: 1.6, maxDistance: 45, target: [0, 3, 0] };
    case 'root': return { ...base, metersPerUnit: 2.5e-4, defaultDistance: 13, minDistance: 1.5, maxDistance: 32 };
    case 'stem': return { ...base, metersPerUnit: Math.max(0.004, params.stemThickness) / 4.4, defaultDistance: 12, minDistance: 1.5, maxDistance: 30 };
    case 'leaf': return { ...base, metersPerUnit: 6.7e-5, defaultDistance: 15, minDistance: 1.6, maxDistance: 34 };
    case 'stoma': return { ...base, metersPerUnit: 5e-6, defaultDistance: 12, minDistance: 1.4, maxDistance: 28 };
    case 'flower': return { ...base, metersPerUnit: 5e-3, defaultDistance: 10, minDistance: 1.2, maxDistance: 26 };
    case 'seed': return { ...base, metersPerUnit: 1e-3, defaultDistance: 10, minDistance: 1.2, maxDistance: 24 };
    case 'fruit': return { ...base, metersPerUnit: 1e-2, defaultDistance: 11, minDistance: 1.2, maxDistance: 26 };
    case 'tissue': return { ...base, metersPerUnit: 4.5e-5, defaultDistance: 15, minDistance: 1.4, maxDistance: 34 };
    case 'cell': return { ...base, metersPerUnit: node.scaleM / 6, defaultDistance: 13, minDistance: 1.3, maxDistance: 30 };
    case 'chloroplast': return { ...base, metersPerUnit: 8.3e-7, defaultDistance: 12, minDistance: 1.3, maxDistance: 28 };
    case 'thylakoid': return { ...base, metersPerUnit: 6.25e-8, defaultDistance: 12, minDistance: 1.2, maxDistance: 28 };
    case 'mitochondrion': return { ...base, metersPerUnit: 2e-7, defaultDistance: 12, minDistance: 1.3, maxDistance: 28 };
    case 'nucleus': return { ...base, metersPerUnit: 8.3e-7, defaultDistance: 12, minDistance: 1.3, maxDistance: 28 };
    case 'membrane': return { ...base, metersPerUnit: 1e-9, defaultDistance: 18, minDistance: 1.5, maxDistance: 40 };
    case 'wall': return { ...base, metersPerUnit: 1e-8, defaultDistance: 15, minDistance: 1.4, maxDistance: 34 };
    case 'molecule': { const r = node.scaleM * 1e10; return { ...base, metersPerUnit: 1e-10, defaultDistance: Math.max(7, r * 1.6 + 3), minDistance: 1.2, maxDistance: Math.max(30, r * 6) }; }
    case 'protein': { const d = proteinById(node.sceneParam ?? ''); const scale = d ? 12 / (d.scaleM * 1e10) : 0.15; return { ...base, metersPerUnit: 1e-10 / scale, defaultDistance: 34, minDistance: 3, maxDistance: 110 }; }
    case 'dna': return { ...base, metersPerUnit: 1e-10, defaultDistance: 120, minDistance: 6, maxDistance: 320 };
    case 'rna': return { ...base, metersPerUnit: 1e-10, defaultDistance: 80, minDistance: 5, maxDistance: 240 };
    case 'atom': return { ...base, metersPerUnit: 1e-10, defaultDistance: 6, minDistance: 0.7, maxDistance: 18 };
  }
}

function SceneContent({ node }: { node: SciNode }) {
  const p = node.sceneParam ?? '';
  switch (node.scene) {
    case 'plant': return <PlantScene />;
    case 'root': return <RootScene />;
    case 'stem': return <StemScene />;
    case 'leaf': return <LeafScene />;
    case 'stoma': return <StomaScene />;
    case 'flower': return <FlowerScene />;
    case 'seed': return <SeedScene />;
    case 'fruit': return <FruitScene />;
    case 'tissue': return <TissueScene kind={p} />;
    case 'cell': return <CellScene type={p || 'parenchyma'} />;
    case 'chloroplast': return <ChloroplastScene />;
    case 'thylakoid': return <ThylakoidScene />;
    case 'mitochondrion': return <MitochondrionScene />;
    case 'nucleus': return <NucleusScene />;
    case 'membrane': return <MembraneScene />;
    case 'wall': return <WallScene />;
    case 'molecule': return <MoleculeScene id={p} />;
    case 'protein': return <ProteinScene id={p} />;
    case 'dna': return <DNAScene />;
    case 'rna': return <RNAScene kind={p} />;
    case 'atom': return <AtomScene el={p} />;
  }
}

function Reveal({ children, nonce }: { children: React.ReactNode; nonce: number }) {
  const ref = useRef<THREE.Group>(null!); const t = useRef(0); const reduced = useStore((s) => s.reducedMotion);
  useEffect(() => { t.current = 0; }, [nonce]);
  useFrame((_, dt) => { if (!ref.current) return; if (reduced) { ref.current.scale.setScalar(1); return; } t.current = Math.min(1, t.current + dt * 1.4); const e = 1 - Math.pow(1 - t.current, 3); ref.current.scale.setScalar(0.92 + 0.08 * e); });
  return <group ref={ref}>{children}</group>;
}

const DIR = new THREE.Vector3(0.45, 0.32, 1).normalize();
function CameraRig({ info, nonce }: { info: SceneInfo; nonce: number }) {
  const controls = useRef<OrbitControlsImpl>(null!);
  const { camera, gl } = useThree();
  const req = useStore((s) => s.cameraRequest); const reduced = useStore((s) => s.reducedMotion);
  const anim = useRef<{ p0: THREE.Vector3; p1: THREE.Vector3; t0: THREE.Vector3; t1: THREE.Vector3; t: number; dur: number } | null>(null);
  const pending = useRef<{ ids: string[]; tries: number } | null>(null);
  const wheel = useRef(0); const cooldown = useRef(0); const frame = useRef(0);
  const target = useMemo(() => new THREE.Vector3(...(info.target ?? [0, 0, 0])), [info]);

  const goto = (p1: THREE.Vector3, t1: THREE.Vector3, dur = 1.1) => {
    if (reduced) { camera.position.copy(p1); controls.current.target.copy(t1); controls.current.update(); return; }
    anim.current = { p0: camera.position.clone(), p1, t0: controls.current.target.clone(), t1, t: 0, dur };
  };
  // scene entered → reset camera
  useEffect(() => { const p = target.clone().addScaledVector(DIR, info.defaultDistance); if (nonce === 0) { camera.position.copy(p); controls.current?.target.copy(target); controls.current?.update(); } else { camera.position.copy(target.clone().addScaledVector(DIR, info.maxDistance * 0.9)); goto(p, target.clone(), 1.3); } }, [nonce]); // eslint-disable-line
  useEffect(() => {
    if (!req) return;
    if (req.type === 'reset') { const p = target.clone().addScaledVector(DIR, info.defaultDistance); goto(p, target.clone()); }
    else if (req.type === 'focus' && req.partId) pending.current = { ids: req.partId.split('|'), tries: 40 };
    else if (req.type === 'restore' && req.camera) { const c = req.camera; goto(new THREE.Vector3(c[0], c[1], c[2]), new THREE.Vector3(c[3], c[4], c[5])); }
  }, [req]); // eslint-disable-line
  useEffect(() => {
    const el = gl.domElement;
    const onWheel = (e: WheelEvent) => { wheel.current += e.deltaY < 0 ? Math.min(120, -e.deltaY) : -Math.min(120, e.deltaY); wheel.current = Math.max(-900, Math.min(900, wheel.current)); };
    el.addEventListener('wheel', onWheel, { passive: true });
    return () => el.removeEventListener('wheel', onWheel);
  }, [gl]);

  useFrame((_, dt) => {
    const c = controls.current; if (!c) return;
    if (pending.current) {
      const reg = pending.current.ids.map((k) => partRegistry.get(k)).find(Boolean);
      if (reg) { const dist = Math.min(info.maxDistance * 0.9, Math.max(info.minDistance * 1.15, reg.radius * 3.2)); const dir = camera.position.clone().sub(c.target).normalize(); if (dir.length() < 0.1) dir.copy(DIR); goto(reg.pos.clone().addScaledVector(dir, dist), reg.pos.clone()); pending.current = null; }
      else if (--pending.current.tries <= 0) pending.current = null;
    }
    if (anim.current) {
      const a = anim.current; a.t = Math.min(1, a.t + dt / a.dur); const e = a.t < 0.5 ? 4 * a.t ** 3 : 1 - Math.pow(-2 * a.t + 2, 3) / 2;
      camera.position.lerpVectors(a.p0, a.p1, e); c.target.lerpVectors(a.t0, a.t1, e); c.update();
      if (a.t >= 1) anim.current = null;
    }
    // multiscale zoom-through
    const dist = camera.position.distanceTo(c.target);
    cooldown.current = Math.max(0, cooldown.current - dt);
    wheel.current *= Math.pow(0.15, dt);
    const st = useStore.getState();
    const atMin = dist <= info.minDistance * 1.06; const atMax = dist >= info.maxDistance * 0.96;
    if (cooldown.current <= 0 && !anim.current) {
      if (atMin && wheel.current > 50) { const prog = Math.min(1, wheel.current / 420); if (!st.zoomHint || Math.abs(st.zoomHint.progress - prog) > 0.05) st.set({ zoomHint: { dir: 'in', progress: prog } }); if (prog >= 1) { wheel.current = 0; cooldown.current = 1.8; st.set({ zoomHint: null }); st.descend(); } }
      else if (atMax && wheel.current < -50 && st.path.length > 1) { const prog = Math.min(1, -wheel.current / 420); if (!st.zoomHint || Math.abs(st.zoomHint.progress - prog) > 0.05) st.set({ zoomHint: { dir: 'out', progress: prog } }); if (prog >= 1) { wheel.current = 0; cooldown.current = 1.8; st.set({ zoomHint: null }); st.ascend(); } }
      else if (st.zoomHint) st.set({ zoomHint: null });
    }
    if (++frame.current % 12 === 0) {
      const fovH = 2 * dist * Math.tan(((camera as THREE.PerspectiveCamera).fov * Math.PI) / 360) * info.metersPerUnit;
      if (Math.abs(fovH - st.fovMeters) / Math.max(1e-30, st.fovMeters) > 0.02) st.set({ fovMeters: fovH });
    }
  });
  return <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={0.08} minDistance={info.minDistance} maxDistance={info.maxDistance} enablePan zoomSpeed={0.8} rotateSpeed={0.7} touches={{ ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }}
    onEnd={() => { const c = controls.current; useStore.getState().set({ cameraState: [camera.position.x, camera.position.y, camera.position.z, c.target.x, c.target.y, c.target.z] }); }} />;
}

function Clipping({ info }: { info: SceneInfo }) {
  const { gl } = useThree(); const clip = useStore((s) => s.clip);
  useEffect(() => {
    gl.localClippingEnabled = true;
    if (!clip.enabled) { gl.clippingPlanes = []; return; }
    const n = new THREE.Vector3(Math.sin((clip.angle * Math.PI) / 180) * Math.cos((clip.tilt * Math.PI) / 180), Math.sin((clip.tilt * Math.PI) / 180), Math.cos((clip.angle * Math.PI) / 180) * Math.cos((clip.tilt * Math.PI) / 180));
    gl.clippingPlanes = [new THREE.Plane(n.negate(), clip.offset * info.defaultDistance * 0.5)];
    return () => { gl.clippingPlanes = []; };
  }, [clip, gl, info]);
  return null;
}

function Lights({ info }: { info: SceneInfo }) {
  const angle = useStore((s) => s.lightAngle); const intensity = useStore((s) => s.lightIntensity); const q = QUALITY_PRESETS[useStore((s) => s.quality)];
  const living = useStore((s) => s.living); const reduced = useStore((s) => s.reducedMotion);
  const sun = useRef<THREE.DirectionalLight>(null!);
  const d = info.defaultDistance;
  useFrame(({ clock }) => { if (!sun.current) return; const a = ((angle + (living && !reduced ? Math.sin(clock.elapsedTime * 0.05) * 6 : 0)) * Math.PI) / 180; sun.current.position.set(Math.cos(a) * d * 2, Math.max(0.15, Math.sin(a)) * d * 2, d * 0.8); const warm = 1 - Math.max(0, Math.sin(a)); sun.current.color.setRGB(1, 0.95 - warm * 0.25, 0.85 - warm * 0.45); });
  return (
    <>
      <hemisphereLight args={['#dfe9ff', '#3a3326', 0.55 * intensity]} />
      <directionalLight ref={sun} intensity={1.6 * intensity} castShadow={q.shadows} shadow-mapSize={[2048, 2048]} shadow-camera-near={0.1} shadow-camera-far={d * 6} shadow-camera-left={-d} shadow-camera-right={d} shadow-camera-top={d} shadow-camera-bottom={-d} shadow-bias={-0.0005} />
      <directionalLight position={[-d, d * 0.3, -d]} intensity={0.35 * intensity} color="#a8c4ff" />
      <pointLight position={[0, d * 0.5, d * 0.6]} intensity={0.3 * intensity * d} distance={d * 4} decay={2} />
    </>
  );
}

function Measurements() {
  const pts = useStore((s) => s.measurePoints); const ms = useStore((s) => s.measurements); const info = useSceneInfoCtx();
  const cur = ms.filter((m) => m.scene === info.id);
  const r = info.defaultDistance * 0.008;
  return <group>
    {pts.map((p, i) => <mesh key={i} position={p}><sphereGeometry args={[r, 12, 12]} /><meshBasicMaterial color="#ffd166" /></mesh>)}
    {cur.map((m) => <group key={m.id}><Line points={[m.a, m.b]} color="#ffd166" lineWidth={2} dashed dashSize={r * 2} gapSize={r} /><mesh position={m.a}><sphereGeometry args={[r, 10, 10]} /><meshBasicMaterial color="#ffd166" /></mesh><mesh position={m.b}><sphereGeometry args={[r, 10, 10]} /><meshBasicMaterial color="#ffd166" /></mesh>
      <Html position={[(m.a[0] + m.b[0]) / 2, (m.a[1] + m.b[1]) / 2, (m.a[2] + m.b[2]) / 2]} center style={{ pointerEvents: 'none' }}><div className="ps-measure">{m.label}</div></Html></group>)}
  </group>;
}
import { useContext } from 'react';
const useSceneInfoCtx = () => useContext(SceneCtx);

export default function Viewport() {
  const node = useCurrentNode(); const params = useParams(); const nonce = useStore((s) => s.sceneNonce);
  const quality = useStore((s) => s.quality); const q = QUALITY_PRESETS[quality]; const hc = useStore((s) => s.highContrast);
  const info = useMemo(() => sceneInfoFor(node, params), [node, params]);
  const [lost, setLost] = useState(false);
  const bg = hc ? '#000000' : node.level >= 6 ? '#0b1020' : node.level >= 3 ? '#0e1a14' : '#111a13';
  return (
    <div className="absolute inset-0" aria-label={`3D view: ${node.name}`} role="img">
      <Canvas shadows={q.shadows} dpr={q.dpr} camera={{ fov: 42, near: 0.02, far: 2000, position: [0, 4, 15] }} gl={{ antialias: true, powerPreference: 'high-performance', alpha: false, logarithmicDepthBuffer: true }}
        onCreated={({ gl }) => { gl.setClearColor(bg); gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.05; gl.domElement.addEventListener('webglcontextlost', (e) => { e.preventDefault(); setLost(true); }); }}
        onPointerMissed={() => { if (!useStore.getState().measureActive) useStore.getState().select(null); }}>
        <color attach="background" args={[bg]} />
        <fog attach="fog" args={[bg, info.defaultDistance * 1.6, info.maxDistance * 2.2]} />
        <SceneCtx.Provider value={info}>
          <Lights info={info} />
          <Clipping info={info} />
          <CameraRig info={info} nonce={nonce} />
          <Suspense fallback={<Html center><div className="ps-loading">Building scene…</div></Html>}>
            <Reveal nonce={nonce}><group key={nonce}><SceneContent node={node} /></group></Reveal>
          </Suspense>
          <Measurements />
        </SceneCtx.Provider>
      </Canvas>
      {lost && <div className="absolute inset-0 flex items-center justify-center bg-black/80 text-white text-sm p-6 text-center">WebGL context lost. Lower the quality preset and reload the page.<button className="ml-3 underline" onClick={() => location.reload()}>Reload</button></div>}
    </div>
  );
}
