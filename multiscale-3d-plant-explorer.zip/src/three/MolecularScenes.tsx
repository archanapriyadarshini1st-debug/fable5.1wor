import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { create } from 'zustand';
import { Html, Line } from '@react-three/drei';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { Tag, Label, useQuality, registerPart, useSceneInfo } from './core';
import { useStore } from '@/store';
import { elementOf, rng } from '@/data/core';
import { loadMolecule, loadProtein, perceiveBonds, type Structure, type Atom } from '@/lib/loaders';
import { moleculeById, proteinById } from '@/data/molecules';

// ─── molecular UI state shared with the inspector ────────────────────────────
export interface PickedAtom { index: number; el: string; pos: [number, number, number]; neighbors: { el: string; dist: number; order: number }[]; res?: string; chain?: string; resSeq?: number }
interface MolState { picked: PickedAtom | null; structure: Structure | null; loading: boolean; setPicked: (p: PickedAtom | null) => void; setStructure: (s: Structure | null, loading?: boolean) => void }
export const useMolStore = create<MolState>((set) => ({ picked: null, structure: null, loading: false, setPicked: (picked) => set({ picked }), setStructure: (structure, loading = false) => set({ structure, loading }) }));

const CHAIN_COLORS = ['#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f', '#edc948', '#b07aa1', '#ff9da7', '#9c755f', '#bab0ac', '#86bcb6', '#d37295'];

function useStructure(kind: 'molecule' | 'protein', id: string, publish = true) {
  const [s, setS] = useState<Structure | null>(null);
  useEffect(() => {
    let alive = true;
    if (publish) useMolStore.getState().setStructure(null, true);
    const p = kind === 'molecule' ? loadMolecule(id, (el) => elementOf(el).covalent) : loadProtein(id);
    p.then((st) => { if (!alive) return; setS(st); if (publish) useMolStore.getState().setStructure(st, false); });
    return () => { alive = false; };
  }, [kind, id, publish]);
  return s;
}

// ─── generic instanced structure renderer ────────────────────────────────────
interface RenderProps { structure: Structure; representation: 'ballstick' | 'spacefill' | 'wire' | 'surface' | 'backbone'; partId: string; scale?: number; showH?: boolean; colorBy?: 'element' | 'chain' | 'residue'; center?: boolean; pickable?: boolean; atomLabels?: boolean }
export function StructureRenderer({ structure, representation, partId, scale = 1, showH = true, colorBy = 'element', center = true, pickable = true, atomLabels = false }: RenderProps) {
  const atomsRef = useRef<THREE.InstancedMesh>(null!);
  const bondsRef = useRef<THREE.InstancedMesh>(null!);
  const selectedId = useStore((s) => s.selectedId); const hovered = useStore((s) => s.hoveredId) === partId;
  const focusMode = useStore((s) => s.focusMode); const viewLayer = useStore((s) => s.viewLayer);
  const picked = useMolStore((s) => s.picked);
  const sceneInfo = useSceneInfo(); const measureActive = useStore((s) => s.measureActive);
  const q = useQuality();
  const [c0, c1, c2] = center ? structure.center : [0, 0, 0];

  const atoms = useMemo(() => structure.atoms.map((a, i) => ({ ...a, i })).filter((a) => showH || a.el !== 'H'), [structure, showH]);
  const bonds = useMemo(() => {
    let b = structure.bonds;
    if (!b.length && structure.atoms.length <= 4000 && representation !== 'backbone') b = perceiveBonds(structure.atoms, (el) => elementOf(el).covalent);
    const keep = new Set(atoms.map((a) => a.i));
    return b.filter((x) => keep.has(x.a) && keep.has(x.b));
  }, [structure, atoms, representation]);
  const bondInstances = useMemo(() => {
    if (representation === 'spacefill' || representation === 'backbone') return [] as { a: Atom; b: Atom; off: THREE.Vector3; thin: boolean }[];
    const out: { a: Atom; b: Atom; off: THREE.Vector3; thin: boolean }[] = [];
    const up = new THREE.Vector3(0, 1, 0);
    for (const bd of bonds) {
      const a = structure.atoms[bd.a], b = structure.atoms[bd.b];
      const dir = new THREE.Vector3(b.x - a.x, b.y - a.y, b.z - a.z).normalize();
      const perp = new THREE.Vector3().crossVectors(dir, Math.abs(dir.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : up).normalize();
      const n = bd.order === 2 ? 2 : bd.order === 3 ? 3 : 1;
      if (bd.order === 4) { out.push({ a, b, off: new THREE.Vector3(), thin: false }); out.push({ a, b, off: perp.clone().multiplyScalar(0.2), thin: true }); continue; }
      for (let k = 0; k < n; k++) { const o = n === 1 ? 0 : (k - (n - 1) / 2) * 0.22; out.push({ a, b, off: perp.clone().multiplyScalar(o), thin: n > 1 }); }
    }
    return out;
  }, [bonds, structure, representation]);

  const atomR = (el: string) => { const e = elementOf(el); switch (representation) { case 'spacefill': return e.vdw; case 'surface': return e.vdw * 1.15; case 'wire': return 0.07; default: return e.covalent * 0.32 + 0.08; } };
  const bondR = representation === 'wire' ? 0.05 : 0.11;
  const colorOf = (a: Atom & { i: number }) => {
    if (colorBy === 'chain' && a.chain) return CHAIN_COLORS[(a.chain.charCodeAt(0) - 65 + 26) % CHAIN_COLORS.length];
    if (colorBy === 'residue' && a.res) return a.hetero ? '#ff6ec7' : CHAIN_COLORS[(a.resSeq ?? 0) % CHAIN_COLORS.length];
    return elementOf(a.el).color;
  };

  useEffect(() => {
    const m = new THREE.Matrix4(); const col = new THREE.Color(); const sc = new THREE.Vector3(); const q0 = new THREE.Quaternion();
    if (atomsRef.current) {
      atoms.forEach((a, k) => { const r = atomR(a.el) * scale; sc.set(r, r, r); m.compose(new THREE.Vector3((a.x - c0) * scale, (a.y - c1) * scale, (a.z - c2) * scale), q0, sc); atomsRef.current.setMatrixAt(k, m); col.set(colorOf(a)); if (picked && picked.index === a.i) col.set('#7fe3ff'); atomsRef.current.setColorAt(k, col); });
      atomsRef.current.instanceMatrix.needsUpdate = true; if (atomsRef.current.instanceColor) atomsRef.current.instanceColor.needsUpdate = true;
      atomsRef.current.computeBoundingSphere();
    }
    if (bondsRef.current && bondInstances.length) {
      const up = new THREE.Vector3(0, 1, 0); const qq = new THREE.Quaternion();
      bondInstances.forEach((bd, k) => {
        const a = new THREE.Vector3((bd.a.x - c0) * scale, (bd.a.y - c1) * scale, (bd.a.z - c2) * scale).add(bd.off.clone().multiplyScalar(scale));
        const b = new THREE.Vector3((bd.b.x - c0) * scale, (bd.b.y - c1) * scale, (bd.b.z - c2) * scale).add(bd.off.clone().multiplyScalar(scale));
        const d = b.clone().sub(a); const len = d.length(); qq.setFromUnitVectors(up, d.normalize());
        const r = (bd.thin ? bondR * 0.7 : bondR) * scale;
        m.compose(a.clone().add(b).multiplyScalar(0.5), qq, new THREE.Vector3(r, len, r)); bondsRef.current.setMatrixAt(k, m);
      });
      bondsRef.current.instanceMatrix.needsUpdate = true;
    }
    registerPart(partId, new THREE.Vector3(0, 0, 0), structure.radius * scale);
  }, [atoms, bondInstances, scale, representation, colorBy, picked, c0, c1, c2, partId, structure.radius]);

  const dim = focusMode && selectedId && selectedId !== partId;
  const opacity = representation === 'surface' ? 0.55 : viewLayer === 'xray' ? 0.35 : dim ? 0.15 : 1;
  const onPick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (measureActive) { useStore.getState().addMeasurePoint([e.point.x, e.point.y, e.point.z], sceneInfo.metersPerUnit, sceneInfo.id); return; }
    if (!pickable) { useStore.getState().select(partId); return; }
    const k = e.instanceId ?? 0; const a = atoms[k]; if (!a) return;
    const neighbors = bonds.filter((b) => b.a === a.i || b.b === a.i).map((b) => { const o = structure.atoms[b.a === a.i ? b.b : b.a]; return { el: o.el, dist: Math.hypot(o.x - a.x, o.y - a.y, o.z - a.z), order: b.order }; });
    useMolStore.getState().setPicked({ index: a.i, el: a.el, pos: [(a.x - c0) * scale, (a.y - c1) * scale, (a.z - c2) * scale], neighbors, res: a.res, chain: a.chain, resSeq: a.resSeq });
    useStore.getState().select(`atom-${elementOf(a.el).symbol}`);
  };
  const labelled = atomLabels && atoms.length <= 40 ? atoms.filter((a) => a.el !== 'H' && (atoms.length <= 12 || a.el !== 'C')) : [];
  const seg = q.segments >= 24 ? 16 : q.segments >= 16 ? 12 : 8;
  if (representation === 'backbone') return <Backbone structure={structure} scale={scale} center={center} partId={partId} colorBy={colorBy} />;
  return (
    <group>
      <instancedMesh key={`a${atoms.length}${representation}`} ref={atomsRef} args={[undefined, undefined, Math.max(1, atoms.length)]} onClick={onPick} onDoubleClick={(e) => { e.stopPropagation(); }}
        onPointerOver={(e) => { e.stopPropagation(); useStore.getState().hover(partId); document.body.style.cursor = 'pointer'; }} onPointerOut={() => { useStore.getState().hover(null); document.body.style.cursor = 'auto'; }} frustumCulled={false}>
        <sphereGeometry args={[1, seg, seg]} />
        <meshPhysicalMaterial roughness={0.35} metalness={0.05} transparent={opacity < 1} opacity={opacity} emissive={hovered ? '#ffffff' : '#000000'} emissiveIntensity={hovered ? 0.12 : 0} clearcoat={0.4} depthWrite={opacity > 0.5} />
      </instancedMesh>
      {bondInstances.length > 0 && <instancedMesh key={`b${bondInstances.length}${representation}`} ref={bondsRef} args={[undefined, undefined, bondInstances.length]} onClick={(e) => { e.stopPropagation(); useStore.getState().select(partId); }} frustumCulled={false}>
        <cylinderGeometry args={[1, 1, 1, 10, 1]} />
        <meshPhysicalMaterial color="#9aa3a8" roughness={0.5} transparent={opacity < 1} opacity={opacity} depthWrite={opacity > 0.5} />
      </instancedMesh>}
      {picked && atoms.some((a) => a.i === picked.index) && <group position={picked.pos}><Label text={`${elementOf(picked.el).name} (${picked.el})`} sub={`${picked.neighbors.length} bond${picked.neighbors.length === 1 ? '' : 's'}${picked.res ? ` · ${picked.res} ${picked.chain}${picked.resSeq}` : ''}`} offset={[1.2 * scale + 0.4, 1.2 * scale + 0.4, 0]} selected /></group>}
      {labelled.map((a) => <Html key={a.i} position={[(a.x - c0) * scale, (a.y - c1) * scale + atomR(a.el) * scale + 0.15, (a.z - c2) * scale]} center style={{ pointerEvents: 'none' }}><span className="ps-atom-label">{a.el}</span></Html>)}
    </group>
  );
}

function Backbone({ structure, scale, center, partId, colorBy }: { structure: Structure; scale: number; center: boolean; partId: string; colorBy: string }) {
  const [c0, c1, c2] = center ? structure.center : [0, 0, 0];
  const traces = useMemo(() => {
    const out: { pts: [number, number, number][]; color: string }[] = [];
    let cur: [number, number, number][] = []; let curChain = ''; let last: Atom | null = null;
    const push = () => { if (cur.length > 1) out.push({ pts: cur, color: colorBy === 'element' ? '#7fb2e0' : CHAIN_COLORS[(curChain.charCodeAt(0) - 65 + 26) % CHAIN_COLORS.length] }); cur = []; };
    for (const a of structure.atoms) {
      if (a.hetero) continue;
      if (a.name !== 'CA' && a.name !== 'P') continue;
      if (a.chain !== curChain || (last && Math.hypot(a.x - last.x, a.y - last.y, a.z - last.z) > 8)) { push(); curChain = a.chain ?? ''; }
      cur.push([(a.x - c0) * scale, (a.y - c1) * scale, (a.z - c2) * scale]); last = a;
    }
    push();
    return out;
  }, [structure, scale, c0, c1, c2, colorBy]);
  const ligands = useMemo(() => structure.atoms.filter((a) => a.hetero && a.el !== 'H'), [structure]);
  const ref = useRef<THREE.InstancedMesh>(null!);
  useEffect(() => { if (!ref.current || !ligands.length) return; const m = new THREE.Matrix4(); const c = new THREE.Color(); ligands.forEach((a, k) => { m.makeTranslation((a.x - c0) * scale, (a.y - c1) * scale, (a.z - c2) * scale); m.scale(new THREE.Vector3(0.6 * scale, 0.6 * scale, 0.6 * scale)); ref.current.setMatrixAt(k, m); c.set(elementOf(a.el).color); ref.current.setColorAt(k, c); }); ref.current.instanceMatrix.needsUpdate = true; if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true; }, [ligands, scale, c0, c1, c2]);
  return (
    <group onClick={(e) => { e.stopPropagation(); useStore.getState().select(partId); }}>
      {traces.map((t, i) => <Line key={i} points={t.pts} color={t.color} lineWidth={2.5} />)}
      {ligands.length > 0 && <instancedMesh ref={ref} args={[undefined, undefined, ligands.length]} frustumCulled={false}><sphereGeometry args={[1, 8, 8]} /><meshStandardMaterial roughness={0.4} /></instancedMesh>}
    </group>
  );
}

// ─── Protein renderer usable inside other scenes ─────────────────────────────
export function ProteinRenderer({ id, scale, position, rotation, partId, forceMode, publish = false }: { id: string; scale: number; position?: [number, number, number]; rotation?: [number, number, number]; partId: string; forceMode?: 'atoms' | 'backbone'; publish?: boolean }) {
  const s = useStructure('protein', id, publish);
  const q = useQuality(); const proteinMode = useStore((st) => st.proteinMode); const colorBy = useStore((st) => st.colorBy); const rep = useStore((st) => st.representation);
  const def = proteinById(id);
  if (!s) return <group position={position ?? [0, 0, 0]}><mesh><sphereGeometry args={[Math.max(1, (def?.scaleM ?? 5e-9) * 1e10 * scale * 0.5), 16, 12]} /><meshStandardMaterial color="#4a8ad0" wireframe transparent opacity={0.4} /></mesh><Html center><div className="ps-loading">Loading PDB {def?.pdb}…</div></Html></group>;
  if (s.status === 'unavailable') return <group position={position ?? [0, 0, 0]}><mesh><sphereGeometry args={[Math.max(1, (def?.scaleM ?? 5e-9) * 1e10 * scale * 0.5), 16, 12]} /><meshStandardMaterial color="#666" wireframe transparent opacity={0.4} /></mesh><Tag position={[0, 0, 0]} text="STRUCTURE NOT AVAILABLE" sub={s.message} offset={[1, 1, 0]} /></group>;
  const tooMany = s.atoms.length > q.maxAtoms;
  const mode = forceMode ?? (tooMany || proteinMode === 'backbone' ? 'backbone' : 'atoms');
  const gp: Record<string, unknown> = {}; if (position) gp.position = position; if (rotation) gp.rotation = rotation;
  return <group {...gp}><StructureRenderer structure={s} representation={mode === 'backbone' ? 'backbone' : rep === 'ballstick' && s.atoms.length > 6000 ? 'spacefill' : rep === 'wire' ? 'wire' : rep === 'surface' ? 'surface' : rep === 'ballstick' ? 'ballstick' : 'spacefill'} partId={partId} scale={scale} colorBy={colorBy === 'element' && s.atoms.length > 3000 ? 'chain' : colorBy} showH={false} pickable /></group>;
}

// ─── MOLECULE SCENE ──────────────────────────────────────────────────────────
export function MoleculeScene({ id }: { id: string }) {
  const s = useStructure('molecule', id);
  const rep = useStore((st) => st.representation); const showH = useStore((st) => st.showHydrogens);
  const def = moleculeById(id);
  const spin = useRef<THREE.Group>(null!); const living = useStore((st) => st.living); const reduced = useStore((st) => st.reducedMotion);
  useFrame((_, dt) => { if (spin.current && living && !reduced) spin.current.rotation.y += dt * 0.08; });
  useEffect(() => () => useMolStore.getState().setPicked(null), [id]);
  if (!s) return <Html center><div className="ps-loading">Retrieving {def?.name ?? id} from {def?.hard ? 'experimental geometry table' : def?.pdbLigand ? 'RCSB PDB' : 'PubChem'}…</div></Html>;
  if (s.status === 'unavailable') return <group><mesh><icosahedronGeometry args={[1.5, 1]} /><meshStandardMaterial color="#555" wireframe /></mesh><Tag position={[0, 0, 0]} text="3D STRUCTURE NOT AVAILABLE" sub={s.message} offset={[1.5, 1.5, 0]} /></group>;
  return (
    <group ref={spin}>
      <StructureRenderer structure={s} representation={rep} partId={id} showH={showH} atomLabels />
      <Tag position={[-s.radius - 1, s.radius + 0.8, 0]} text={`${def?.name ?? id} · ${def?.formula ?? ''}`} sub={`${s.atoms.length} atoms${showH ? '' : ' (H hidden)'} · ${s.bonds.length || 'perceived'} bonds · ${s.source.name}${s.source.id ? ' ' + s.source.id : ''}`} offset={[-0.4, 0.6, 0]} />
      {rep === 'surface' && <Tag position={[s.radius + 0.5, -s.radius - 0.5, 0]} text="APPROXIMATE SURFACE" sub="inflated van der Waals spheres — not a computed solvent-accessible or electron-density surface" offset={[0.5, -0.5, 0]} />}
    </group>
  );
}

// ─── PROTEIN SCENE ───────────────────────────────────────────────────────────
export function ProteinScene({ id }: { id: string }) {
  const def = proteinById(id);
  const scale = def ? 12 / (def.scaleM * 1e10) : 0.15;
  const spin = useRef<THREE.Group>(null!); const living = useStore((st) => st.living); const reduced = useStore((st) => st.reducedMotion);
  useFrame((_, dt) => { if (spin.current && living && !reduced) spin.current.rotation.y += dt * 0.05; });
  const st = useMolStore((s) => s.structure);
  useEffect(() => () => useMolStore.getState().setPicked(null), [id]);
  return (
    <group ref={spin}>
      <ProteinRenderer id={id} scale={scale} partId={id} publish />
      {def && <Tag position={[-13, 13, 0]} text={`${def.name} — PDB ${def.pdb}`} sub={`${def.organism} · ${def.method} ${def.resolution}${st ? ` · ${st.atoms.length.toLocaleString()} atoms · ${st.chains?.length ?? 0} chains` : ''}`} offset={[-0.4, 0.8, 0]} />}
      {def?.note && <Tag position={[0, -13, 0]} text={def.note} offset={[0.5, -0.6, 0]} />}
      {st && st.ligandResidues && Object.keys(st.ligandResidues).length > 0 && <Tag position={[13, -12, 0]} text="Bound cofactors / ligands" sub={Object.entries(st.ligandResidues).slice(0, 8).map(([k, v]) => `${k}×${v}`).join(' · ')} offset={[0.5, -0.5, 0]} />}
    </group>
  );
}

// ─── DNA ─────────────────────────────────────────────────────────────────────
const BASE_COLORS: Record<string, string> = { A: '#4e9af1', T: '#f6c445', G: '#54c26b', C: '#ef5a5a' };
const PAIR: Record<string, string> = { A: 'T', T: 'A', G: 'C', C: 'G' };
export function DNAScene() {
  const mode = useStore((s) => s.dnaMode);
  const seq = useMemo(() => { const r = rng(42); return Array.from({ length: 24 }, () => 'ATGC'[Math.floor(r() * 4)]); }, []);
  const RISE = 3.4, TWIST = (36 * Math.PI) / 180, R = 10;      // canonical B-DNA (Å)
  const built = useMemo(() => {
    const p1: [number, number, number][] = []; const p2: [number, number, number][] = [];
    const pairs: { pos: [number, number, number]; rot: number; b1: string; b2: string }[] = [];
    seq.forEach((b, i) => { const y = (i - seq.length / 2) * RISE; const a1 = i * TWIST; const a2 = a1 + (144 * Math.PI) / 180; p1.push([Math.cos(a1) * R, y, Math.sin(a1) * R]); p2.push([Math.cos(a2) * R, y, Math.sin(a2) * R]); pairs.push({ pos: [0, y, 0], rot: a1 + (72 * Math.PI) / 180, b1: b, b2: PAIR[b] }); });
    return { p1, p2, pairs };
  }, [seq]);
  const spin = useRef<THREE.Group>(null!); const living = useStore((st) => st.living); const reduced = useStore((st) => st.reducedMotion);
  useFrame((_, dt) => { if (spin.current && living && !reduced) spin.current.rotation.y += dt * 0.1; });
  if (mode === 'crystal') return <group ref={spin}><ProteinRenderer id="dna-1bna" scale={1} partId="dna-1bna" publish forceMode="atoms" /><Tag position={[-16, 20, 0]} text="B-DNA crystal structure — PDB 1BNA (Drew–Dickerson dodecamer)" sub="1.9 Å X-ray · 12 bp · atoms coloured by element · waters removed" offset={[-0.4, 0.8, 0]} /></group>;
  return (
    <group ref={spin} onClick={(e) => { e.stopPropagation(); useStore.getState().select('dna'); }}>
      <Line points={built.p1} color="#e8e8ff" lineWidth={5} />
      <Line points={built.p2} color="#c8c8f0" lineWidth={5} />
      {built.p1.map((p, i) => <mesh key={`p${i}`} position={p}><sphereGeometry args={[1.1, 12, 10]} /><meshStandardMaterial color="#ff8000" /></mesh>)}
      {built.p2.map((p, i) => <mesh key={`q${i}`} position={p}><sphereGeometry args={[1.1, 12, 10]} /><meshStandardMaterial color="#ff8000" /></mesh>)}
      {built.pairs.map((bp, i) => <group key={i} position={bp.pos} rotation={[0, -bp.rot, 0]}>
        <mesh position={[R * 0.25, 0, 0]}><boxGeometry args={[R * 0.5 - 0.3, 1.2, 2.2]} /><meshStandardMaterial color={BASE_COLORS[bp.b1]} /></mesh>
        <mesh position={[-R * 0.25, 0, 0]}><boxGeometry args={[R * 0.5 - 0.3, 1.2, 2.2]} /><meshStandardMaterial color={BASE_COLORS[bp.b2]} /></mesh>
        <mesh position={[R * 0.5 - 0.3, 0, 0]}><sphereGeometry args={[0.7, 8, 8]} /><meshStandardMaterial color="#d0d0d0" /></mesh>
        <mesh position={[-R * 0.5 + 0.3, 0, 0]}><sphereGeometry args={[0.7, 8, 8]} /><meshStandardMaterial color="#d0d0d0" /></mesh>
        {i % 6 === 0 && <Html position={[R * 0.25, 1.4, 0]} center style={{ pointerEvents: 'none' }}><span className="ps-atom-label">{bp.b1}·{bp.b2}</span></Html>}
      </group>)}
      <Tag position={[-R - 4, 44, 0]} text="B-DNA double helix — idealised geometric model" sub="rise 3.4 Å/bp · 10 bp/turn (36°) · diameter 2.0 nm · orange = phosphate, grey = deoxyribose · A blue · T yellow · G green · C red" offset={[-0.4, 1, 0]} />
      <Tag position={[R + 1, 10, 0]} text="Major groove (≈2.2 nm)" offset={[4, 1, 0]} />
      <Tag position={[R + 1, -6, 0]} text="Minor groove (≈1.2 nm)" offset={[4, -1, 0]} />
      <Tag position={[0, 46, 0]} text="one helical turn ≈ 3.4 nm" offset={[3, 1, 0]} />
      <Tag position={[R, -44, 0]} text="strands are antiparallel (5′→3′ / 3′→5′)" offset={[2, -1, 0]} />
    </group>
  );
}

// ─── RNA (conceptual) ────────────────────────────────────────────────────────
export function RNAScene({ kind }: { kind: string }) {
  const built = useMemo(() => {
    const r = rng(kind === 'mrna' ? 7 : 11); const pts: THREE.Vector3[] = [];
    if (kind === 'mrna') { for (let i = 0; i < 40; i++) pts.push(new THREE.Vector3(i * 1.6 - 32, Math.sin(i * 0.5) * 4 + (r() - 0.5) * 2, Math.cos(i * 0.4) * 3)); }
    else { let p = new THREE.Vector3(); for (let i = 0; i < 60; i++) { p = p.clone().add(new THREE.Vector3((r() - 0.5) * 8, (r() - 0.5) * 8, (r() - 0.5) * 8)); if (p.length() > 14) p.setLength(12); pts.push(p.clone()); } }
    const curve = new THREE.CatmullRomCurve3(pts); const tube = new THREE.TubeGeometry(curve, 240, 0.6, 8, false);
    const bases = Array.from({ length: kind === 'mrna' ? 40 : 60 }, (_, i) => { const t = (i + 0.5) / (kind === 'mrna' ? 40 : 60); const p = curve.getPointAt(t); const n = curve.getTangentAt(t); const side = new THREE.Vector3(0, 1, 0).cross(n).normalize(); if (side.length() < 0.1) side.set(1, 0, 0); return { pos: p.clone().addScaledVector(side, 1.8), dir: side, base: 'AUGC'[Math.floor(rng(i + 3)() * 4)] }; });
    return { tube, bases };
  }, [kind]);
  return (
    <group onClick={(e) => { e.stopPropagation(); useStore.getState().select(kind); }}>
      <mesh geometry={built.tube}><meshStandardMaterial color="#ffb37a" roughness={0.5} /></mesh>
      {built.bases.map((b, i) => <group key={i} position={b.pos}><mesh quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.dir)}><boxGeometry args={[1.2, 2.6, 0.5]} /><meshStandardMaterial color={{ A: '#4e9af1', U: '#c084fc', G: '#54c26b', C: '#ef5a5a' }[b.base]} /></mesh></group>)}
      {kind === 'mrna' ? <>
        <Tag position={[-33, 4, 0]} text="5′ cap (7-methylguanosine)" offset={[-1, 2, 0]} />
        <Tag position={[0, 6, 0]} text="coding sequence (codons read in triplets)" offset={[1, 2, 0]} />
        <Tag position={[32, 4, 0]} text="3′ poly(A) tail" offset={[1, 2, 0]} />
        <Tag position={[-20, -8, 0]} text="CONCEPTUAL mRNA — single strand, no fixed tertiary structure" sub="bases: A blue · U purple · G green · C red · STRUCTURE NOT AVAILABLE as an experimental 3D model" offset={[0.5, -1.5, 0]} />
      </> : <Tag position={[-14, 16, 0]} text="CONCEPTUAL rRNA fold" sub="real rRNA structures exist only inside whole-ribosome models (e.g. PDB 8B2L, wheat 80S) — too large to stream here" offset={[-0.5, 1.5, 0]} />}
    </group>
  );
}

// ─── ATOM ────────────────────────────────────────────────────────────────────
const CONFIG: Record<string, string> = { H: '1s¹', C: '1s² 2s² 2p²', N: '1s² 2s² 2p³', O: '1s² 2s² 2p⁴', P: '[Ne] 3s² 3p³', S: '[Ne] 3s² 3p⁴', Mg: '[Ne] 3s²', K: '[Ar] 4s¹', Ca: '[Ar] 4s²', Fe: '[Ar] 3d⁶ 4s²', Mn: '[Ar] 3d⁵ 4s²', Cl: '[Ne] 3s² 3p⁵', Na: '[Ne] 3s¹', Zn: '[Ar] 3d¹⁰ 4s²', Cu: '[Ar] 3d¹⁰ 4s¹' };
export function AtomScene({ el }: { el: string }) {
  const e = elementOf(el);
  const { threshold, opacity, orbital } = useStore((s) => s.electron);
  const q = useQuality();
  const n = Math.round(9000 * q.particles);
  const cloud = useMemo(() => {
    const r = rng(e.Z + 1); const a = e.vdw / 2.6; const pos = new Float32Array(n * 3); const rad = new Float32Array(n);
    for (let i = 0; i < n; i++) { const rr = -(a / 2) * (Math.log(r()) + Math.log(r()) + Math.log(r())); const u = r() * 2 - 1; const t = r() * Math.PI * 2; const s = Math.sqrt(1 - u * u); pos[i * 3] = s * Math.cos(t) * rr; pos[i * 3 + 1] = u * rr; pos[i * 3 + 2] = s * Math.sin(t) * rr; rad[i] = rr; }
    return { pos, rad, a };
  }, [e, n]);
  const ref = useRef<THREE.Points>(null!);
  useEffect(() => { if (!ref.current) return; const g = ref.current.geometry; const filtered: number[] = []; const rMax = -(cloud.a / 2) * Math.log(Math.max(0.01, 1 - threshold)) * 1.4; for (let i = 0; i < n; i++) if (cloud.rad[i] < rMax) filtered.push(cloud.pos[i * 3], cloud.pos[i * 3 + 1], cloud.pos[i * 3 + 2]); g.setAttribute('position', new THREE.Float32BufferAttribute(filtered, 3)); g.computeBoundingSphere(); }, [cloud, threshold, n]);
  const isoR = -(cloud.a / 2) * Math.log(Math.max(0.01, 1 - threshold)) * 1.4;
  const spin = useRef<THREE.Group>(null!); const living = useStore((st) => st.living); const reduced = useStore((st) => st.reducedMotion);
  useFrame((_, dt) => { if (spin.current && living && !reduced) spin.current.rotation.y += dt * 0.15; });
  return (
    <group ref={spin} onClick={(ev) => { ev.stopPropagation(); useStore.getState().select(`atom-${e.symbol}`); }}>
      <mesh><sphereGeometry args={[0.12, 16, 12]} /><meshStandardMaterial color="#ff5050" emissive="#ff2020" emissiveIntensity={0.6} /></mesh>
      <points ref={ref}><bufferGeometry /><pointsMaterial color={e.color} size={0.03} transparent opacity={opacity} depthWrite={false} blending={THREE.AdditiveBlending} sizeAttenuation /></points>
      <mesh><sphereGeometry args={[isoR, 32, 24]} /><meshPhysicalMaterial color={e.color} transparent opacity={opacity * 0.25} roughness={0.2} side={THREE.DoubleSide} depthWrite={false} /></mesh>
      <mesh><sphereGeometry args={[e.vdw, 32, 24]} /><meshBasicMaterial color="#ffffff" wireframe transparent opacity={0.08} /></mesh>
      {orbital && e.Z >= 5 && [0, 1, 2].map((ax) => <group key={ax} rotation={[ax === 1 ? Math.PI / 2 : 0, 0, ax === 2 ? Math.PI / 2 : 0]}>{[1, -1].map((s) => <mesh key={s} position={[0, s * e.covalent * 0.8, 0]}><sphereGeometry args={[e.covalent * 0.5, 16, 12]} /><meshPhysicalMaterial color={s > 0 ? '#7fb2ff' : '#ff9a7f'} transparent opacity={0.25} depthWrite={false} /></mesh>)}</group>)}
      <Tag position={[-e.vdw - 0.3, e.vdw + 0.4, 0]} text={`${e.name} (${e.symbol}) · Z = ${e.Z}`} sub={`electron configuration ${CONFIG[e.symbol] ?? '—'} · mass ${e.mass} u · covalent r ${e.covalent} Å · vdW r ${e.vdw} Å (wire sphere)`} offset={[-0.3, 0.5, 0]} />
      <Tag position={[0, -e.vdw - 0.3, 0]} text="ELECTRON DENSITY / MODEL VISUALIZATION" sub={`point cloud samples a hydrogen-like 1s radial form scaled to this element — conceptual, not a computed density${orbital ? ' · p-lobes = schematic angular shapes' : ''}`} offset={[0.5, -0.6, 0]} />
      <Tag position={[0.12, 0.12, 0]} text="nucleus (not to scale)" sub={`${e.Z} protons; real nuclear radius ~10⁻⁵ of the atom`} offset={[0.5, 0.35, 0]} />
    </group>
  );
}
