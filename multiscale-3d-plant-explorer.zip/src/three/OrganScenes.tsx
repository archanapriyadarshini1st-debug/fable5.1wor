import { useMemo } from 'react';
import * as THREE from 'three';
import { Part, Instances, FlowParticles, Tag, blob, ellipsoid, deg, useQuality } from './core';
import { useStore, useSpecies, useParams } from '@/store';
import { rng } from '@/data/core';

const C = { epidermis: '#c9d8a8', cuticle: '#e6f0d0', cortex: '#d9e3a3', parenchyma: '#cfe0a1', endodermis: '#b8c98a', casparian: '#b5432c', pericycle: '#d8c98a', xylem: '#d04a3a', phloem: '#e0a43a', cambium: '#efe9a8', pith: '#f0f0d0', fibre: '#c9b27a', palisade: '#4e9a3a', spongy: '#79b35a', guard: '#3f8f3a', collenchyma: '#e8d7b0', meristem: '#e9d5ec', cork: '#7a5a3a', sheath: '#8fc46a', chloroplast: '#2f7d32', nucleus: '#6a4c93', vacuole: '#d8ecf5' };
export const TISSUE_COLORS = C;

function grid(nx: number, ny: number, nz: number, s: number, jitter: number, seed: number, skip = 0) {
  const r = rng(seed); const out: { pos: [number, number, number]; rot: [number, number, number]; scale: number }[] = [];
  for (let x = 0; x < nx; x++) for (let y = 0; y < ny; y++) for (let z = 0; z < nz; z++) {
    if (r() < skip) continue;
    out.push({ pos: [(x - (nx - 1) / 2) * s + (r() - 0.5) * jitter, (y - (ny - 1) / 2) * s + (r() - 0.5) * jitter, (z - (nz - 1) / 2) * s + (r() - 0.5) * jitter], rot: [r() * 0.4, r() * 6, r() * 0.4], scale: 0.85 + r() * 0.3 });
  }
  return out;
}

// ─── ROOT ────────────────────────────────────────────────────────────────────
export function RootScene() {
  const sp = useSpecies(); const transport = useStore((s) => s.transport); const q = useQuality();
  const mono = sp.type === 'monocot';
  const hairs = useMemo(() => { const r = rng(4); return Array.from({ length: Math.round(90 * q.instances) }, () => { const a = r() * Math.PI * 2; const y = 0.2 + r() * 2.6; return { pos: [Math.cos(a) * 2.0, y, Math.sin(a) * 2.0] as [number, number, number], rot: [0, -a, Math.PI / 2 + (r() - 0.5) * 0.4] as [number, number, number], scale: 0.7 + r() * 0.6 }; }); }, [q.instances]);
  const cortexCells = useMemo(() => { const out: { pos: [number, number, number]; scale: number }[] = []; const r = rng(2); for (let ring = 0; ring < 4; ring++) { const rad = 1.15 + ring * 0.22; const n = Math.round(rad * 22); for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + ring * 0.1; out.push({ pos: [Math.cos(a) * rad, 3.02, Math.sin(a) * rad], scale: 0.9 + r() * 0.2 }); } } return out; }, []);
  const xylemArms = mono ? 12 : 4;
  const curves = useMemo(() => Array.from({ length: 6 }, (_, i) => { const a = (i / 6) * Math.PI * 2; return new THREE.CatmullRomCurve3([new THREE.Vector3(Math.cos(a) * 2.6, 2.4, Math.sin(a) * 2.6), new THREE.Vector3(Math.cos(a) * 1.2, 2.5, Math.sin(a) * 1.2), new THREE.Vector3(0, 2.8, 0), new THREE.Vector3(0, 4.5, 0)]); }), []);
  const cellGeo = useMemo(() => blob(0.11, 0.1, 3, 1), []);
  return (
    <group>
      {/* layers – each inner layer slightly taller so the cut face reads as rings */}
      <Part id="root-epidermis" color={C.epidermis} position={[0, 0.5, 0]} radius={2.2} explodeDir={[0, 0, 0]}><cylinderGeometry args={[2.0, 1.7, 5, 48]} /></Part>
      <Part id="root-cortex" color={C.cortex} position={[0, 0.51, 0]} radius={2}><cylinderGeometry args={[1.86, 1.55, 5.02, 48]} /></Part>
      <Instances id="root-cortex" geometry={cellGeo} color="#e6eebb" items={cortexCells} label="Cortex parenchyma cells (cut face)" radius={1.5} />
      <Part id="endodermis" color={C.endodermis} position={[0, 0.52, 0]} radius={1.1}><cylinderGeometry args={[1.02, 0.8, 5.04, 48]} /></Part>
      <mesh position={[0, 3.06, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[1.0, 0.025, 8, 64]} /><meshStandardMaterial color={C.casparian} emissive={C.casparian} emissiveIntensity={0.4} /></mesh>
      <Part id="pericycle" color={C.pericycle} position={[0, 0.53, 0]} radius={1}><cylinderGeometry args={[0.92, 0.7, 5.06, 48]} /></Part>
      <Part id="root-vascular" color={mono ? C.pith : '#f3e2c8'} position={[0, 0.54, 0]} radius={0.9}><cylinderGeometry args={[0.86, 0.66, 5.08, 48]} /></Part>
      {/* xylem */}
      {mono
        ? Array.from({ length: xylemArms }, (_, i) => { const a = (i / xylemArms) * Math.PI * 2; return <Part key={i} id="xylem" color={C.xylem} position={[Math.cos(a) * 0.62, 0.56, Math.sin(a) * 0.62]} noRegister={i > 0} radius={0.2}><cylinderGeometry args={[0.13, 0.1, 5.12, 12]} /></Part>; })
        : Array.from({ length: xylemArms }, (_, i) => <Part key={i} id="xylem" color={C.xylem} position={[0, 0.56, 0]} rotation={[0, (i / xylemArms) * Math.PI, 0]} noRegister={i > 0} radius={0.8}><boxGeometry args={[1.5, 5.12, 0.22]} /></Part>)}
      {/* phloem */}
      {Array.from({ length: xylemArms }, (_, i) => { const a = ((i + 0.5) / xylemArms) * Math.PI * 2; const rad = mono ? 0.62 : 0.55; return <Part key={i} id="phloem" color={C.phloem} position={[Math.cos(a) * rad, 0.57, Math.sin(a) * rad]} noRegister={i > 0} radius={0.2}><cylinderGeometry args={[mono ? 0.09 : 0.16, mono ? 0.07 : 0.13, 5.14, 10]} /></Part>; })}
      {mono && <Part id="pith" color={C.pith} position={[0, 0.58, 0]} radius={0.4}><cylinderGeometry args={[0.4, 0.3, 5.16, 24]} /></Part>}
      {/* root tip */}
      <Part id="root-tip" color={C.epidermis} position={[0, -2.9, 0]} radius={1.7}><cylinderGeometry args={[1.7, 0.9, 1.8, 32]} /></Part>
      <Part id="meristem" color={C.meristem} position={[0, -3.35, 0]} radius={0.9} label="Apical meristem (zone of cell division)"><sphereGeometry args={[0.85, 24, 16]} /></Part>
      <Part id="root-cap" color="#e8dcb8" position={[0, -4.1, 0]} radius={1} alwaysLabel labelOffset={[1.2, -0.5, 0]}><sphereGeometry args={[1.05, 24, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2]} /></Part>
      <Instances id="root-epidermis" geometry={new THREE.CylinderGeometry(0.03, 0.015, 1.6, 5)} color="#f4f0dc" items={hairs.map((h) => ({ ...h, pos: [h.pos[0] * 1.35, h.pos[1], h.pos[2] * 1.35] as [number, number, number] }))} label="Root hairs (zone of maturation)" radius={1} />
      <Tag position={[2.6, -1.6, 0]} text="Zone of elongation" offset={[0.8, 0, 0]} />
      <Tag position={[2.6, 1.6, 0]} text="Zone of maturation (root hairs)" offset={[0.8, 0.3, 0]} />
      <Tag position={[0, 3.1, 0]} text={mono ? 'Cross-section: polyarch xylem ring + pith (monocot)' : 'Cross-section: tetrarch xylem star (eudicot)'} sub="epidermis → cortex → endodermis (Casparian strip, red) → pericycle → stele" offset={[1.8, 1.2, 0]} />
      {transport && <><FlowParticles curves={curves} count={240} color="#5fc9ff" size={0.07} speed={0.15} spread={0.05} /><Tag position={[-2.8, 3.2, 0]} text="CONCEPTUAL WATER PATH" sub="apoplast/symplast inward → membrane crossing at endodermis → xylem upward" offset={[-0.8, 0.6, 0]} /></>}
    </group>
  );
}

// ─── STEM ────────────────────────────────────────────────────────────────────
export function StemScene() {
  const sp = useSpecies(); const p = useParams(); const transport = useStore((s) => s.transport);
  const mono = sp.type === 'monocot'; const woody = sp.secondaryGrowth;
  const square = sp.id === 'mint';
  const bundles = useMemo(() => {
    const r = rng(9); const out: { pos: [number, number]; s: number }[] = [];
    if (mono) { for (let i = 0; i < 26; i++) { const a = r() * Math.PI * 2; const rad = Math.sqrt(r()) * 1.75; out.push({ pos: [Math.cos(a) * rad, Math.sin(a) * rad], s: 0.6 + (rad / 1.8) * 0.4 }); } }
    else { const n = square ? 4 : 9; for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + (square ? Math.PI / 4 : 0); out.push({ pos: [Math.cos(a) * 1.45, Math.sin(a) * 1.45], s: 1 }); } }
    return out;
  }, [mono, square]);
  const vesselHoles = useMemo(() => bundles.flatMap((b, bi) => Array.from({ length: 4 }, (_, i) => { const dir = Math.atan2(b.pos[1], b.pos[0]); const rad = Math.hypot(b.pos[0], b.pos[1]) - (mono ? 0 : 0.2) - i * 0.12; return { pos: [Math.cos(dir) * rad + (i % 2 ? 0.08 : -0.08) * Math.sin(dir), 3.16, Math.sin(dir) * rad - (i % 2 ? 0.08 : -0.08) * Math.cos(dir)] as [number, number, number], scale: (0.5 + (i / 4) * 0.8) * b.s, key: bi * 10 + i }; })), [bundles, mono]);
  const curves = useMemo(() => bundles.slice(0, 8).map((b) => new THREE.CatmullRomCurve3([new THREE.Vector3(b.pos[0] * 0.85, -3.5, b.pos[1] * 0.85), new THREE.Vector3(b.pos[0] * 0.85, 0, b.pos[1] * 0.85), new THREE.Vector3(b.pos[0] * 0.85, 4, b.pos[1] * 0.85)])), [bundles]);
  const seg = square ? 4 : 48; const rotY = square ? Math.PI / 4 : 0;
  return (
    <group>
      {woody && <Part id="cork" color={C.cork} position={[0, 0, 0]} rotation={[0, rotY, 0]} radius={2.4}><cylinderGeometry args={[2.35, 2.35, 6, seg]} /></Part>}
      <Part id="stem-epidermis" color={woody ? '#8a6d4e' : p.stemColor} rotation={[0, rotY, 0]} radius={2.3}><cylinderGeometry args={[2.2, 2.2, 6.02, seg]} /></Part>
      <Part id="cortex" color={C.collenchyma} rotation={[0, rotY, 0]} radius={2}><cylinderGeometry args={[2.05, 2.05, 6.04, seg]} /></Part>
      {square && [0, 1, 2, 3].map((i) => <Part key={i} id="cortex" color="#f0dfc0" position={[Math.cos(i * Math.PI / 2 + Math.PI / 4) * 1.9, 0.02, Math.sin(i * Math.PI / 2 + Math.PI / 4) * 1.9]} noRegister radius={0.3} label="Collenchyma strand (corner of square stem)"><cylinderGeometry args={[0.3, 0.3, 6.06, 12]} /></Part>)}
      {!mono && <Part id="cortex" color={C.parenchyma} position={[0, 0.02, 0]} radius={1.9} noRegister><cylinderGeometry args={[1.85, 1.85, 6.06, 48]} /></Part>}
      {mono && <Part id="cortex" color={C.parenchyma} position={[0, 0.02, 0]} radius={1.9} noRegister label="Ground tissue (no cortex/pith distinction in monocots)"><cylinderGeometry args={[1.85, 1.85, 6.06, 48]} /></Part>}
      {woody ? (
        <group>
          <Part id="phloem" color={C.phloem} position={[0, 0.03, 0]} radius={1.7} label="Secondary phloem"><cylinderGeometry args={[1.72, 1.72, 6.08, 48]} /></Part>
          <Part id="cambium" color={C.cambium} position={[0, 0.04, 0]} radius={1.55} label="Vascular cambium"><cylinderGeometry args={[1.56, 1.56, 6.1, 48]} /></Part>
          {[1.5, 1.25, 1.0, 0.75, 0.5].map((rr, i) => <Part key={i} id="xylem" color={i % 2 ? '#e2b48c' : '#c98b62'} position={[0, 0.05 + i * 0.01, 0]} noRegister={i > 0} radius={rr} label={`Secondary xylem (wood) — growth ring ${i + 1}`}><cylinderGeometry args={[rr, rr, 6.12 + i * 0.02, 48]} /></Part>)}
          <Part id="pith" color={C.pith} position={[0, 0.12, 0]} radius={0.3}><cylinderGeometry args={[0.3, 0.3, 6.24, 24]} /></Part>
        </group>
      ) : (
        <group>
          {!mono && <Part id="pith" color={C.pith} position={[0, 0.03, 0]} radius={1.1}><cylinderGeometry args={[1.1, 1.1, 6.08, 48]} /></Part>}
          {bundles.map((b, i) => { const dir = Math.atan2(b.pos[1], b.pos[0]); const rad = Math.hypot(b.pos[0], b.pos[1]); const s = b.s; return (
            <group key={i} rotation={[0, -dir, 0]} position={[0, 0.04, 0]}>
              <Part id="vascular-bundle" color={C.fibre} position={[rad + 0.33 * s, 0, 0]} noRegister={i > 0} radius={0.5} label="Bundle cap (sclerenchyma fibres)"><cylinderGeometry args={[0.16 * s, 0.16 * s, 6.1, 12]} /></Part>
              <Part id="phloem" color={C.phloem} position={[rad + 0.12 * s, 0.01, 0]} noRegister={i > 0} radius={0.3}><cylinderGeometry args={[0.2 * s, 0.2 * s, 6.12, 14]} /></Part>
              {!mono && <Part id="cambium" color={C.cambium} position={[rad - 0.08 * s, 0.02, 0]} noRegister={i > 0} radius={0.2}><boxGeometry args={[0.06, 6.14, 0.5 * s]} /></Part>}
              <Part id="xylem" color={C.xylem} position={[rad - 0.33 * s, 0.03, 0]} noRegister={i > 0} radius={0.35}><cylinderGeometry args={[0.28 * s, 0.28 * s, 6.16, 14]} /></Part>
              {sp.id === 'tomato' && <Part id="phloem" color={C.phloem} position={[rad - 0.66 * s, 0.01, 0]} noRegister radius={0.2} label="Internal phloem (bicollateral bundle)"><cylinderGeometry args={[0.12, 0.12, 6.12, 10]} /></Part>}
            </group>); })}
          <Instances id="vessel-element" geometry={new THREE.CylinderGeometry(0.05, 0.05, 0.05, 8)} color="#5a1a12" items={vesselHoles} label="Vessel lumina (xylem)" radius={0.3} />
        </group>
      )}
      <Tag position={[0, 3.1, 0]} text={woody ? 'Woody stem cross-section (secondary growth)' : mono ? 'Monocot stem: scattered vascular bundles' : square ? 'Square stem (Lamiaceae): 4 corner collenchyma strands' : 'Eudicot stem: ring of vascular bundles around pith'} sub="epidermis → cortex → phloem | cambium | xylem → pith" offset={[2, 1.2, 0]} />
      {transport && <><FlowParticles curves={curves} count={300} color="#5fc9ff" size={0.06} speed={0.18} spread={0.08} /><FlowParticles curves={curves} count={150} color="#ffb347" size={0.06} speed={0.1} spread={0.4} reverse seed={5} /><Tag position={[-2.6, 3.2, 0]} text="CONCEPTUAL FLOW VISUALIZATION" sub="blue up = xylem sap · amber down = phloem sap" offset={[-0.8, 0.6, 0]} /></>}
    </group>
  );
}

// ─── LEAF ────────────────────────────────────────────────────────────────────
export function LeafScene() {
  const sp = useSpecies(); const q = useQuality(); const transport = useStore((s) => s.transport); const gas = useStore((s) => s.gasExchange);
  const mono = sp.type === 'monocot'; const kranz = sp.id === 'maize'; const mint = sp.id === 'mint';
  const W = 10, D = 6;
  const upper = useMemo(() => grid(16, 1, 10, 0.62, 0.05, 1).map((c) => ({ ...c, pos: [c.pos[0], 1.35, c.pos[2]] as [number, number, number], rot: [0, 0, 0] as [number, number, number] })), []);
  const lower = useMemo(() => grid(16, 1, 10, 0.62, 0.05, 2).filter((_, i) => i % 9 !== 4).map((c) => ({ ...c, pos: [c.pos[0], -1.2, c.pos[2]] as [number, number, number], rot: [0, 0, 0] as [number, number, number] })), []);
  const stomata = useMemo(() => grid(16, 1, 10, 0.62, 0.05, 2).filter((_, i) => i % 9 === 4).map((c) => ({ pos: [c.pos[0], -1.2, c.pos[2]] as [number, number, number] })), []);
  const palisade = useMemo(() => grid(Math.round(22 * q.instances), mono ? 1 : 2, Math.round(13 * q.instances), mono ? 0.7 : 0.45, 0.06, 3).filter((c) => Math.abs(c.pos[0]) > 1.1 || mono).map((c) => ({ ...c, pos: [c.pos[0], mono ? 0.6 : c.pos[1] * 1.9 + 0.45, c.pos[2]] as [number, number, number], rot: [0, 0, 0] as [number, number, number], scale: c.scale * (mono ? 0.9 : 1) })), [q.instances, mono]);
  const spongy = useMemo(() => grid(Math.round(13 * q.instances), 2, Math.round(8 * q.instances), 0.72, 0.28, 4, 0.22).filter((c) => Math.abs(c.pos[0]) > 1.0).map((c) => ({ ...c, pos: [c.pos[0], c.pos[1] * 0.85 - 0.45, c.pos[2]] as [number, number, number] })), [q.instances]);
  const chloro = useMemo(() => { const r = rng(7); return palisade.flatMap((c) => Array.from({ length: 5 }, () => ({ pos: [c.pos[0] + (r() - 0.5) * 0.24, c.pos[1] + (r() - 0.5) * 1.5, c.pos[2] + (r() - 0.5) * 0.24] as [number, number, number] }))); }, [palisade]);
  const gasCurves = useMemo(() => stomata.slice(0, 8).map((s) => new THREE.CatmullRomCurve3([new THREE.Vector3(s.pos[0], -2.6, s.pos[2]), new THREE.Vector3(s.pos[0], -1.2, s.pos[2]), new THREE.Vector3(s.pos[0] + 0.3, -0.4, s.pos[2] + 0.2), new THREE.Vector3(s.pos[0] - 0.2, 0.6, s.pos[2] - 0.3)])), [stomata]);
  const veinCurve = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0.15, -D / 2 - 1), new THREE.Vector3(0, 0.15, 0), new THREE.Vector3(0, 0.15, D / 2 + 1)])], []);
  const palGeo = useMemo(() => new THREE.CapsuleGeometry(mono ? 0.3 : 0.19, mono ? 0.4 : 1.5, 4, 10), [mono]);
  const spGeo = useMemo(() => blob(0.36, 0.35, 5, 2), []);
  const guardGeo = useMemo(() => new THREE.TorusGeometry(0.14, 0.06, 8, 12, Math.PI), []);
  const guards = useMemo(() => stomata.flatMap((s) => [{ pos: [s.pos[0] - 0.05, s.pos[1], s.pos[2]] as [number, number, number], rot: [Math.PI / 2, 0, Math.PI / 2] as [number, number, number] }, { pos: [s.pos[0] + 0.05, s.pos[1], s.pos[2]] as [number, number, number], rot: [Math.PI / 2, 0, -Math.PI / 2] as [number, number, number] }]), [stomata]);
  return (
    <group>
      <Part id="cuticle" color={C.cuticle} position={[0, 1.6, 0]} radius={5} opacity={0.6} explodeDir={[0, 1.5, 0]}><boxGeometry args={[W, 0.06, D]} /></Part>
      <Instances id="upper-epidermis" geometry={new THREE.BoxGeometry(0.58, 0.34, 0.58)} color={C.epidermis} items={upper} explodeDir={[0, 1, 0]} radius={5} />
      {mint && <Instances id="trichome" geometry={new THREE.SphereGeometry(0.18, 10, 8)} color="#f2e6a0" items={[{ pos: [-2.5, 1.8, 1.2] }, { pos: [1.8, 1.8, -1.6] }, { pos: [3.6, 1.8, 0.8] }]} label="Peltate glandular trichome (essential-oil gland)" radius={0.3} />}
      {!mint && sp.type !== 'monocot' && <Instances id="trichome" geometry={new THREE.ConeGeometry(0.06, 0.8, 6)} color="#eef2dc" items={[{ pos: [-3.5, 1.95, 1.5] }, { pos: [2.8, 1.95, -1.9] }]} label="Trichome (leaf hair)" radius={0.4} />}
      <Instances id={mono ? 'mesophyll' : 'palisade-mesophyll'} geometry={palGeo} color={C.palisade} items={palisade} explodeDir={[0, 0.5, 0]} radius={2} label={mono ? 'Mesophyll (undifferentiated in grasses)' : undefined} />
      <Instances id="chloroplast" geometry={new THREE.SphereGeometry(0.05, 6, 6)} color="#1f5f22" items={chloro} explodeDir={[0, 0.5, 0]} ignoreFocus radius={0.5} label="Chloroplasts inside mesophyll cells" />
      <Instances id="spongy-mesophyll" geometry={spGeo} color={C.spongy} items={spongy} explodeDir={[0, -0.5, 0]} radius={2} />
      <Part id="air-space" color="#cfe8ff" position={[-3.2, -0.5, 1.4]} radius={0.5} opacity={0.15} label="Intercellular air space" explodeDir={[0, -0.5, 0]}><sphereGeometry args={[0.55, 12, 12]} /></Part>
      {/* vein */}
      <Part id="leaf-vascular" color={kranz ? C.sheath : '#b9d59a'} rotation={[Math.PI / 2, 0, 0]} position={[0, 0.15, 0]} radius={1} label={kranz ? 'Bundle sheath — Kranz anatomy (chloroplast-rich)' : 'Bundle sheath'} explodeDir={[0, 0, 0]}><cylinderGeometry args={[kranz ? 1.0 : 0.85, kranz ? 1.0 : 0.85, D, 24]} /></Part>
      <Part id="bundle-sheath" color={kranz ? '#5aa54a' : '#d4e6b8'} rotation={[Math.PI / 2, 0, 0]} position={[0, 0.15, 0]} radius={0.8} noRegister={false}><cylinderGeometry args={[kranz ? 0.85 : 0.7, kranz ? 0.85 : 0.7, D + 0.02, 24]} /></Part>
      {[-0.28, 0, 0.28].map((x, i) => <Part key={i} id="xylem" color={C.xylem} rotation={[Math.PI / 2, 0, 0]} position={[x, 0.42, 0]} noRegister={i > 0} radius={0.3} explodeDir={[0, 0.4, 0]}><cylinderGeometry args={[0.11, 0.11, D + 0.05, 10]} /></Part>)}
      {[-0.32, -0.1, 0.1, 0.32].map((x, i) => <Part key={i} id="phloem" color={C.phloem} rotation={[Math.PI / 2, 0, 0]} position={[x, -0.18, 0]} noRegister={i > 0} radius={0.3} explodeDir={[0, -0.4, 0]}><cylinderGeometry args={[0.08, 0.08, D + 0.05, 10]} /></Part>)}
      <Instances id="lower-epidermis" geometry={new THREE.BoxGeometry(0.58, 0.3, 0.58)} color={C.epidermis} items={lower} explodeDir={[0, -1, 0]} radius={5} />
      <Instances id="stoma" geometry={guardGeo} color={C.guard} items={guards} explodeDir={[0, -1, 0]} radius={0.3} label="Stomata (pairs of guard cells)" />
      <Part id="cuticle" color={C.cuticle} position={[0, -1.42, 0]} radius={5} opacity={0.6} explodeDir={[0, -1.5, 0]} noRegister><boxGeometry args={[W, 0.05, D]} /></Part>
      <Tag position={[-W / 2, 1.6, D / 2]} text="Leaf cross-section" sub={mono ? 'monocot: parallel veins, uniform mesophyll, amphistomatous' : 'eudicot: palisade above, spongy below, hypostomatous'} offset={[-0.6, 0.8, 0]} />
      {transport && <><FlowParticles curves={veinCurve} count={140} color="#5fc9ff" size={0.06} speed={0.2} spread={0.35} /><FlowParticles curves={veinCurve} count={100} color="#ffb347" size={0.06} speed={0.12} spread={0.45} reverse seed={2} /><Tag position={[0.9, 0.9, -D / 2]} text="CONCEPTUAL FLOW: vein" sub="xylem water (blue) · phloem sucrose (amber)" offset={[0.8, 0.6, 0]} /></>}
      {gas && <><FlowParticles curves={gasCurves} count={160} color="#c8c8c8" size={0.07} speed={0.25} spread={0.1} /><FlowParticles curves={gasCurves} count={120} color="#7fe3ff" size={0.07} speed={0.3} spread={0.1} reverse seed={4} /><Tag position={[2.5, -2.4, 1.5]} text="CONCEPTUAL GAS EXCHANGE" sub="grey CO₂ in through stomata · blue H₂O vapour / O₂ out" offset={[1, -0.6, 0]} /></>}
    </group>
  );
}

// ─── STOMA ───────────────────────────────────────────────────────────────────
export function StomaScene() {
  const sp = useSpecies(); const aperture = useStore((s) => s.stomaAperture); const gas = useStore((s) => s.gasExchange);
  const grass = sp.type === 'monocot';
  const pavement = useMemo(() => { const r = rng(21); const out: { pos: [number, number, number]; rot: [number, number, number]; scale: [number, number, number] }[] = []; for (let x = -3; x <= 3; x++) for (let z = -3; z <= 3; z++) { if (Math.abs(x) <= 1 && Math.abs(z) <= 0) continue; out.push({ pos: [x * 1.9 + (r() - 0.5) * 0.3, 0, z * 1.5 + (r() - 0.5) * 0.3], rot: [0, r() * 0.3, 0], scale: [1.7 + r() * 0.3, 0.5, 1.3 + r() * 0.3] }); } return out; }, []);
  const chloro = useMemo(() => { const r = rng(3); return [-1, 1].flatMap((side) => Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * Math.PI - Math.PI / 2; const R = grass ? 0.3 : 1.15; return { pos: [side * (grass ? 0.35 + aperture * 0.3 : (0.55 + aperture * 0.45)) + (grass ? 0 : Math.cos(a) * 0) + side * Math.cos(a) * (grass ? 0 : 0.0), 0.32 + (r() - 0.5) * 0.1, Math.sin(a) * R * (grass ? 4 : 1)] as [number, number, number] }; })); }, [aperture, grass]);
  const gasCurves = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(0.2, 3, 0.3), new THREE.Vector3(0, 0.5, 0), new THREE.Vector3(-0.3, -2.5, -0.4)]), new THREE.CatmullRomCurve3([new THREE.Vector3(-0.2, 3, -0.3), new THREE.Vector3(0, 0.4, 0.1), new THREE.Vector3(0.4, -2.5, 0.5)])], []);
  const gap = 0.5 + aperture * 0.55;
  return (
    <group>
      <Instances id="epidermal-cell" geometry={new THREE.BoxGeometry(1, 1, 1)} color={C.epidermis} items={pavement} label="Epidermal pavement cells" radius={3} />
      {grass ? (
        <>
          {[-1, 1].map((s) => <Part key={s} id="guard-cell" color={C.guard} position={[s * gap * 0.7, 0.25, 0]} noRegister={s > 0} radius={1.5} label="Guard cell (dumbbell-shaped, grasses)"><capsuleGeometry args={[0.22, 3.2, 6, 12]} /></Part>)}
          {[-1, 1].flatMap((s) => [-1, 1].map((e) => <Part key={`${s}${e}`} id="guard-cell" color={C.guard} position={[s * gap * 0.9, 0.25, e * 1.9]} noRegister radius={0.5}><sphereGeometry args={[0.55, 14, 12]} /></Part>))}
          {[-1, 1].map((s) => <Part key={s} id="stoma" color="#b7cf9a" position={[s * (gap * 0.7 + 1.0), 0.15, 0]} noRegister={s > 0} radius={1} label="Subsidiary cell"><capsuleGeometry args={[0.35, 3.0, 6, 12]} /></Part>)}
        </>
      ) : (
        [-1, 1].map((s) => <Part key={s} id="guard-cell" color={C.guard} position={[s * gap, 0.25, 0]} rotation={[Math.PI / 2, 0, s > 0 ? -Math.PI / 2 : Math.PI / 2]} noRegister={s > 0} radius={1.5} label="Guard cell (kidney-shaped)"><torusGeometry args={[1.15, 0.42, 14, 28, Math.PI]} /></Part>)
      )}
      <Instances id="chloroplast" geometry={new THREE.SphereGeometry(0.1, 8, 8)} color={C.chloroplast} items={chloro} ignoreFocus label="Guard-cell chloroplasts" radius={0.5} />
      <Part id="pore" color="#0b1a12" position={[0, -0.3, 0]} radius={0.6} opacity={0.85} label="Stomatal pore → substomatal cavity"><boxGeometry args={[Math.max(0.05, (gap - 0.5) * 2 + 0.1), 1.2, grass ? 2.8 : 1.6]} /></Part>
      <Tag position={[0, 0.9, -1.9]} text={`Stoma — aperture ${(aperture * 100).toFixed(0)} %`} sub="guard-cell swelling (K⁺ + water uptake) opens the pore; ABA closes it" offset={[1.5, 0.9, 0]} />
      {gas && <><FlowParticles curves={gasCurves} count={120} color="#c8c8c8" size={0.08} speed={0.3 * aperture + 0.05} spread={gap * 0.4} /><FlowParticles curves={gasCurves} count={120} color="#7fe3ff" size={0.08} speed={0.35 * aperture + 0.05} spread={gap * 0.4} reverse seed={8} /><Tag position={[2.5, 2.5, 0]} text="CONCEPTUAL GAS EXCHANGE" sub="rate scales with aperture only illustratively" offset={[0.8, 0.4, 0]} /></>}
    </group>
  );
}

// ─── FLOWER ──────────────────────────────────────────────────────────────────
export function FlowerScene() {
  const sp = useSpecies(); const p = useParams();
  const nPetals = sp.id === 'rose' ? 18 : sp.id === 'sunflower' ? 5 : sp.type === 'monocot' ? 0 : 5;
  const nStamens = sp.type === 'monocot' ? 3 : sp.id === 'rose' ? 20 : sp.id === 'sunflower' ? 5 : 6;
  const petalGeo = useMemo(() => { const g = new THREE.SphereGeometry(1, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2); g.scale(1.1, 0.4, 2.2); return g; }, []);
  const ovules = useMemo(() => { const r = rng(2); return Array.from({ length: 14 }, (_, i) => ({ pos: [Math.cos(i * 0.9) * 0.45 * (0.4 + r() * 0.6), -1.4 + (i % 4) * 0.28 - 0.4, Math.sin(i * 0.9) * 0.45 * (0.4 + r() * 0.6)] as [number, number, number] })); }, []);
  return (
    <group>
      <Part id="flower" color="#6f9a4a" position={[0, -2.6, 0]} radius={1} label="Receptacle / pedicel"><cylinderGeometry args={[0.7, 0.3, 1.4, 16]} /></Part>
      {Array.from({ length: 5 }, (_, i) => <Part key={i} id="sepal" color="#4f7f36" position={[Math.cos(i / 5 * Math.PI * 2) * 0.8, -1.9, Math.sin(i / 5 * Math.PI * 2) * 0.8]} rotation={[deg(-60), -(i / 5) * Math.PI * 2 + Math.PI / 2, 0]} scale={0.7} noRegister={i > 0} radius={1} explodeDir={[Math.cos(i / 5 * Math.PI * 2) * 1.5, -0.5, Math.sin(i / 5 * Math.PI * 2) * 1.5]} geometry={petalGeo} />)}
      {Array.from({ length: nPetals }, (_, i) => { const a = (i / nPetals) * Math.PI * 2 + (sp.id === 'rose' ? i * 0.4 : 0); const layer = sp.id === 'rose' ? 0.6 + (i % 3) * 0.3 : 1; return <Part key={i} id="petal" color={p.petalColor} position={[Math.cos(a) * 0.7 * layer, -1.6 + (sp.id === 'rose' ? (i % 3) * 0.2 : 0), Math.sin(a) * 0.7 * layer]} rotation={[deg(-35 - (sp.id === 'rose' ? (i % 3) * 15 : 0)), -a + Math.PI / 2, 0]} scale={1.1 * layer} noRegister={i > 0} radius={2} explodeDir={[Math.cos(a) * 2, 0.3, Math.sin(a) * 2]} geometry={petalGeo} sheen={0.6} />; })}
      {Array.from({ length: nStamens }, (_, i) => { const a = (i / nStamens) * Math.PI * 2 + 0.3; const R = 0.95; return <group key={i}>
        <Part id="filament" color="#efe6c0" position={[Math.cos(a) * R, -0.5, Math.sin(a) * R]} rotation={[Math.sin(a) * 0.25, 0, -Math.cos(a) * 0.25]} noRegister={i > 0} radius={0.3} explodeDir={[Math.cos(a) * 1.2, 1, Math.sin(a) * 1.2]}><cylinderGeometry args={[0.05, 0.06, 2.2, 8]} /></Part>
        <Part id="anther" color="#e8b923" position={[Math.cos(a) * (R + 0.25), 0.7, Math.sin(a) * (R + 0.25)]} rotation={[0, -a, 0]} noRegister={i > 0} radius={0.3} explodeDir={[Math.cos(a) * 1.2, 1.4, Math.sin(a) * 1.2]}><capsuleGeometry args={[0.13, 0.35, 4, 10]} /></Part></group>; })}
      <Part id="ovary" color="#bfe0a0" position={[0, -1.4, 0]} radius={0.9} side={THREE.DoubleSide} explodeDir={[0, -0.6, 0]} label="Ovary (cutaway)"><sphereGeometry args={[0.85, 32, 24, 0, Math.PI * 1.55]} /></Part>
      <Instances id="ovule" geometry={new THREE.SphereGeometry(0.11, 10, 10)} color="#f7f1c7" items={ovules} explodeDir={[0, -0.6, 0]} radius={0.3} label="Ovules (on placenta)" />
      <Part id="style" color="#d7e7b8" position={[0, 0.2, 0]} radius={1} explodeDir={[0, 0.8, 0]}><cylinderGeometry args={[0.12, 0.2, 2.4, 12]} /></Part>
      <Part id="stigma" color="#e6d25a" position={[0, 1.55, 0]} radius={0.4} explodeDir={[0, 1.8, 0]} alwaysLabel labelOffset={[0.8, 0.7, 0]}><sphereGeometry args={[0.3, 16, 12]} /></Part>
      <Tag position={[-2.5, 1.8, 0]} text={sp.id === 'sunflower' ? 'Model: single disc floret of the capitulum' : sp.type === 'monocot' ? 'Model: generalised floret (grasses lack petals; lodicules, palea/lemma not shown)' : 'Generalised bisexual flower'} sub="sepals · petals · stamens (filament + anther) · carpel (stigma · style · ovary · ovules)" offset={[-0.6, 0.8, 0]} />
    </group>
  );
}

// ─── SEED ────────────────────────────────────────────────────────────────────
export function SeedScene() {
  const sp = useSpecies(); const mono = sp.type === 'monocot';
  return (
    <group>
      {mono ? (
        <group>
          <Part id="seed-coat" color="#d9b45a" side={THREE.DoubleSide} radius={3} label="Pericarp + testa (fused: caryopsis)" opacity={0.95}><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 32, 24, Math.PI * 0.5, Math.PI * 1.5); g.scale(1.6, 2.6, 1.2); return g; })()} /></Part>
          <Part id="endosperm" color="#f4e7b8" radius={2} explodeDir={[0, 0.8, 0]} label="Starchy endosperm (with outer aleurone layer)"><primitive attach="geometry" object={ellipsoid(1.45, 2.3, 1.0)} /></Part>
          <Part id="embryo" color="#c9dd8a" position={[0.75, -1.2, 0.2]} radius={0.8} explodeDir={[1.5, -0.5, 0]} label="Embryo (scutellum + axis)"><primitive attach="geometry" object={ellipsoid(0.55, 1.0, 0.35)} /></Part>
          <Part id="cotyledon" color="#a9c86a" position={[0.5, -1.2, 0.35]} radius={0.5} explodeDir={[1.5, -0.5, 0]} label="Scutellum (single cotyledon)"><primitive attach="geometry" object={ellipsoid(0.25, 0.9, 0.2)} /></Part>
          <Part id="plumule" color="#7fae4e" position={[0.9, -0.5, 0.3]} radius={0.3} explodeDir={[1.5, 0.4, 0]} label="Plumule in coleoptile"><coneGeometry args={[0.16, 0.5, 8]} /></Part>
          <Part id="radicle" color="#e3dcb0" position={[0.9, -1.95, 0.3]} rotation={[Math.PI, 0, 0]} radius={0.3} explodeDir={[1.5, -1.2, 0]} label="Radicle in coleorhiza"><coneGeometry args={[0.14, 0.5, 8]} /></Part>
          <Tag position={[-1.8, 2.4, 0]} text="Grass grain (caryopsis) — longitudinal cutaway" sub="endosperm-rich monocot seed" offset={[-0.5, 0.6, 0]} />
        </group>
      ) : (
        <group>
          <Part id="seed-coat" color="#8b5a2b" side={THREE.DoubleSide} radius={3} label="Seed coat (testa)"><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 32, 24, Math.PI * 0.55, Math.PI * 1.45); g.scale(1.5, 2.4, 1.1); return g; })()} /></Part>
          {[-1, 1].map((s) => <Part key={s} id="cotyledon" color="#e9e2b0" position={[0, 0, s * 0.42]} radius={2} noRegister={s > 0} explodeDir={[0, 0, s * 1.5]} label="Cotyledon (storage seed leaf)"><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 24, 16, 0, Math.PI); g.scale(1.3, 2.2, 0.8); g.rotateY(s > 0 ? 0 : Math.PI); return g; })()} /></Part>)}
          <Part id="embryo" color="#b9d47a" position={[0.5, 0.2, 0]} radius={1} explodeDir={[0.8, 0, 0]} label="Embryo axis (hypocotyl)"><capsuleGeometry args={[0.16, 1.6, 6, 12]} /></Part>
          <Part id="plumule" color="#7fae4e" position={[0.5, 1.3, 0]} radius={0.3} explodeDir={[0.8, 0.6, 0]}><sphereGeometry args={[0.24, 12, 10]} /></Part>
          <Part id="radicle" color="#e3dcb0" position={[0.5, -1.15, 0]} rotation={[Math.PI, 0, 0]} radius={0.3} explodeDir={[0.8, -0.6, 0]}><coneGeometry args={[0.16, 0.6, 10]} /></Part>
          <Tag position={[-1.8, 2.4, 0]} text="Eudicot seed — cutaway" sub={sp.id === 'sunflower' ? 'sunflower "seed" is an achene: fruit wall + oil-rich cotyledons, no endosperm at maturity' : 'reserves in cotyledons (endosperm largely absorbed)'} offset={[-0.5, 0.6, 0]} />
        </group>
      )}
    </group>
  );
}

// ─── FRUIT ───────────────────────────────────────────────────────────────────
export function FruitScene() {
  const sp = useSpecies(); const p = useParams();
  const type = p.fruitType;
  const seeds = useMemo(() => { const r = rng(6); return Array.from({ length: 24 }, (_, i) => { const loc = i % 3; const a = (loc / 3) * Math.PI * 2 + 0.5 + (r() - 0.5) * 0.8; const rad = 0.9 + r() * 0.5; return { pos: [Math.cos(a) * rad, (r() - 0.5) * 1.6, Math.sin(a) * rad] as [number, number, number], rot: [r() * 3, r() * 3, 0] as [number, number, number] }; }); }, []);
  const kernels = useMemo(() => { const out: { pos: [number, number, number] }[] = []; for (let row = 0; row < 14; row++) for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2 + (row % 2) * 0.26; out.push({ pos: [Math.cos(a) * 1.35, row * 0.42 - 2.7, Math.sin(a) * 1.35] }); } return out.filter((k) => Math.atan2(k.pos[2], k.pos[0]) > -1.0); }, []);
  if (type === 'cob') return <group>
    <Part id="fruit" color="#e9e0b0" radius={3} label="Cob (rachis)"><cylinderGeometry args={[1.1, 1.0, 6, 24]} /></Part>
    <Instances id="seed" geometry={ellipsoid(0.24, 0.2, 0.2)} color={p.fruitColor} items={kernels} label="Kernels (caryopses)" radius={2} />
    <Part id="leaf" color="#8fbf5a" position={[0, 0, 0]} radius={3} side={THREE.DoubleSide} opacity={0.9} label="Husk leaves"><cylinderGeometry args={[1.9, 1.7, 6.2, 24, 1, true, Math.PI * 0.2, Math.PI * 1.2]} /></Part>
    <Tag position={[-2.2, 3.4, 0]} text="Maize ear (cutaway husk)" sub="each kernel is a one-seeded fruit (caryopsis)" offset={[-0.5, 0.6, 0]} /></group>;
  if (type === 'caryopsis' || type === 'achene') return <group>
    <Part id="exocarp" color={type === 'achene' ? '#3a2f2a' : '#d9b45a'} side={THREE.DoubleSide} radius={3} label={type === 'achene' ? 'Pericarp (achene hull)' : 'Pericarp fused to testa'}><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 32, 24, Math.PI * 0.5, Math.PI * 1.5); g.scale(1.6, 2.8, 1.0); return g; })()} /></Part>
    <Part id="seed" color="#f1e6b5" radius={2} explodeDir={[0, 0.5, 0]}><primitive attach="geometry" object={ellipsoid(1.3, 2.4, 0.8)} /></Part>
    <Tag position={[-2, 3, 0]} text={type === 'achene' ? 'Sunflower achene — dry, one-seeded fruit' : 'Grain (caryopsis)'} sub="cutaway: fruit wall around a single seed" offset={[-0.5, 0.6, 0]} /></group>;
  const drupe = type === 'drupe'; const hip = type === 'hip';
  return (
    <group>
      <Part id="exocarp" color={p.fruitColor} side={THREE.DoubleSide} radius={3} clearcoat={0.7} roughness={0.3} label={hip ? 'Hypanthium skin (rose hip)' : 'Exocarp (skin)'}><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 40, 28, Math.PI * 0.55, Math.PI * 1.45); g.scale(drupe ? 2.0 : 2.5, drupe ? 3.0 : 2.3, drupe ? 1.8 : 2.5); return g; })()} /></Part>
      <Part id="mesocarp" color={drupe ? '#f4b942' : hip ? '#f0a070' : '#e05b40'} side={THREE.DoubleSide} radius={2.4} explodeDir={[0, 0, 0]} label={hip ? 'Fleshy hypanthium' : 'Mesocarp / pericarp flesh'}><primitive attach="geometry" object={(() => { const g = new THREE.SphereGeometry(1, 40, 28, Math.PI * 0.55, Math.PI * 1.45); g.scale(drupe ? 1.8 : 2.2, drupe ? 2.8 : 2.0, drupe ? 1.6 : 2.2); return g; })()} /></Part>
      {drupe ? (
        <>
          <Part id="endocarp" color="#c9b27a" radius={1.5} explodeDir={[0.5, 0, 0]} label="Stony fibrous endocarp"><primitive attach="geometry" object={ellipsoid(0.9, 2.0, 0.5)} /></Part>
          <Part id="seed" color="#efe3c0" position={[0, 0, 0]} radius={1} explodeDir={[1.2, 0, 0]}><primitive attach="geometry" object={ellipsoid(0.6, 1.6, 0.3)} /></Part>
        </>
      ) : (
        <>
          <Part id="endocarp" color="#f6d7cf" radius={1.2} opacity={0.75} explodeDir={[0, 0, 0]} label={hip ? 'Achenes in the hip cavity' : 'Locules with placental gel'}><sphereGeometry args={[1.6, 24, 16, Math.PI * 0.55, Math.PI * 1.45]} /></Part>
          <Part id="fruit" color="#f3e6d0" radius={0.6} noRegister label="Columella / placenta"><cylinderGeometry args={[0.35, 0.35, 3.2, 12]} /></Part>
          <Instances id="seed" geometry={ellipsoid(0.16, 0.22, 0.08)} color="#f5efd0" items={seeds} radius={0.5} label={hip ? 'Achenes (true fruits)' : 'Seeds'} />
        </>
      )}
      {[0.4, 1.6, 2.8, 4.0].map((a, i) => <Part key={i} id="fruit-vascular" color="#c9d38a" position={[Math.cos(a) * (drupe ? 1.5 : 1.9), 0, Math.sin(a) * (drupe ? 1.3 : 1.9)]} noRegister={i > 0} radius={0.3}><cylinderGeometry args={[0.05, 0.05, drupe ? 4.6 : 3.4, 6]} /></Part>)}
      <Tag position={[-2.6, 2.8, 0]} text={drupe ? 'Mango drupe — cutaway' : hip ? 'Rose hip — accessory fruit (cutaway)' : `${sp.common} berry — cutaway`} sub="skin · flesh · vascular strands · seeds" offset={[-0.5, 0.6, 0]} />
    </group>
  );
}

// ─── TISSUE ENVIRONMENTS ─────────────────────────────────────────────────────
export function TissueScene({ kind }: { kind: string }) {
  const q = useQuality(); const transport = useStore((s) => s.transport);
  const f = q.instances;
  const built = useMemo(() => build(kind, f), [kind, f]);
  const vertical = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(0, -5, 0), new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 5, 0)]), new THREE.CatmullRomCurve3([new THREE.Vector3(1.3, -5, 0), new THREE.Vector3(1.3, 0, 0), new THREE.Vector3(1.3, 5, 0)]), new THREE.CatmullRomCurve3([new THREE.Vector3(-1.3, -5, 0.2), new THREE.Vector3(-1.3, 0, 0.2), new THREE.Vector3(-1.3, 5, 0.2)])], []);
  return (
    <group>
      {built.groups.map((g, i) => <Instances key={i} id={g.id} geometry={g.geo} color={g.color} items={g.items} label={g.label} opacity={g.opacity} alwaysLabel={i === 0} radius={3} ignoreFocus={g.ignoreFocus} flatShading={g.flat} />)}
      {built.extra}
      <Tag position={[-4, 3.4, 0]} text={built.title} sub={built.sub} offset={[-0.4, 0.7, 0]} />
      {transport && (kind === 'xylem' || kind === 'phloem') && <><FlowParticles curves={vertical} count={260} color={kind === 'xylem' ? '#5fc9ff' : '#ffb347'} size={0.1} speed={kind === 'xylem' ? 0.25 : 0.12} spread={0.3} reverse={kind === 'phloem'} /><Tag position={[3, 3, 0]} text="CONCEPTUAL FLOW VISUALIZATION" offset={[0.5, 0.5, 0]} /></>}
    </group>
  );
}

interface TGroup { id: string; geo: THREE.BufferGeometry; color: string; items: { pos: [number, number, number]; rot?: [number, number, number]; scale?: number | [number, number, number]; color?: string }[]; label?: string; opacity?: number; ignoreFocus?: boolean; flat?: boolean }
function build(kind: string, f: number): { groups: TGroup[]; title: string; sub: string; extra?: React.ReactNode } {
  const r = rng(kind.length * 7);
  const groups: TGroup[] = [];
  const nuclei = (cells: { pos: [number, number, number] }[], size = 0.18) => ({ id: 'nucleus', geo: new THREE.SphereGeometry(size, 10, 8), color: C.nucleus, items: cells.map((c) => ({ pos: [c.pos[0] + 0.15, c.pos[1] + 0.1, c.pos[2]] as [number, number, number] })), label: 'Nuclei', ignoreFocus: true } as TGroup);
  switch (kind) {
    case 'parenchyma': { const cells = grid(Math.round(6 * f) + 1, 4, Math.round(4 * f) + 1, 1.25, 0.15, 1); groups.push({ id: 'parenchyma-cell', geo: blob(0.55, 0.12, 2, 2), color: C.parenchyma, items: cells, opacity: 0.85 }, nuclei(cells)); return { groups, title: 'Parenchyma', sub: 'thin-walled living cells with intercellular spaces' }; }
    case 'collenchyma': { const cells = grid(Math.round(5 * f) + 1, 2, Math.round(4 * f) + 1, 1.0, 0.03, 2).map((c) => ({ ...c, rot: [0, 0, 0] as [number, number, number], scale: [0.92, 2.6, 0.92] as [number, number, number] })); groups.push({ id: 'collenchyma-cell', geo: new THREE.BoxGeometry(1, 1, 1), color: C.collenchyma, items: cells, opacity: 0.9 }); groups.push({ id: 'cell-wall', geo: new THREE.CylinderGeometry(0.16, 0.16, 2.62, 6), color: '#d9b98a', items: cells.flatMap((c) => [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([dx, dz]) => ({ pos: [c.pos[0] + dx * 0.46, c.pos[1], c.pos[2] + dz * 0.46] as [number, number, number] }))), label: 'Corner wall thickenings (pectin-rich)', ignoreFocus: true }); return { groups, title: 'Collenchyma', sub: 'living support cells with unevenly thickened primary walls' }; }
    case 'sclerenchyma': { const cells = grid(Math.round(6 * f) + 1, 1, Math.round(5 * f) + 1, 0.75, 0.05, 3).map((c) => ({ ...c, rot: [0, 0, 0] as [number, number, number], scale: [0.7, 9, 0.7] as [number, number, number] })); groups.push({ id: 'fibre-cell', geo: new THREE.CylinderGeometry(0.5, 0.5, 1, 8), color: C.fibre, items: cells }); groups.push({ id: 'cell-wall', geo: new THREE.CylinderGeometry(0.12, 0.12, 1, 6), color: '#3a2a1a', items: cells.map((c) => ({ pos: [c.pos[0], c.pos[1] + 4.51, c.pos[2]] as [number, number, number], scale: [1, 0.05, 1] as [number, number, number] })), label: 'Narrow lumen', ignoreFocus: true }); return { groups, title: 'Sclerenchyma fibres', sub: 'dead cells with thick lignified secondary walls' }; }
    case 'epidermis': case 'epidermis-root': { const root = kind === 'epidermis-root'; const cells = grid(Math.round(7 * f) + 1, 1, Math.round(6 * f) + 1, 1.05, 0.1, 4).map((c) => ({ ...c, rot: [0, r() * 0.2, 0] as [number, number, number], scale: [1, 0.45, 0.9] as [number, number, number] })); groups.push({ id: root ? 'root-hair-cell' : 'epidermal-cell', geo: new THREE.BoxGeometry(1, 1, 1), color: C.epidermis, items: cells }, nuclei(cells, 0.14)); if (root) groups.push({ id: 'root-hair-cell', geo: new THREE.CylinderGeometry(0.08, 0.05, 4, 6), color: '#f4f0dc', items: cells.filter((_, i) => i % 3 === 0).map((c) => ({ pos: [c.pos[0], c.pos[1] + 2.2, c.pos[2]] as [number, number, number], rot: [r() * 0.3, 0, r() * 0.3] as [number, number, number] })), label: 'Root hairs (trichoblast extensions)' }); else groups.push({ id: 'cuticle', geo: new THREE.BoxGeometry(1.05, 0.08, 0.95), color: C.cuticle, items: cells.map((c) => ({ pos: [c.pos[0], c.pos[1] + 0.27, c.pos[2]] as [number, number, number] })), label: 'Cuticle', opacity: 0.6 }); return { groups, title: root ? 'Root epidermis' : 'Epidermis', sub: root ? 'single layer with root hairs; no cuticle' : 'single layer of pavement cells under a cuticle' }; }
    case 'endodermis': { const n = Math.round(22 * f) + 4; const cells = Array.from({ length: n }, (_, i) => { const a = (i / n) * Math.PI * 2; return { pos: [Math.cos(a) * 3, 0, Math.sin(a) * 3] as [number, number, number], rot: [0, -a, 0] as [number, number, number], scale: [0.7, 1.6, 0.75] as [number, number, number] }; }); groups.push({ id: 'endodermal-cell', geo: new THREE.BoxGeometry(1, 1, 1), color: C.endodermis, items: cells }); groups.push({ id: 'endodermal-cell', geo: new THREE.BoxGeometry(0.75, 1.62, 0.08), color: C.casparian, items: cells.map((_c, i) => { const a = ((i + 0.5) / n) * Math.PI * 2; return { pos: [Math.cos(a) * 3, 0, Math.sin(a) * 3] as [number, number, number], rot: [0, -a, 0] as [number, number, number] }; }), label: 'Casparian strip (radial walls)' }); return { groups, title: 'Endodermis', sub: 'ring of cells with Casparian strips (red) blocking apoplastic flow' }; }
    case 'meristem': { const cells = grid(Math.round(7 * f) + 1, 5, Math.round(6 * f) + 1, 0.72, 0.03, 5).map((c) => ({ ...c, rot: [0, 0, 0] as [number, number, number], scale: 0.68 })); groups.push({ id: 'meristematic-cell', geo: new THREE.BoxGeometry(1, 1, 1), color: C.meristem, items: cells, opacity: 0.7 }, { ...nuclei(cells, 0.22), items: cells.map((c) => ({ pos: c.pos })) }); return { groups, title: 'Meristematic tissue', sub: 'small isodiametric dividing cells with large nuclei' }; }
    case 'xylem': { const vessels: TGroup['items'] = []; const rings: TGroup['items'] = []; const tracheids: TGroup['items'] = []; const cols = [[0, 0], [1.3, 0], [-1.3, 0.2], [0.6, 1.2], [-0.7, -1.2]]; cols.forEach(([x, z], ci) => { for (let k = 0; k < 6; k++) { vessels.push({ pos: [x, k * 1.7 - 4.3, z], scale: [1, 1, 1] }); for (let t = 0; t < 4; t++) rings.push({ pos: [x, k * 1.7 - 4.3 + t * 0.4 - 0.6, z], rot: [Math.PI / 2, 0, 0] }); } if (ci > 2) return; }); for (let i = 0; i < 6; i++) tracheids.push({ pos: [2.4, i * 1.5 - 4, (i % 2) * 0.5 - 0.5], scale: [0.5, 1, 0.5] }, { pos: [-2.4, i * 1.5 - 3.7, (i % 2) * 0.5 - 0.2], scale: [0.5, 1, 0.5] }); groups.push({ id: 'vessel-element', geo: new THREE.CylinderGeometry(0.48, 0.48, 1.6, 16, 1, true), color: C.xylem, items: vessels, opacity: 0.55 }); groups.push({ id: 'vessel-element', geo: new THREE.TorusGeometry(0.5, 0.06, 6, 20), color: '#8a2a1e', items: rings, label: 'Annular / helical secondary-wall thickenings', ignoreFocus: true }); groups.push({ id: 'vessel-element', geo: new THREE.TorusGeometry(0.45, 0.05, 6, 20), color: '#5a1a12', items: vessels.map((v) => ({ pos: [v.pos[0], v.pos[1] + 0.8, v.pos[2]] as [number, number, number], rot: [Math.PI / 2, 0, 0] as [number, number, number] })), label: 'Perforation plates between vessel elements', ignoreFocus: true }); groups.push({ id: 'tracheid', geo: new THREE.CapsuleGeometry(0.5, 1.2, 4, 10), color: '#b8443a', items: tracheids, opacity: 0.7 }); return { groups, title: 'Xylem', sub: 'stacked dead vessel elements (perforation plates) + tapered tracheids; lignified walls' }; }
    case 'phloem': { const tubes: TGroup['items'] = []; const plates: TGroup['items'] = []; const comps: TGroup['items'] = []; [[0, 0], [1.4, 0.3], [-1.4, -0.3]].forEach(([x, z]) => { for (let k = 0; k < 6; k++) { tubes.push({ pos: [x, k * 1.6 - 4, z] }); plates.push({ pos: [x, k * 1.6 - 3.2, z], rot: [Math.PI / 2, 0, 0] }); comps.push({ pos: [x + 0.62, k * 1.6 - 4, z + 0.1], scale: [0.35, 1.5, 0.45] }); } }); groups.push({ id: 'sieve-tube-element', geo: new THREE.CylinderGeometry(0.4, 0.4, 1.55, 16), color: C.phloem, items: tubes, opacity: 0.5 }); groups.push({ id: 'sieve-tube-element', geo: new THREE.TorusGeometry(0.36, 0.06, 6, 24), color: '#8a5a1a', items: plates, label: 'Sieve plates (perforated end walls)', ignoreFocus: true }); groups.push({ id: 'companion-cell', geo: new THREE.BoxGeometry(1, 1, 1), color: '#c98a3a', items: comps }); groups.push({ ...nuclei(comps, 0.12), items: comps.map((c) => ({ pos: c.pos })) }); return { groups, title: 'Phloem', sub: 'living sieve tubes (no nucleus) with sieve plates + dense companion cells' }; }
    case 'palisade': { const cells = grid(Math.round(6 * f) + 1, 1, Math.round(5 * f) + 1, 0.95, 0.06, 6).map((c) => ({ ...c, rot: [0, 0, 0] as [number, number, number], scale: 1 })); const chl = cells.flatMap((c) => Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * Math.PI * 2; return { pos: [c.pos[0] + Math.cos(a) * 0.3, c.pos[1] + (r() - 0.5) * 2.6, c.pos[2] + Math.sin(a) * 0.3] as [number, number, number] }; })); groups.push({ id: 'palisade-cell', geo: new THREE.CapsuleGeometry(0.4, 2.6, 4, 12), color: '#a9d68a', items: cells, opacity: 0.45 }); groups.push({ id: 'chloroplast', geo: ellipsoid(0.13, 0.08, 0.13), color: C.chloroplast, items: chl, label: 'Chloroplasts (peripheral)', ignoreFocus: true }, nuclei(cells)); return { groups, title: 'Palisade mesophyll', sub: 'columnar chlorenchyma; ~70 % of leaf chloroplasts' }; }
    case 'spongy': { const cells = grid(Math.round(5 * f) + 1, 3, Math.round(4 * f) + 1, 1.35, 0.35, 7, 0.2); const chl = cells.flatMap((c) => Array.from({ length: 6 }, () => ({ pos: [c.pos[0] + (r() - 0.5) * 0.7, c.pos[1] + (r() - 0.5) * 0.7, c.pos[2] + (r() - 0.5) * 0.7] as [number, number, number] }))); groups.push({ id: 'spongy-cell', geo: blob(0.55, 0.4, 8, 2), color: '#bfe0a0', items: cells, opacity: 0.55 }); groups.push({ id: 'chloroplast', geo: ellipsoid(0.12, 0.08, 0.12), color: C.chloroplast, items: chl, label: 'Chloroplasts', ignoreFocus: true }, nuclei(cells, 0.15)); return { groups, title: 'Spongy mesophyll', sub: 'irregular lobed cells with large air spaces' }; }
    case 'mesophyll': { const pal = grid(Math.round(7 * f) + 1, 1, Math.round(5 * f) + 1, 0.9, 0.05, 9).map((c) => ({ ...c, pos: [c.pos[0], 1.6, c.pos[2]] as [number, number, number], rot: [0, 0, 0] as [number, number, number], scale: 1 })); const spo = grid(Math.round(5 * f) + 1, 2, Math.round(4 * f) + 1, 1.3, 0.35, 10, 0.2).map((c) => ({ ...c, pos: [c.pos[0], c.pos[1] - 1.4, c.pos[2]] as [number, number, number] })); groups.push({ id: 'palisade-mesophyll', geo: new THREE.CapsuleGeometry(0.38, 2.2, 4, 12), color: '#a9d68a', items: pal, opacity: 0.6 }); groups.push({ id: 'spongy-mesophyll', geo: blob(0.55, 0.4, 8, 2), color: '#bfe0a0', items: spo, opacity: 0.6 }); groups.push({ id: 'chloroplast', geo: ellipsoid(0.12, 0.08, 0.12), color: C.chloroplast, items: [...pal.flatMap((c) => Array.from({ length: 10 }, (_, i) => ({ pos: [c.pos[0] + Math.cos(i) * 0.28, c.pos[1] + (r() - 0.5) * 2.2, c.pos[2] + Math.sin(i) * 0.28] as [number, number, number] }))), ...spo.flatMap((c) => Array.from({ length: 5 }, () => ({ pos: [c.pos[0] + (r() - 0.5) * 0.7, c.pos[1] + (r() - 0.5) * 0.7, c.pos[2] + (r() - 0.5) * 0.7] as [number, number, number] })))], label: 'Chloroplasts', ignoreFocus: true }); return { groups, title: 'Mesophyll', sub: 'palisade layer (top) over spongy layer (bottom)' }; }
    case 'cork': { const cells = grid(Math.round(7 * f) + 1, 6, Math.round(6 * f) + 1, 0.82, 0.02, 11).map((c) => ({ ...c, rot: [0, 0, 0] as [number, number, number], scale: [0.78, 0.4, 0.78] as [number, number, number] })); groups.push({ id: 'cork', geo: new THREE.BoxGeometry(1, 1, 1), color: C.cork, items: cells, label: 'Cork cells (dead, suberised, in radial files)' }); return { groups, title: 'Periderm (cork)', sub: 'suberised dead cells produced by the cork cambium' }; }
    default: { const cells = grid(5, 3, 4, 1.25, 0.15, 1); groups.push({ id: 'parenchyma-cell', geo: blob(0.55, 0.12, 2, 2), color: C.parenchyma, items: cells }); return { groups, title: kind, sub: '' }; }
  }
}
