import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Part, Instances, FlowParticles, Tag, taperedTube, leafGeometry, petalGeometry, ellipsoid, deg, useQuality } from './core';
import { useStore, useParams, useSpecies } from '@/store';
import { rng, formatMeters } from '@/data/core';
import { growthStageAt } from '@/data/species';
import type { PlantParams, Species } from '@/data/species';

const smooth = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

interface Build {
  scale: number; // scene units per metre
  stemCurve: THREE.CatmullRomCurve3; stemGeo: THREE.BufferGeometry; h: number;
  branches: { curve: THREE.CatmullRomCurve3; geo: THREE.BufferGeometry; tip: THREE.Vector3 }[];
  leaves: { pos: [number, number, number]; rot: [number, number, number]; scale: number }[];
  leafGeo: THREE.BufferGeometry;
  roots: THREE.BufferGeometry[]; rootTips: THREE.Vector3[]; hairs: { pos: [number, number, number]; rot: [number, number, number] }[];
  flowerSpots: { pos: THREE.Vector3; dir: THREE.Vector3 }[]; fruitSpots: { pos: THREE.Vector3; dir: THREE.Vector3 }[];
  waterCurves: THREE.CatmullRomCurve3[]; sugarCurves: THREE.CatmullRomCurve3[]; nutrientCurves: THREE.CatmullRomCurve3[];
  heroLeaf: number;
}

function buildPlant(p: PlantParams, sp: Species, g: number, segments: number, instF: number): Build {
  const r = rng(p.seed);
  const scale = 8 / Math.max(0.3, p.height);
  const hFactor = smooth(0.06, 0.97, g);
  const h = p.height * scale * Math.max(0.05, hFactor);
  const grass = sp.type === 'monocot';
  const fern = sp.type === 'fern';
  const stemR = (p.stemThickness / 2) * scale * (0.4 + 0.6 * hFactor);
  // stem
  const lean = (r() - 0.5) * 0.15 * h;
  const stemPts = fern
    ? [new THREE.Vector3(-0.4, -0.1, 0), new THREE.Vector3(0, 0.05, 0), new THREE.Vector3(0.5, 0.15, 0.05)]
    : [new THREE.Vector3(0, -0.05, 0), new THREE.Vector3(lean * 0.3, h * 0.35, 0), new THREE.Vector3(lean * 0.7, h * 0.7, lean * 0.2), new THREE.Vector3(lean, h, lean * 0.3)];
  const stemCurve = new THREE.CatmullRomCurve3(stemPts);
  const radial = sp.id === 'mint' ? 4 : 12;
  const stemGeo = taperedTube(stemCurve, fern ? stemR * 3 : stemR, fern ? stemR * 2.5 : stemR * (grass ? 0.8 : 0.45), segments, radial, p.woody ? 0.05 : 0);
  // branches
  const branches: Build['branches'] = [];
  const nBr = fern ? 0 : Math.round(p.branchCount * smooth(0.2, 0.8, g));
  for (let i = 0; i < nBr; i++) {
    const t = grass ? 0.02 : 0.25 + (i / Math.max(1, nBr)) * 0.6;
    const base = stemCurve.getPointAt(t);
    const ang = i * deg(137.5) + r() * 0.5;
    const len = (grass ? h * (0.7 + r() * 0.3) : (p.height * scale) * (0.25 + r() * 0.2) * (1 - t * 0.5)) * smooth(0.2, 0.9, g);
    const up = grass ? 0.9 : 0.55 + r() * 0.3;
    const dir = new THREE.Vector3(Math.cos(ang) * (1 - up), up, Math.sin(ang) * (1 - up)).normalize();
    const mid = base.clone().addScaledVector(dir, len * 0.5).add(new THREE.Vector3(0, len * 0.08, 0));
    const tip = base.clone().addScaledVector(dir, len).add(new THREE.Vector3(0, grass ? 0 : -len * 0.05, 0));
    const curve = new THREE.CatmullRomCurve3([base, mid, tip]);
    branches.push({ curve, geo: taperedTube(curve, stemR * (grass ? 0.9 : 0.5), stemR * 0.15, Math.max(8, segments / 2), 8), tip });
  }
  // leaves
  const nLeafTotal = Math.round(p.leafCount * instF);
  const nLeaf = Math.round(nLeafTotal * smooth(0.12, 0.75, g));
  const leafLen = p.leafSize * scale * (0.6 + 0.4 * smooth(0.15, 0.8, g));
  const leafGeo = leafGeometry(p.leafShape, 1, p.leafShape === 'linear' ? 0.08 : p.leafShape === 'frond' ? 0.35 : p.leafShape === 'lanceolate' ? 0.32 : 0.7, fern ? 0.25 : 0.15);
  const leaves: Build['leaves'] = [];
  const carriers: { curve: THREE.Curve<THREE.Vector3>; t0: number; t1: number }[] = [{ curve: stemCurve, t0: fern ? 0.05 : grass ? 0.1 : 0.15, t1: fern ? 0.95 : 0.95 }];
  for (const b of branches) carriers.push({ curve: b.curve, t0: 0.3, t1: 1 });
  for (let i = 0; i < nLeaf; i++) {
    const c = carriers[i % carriers.length];
    const k = Math.floor(i / carriers.length);
    const per = Math.ceil(nLeaf / carriers.length);
    const t = c.t0 + (c.t1 - c.t0) * ((k + 0.5) / per);
    const pos = c.curve.getPointAt(t);
    const ang = fern ? (i / nLeaf) * Math.PI * 2 + r() * 0.3 : i * deg(137.5) + (sp.id === 'mint' && i % 2 ? Math.PI : 0);
    const tilt = fern ? deg(30 + r() * 25) : deg(p.leafAngle) * (0.8 + r() * 0.4);
    const sc = fern ? leafLen * (0.7 + r() * 0.5) : leafLen * (0.6 + r() * 0.6) * (grass ? 1 : 1 - t * 0.3);
    leaves.push({ pos: [pos.x, pos.y, pos.z], rot: [tilt, -ang + Math.PI / 2, 0], scale: sc });
  }
  // roots
  const roots: THREE.BufferGeometry[] = []; const rootTips: THREE.Vector3[] = []; const hairs: Build['hairs'] = [];
  const rootF = smooth(0.03, 0.6, g);
  const rDepth = p.rootDepth * scale * rootF; const rSpread = p.rootSpread * scale * rootF;
  const makeRoot = (start: THREE.Vector3, dir: THREE.Vector3, len: number, rad: number, depth: number) => {
    const mid = start.clone().addScaledVector(dir, len * 0.5).add(new THREE.Vector3((r() - 0.5) * len * 0.3, 0, (r() - 0.5) * len * 0.3));
    const end = start.clone().addScaledVector(dir, len);
    const curve = new THREE.CatmullRomCurve3([start, mid, end]);
    roots.push(taperedTube(curve, rad, rad * 0.25, 10, 6));
    if (depth >= 1 || r() < 0.4) { rootTips.push(end); for (let i = 0; i < 5; i++) { const t = 0.6 + r() * 0.35; const q = curve.getPointAt(t); hairs.push({ pos: [q.x, q.y, q.z], rot: [r() * 3, r() * 3, r() * 3] }); } }
    if (depth < 2 && len > 0.4) { const n = 2 + Math.floor(r() * 3); for (let i = 0; i < n; i++) { const t = 0.2 + r() * 0.6; const b = curve.getPointAt(t); const d = new THREE.Vector3(r() - 0.5, -0.3 - r() * 0.5, r() - 0.5).normalize(); makeRoot(b, d, len * (0.35 + r() * 0.3), rad * 0.4, depth + 1); } }
  };
  if (p.fibrousRoots || grass) { const n = Math.round(14 * instF); for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; const d = new THREE.Vector3(Math.cos(a) * (0.3 + r() * 0.5), -1, Math.sin(a) * (0.3 + r() * 0.5)).normalize(); makeRoot(new THREE.Vector3(0, 0, 0), d, rDepth * (0.5 + r() * 0.5), stemR * 0.35, 1); } }
  else { makeRoot(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.05, -1, 0.02).normalize(), rDepth, stemR * 0.9, 0); const n = Math.round(6 * instF); for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + r(); const d = new THREE.Vector3(Math.cos(a), -0.35 - r() * 0.4, Math.sin(a)).normalize(); makeRoot(new THREE.Vector3(0, -rDepth * (0.05 + r() * 0.3), 0), d, rSpread * (0.6 + r() * 0.5), stemR * 0.4, 1); } }
  // flowers & fruit spots
  const top = stemCurve.getPointAt(1);
  const spots: { pos: THREE.Vector3; dir: THREE.Vector3 }[] = [{ pos: top, dir: new THREE.Vector3(0, 1, 0) }];
  for (const b of branches) spots.push({ pos: b.tip, dir: b.curve.getTangentAt(1) });
  if (sp.id === 'mint') for (let i = 0; i < 4; i++) spots.push({ pos: stemCurve.getPointAt(0.65 + i * 0.1), dir: new THREE.Vector3(0, 1, 0) });
  if (sp.id === 'maize') spots.push({ pos: stemCurve.getPointAt(0.5).add(new THREE.Vector3(stemR * 1.5, 0, 0)), dir: new THREE.Vector3(0.6, 1, 0).normalize() });
  const flowerSpots = spots.slice(0, Math.max(0, p.flowerCount));
  const fruitSpots = sp.id === 'maize' ? spots.slice(-2) : sp.id === 'tomato' || sp.id === 'mango' ? spots.slice(1, 1 + p.fruitCount).map((s) => ({ pos: s.pos.clone().add(new THREE.Vector3(0, -0.2, 0)), dir: s.dir })) : spots.slice(0, p.fruitCount);
  // transport curves
  const waterCurves: THREE.CatmullRomCurve3[] = []; const sugarCurves: THREE.CatmullRomCurve3[] = []; const nutrientCurves: THREE.CatmullRomCurve3[] = [];
  const tips = rootTips.slice(0, 6);
  for (let i = 0; i < Math.min(6, Math.max(1, leaves.length)); i++) {
    const lf = leaves[Math.floor((i / 6) * leaves.length)] ?? { pos: [top.x, top.y, top.z] };
    const rt = tips[i % Math.max(1, tips.length)] ?? new THREE.Vector3(0, -1, 0);
    const leafP = new THREE.Vector3(...(lf.pos as [number, number, number]));
    const attachT = Math.min(0.98, Math.max(0.02, leafP.y / Math.max(0.1, h)));
    waterCurves.push(new THREE.CatmullRomCurve3([rt, new THREE.Vector3(0, -0.05, 0), stemCurve.getPointAt(attachT * 0.5), stemCurve.getPointAt(attachT), leafP]));
    sugarCurves.push(new THREE.CatmullRomCurve3([leafP, stemCurve.getPointAt(attachT), stemCurve.getPointAt(attachT * 0.5), new THREE.Vector3(0, -0.05, 0), rt]));
    nutrientCurves.push(new THREE.CatmullRomCurve3([rt.clone().add(new THREE.Vector3((r() - 0.5) * 2, -0.5, (r() - 0.5) * 2)), rt, new THREE.Vector3(0, -0.05, 0), stemCurve.getPointAt(attachT)]));
  }
  return { scale, stemCurve, stemGeo, h, branches, leaves, leafGeo, roots, rootTips, hairs, flowerSpots, fruitSpots, waterCurves, sugarCurves, nutrientCurves, heroLeaf: Math.floor(leaves.length * 0.6) };
}

export default function PlantScene() {
  const p = useParams(); const sp = useSpecies(); const q = useQuality();
  const growthMode = useStore((s) => s.growthMode); const growth = useStore((s) => s.growthMode ? s.growth : 1);
  const transport = useStore((s) => s.transport); const nutrients = useStore((s) => s.nutrients);
  const living = useStore((s) => s.living); const reduced = useStore((s) => s.reducedMotion);
  const b = useMemo(() => buildPlant(p, sp, growth, q.segments, q.instances), [p, sp, growth, q.segments, q.instances]);
  const sway = useRef<THREE.Group>(null!);
  useFrame(({ clock }) => { if (!sway.current) return; const t = clock.elapsedTime; const a = living && !reduced ? Math.sin(t * 0.7) * 0.012 + Math.sin(t * 1.9) * 0.004 : 0; sway.current.rotation.z = a; sway.current.rotation.x = a * 0.6; });
  const stage = growthStageAt(growth);
  const seedVisible = growth < 0.1;
  const flowerF = smooth(0.62, 0.8, growth) * (sp.hasFlower ? 1 : 0);
  const fruitF = smooth(0.82, 0.96, growth) * (sp.hasFruit ? 1 : 0);
  const leafItems = useMemo(() => b.leaves.map((l) => ({ pos: l.pos, rot: l.rot, scale: l.scale })), [b]);
  const hairGeo = useMemo(() => new THREE.CylinderGeometry(0.004, 0.002, 0.16, 4), []);
  const hero = b.leaves[b.heroLeaf];

  return (
    <group>
      {/* ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.001, 0]} receiveShadow>
        <ringGeometry args={[0.02, 6, 48]} />
        <meshStandardMaterial color="#3b2f25" transparent opacity={0.55} roughness={1} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.002, 0]}><circleGeometry args={[6, 48]} /><meshStandardMaterial color="#1c1611" transparent opacity={0.25} /></mesh>

      {/* roots */}
      <group>
        {b.roots.map((g, i) => <Part key={i} id="root-system" geometry={g} color={p.fibrousRoots ? '#cfc2a0' : '#d8c9a6'} roughness={0.9} noRegister={i > 0} radius={2} />)}
        {b.hairs.length > 0 && <Instances id="root-tip" geometry={hairGeo} color="#efe7d0" items={b.hairs} label="Root hairs (root tip zone)" radius={0.5} />}
      </group>

      {/* seed */}
      {seedVisible && <Part id="seed" position={[0, 0.12, 0]} color="#8b6b3d" radius={0.3}><primitive object={ellipsoid(0.16, 0.24, 0.12)} attach="geometry" /></Part>}

      <group ref={sway}>
        {/* stem */}
        <Part id="stem" geometry={b.stemGeo} color={p.woody ? '#6b5540' : p.stemColor} roughness={p.woody ? 0.95 : 0.6} radius={b.h * 0.5} />
        {b.branches.map((br, i) => <Part key={i} id="stem" geometry={br.geo} color={p.woody ? '#75604a' : p.stemColor} noRegister radius={1} />)}

        {/* leaves */}
        {leafItems.length > 0 && <Instances id="leaf" geometry={b.leafGeo} color={p.leafColor} items={leafItems} roughness={0.55} radius={hero?.scale ?? 1} />}
        {hero && <group position={hero.pos} rotation={hero.rot}><mesh geometry={b.leafGeo} scale={hero.scale} visible={false} /></group>}
        <LeafBackfaces geo={b.leafGeo} items={leafItems} color={p.leafColor} />

        {/* flowers */}
        {flowerF > 0.01 && b.flowerSpots.map((s, i) => <group key={i} position={s.pos} scale={flowerF}><Flower type={p.flowerType} sp={sp} p={p} dir={s.dir} scale={b.scale} idx={i} /></group>)}
        {/* fruit */}
        {fruitF > 0.01 && b.fruitSpots.map((s, i) => <group key={i} position={s.pos} scale={fruitF}><Fruit type={p.fruitType} p={p} scale={b.scale} idx={i} /></group>)}
        {sp.type === 'fern' && <Sori leaves={leafItems} />}
      </group>

      {/* transport */}
      {transport && <>
        <FlowParticles curves={b.waterCurves} count={400} color="#5fc9ff" size={0.09} speed={0.12} spread={0.06} />
        <FlowParticles curves={b.sugarCurves} count={220} color="#ffb347" size={0.08} speed={0.08} spread={0.08} seed={3} />
        <Tag position={[b.h * 0.05 + 0.6, b.h * 0.5, 0]} text="CONCEPTUAL TRANSPORT VISUALIZATION" sub="blue: xylem water (root→leaf) · amber: phloem sucrose (leaf→sinks)" offset={[0.8, 0.4, 0]} />
      </>}
      {nutrients && <>
        <FlowParticles curves={b.nutrientCurves} count={150} color="#7CFC00" size={0.1} speed={0.07} spread={0.15} seed={11} />
        <FlowParticles curves={b.nutrientCurves} count={90} color="#ff8c00" size={0.1} speed={0.05} spread={0.15} seed={12} />
        <FlowParticles curves={b.nutrientCurves} count={120} color="#b070ff" size={0.1} speed={0.09} spread={0.15} seed={13} />
        <Tag position={[1.5, -0.8, 0]} text="CONCEPTUAL NUTRIENT UPTAKE" sub="green N (NO₃⁻/NH₄⁺) · orange P (phosphate) · purple K⁺ — not quantitative" offset={[1.2, -0.5, 0]} />
      </>}

      {growthMode && <Tag position={[-2.5, b.h + 0.5, 0]} text={`GROWTH STAGE: ${stage.name}`} sub={`${stage.desc} — developmental progression, not species-timed`} offset={[-0.5, 0.5, 0]} />}
      <Tag position={[0, -0.02, 2.2]} text={`${sp.common} · ${sp.scientific}`} sub={`height ≈ ${formatMeters(p.height * Math.max(0.05, smooth(0.06, 0.97, growth)))} · procedural reconstruction`} offset={[0.5, -0.6, 0]} />
    </group>
  );
}

function LeafBackfaces({ geo, items, color }: { geo: THREE.BufferGeometry; items: { pos: [number, number, number]; rot: [number, number, number]; scale: number }[]; color: string }) {
  // second instanced mesh rendering back faces (lighter underside) — avoids double-sided lighting artefacts
  const ref = useRef<THREE.InstancedMesh>(null!);
  const viewLayer = useStore((s) => s.viewLayer);
  useEffect(() => {
    if (!ref.current) return;
    const m = new THREE.Matrix4(); const q = new THREE.Quaternion(); const e = new THREE.Euler();
    items.forEach((it, i) => { e.set(...it.rot); q.setFromEuler(e); m.compose(new THREE.Vector3(...it.pos), q, new THREE.Vector3(it.scale, it.scale, it.scale)); ref.current.setMatrixAt(i, m); });
    ref.current.instanceMatrix.needsUpdate = true;
  }, [items, geo, viewLayer]);
  if (!items.length || viewLayer === 'xray') return null;
  return <instancedMesh key={items.length} ref={ref} args={[geo, undefined, items.length]} raycast={() => null}><meshStandardMaterial color={new THREE.Color(color).offsetHSL(0, -0.1, 0.12)} side={THREE.BackSide} roughness={0.7} /></instancedMesh>;
}

function Sori({ leaves }: { leaves: { pos: [number, number, number]; rot: [number, number, number]; scale: number }[] }) {
  const geo = useMemo(() => new THREE.SphereGeometry(0.02, 6, 6), []);
  const items = useMemo(() => {
    const out: { pos: [number, number, number] }[] = [];
    const m = new THREE.Matrix4(); const e = new THREE.Euler(); const v = new THREE.Vector3();
    for (const l of leaves) { e.set(...l.rot); m.makeRotationFromEuler(e); for (let i = 0; i < 10; i++) { const t = 0.2 + i * 0.07; v.set((i % 2 ? 1 : -1) * 0.08, t, -0.01).multiplyScalar(l.scale).applyMatrix4(m).add(new THREE.Vector3(...l.pos)); out.push({ pos: [v.x, v.y, v.z] }); } }
    return out;
  }, [leaves]);
  return <Instances id="leaf" geometry={geo} color="#8a5a2b" items={items} label="Sori (clusters of sporangia) — fern reproduction" radius={0.3} />;
}

function Flower({ type, sp, p, dir, scale, idx }: { type: string; sp: Species; p: PlantParams; dir: THREE.Vector3; scale: number; idx: number }) {
  const quat = useMemo(() => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize()), [dir]);
  const petalGeo = useMemo(() => petalGeometry(1, 0.45, 0.35), []);
  const r = useMemo(() => rng(idx + 5), [idx]);
  const s = Math.max(0.25, scale * 0.06);
  if (type === 'none') return null;
  if (type === 'composite') {
    const R = s * 1.6;
    const rays = Array.from({ length: 34 }, (_, i) => ({ pos: [Math.cos(i / 34 * Math.PI * 2) * R * 0.9, 0.02, Math.sin(i / 34 * Math.PI * 2) * R * 0.9] as [number, number, number], rot: [Math.PI / 2 + 0.2, 0, -(i / 34) * Math.PI * 2 + Math.PI / 2] as [number, number, number], scale: R * 0.9 }));
    const florets: { pos: [number, number, number] }[] = [];
    for (let i = 0; i < 260; i++) { const a = i * 2.39996; const rr = R * 0.85 * Math.sqrt(i / 260); florets.push({ pos: [Math.cos(a) * rr, 0.06, Math.sin(a) * rr] }); }
    return <group quaternion={quat} rotation={[0, 0, 0]}><group rotation={[0.9, 0, 0]}>
      <Part id="flower" color="#4a3222" radius={R}><cylinderGeometry args={[R * 0.9, R * 0.7, 0.12, 32]} /></Part>
      <Instances id="petal" geometry={petalGeo} color={p.petalColor} items={rays} label="Ray florets (sterile, petal-like)" radius={R} />
      <Instances id="flower" geometry={new THREE.SphereGeometry(R * 0.045, 6, 6)} color="#c88a2a" items={florets} label="Disc florets (fertile) — capitulum inflorescence" radius={R} />
      <Instances id="sepal" geometry={petalGeo} color="#4f7f36" items={Array.from({ length: 20 }, (_, i) => ({ pos: [Math.cos(i / 20 * Math.PI * 2) * R * 0.95, -0.05, Math.sin(i / 20 * Math.PI * 2) * R * 0.95] as [number, number, number], rot: [Math.PI / 2 + 0.6, 0, -(i / 20) * Math.PI * 2 + Math.PI / 2] as [number, number, number], scale: R * 0.5 }))} label="Involucral bracts (phyllaries)" />
    </group></group>;
  }
  if (type === 'rose') {
    const items: { pos: [number, number, number]; rot: [number, number, number]; scale: number }[] = [];
    for (let i = 0; i < 26; i++) { const a = i * 2.39996; const layer = i / 26; items.push({ pos: [Math.cos(a) * layer * s * 0.6, layer * -0.02, Math.sin(a) * layer * s * 0.6], rot: [-(0.15 + layer * 1.1), -a + Math.PI / 2, 0], scale: s * (0.6 + layer * 1.1) }); }
    return <group quaternion={quat}><Part id="sepal" color="#4f7f36" position={[0, -0.05, 0]} radius={s}><coneGeometry args={[s * 0.6, s * 0.7, 5]} /></Part>
      <Instances id="petal" geometry={petalGeo} color={p.petalColor} items={items} radius={s} />
      <Part id="carpel" color="#efd15b" position={[0, s * 0.3, 0]} radius={s * 0.2}><sphereGeometry args={[s * 0.18, 10, 10]} /></Part></group>;
  }
  if (type === 'star') {
    const n = 5;
    return <group quaternion={quat}><group rotation={[Math.PI, 0, 0]}>
      <Instances id="petal" geometry={petalGeo} color={p.petalColor} items={Array.from({ length: n }, (_, i) => ({ pos: [0, 0, 0] as [number, number, number], rot: [-0.9, (i / n) * Math.PI * 2, 0] as [number, number, number], scale: s * 1.3 }))} radius={s} />
      <Instances id="sepal" geometry={petalGeo} color="#5c8a3a" items={Array.from({ length: n }, (_, i) => ({ pos: [0, 0.02, 0] as [number, number, number], rot: [-1.2, (i / n) * Math.PI * 2 + 0.6, 0] as [number, number, number], scale: s * 1.0 }))} />
      <Part id="stamen" color="#e8b923" position={[0, -s * 0.35, 0]} radius={s * 0.3}><coneGeometry args={[s * 0.18, s * 0.7, 8]} /></Part>
    </group></group>;
  }
  if (type === 'spike') {
    const isMaize = sp.id === 'maize';
    const items: { pos: [number, number, number]; rot: [number, number, number]; scale: [number, number, number] }[] = [];
    const n = isMaize ? 60 : 28;
    for (let i = 0; i < n; i++) { const side = i % 2 ? 1 : -1; const y = (i / n) * s * (isMaize ? 5 : 3); items.push({ pos: isMaize ? [Math.cos(i) * s * 0.9, y, Math.sin(i) * s * 0.9] : [side * s * 0.22, y, 0], rot: [0, 0, side * 0.5], scale: isMaize ? [s * 0.08, s * 0.5, s * 0.08] : [s * 0.25, s * 0.45, s * 0.18] }); }
    return <group quaternion={quat}>
      <Instances id="flower" geometry={new THREE.SphereGeometry(1, 8, 8)} color={p.petalColor} items={items} label={isMaize ? 'Tassel (male inflorescence)' : 'Spikelets (florets in a spike)'} radius={s * 2} />
      {!isMaize && <Instances id="flower" geometry={new THREE.CylinderGeometry(0.004, 0.001, s * 2.2, 3)} color="#d6c37a" items={items.map((it) => ({ pos: [it.pos[0], it.pos[1] + s * 1, it.pos[2]] as [number, number, number], rot: [0, 0, it.rot[2] * 0.3] as [number, number, number] }))} label="Awns" />}
    </group>;
  }
  if (type === 'panicle') {
    const items: { pos: [number, number, number] }[] = [];
    for (let i = 0; i < 160; i++) { const y = r() * s * 3; const rr = (1 - y / (s * 3)) * s * 1.4 * r(); const a = r() * Math.PI * 2; items.push({ pos: [Math.cos(a) * rr, y, Math.sin(a) * rr] }); }
    return <group quaternion={quat}><Instances id="flower" geometry={new THREE.SphereGeometry(s * 0.08, 6, 6)} color={p.petalColor} items={items} label="Panicle of many small flowers" radius={s * 2} />
      <Part id="stem" color="#8a6a45" position={[0, s * 1.5, 0]} noRegister><cylinderGeometry args={[s * 0.04, s * 0.06, s * 3, 6]} /></Part></group>;
  }
  if (type === 'verticillaster') {
    const items: { pos: [number, number, number] }[] = [];
    for (let i = 0; i < 30; i++) { const a = (i / 30) * Math.PI * 2; const rr = s * (0.5 + r() * 0.3); items.push({ pos: [Math.cos(a) * rr, (r() - 0.5) * s * 0.4, Math.sin(a) * rr] }); }
    return <group><Instances id="flower" geometry={new THREE.SphereGeometry(s * 0.12, 6, 6)} color={p.petalColor} items={items} label="Verticillaster (whorl of small bilabiate flowers)" radius={s} /></group>;
  }
  return null;
}

function Fruit({ type, p, scale, idx }: { type: string; p: PlantParams; scale: number; idx: number }) {
  const s = Math.max(0.2, scale * 0.045);
  const r = useMemo(() => rng(idx * 13 + 1), [idx]);
  switch (type) {
    case 'berry': { const n = 3; return <group>{Array.from({ length: n }, (_, i) => <Part key={i} id="fruit" color={p.fruitColor} position={[Math.cos(i * 2.1) * s * 0.9, -s * (0.6 + i * 0.5), Math.sin(i * 2.1) * s * 0.9]} radius={s} noRegister={i > 0} clearcoat={0.6} roughness={0.3}><sphereGeometry args={[s * (0.7 + r() * 0.3), 16, 16]} /></Part>)}</group>; }
    case 'drupe': return <Part id="fruit" color={p.fruitColor} position={[0, -s * 1.6, 0]} rotation={[0, 0, 0.3]} radius={s * 1.5} clearcoat={0.5} roughness={0.35}><primitive object={ellipsoid(s * 0.9, s * 1.4, s * 0.8)} attach="geometry" /></Part>;
    case 'hip': return <Part id="fruit" color={p.fruitColor} position={[0, 0.1, 0]} radius={s} clearcoat={0.5}><primitive object={ellipsoid(s * 0.5, s * 0.8, s * 0.5)} attach="geometry" /></Part>;
    case 'achene': { const items: { pos: [number, number, number] }[] = []; const R = Math.max(0.25, scale * 0.06) * 1.6; for (let i = 0; i < 260; i++) { const a = i * 2.39996; const rr = R * 0.85 * Math.sqrt(i / 260); items.push({ pos: [Math.cos(a) * rr, 0.07, Math.sin(a) * rr] }); } return <group rotation={[0.9, 0, 0]}><Instances id="fruit" geometry={ellipsoid(R * 0.04, R * 0.02, R * 0.07)} color={p.fruitColor} items={items} label="Achenes (one-seeded dry fruits) on the receptacle" radius={R} /></group>; }
    case 'caryopsis': return <Part id="fruit" color={p.fruitColor} position={[0, s * 1.5, 0]} radius={s}><primitive object={ellipsoid(s * 0.35, s * 1.4, s * 0.3)} attach="geometry" /></Part>;
    case 'cob': return <group rotation={[0, 0, -0.5]}><Part id="fruit" color={p.fruitColor} position={[0, s * 1.2, 0]} radius={s * 2}><cylinderGeometry args={[s * 0.45, s * 0.5, s * 3, 12]} /></Part>
      <Part id="leaf" color="#7fae4e" position={[0, s * 0.9, 0]} noRegister opacity={0.85}><cylinderGeometry args={[s * 0.55, s * 0.6, s * 2.6, 8, 1, true]} /></Part></group>;
    case 'nutlet': return null;
    default: return null;
  }
}
