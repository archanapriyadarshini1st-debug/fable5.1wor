import { useMemo, Suspense } from 'react';
import * as THREE from 'three';
import { Part, Instances, FlowParticles, Tag, Jitter, blob, ellipsoid, useQuality } from './core';
import { ProteinRenderer } from './MolecularScenes';
import { useStore } from '@/store';
import { rng } from '@/data/core';

const CC = { wall: '#d9c9a0', membrane: '#f0b46a', cytoplasm: '#e7f2d9', nucleus: '#7b5aa6', nucleolus: '#4a2d73', vacuole: '#cfe8f7', chloro: '#2f8f3a', mito: '#e0603a', er: '#d8a0c0', golgi: '#e8c46a', ribo: '#5b5b7a', perox: '#9ad0e0', starch: '#f4f4f0', casparian: '#b5432c' };

const radial = (p: [number, number, number], k = 1.2): [number, number, number] => { const l = Math.hypot(...p) || 1; return [(p[0] / l) * k, (p[1] / l) * k, (p[2] / l) * k]; };

function scatter(n: number, rx: number, ry: number, rz: number, seed: number, shell = 0.6) {
  const r = rng(seed); const out: { pos: [number, number, number]; rot: [number, number, number] }[] = [];
  for (let i = 0; i < n; i++) { const u = r() * 2 - 1; const t = r() * Math.PI * 2; const s = Math.sqrt(1 - u * u); const rad = shell + (1 - shell) * r(); out.push({ pos: [s * Math.cos(t) * rx * rad, u * ry * rad, s * Math.sin(t) * rz * rad], rot: [r() * 3, r() * 3, r() * 3] }); }
  return out;
}

// ─── CELL ────────────────────────────────────────────────────────────────────
export function CellScene({ type }: { type: string }) {
  const q = useQuality(); const f = q.instances;
  const cfg = useMemo(() => cellConfig(type), [type]);
  const { rx, ry, rz } = cfg;
  const chloros = useMemo(() => cfg.chloroplasts ? scatter(Math.round(cfg.chloroplasts * f), rx * 0.78, ry * 0.8, rz * 0.78, 1, 0.85) : [], [cfg, f, rx, ry, rz]);
  const mitos = useMemo(() => cfg.mitochondria ? scatter(Math.round(cfg.mitochondria * f), rx * 0.7, ry * 0.75, rz * 0.7, 2, 0.6) : [], [cfg, f, rx, ry, rz]);
  const ribos = useMemo(() => cfg.alive ? scatter(Math.round(260 * f), rx * 0.75, ry * 0.8, rz * 0.75, 3, 0.5) : [], [cfg, f, rx, ry, rz]);
  const perox = useMemo(() => cfg.alive ? scatter(3, rx * 0.6, ry * 0.7, rz * 0.6, 4, 0.7) : [], [cfg, rx, ry, rz]);
  const starch = useMemo(() => cfg.starch ? scatter(cfg.starch, rx * 0.5, ry * 0.6, rz * 0.5, 5, 0.3) : [], [cfg, rx, ry, rz]);
  const plasmo = useMemo(() => cfg.wall ? Array.from({ length: 8 }, (_, i) => ({ pos: [(i % 2 ? 1 : -1) * rx * 1.0, (i / 8 - 0.5) * ry * 1.2, ((i >> 1) % 2 ? 1 : -1) * rz * 0.5] as [number, number, number], rot: [0, 0, Math.PI / 2] as [number, number, number] })) : [], [cfg, rx, ry, rz]);
  const shellGeo = useMemo(() => cfg.shape(1.0), [cfg]);
  const memGeo = useMemo(() => cfg.shape(0.93), [cfg]);
  const cytoGeo = useMemo(() => cfg.shape(0.9), [cfg]);
  const vacGeo = useMemo(() => cfg.vacuole ? blob(1, 0.12, 9, 3) : null, [cfg]);
  const nucPos: [number, number, number] = cfg.nucleusPos ?? [rx * 0.45, ry * 0.2, rz * 0.35];
  const erRings = useMemo(() => cfg.alive ? [0, 1, 2].map((i) => ({ pos: nucPos, rot: [i * 1.1, i * 0.7, i * 0.4] as [number, number, number], scale: 1 + i * 0.22 })) : [], [cfg, nucPos]);
  const golgi = useMemo(() => cfg.alive ? [0, 1, 2, 3, 4].map((i) => ({ pos: [-rx * 0.45, -ry * 0.3 + i * 0.16, rz * 0.3] as [number, number, number], rot: [0.3, 0.2, 0] as [number, number, number], scale: [1 - i * 0.08, 1, 1 - i * 0.08] as [number, number, number] })) : [], [cfg, rx, ry, rz]);
  return (
    <group>
      {cfg.wall && <Part id="cell-wall" geometry={shellGeo} color={cfg.wallColor ?? CC.wall} side={THREE.DoubleSide} opacity={cfg.wallOpacity ?? 0.5} roughness={0.9} radius={Math.max(rx, ry, rz)} shell alwaysLabel={false} />}
      {cfg.alive && <Part id="plasma-membrane" geometry={memGeo} color={CC.membrane} side={THREE.DoubleSide} opacity={0.35} radius={Math.max(rx, ry, rz) * 0.9} shell />}
      {cfg.alive && <Part id="cytoplasm" geometry={cytoGeo} color={CC.cytoplasm} side={THREE.BackSide} opacity={0.18} radius={Math.max(rx, ry, rz) * 0.85} shell depthWrite={false} />}
      {cfg.vacuole && vacGeo && <Part id="vacuole" geometry={vacGeo} color={CC.vacuole} opacity={0.42} transmission={0.2} scale={[rx * cfg.vacuole, ry * cfg.vacuole * 0.95, rz * cfg.vacuole]} position={[-rx * 0.08, -ry * 0.05, -rz * 0.05]} radius={rx * cfg.vacuole} explodeDir={[0, -1.5, 0]} shell label="Central vacuole (tonoplast-bounded)" />}
      {cfg.nucleus && <Jitter amount={0.02} seed={1}><Part id="nucleus" color={CC.nucleus} position={nucPos} opacity={0.85} radius={cfg.nucleus} explodeDir={radial(nucPos, 2)}><sphereGeometry args={[cfg.nucleus, 24, 18]} /></Part>
        <Part id="nucleolus" color={CC.nucleolus} position={[nucPos[0] + cfg.nucleus * 0.3, nucPos[1], nucPos[2]]} radius={cfg.nucleus * 0.35} explodeDir={radial(nucPos, 2)} noRegister><sphereGeometry args={[cfg.nucleus * 0.35, 14, 12]} /></Part></Jitter>}
      {chloros.length > 0 && <Instances id="chloroplast" geometry={ellipsoid(0.55, 0.28, 0.4)} color={CC.chloro} items={chloros} explodeDir={[1.2, 1.2, 0]} radius={0.6} />}
      {mitos.length > 0 && <Instances id="mitochondrion" geometry={new THREE.CapsuleGeometry(0.16, 0.4, 4, 10)} color={CC.mito} items={mitos} explodeDir={[-1.2, 1, 0]} radius={0.4} />}
      {ribos.length > 0 && <Instances id="ribosome" geometry={new THREE.SphereGeometry(0.05, 5, 5)} color={CC.ribo} items={ribos} ignoreFocus radius={0.2} explodeDir={[0, 0, 1.5]} />}
      {erRings.length > 0 && <Instances id="er" geometry={new THREE.TorusGeometry(cfg.nucleus! * 1.35, 0.07, 8, 40)} color={CC.er} items={erRings} radius={cfg.nucleus! * 1.5} explodeDir={radial(nucPos, 2.5)} label="Endoplasmic reticulum (around nucleus)" />}
      {golgi.length > 0 && <Instances id="golgi" geometry={new THREE.CylinderGeometry(0.55, 0.55, 0.06, 20)} color={CC.golgi} items={golgi} radius={0.6} explodeDir={[-2, -1, 1]} />}
      {perox.length > 0 && <Instances id="peroxisome" geometry={new THREE.SphereGeometry(0.22, 12, 10)} color={CC.perox} items={perox} radius={0.3} explodeDir={[1, -1.5, 1]} />}
      {starch.length > 0 && <Instances id="starch-grain" geometry={ellipsoid(0.5, 0.35, 0.45)} color={CC.starch} items={starch} radius={0.5} label="Amyloplast starch grains" explodeDir={[0, 1.5, -1]} />}
      {plasmo.length > 0 && <Instances id="plasmodesma" geometry={new THREE.CylinderGeometry(0.05, 0.05, 0.4, 6)} color="#8a7a5a" items={plasmo} radius={0.2} label="Plasmodesmata (through the wall)" />}
      {cfg.extra}
      <Tag position={[-rx - 0.5, ry + 0.8, 0]} text={cfg.title} sub={cfg.sub} offset={[-0.5, 0.6, 0]} />
    </group>
  );
}

interface CellCfg { rx: number; ry: number; rz: number; shape: (s: number) => THREE.BufferGeometry; wall: boolean; alive: boolean; vacuole?: number; nucleus?: number; nucleusPos?: [number, number, number]; chloroplasts?: number; mitochondria?: number; starch?: number; wallColor?: string; wallOpacity?: number; title: string; sub: string; extra?: React.ReactNode }
function cellConfig(type: string): CellCfg {
  const cap = (r: number, l: number) => (s: number) => new THREE.CapsuleGeometry(r * s, l * s, 8, 24);
  const box = (x: number, y: number, z: number) => (s: number) => { const g = new THREE.BoxGeometry(x * s, y * s, z * s, 4, 4, 4); return g; };
  const sph = (r: number, n = 0.1, seed = 1) => (s: number) => blob(r * s, n, seed, 3);
  switch (type) {
    case 'palisade': return { rx: 1.2, ry: 3.2, rz: 1.2, shape: cap(1.15, 4.2), wall: true, alive: true, vacuole: 0.7, nucleus: 0.55, chloroplasts: 46, mitochondria: 14, title: 'Palisade mesophyll cell', sub: '≈ 60 µm tall · peripheral chloroplasts around a central vacuole' };
    case 'spongy': return { rx: 2.4, ry: 2.2, rz: 2.4, shape: sph(2.4, 0.35, 4), wall: true, alive: true, vacuole: 0.62, nucleus: 0.5, chloroplasts: 18, mitochondria: 10, title: 'Spongy mesophyll cell', sub: 'lobed; large surface exposed to air spaces' };
    case 'epidermal': return { rx: 3.2, ry: 0.9, rz: 2.4, shape: box(6.4, 1.8, 4.8), wall: true, alive: true, vacuole: 0.8, nucleus: 0.4, nucleusPos: [1.2, 0, 0.6], mitochondria: 8, wallColor: '#d4cf9a', wallOpacity: 0.55, title: 'Epidermal pavement cell', sub: 'thick outer wall + cuticle; usually no chloroplasts', extra: <Part id="cuticle" color="#eef2d0" position={[0, 1.05, 0]} opacity={0.5} radius={3} shell><boxGeometry args={[6.6, 0.12, 5]} /></Part> };
    case 'guard': return { rx: 2.6, ry: 1.0, rz: 1.0, shape: (s) => { const g = new THREE.TorusGeometry(2.0 * s, 0.75 * s, 16, 40, Math.PI); g.rotateX(Math.PI / 2); return g; }, wall: true, alive: true, vacuole: 0.5, nucleus: 0.4, nucleusPos: [2.0, 0, 0.1], chloroplasts: 10, mitochondria: 8, wallColor: '#c8d89a', title: 'Guard cell', sub: 'kidney-shaped; wall thicker on pore side; radial microfibrils' };
    case 'roothair': return { rx: 1.1, ry: 1.1, rz: 1.1, shape: (s) => { const g = new THREE.CapsuleGeometry(0.55 * s, 7.5 * s, 8, 20); g.rotateZ(Math.PI / 2); g.translate(3.8 * s, 0, 0); const body = new THREE.BoxGeometry(2.2 * s, 2.2 * s, 2.2 * s, 3, 3, 3); return mergeGeo([body, g]); }, wall: true, alive: true, vacuole: 0.7, nucleus: 0.45, nucleusPos: [3.5, 0, 0], mitochondria: 12, wallOpacity: 0.4, title: 'Root hair cell', sub: 'tubular extension up to ~1 mm; thin wall; no chloroplasts' };
    case 'parenchyma': return { rx: 2.3, ry: 2.3, rz: 2.3, shape: sph(2.3, 0.1, 2), wall: true, alive: true, vacuole: 0.75, nucleus: 0.5, mitochondria: 12, starch: 5, title: 'Parenchyma cell', sub: 'generic living cell; here with amyloplasts (storage parenchyma)' };
    case 'collenchyma': return { rx: 1.0, ry: 2.6, rz: 1.0, shape: box(2, 5.2, 2), wall: true, alive: true, vacuole: 0.65, nucleus: 0.4, mitochondria: 8, wallOpacity: 0.55, title: 'Collenchyma cell', sub: 'living; corners thickened with pectin-rich primary wall', extra: <>{[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([x, z], i) => <Part key={i} id="cell-wall" color="#d9b98a" position={[x * 0.95, 0, z * 0.95]} noRegister radius={0.3} label="Corner thickening"><cylinderGeometry args={[0.32, 0.32, 5.3, 8]} /></Part>)}</> };
    case 'fibre': return { rx: 0.7, ry: 4.5, rz: 0.7, shape: cap(0.7, 8), wall: true, alive: false, wallOpacity: 0.95, wallColor: '#c9b27a', title: 'Sclerenchyma fibre', sub: 'dead at maturity; thick lignified secondary wall; tiny lumen', extra: <Part id="cell-wall" color="#2a1a10" radius={0.2} noRegister label="Lumen"><cylinderGeometry args={[0.12, 0.12, 8.2, 8]} /></Part> };
    case 'endodermal': return { rx: 1.3, ry: 1.3, rz: 1.3, shape: box(2.6, 2.6, 2.6), wall: true, alive: true, vacuole: 0.7, nucleus: 0.45, mitochondria: 8, title: 'Endodermal cell', sub: 'Casparian strip (red band) in radial/transverse walls', extra: <Part id="cell-wall" color={CC.casparian} emissive={CC.casparian} emissiveIntensity={0.3} radius={1.4} noRegister label="Casparian strip (lignin/suberin)"><boxGeometry args={[2.7, 0.5, 2.7]} /></Part> };
    case 'vessel': return { rx: 1.4, ry: 3.0, rz: 1.4, shape: (s) => new THREE.CylinderGeometry(1.4 * s, 1.4 * s, 6 * s, 28, 1, true), wall: true, alive: false, wallOpacity: 0.85, wallColor: '#d04a3a', title: 'Vessel element', sub: 'dead, hollow; perforation plates at ends; helical thickenings', extra: <>{[-3, 3].map((y) => <Part key={y} id="cell-wall" color="#8a2a1e" position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]} noRegister radius={1.4} label="Perforation plate (open end wall)"><torusGeometry args={[1.35, 0.12, 8, 32]} /></Part>)}{Array.from({ length: 12 }, (_, i) => <Part key={i} id="cell-wall" color="#8a2a1e" position={[0, -2.6 + i * 0.47, 0]} rotation={[Math.PI / 2, 0, 0]} noRegister radius={1.4} label="Helical secondary-wall thickening"><torusGeometry args={[1.42, 0.07, 6, 28]} /></Part>)}</> };
    case 'tracheid': return { rx: 0.8, ry: 4, rz: 0.8, shape: cap(0.8, 7), wall: true, alive: false, wallOpacity: 0.8, wallColor: '#b8443a', title: 'Tracheid', sub: 'dead, tapered; water passes through bordered pits (no perforations)', extra: <Instances id="cell-wall" geometry={new THREE.TorusGeometry(0.14, 0.04, 6, 12)} color="#5a1a12" items={Array.from({ length: 24 }, (_, i) => ({ pos: [Math.cos(i * 1.3) * 0.8, -3 + i * 0.26, Math.sin(i * 1.3) * 0.8] as [number, number, number], rot: [0, -i * 1.3 + Math.PI / 2, 0] as [number, number, number] }))} label="Bordered pits" /> };
    case 'sieve': return { rx: 1.0, ry: 3.0, rz: 1.0, shape: (s) => new THREE.CylinderGeometry(1 * s, 1 * s, 6 * s, 24, 1, true), wall: true, alive: true, mitochondria: 6, wallOpacity: 0.5, title: 'Sieve-tube element', sub: 'living but enucleate; sieve plates; parietal cytoplasm', extra: <>{[-3, 3].map((y) => <Part key={y} id="plasma-membrane" color="#e0a43a" position={[0, y, 0]} noRegister radius={1} label="Sieve plate (with sieve pores)"><cylinderGeometry args={[1, 1, 0.12, 24]} /></Part>)}<Instances id="er" geometry={new THREE.CylinderGeometry(0.1, 0.1, 0.14, 6)} color="#3a2a10" items={Array.from({ length: 14 }, (_, i) => ({ pos: [Math.cos(i) * 0.6, 3.07, Math.sin(i) * 0.6] as [number, number, number] }))} label="Sieve pores" ignoreFocus /></> };
    case 'companion': return { rx: 0.7, ry: 2.6, rz: 0.7, shape: box(1.4, 5.2, 1.4), wall: true, alive: true, vacuole: 0.3, nucleus: 0.42, nucleusPos: [0, 0.8, 0], mitochondria: 26, title: 'Companion cell', sub: 'dense cytoplasm, many mitochondria; loads sucrose into sieve tubes' };
    case 'meristem': return { rx: 1.2, ry: 1.2, rz: 1.2, shape: box(2.4, 2.4, 2.4), wall: true, alive: true, vacuole: 0.25, nucleus: 0.75, nucleusPos: [0.1, 0.1, 0.1], mitochondria: 10, wallOpacity: 0.35, title: 'Meristematic cell', sub: 'small; large nucleus; tiny vacuoles; proplastids', extra: <Instances id="proplastid" geometry={new THREE.SphereGeometry(0.16, 8, 8)} color="#a8d88a" items={scatter(8, 0.9, 0.9, 0.9, 12, 0.6)} label="Proplastids" /> };
    case 'animal': return { rx: 2.4, ry: 2.0, rz: 2.4, shape: sph(2.3, 0.3, 6), wall: false, alive: true, nucleus: 0.8, nucleusPos: [0.2, 0.1, 0.2], mitochondria: 20, title: 'Animal cell (reference)', sub: 'no wall · no chloroplasts · no central vacuole · has lysosomes & centrioles', extra: <><Instances id="animal-cell" geometry={new THREE.SphereGeometry(0.2, 10, 8)} color="#c05a8a" items={scatter(6, 1.6, 1.4, 1.6, 21, 0.5)} label="Lysosomes" /><Instances id="animal-cell" geometry={new THREE.CylinderGeometry(0.08, 0.08, 0.4, 8)} color="#3a7a9a" items={[{ pos: [-1.2, 0.6, 0.4], rot: [0, 0, 0] }, { pos: [-1.2, 0.6, 0.7], rot: [Math.PI / 2, 0, 0] }]} label="Centrioles" /></> };
    default: return cellConfig('parenchyma');
  }
}
function mergeGeo(list: THREE.BufferGeometry[]) {
  // simple merge of non-indexed positions/normals (both geometries → non-indexed)
  const parts = list.map((g) => g.toNonIndexed());
  const pos: number[] = []; const nor: number[] = [];
  for (const g of parts) { pos.push(...Array.from(g.getAttribute('position').array)); nor.push(...Array.from(g.getAttribute('normal').array)); }
  const m = new THREE.BufferGeometry(); m.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); m.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); return m;
}

// ─── CHLOROPLAST ─────────────────────────────────────────────────────────────
export function ChloroplastScene() {
  const photo = useStore((s) => s.photosynthesis); const lightAngle = useStore((s) => s.lightAngle); const q = useQuality();
  const stacks = useMemo(() => { const r = rng(3); return Array.from({ length: 11 }, (_, i) => ({ pos: [(i % 4 - 1.5) * 1.5 + (r() - 0.5) * 0.4, (Math.floor(i / 4) - 1) * 1.0 + (r() - 0.5) * 0.3, (r() - 0.5) * 2.2] as [number, number, number], n: 5 + Math.floor(r() * 7) })); }, []);
  const discs = useMemo(() => stacks.flatMap((s) => Array.from({ length: s.n }, (_, k) => ({ pos: [s.pos[0], s.pos[1] + (k - s.n / 2) * 0.1, s.pos[2]] as [number, number, number] }))), [stacks]);
  const lamellae = useMemo(() => stacks.slice(0, -1).map((s, i) => { const t = stacks[i + 1]; const mid: [number, number, number] = [(s.pos[0] + t.pos[0]) / 2, (s.pos[1] + t.pos[1]) / 2, (s.pos[2] + t.pos[2]) / 2]; const d = new THREE.Vector3(t.pos[0] - s.pos[0], t.pos[1] - s.pos[1], t.pos[2] - s.pos[2]); const len = d.length(); const rot = new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), d.normalize())); return { pos: mid, rot: [rot.x, rot.y, rot.z] as [number, number, number], scale: [len, 1, 1] as [number, number, number] }; }), [stacks]);
  const ribos = useMemo(() => scatter(Math.round(120 * q.instances), 2.6, 1.3, 1.7, 8, 0.2), [q.instances]);
  const lightDir = useMemo(() => new THREE.Vector3(Math.cos((lightAngle * Math.PI) / 180), Math.sin((lightAngle * Math.PI) / 180), 0.3).normalize(), [lightAngle]);
  const photonCurves = useMemo(() => stacks.slice(0, 5).map((s) => new THREE.CatmullRomCurve3([new THREE.Vector3(...s.pos).addScaledVector(lightDir, 7), new THREE.Vector3(...s.pos).addScaledVector(lightDir, 3.5), new THREE.Vector3(...s.pos)])), [stacks, lightDir]);
  const inCurves = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(-4.2, -0.5, 0), new THREE.Vector3(-2.5, -0.3, 0.3), new THREE.Vector3(-1.5, 0, 0.4)]), new THREE.CatmullRomCurve3([new THREE.Vector3(0, -2.6, 0.5), new THREE.Vector3(0.3, -1.4, 0.4), new THREE.Vector3(0.8, -0.6, 0.2)])], []);
  const outCurves = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(1.5, 0.2, 0.3), new THREE.Vector3(2.8, 0.8, 0.4), new THREE.Vector3(4.6, 1.4, 0.5)]), new THREE.CatmullRomCurve3([new THREE.Vector3(0.5, 0.5, 0.2), new THREE.Vector3(1.2, 1.6, 0.4), new THREE.Vector3(2, 3, 0.5)])], []);
  return (
    <group>
      <Part id="outer-envelope" color="#7cc47a" side={THREE.DoubleSide} opacity={0.3} radius={3.6} shell><primitive attach="geometry" object={ellipsoid(3.6, 1.9, 2.5, 40)} /></Part>
      <Part id="inner-envelope" color="#5aa858" side={THREE.DoubleSide} opacity={0.3} radius={3.4} shell><primitive attach="geometry" object={ellipsoid(3.42, 1.75, 2.35, 40)} /></Part>
      <Part id="stroma" color="#bfe3a8" side={THREE.BackSide} opacity={0.22} radius={3.2} shell depthWrite={false}><primitive attach="geometry" object={ellipsoid(3.3, 1.65, 2.25, 32)} /></Part>
      <Instances id="thylakoid" geometry={new THREE.CylinderGeometry(0.5, 0.5, 0.06, 20)} color="#2f7d32" items={discs} label="Grana (stacked thylakoids)" radius={0.6} explodeDir={[0, 1.2, 0]} />
      <Instances id="stroma-lamella" geometry={new THREE.BoxGeometry(1, 0.04, 0.3)} color="#3f9a44" items={lamellae} label="Stroma lamellae (connecting grana)" radius={1} explodeDir={[0, 1.2, 0]} />
      <Part id="starch-grain" color={CC.starch} position={[1.9, -0.7, -0.6]} radius={0.6} explodeDir={[1.5, -1, -1]}><primitive attach="geometry" object={ellipsoid(0.7, 0.45, 0.55)} /></Part>
      <Instances id="plastoglobule" geometry={new THREE.SphereGeometry(0.1, 8, 8)} color="#f0d060" items={scatter(9, 2.6, 1.2, 1.6, 4, 0.4)} radius={0.2} />
      <Instances id="ribosome" geometry={new THREE.SphereGeometry(0.04, 5, 5)} color={CC.ribo} items={ribos} label="Plastid 70S ribosomes" ignoreFocus radius={0.2} />
      <Part id="stroma" color="#5a4a8a" position={[-2, 0.6, 0.8]} rotation={[0.5, 0.3, 0]} noRegister radius={0.4} label="Plastid DNA (circular nucleoid)"><torusGeometry args={[0.35, 0.02, 6, 32]} /></Part>
      <Tag position={[-3.6, 2.2, 0]} text="Chloroplast" sub="double envelope · stroma (Calvin cycle) · thylakoids (light reactions)" offset={[-0.5, 0.7, 0]} />
      {photo && <Suspense fallback={null}>
        <FlowParticles curves={photonCurves} count={200} color="#fff1a0" size={0.09} speed={0.5} spread={0.25} />
        <FlowParticles curves={[inCurves[0]]} count={60} color="#5fc9ff" size={0.09} speed={0.3} spread={0.2} seed={1} />
        <FlowParticles curves={[inCurves[1]]} count={60} color="#c8c8c8" size={0.09} speed={0.3} spread={0.2} seed={2} />
        <FlowParticles curves={[outCurves[0]]} count={60} color="#ffb347" size={0.09} speed={0.25} spread={0.2} seed={3} />
        <FlowParticles curves={[outCurves[1]]} count={60} color="#ff6b6b" size={0.09} speed={0.35} spread={0.2} seed={4} />
        <Tag position={lightDir.clone().multiplyScalar(6.5).toArray() as [number, number, number]} text="LIGHT (photons)" sub={`incidence angle ${lightAngle}° — illustrative`} offset={[0.5, 0.5, 0]} />
        <Tag position={[-4.4, -0.7, 0]} text="H₂O in" offset={[-0.6, -0.4, 0]} />
        <Tag position={[0, -2.8, 0.5]} text="CO₂ in → stroma" offset={[0.6, -0.5, 0]} />
        <Tag position={[4.8, 1.5, 0.5]} text="Triose-P / sugar out" offset={[0.6, 0.4, 0]} />
        <Tag position={[2.1, 3.1, 0.5]} text="O₂ out" offset={[0.5, 0.4, 0]} />
        <Tag position={[0, -3.6, 2]} text="EDUCATIONAL VISUALIZATION — not a molecular simulation" sub="Light reactions (thylakoid): 2H₂O → O₂ + 4H⁺ + 4e⁻ ; ATP + NADPH. Calvin cycle (stroma): 3CO₂ + 9ATP + 6NADPH → triose-P" offset={[0.8, -0.6, 0]} />
      </Suspense>}
    </group>
  );
}

// ─── THYLAKOID ───────────────────────────────────────────────────────────────
export function ThylakoidScene() {
  const photo = useStore((s) => s.photosynthesis);
  const discs = [-1.2, -0.6, 0, 0.6, 1.2];
  const eCurve = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(-2.6, 1.6, 0), new THREE.Vector3(-1.4, 1.5, 0.3), new THREE.Vector3(-0.3, 1.5, 0.4), new THREE.Vector3(0.6, 1.25, 0.2), new THREE.Vector3(2.2, 1.5, 0), new THREE.Vector3(3.2, 1.8, 0.3), new THREE.Vector3(4.2, 1.9, 0.5)])], []);
  const hCurves = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(-2.6, 1.9, 0.6), new THREE.Vector3(-2.6, 1.55, 0.6), new THREE.Vector3(-2.6, 1.25, 0.6)]), new THREE.CatmullRomCurve3([new THREE.Vector3(0, 1.9, 0.6), new THREE.Vector3(0, 1.55, 0.6), new THREE.Vector3(0, 1.25, 0.6)]), new THREE.CatmullRomCurve3([new THREE.Vector3(5.6, 1.25, 0), new THREE.Vector3(5.6, 1.7, 0), new THREE.Vector3(5.6, 2.5, 0)])], []);
  return (
    <group>
      {discs.map((y, i) => <group key={i} position={[0, y, 0]}>
        <Part id="granum" color="#2f7d32" side={THREE.DoubleSide} opacity={0.75} noRegister={i > 0} radius={3.2} shell label="Thylakoid membrane (granum disc)"><cylinderGeometry args={[3.2, 3.2, 0.34, 48, 1, true]} /></Part>
        <Part id="granum" color="#2f7d32" position={[0, 0.17, 0]} noRegister radius={3.2} opacity={0.75} shell><cylinderGeometry args={[3.2, 3.2, 0.02, 48]} /></Part>
        <Part id="granum" color="#2f7d32" position={[0, -0.17, 0]} noRegister radius={3.2} opacity={0.75} shell><cylinderGeometry args={[3.2, 3.2, 0.02, 48]} /></Part>
        <Part id="lumen" color="#a8d8a0" noRegister={i > 0} radius={3} opacity={0.35} shell><cylinderGeometry args={[3.1, 3.1, 0.24, 48]} /></Part>
      </group>)}
      <Part id="stroma-lamella" color="#3f9a44" position={[4.9, 1.2, 0]} rotation={[0, 0, 0]} radius={2.4} opacity={0.8} shell><boxGeometry args={[4, 0.28, 3]} /></Part>
      {/* protein complexes on top disc (conceptual shapes; real structures load when selected) */}
      {[[-2.6, 0], [-1.6, 1.2], [-0.8, -1.4], [1.2, -0.6], [0.4, 1.6]].map(([x, z], i) => <group key={i}>
        <Part id="psii" color="#3a8f5a" position={[x, 1.55, z]} noRegister={i > 0} radius={0.5} label="Photosystem II dimer (conceptual shape — click to load PDB 3WU2)"><primitive attach="geometry" object={ellipsoid(0.55, 0.28, 0.35)} /></Part>
        <Part id="lhcii" color="#6fbf5a" position={[x + 0.7, 1.5, z + 0.2]} noRegister={i > 0} radius={0.3} label="LHCII trimer (conceptual shape — PDB 2BHW)"><cylinderGeometry args={[0.3, 0.3, 0.3, 12]} /></Part>
        <Part id="lhcii" color="#6fbf5a" position={[x - 0.7, 1.5, z - 0.2]} noRegister radius={0.3}><cylinderGeometry args={[0.3, 0.3, 0.3, 12]} /></Part>
      </group>)}
      <Part id="cytb6f" color="#e08a3a" position={[0, 1.5, 0.4]} radius={0.4} label="Cytochrome b₆f (conceptual shape — PDB 6RQF)"><boxGeometry args={[0.6, 0.36, 0.4]} /></Part>
      <Part id="plastocyanin" color="#4a7ad0" position={[0.9, 1.15, 0.5]} radius={0.15} label="Plastocyanin (lumen, PDB 1AG6)"><sphereGeometry args={[0.14, 10, 10]} /></Part>
      <Part id="psi" color="#2f6fa0" position={[3.6, 1.55, 0.3]} radius={0.5} label="Photosystem I (conceptual shape; no structure loaded — see PDB 4XK8 for pea PSI)"><primitive attach="geometry" object={ellipsoid(0.55, 0.3, 0.45)} /></Part>
      <Part id="ferredoxin" color="#d05050" position={[4.2, 1.95, 0.5]} radius={0.15} label="Ferredoxin (stroma side, PDB 1A70)"><sphereGeometry args={[0.13, 10, 10]} /></Part>
      <group position={[5.6, 1.4, 0]}>
        <Part id="atp-synthase" color="#c8a040" radius={0.5} label="ATP synthase CF₁F₀ (conceptual shape — spinach structure PDB 6FKF)"><cylinderGeometry args={[0.2, 0.2, 0.5, 12]} /></Part>
        <Part id="atp-synthase" color="#d8b050" position={[0, 0.55, 0]} noRegister radius={0.4}><sphereGeometry args={[0.38, 14, 12]} /></Part>
      </group>
      <Tag position={[-3.4, 2.6, 0]} text="Thylakoid membrane system" sub="grana stack (PSII + LHCII) · stroma lamella (PSI + ATP synthase) · lumen inside" offset={[-0.5, 0.7, 0]} />
      {photo && <>
        <FlowParticles curves={eCurve} count={90} color="#ffe680" size={0.08} speed={0.18} spread={0.06} />
        <FlowParticles curves={hCurves} count={90} color="#ff9ecf" size={0.07} speed={0.25} spread={0.15} seed={7} />
        <Tag position={[0.5, 3.2, 0]} text="Z-SCHEME (CONCEPTUAL)" sub="e⁻: H₂O → PSII → PQ → cyt b₆f → PC → PSI → Fd → NADP⁺ ; H⁺ pumped into lumen, returned through ATP synthase" offset={[0.5, 0.6, 0]} />
      </>}
    </group>
  );
}

// ─── MITOCHONDRION ───────────────────────────────────────────────────────────
export function MitochondrionScene() {
  const exp = useStore((s) => s.photosynthesis); // reuse "pathway" toggle for respiration animation
  const cristae = useMemo(() => Array.from({ length: 9 }, (_, i) => ({ pos: [(i - 4) * 0.62, 0, 0] as [number, number, number], rot: [0, 0, Math.PI / 2] as [number, number, number], scale: [1, 1, 1] as [number, number, number] })), []);
  const knobs = useMemo(() => cristae.flatMap((c) => scatter(12, 0.2, 1.1, 1.1, 5, 0.9).map((k) => ({ pos: [c.pos[0] + k.pos[0] * 0.3, k.pos[1], k.pos[2]] as [number, number, number] }))), [cristae]);
  const curves = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(-4.5, 1.5, 0), new THREE.Vector3(-3, 0.6, 0.2), new THREE.Vector3(-1.5, 0, 0.3)]), new THREE.CatmullRomCurve3([new THREE.Vector3(1.5, 0.2, 0.3), new THREE.Vector3(3, 1, 0.2), new THREE.Vector3(4.5, 2, 0)])], []);
  return (
    <group>
      <Part id="outer-membrane" color="#e08a6a" side={THREE.DoubleSide} opacity={0.3} radius={3.5} shell><capsuleGeometry args={[1.7, 4, 12, 32]} /></Part>
      <group rotation={[0, 0, Math.PI / 2]}>
        <Part id="intermembrane-space" color="#f7d9c8" side={THREE.BackSide} opacity={0.15} radius={3.4} shell depthWrite={false}><capsuleGeometry args={[1.62, 3.9, 12, 32]} /></Part>
        <Part id="inner-membrane" color="#d0603a" side={THREE.DoubleSide} opacity={0.35} radius={3.3} shell><capsuleGeometry args={[1.48, 3.8, 12, 32]} /></Part>
        <Part id="matrix" color="#f6e2c0" side={THREE.BackSide} opacity={0.2} radius={3.2} shell depthWrite={false}><capsuleGeometry args={[1.42, 3.7, 12, 32]} /></Part>
      </group>
      <Instances id="cristae" geometry={ellipsoid(1.3, 0.08, 1.2)} color="#c8503a" items={cristae} radius={1.3} explodeDir={[0, 1.2, 0]} />
      <Instances id="cristae" geometry={new THREE.SphereGeometry(0.06, 6, 6)} color="#e8c060" items={knobs} label="ATP synthase knobs (F₁ heads face the matrix)" ignoreFocus radius={0.2} />
      <Part id="matrix" color="#5a4a8a" position={[0.3, -0.7, 0.4]} rotation={[0.4, 0.6, 0]} noRegister radius={0.4} label="mtDNA nucleoid (circular)"><torusGeometry args={[0.3, 0.02, 6, 32]} /></Part>
      <Instances id="ribosome" geometry={new THREE.SphereGeometry(0.035, 5, 5)} color={CC.ribo} items={scatter(80, 2.4, 1.1, 1.1, 9, 0.2)} label="Mitochondrial ribosomes" ignoreFocus radius={0.2} />
      <Tag position={[-3.6, 2.2, 0]} text="Mitochondrion" sub="outer membrane · intermembrane space · inner membrane folded into cristae · matrix" offset={[-0.5, 0.7, 0]} />
      {exp && <><FlowParticles curves={[curves[0]]} count={60} color="#c0e0ff" size={0.08} speed={0.3} spread={0.2} /><FlowParticles curves={[curves[1]]} count={60} color="#c8c8c8" size={0.08} speed={0.3} spread={0.2} seed={3} /><FlowParticles curves={[curves[1]]} count={40} color="#ffd060" size={0.09} speed={0.2} spread={0.3} seed={4} />
        <Tag position={[-4.8, 1.8, 0]} text="pyruvate + O₂ in" offset={[-0.5, 0.5, 0]} /><Tag position={[4.8, 2.2, 0]} text="CO₂ + ATP out" offset={[0.5, 0.5, 0]} /><Tag position={[0, -2.6, 1.5]} text="CONCEPTUAL RESPIRATION VISUALIZATION" sub="TCA cycle in matrix; electron transport + ATP synthase on cristae" offset={[0.8, -0.5, 0]} /></>}
    </group>
  );
}

// ─── NUCLEUS ─────────────────────────────────────────────────────────────────
export function NucleusScene() {
  const pores = useMemo(() => scatter(48, 3.0, 3.0, 3.0, 4, 1).map((p) => { const v = new THREE.Vector3(...p.pos).normalize(); const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), v); const e = new THREE.Euler().setFromQuaternion(q); return { pos: [v.x * 2.95, v.y * 2.95, v.z * 2.95] as [number, number, number], rot: [e.x, e.y, e.z] as [number, number, number] }; }), []);
  const chromatin = useMemo(() => { const r = rng(5); return Array.from({ length: 7 }, (_, i) => { const pts: THREE.Vector3[] = []; let p = new THREE.Vector3((r() - 0.5) * 3, (r() - 0.5) * 3, (r() - 0.5) * 3); for (let k = 0; k < 14; k++) { p = p.clone().add(new THREE.Vector3((r() - 0.5) * 1.6, (r() - 0.5) * 1.6, (r() - 0.5) * 1.6)); if (p.length() > 2.4) p.setLength(2.2); pts.push(p); } return { geo: new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 80, 0.09, 8, false), color: ['#8a6ad0', '#6a4ab0', '#a080e0', '#7a5ac0', '#9a7ad8', '#6f52b8', '#8f70d4'][i] }; }); }, []);
  return (
    <group>
      <Part id="nuclear-envelope" color="#a58cd6" side={THREE.DoubleSide} opacity={0.28} radius={3.1} shell><sphereGeometry args={[3.05, 48, 32]} /></Part>
      <Part id="nuclear-envelope" color="#a58cd6" side={THREE.DoubleSide} opacity={0.28} radius={2.9} noRegister shell><sphereGeometry args={[2.85, 48, 32]} /></Part>
      <Part id="nucleoplasm" color="#efe6ff" side={THREE.BackSide} opacity={0.15} radius={2.8} shell depthWrite={false}><sphereGeometry args={[2.8, 32, 24]} /></Part>
      <Instances id="nuclear-pore" geometry={new THREE.TorusGeometry(0.16, 0.06, 8, 16)} color="#5f4a9a" items={pores} radius={0.3} />
      {chromatin.map((c, i) => <Part key={i} id="chromatin" geometry={c.geo} color={c.color} noRegister={i > 0} radius={2.4} explodeDir={[0, 0, 0]} />)}
      <Part id="nucleolus" color={CC.nucleolus} position={[0.6, -0.3, 0.4]} radius={0.9} explodeDir={[1.5, -0.8, 1]}><primitive attach="geometry" object={blob(0.9, 0.1, 2, 3)} /></Part>
      <Part id="er" color={CC.er} position={[3.4, 0.8, 0]} rotation={[0, 0, 0.4]} radius={0.5} label="ER continuous with outer nuclear membrane"><torusGeometry args={[0.6, 0.06, 8, 24, Math.PI]} /></Part>
      <Tag position={[-3.2, 3.2, 0]} text="Nucleus" sub="double envelope with pore complexes · chromatin fibres (schematic) · nucleolus" offset={[-0.5, 0.7, 0]} />
    </group>
  );
}

// ─── PLASMA MEMBRANE ─────────────────────────────────────────────────────────
export function MembraneScene() {
  const q = useQuality();
  const lipids = useMemo(() => { const r = rng(2); const out: { head: [number, number, number]; tail: [number, number, number]; tailRot: [number, number, number] }[][] = [[], []]; const n = Math.round(22 * Math.sqrt(q.instances)); for (let x = 0; x < n; x++) for (let z = 0; z < Math.round(n * 0.7); z++) { const px = (x - n / 2) * 0.9 + (r() - 0.5) * 0.2; const pz = (z - n * 0.35) * 0.9 + (r() - 0.5) * 0.2; if (Math.hypot(px, pz) < 3.0) continue; out[0].push({ head: [px, 1.9, pz], tail: [px, 1.0, pz], tailRot: [(r() - 0.5) * 0.4, 0, (r() - 0.5) * 0.4] }); out[1].push({ head: [px, -1.9, pz], tail: [px, -1.0, pz], tailRot: [(r() - 0.5) * 0.4, 0, (r() - 0.5) * 0.4] }); } return out; }, [q.instances]);
  const water = useMemo(() => [new THREE.CatmullRomCurve3([new THREE.Vector3(0.8, 5, 0.8), new THREE.Vector3(0.8, 0, 0.8), new THREE.Vector3(0.8, -5, 0.8)]), new THREE.CatmullRomCurve3([new THREE.Vector3(-0.8, 5, -0.8), new THREE.Vector3(-0.8, 0, -0.8), new THREE.Vector3(-0.8, -5, -0.8)])], []);
  const headGeo = useMemo(() => new THREE.SphereGeometry(0.4, 10, 8), []);
  const tailGeo = useMemo(() => new THREE.CylinderGeometry(0.09, 0.09, 1.6, 6), []);
  const heads = useMemo(() => [...lipids[0], ...lipids[1]].map((l) => ({ pos: l.head })), [lipids]);
  const tails = useMemo(() => [...lipids[0], ...lipids[1]].flatMap((l) => [{ pos: [l.tail[0] - 0.14, l.tail[1], l.tail[2]] as [number, number, number], rot: l.tailRot }, { pos: [l.tail[0] + 0.14, l.tail[1], l.tail[2]] as [number, number, number], rot: [-l.tailRot[0], 0, -l.tailRot[2]] as [number, number, number] }]), [lipids]);
  return (
    <group>
      <Instances id="plasma-membrane" geometry={headGeo} color="#f0b46a" items={heads} label="Phospholipid head groups (hydrophilic)" radius={6} />
      <Instances id="glycerol" geometry={tailGeo} color="#f7e2b0" items={tails} label="Fatty-acyl tails (hydrophobic core)" radius={6} ignoreFocus />
      <Suspense fallback={<Part id="aquaporin" color="#4a8ad0" radius={3} label="Aquaporin tetramer — loading PDB 1Z98…"><cylinderGeometry args={[2.6, 2.6, 4.4, 24]} /></Part>}>
        <ProteinRenderer id="aquaporin" scale={0.075} position={[0, 0, 0]} rotation={[0, 0, 0]} partId="aquaporin" forceMode="atoms" />
      </Suspense>
      <FlowParticles curves={water} count={60} color="#5fc9ff" size={0.14} speed={0.2} spread={0.15} />
      <Tag position={[-8, 3, 0]} text="Plasma membrane — fluid-mosaic model (schematic bilayer)" sub="bilayer ≈ 7–8 nm; embedded aquaporin SoPIP2;1 rendered from PDB 1Z98 atomic coordinates" offset={[-0.4, 0.8, 0]} />
      <Tag position={[0.8, 5, 0.8]} text="water flux through aquaporin channels (conceptual)" offset={[0.8, 0.6, 0]} />
    </group>
  );
}

// ─── CELL WALL ───────────────────────────────────────────────────────────────
export function WallScene() {
  const q = useQuality();
  const fibrils = useMemo(() => { const out: { pos: [number, number, number]; rot: [number, number, number] }[] = []; const layers = [0, 0.6, 1.2, 1.8]; layers.forEach((y, li) => { const ang = li % 2 ? Math.PI / 2 + 0.3 : 0.1; const n = Math.round(10 * q.instances); for (let i = 0; i < n; i++) { const off = (i - n / 2) * 0.85; out.push({ pos: [Math.cos(ang + Math.PI / 2) * off, y, Math.sin(ang + Math.PI / 2) * off], rot: [0, -ang, Math.PI / 2] }); } }); return out; }, [q.instances]);
  const tethers = useMemo(() => { const r = rng(4); return Array.from({ length: Math.round(120 * q.instances) }, () => ({ pos: [(r() - 0.5) * 8, r() * 2, (r() - 0.5) * 8] as [number, number, number], rot: [r() * 3, r() * 3, r() * 3] as [number, number, number] })); }, [q.instances]);
  const rings = useMemo(() => Array.from({ length: 16 }, (_, i) => ({ pos: [-4 + i * 0.52, 2.9, 2.6] as [number, number, number], rot: [i % 2 ? 0 : Math.PI, 0, Math.PI / 2] as [number, number, number] })), []);
  return (
    <group>
      <Part id="plasma-membrane" color="#f0b46a" position={[0, -0.6, 0]} radius={5} opacity={0.6} shell><boxGeometry args={[9, 0.18, 9]} /></Part>
      <Part id="cell-wall" color="#e9dcbf" position={[0, 0.9, 0]} radius={5} opacity={0.15} shell depthWrite={false} label="Pectin / hemicellulose matrix"><boxGeometry args={[9, 2.6, 9]} /></Part>
      <Part id="cell-wall" color="#d2b98a" position={[0, 2.4, 0]} radius={5} opacity={0.6} noRegister label="Middle lamella (pectin-rich, shared with neighbour)"><boxGeometry args={[9, 0.14, 9]} /></Part>
      <Instances id="cellulose" geometry={new THREE.CylinderGeometry(0.16, 0.16, 8.5, 8)} color="#f4f0e0" items={fibrils} label="Cellulose microfibrils (~3 nm; crossed layers)" radius={4} />
      <Instances id="cell-wall" geometry={new THREE.CylinderGeometry(0.025, 0.025, 0.8, 4)} color="#c9a86a" items={tethers} label="Hemicellulose (xyloglucan) tethers" ignoreFocus radius={0.3} />
      {/* hero microfibril with glucan chain detail */}
      <Part id="cellulose" color="#f4f0e0" position={[0, 2.9, 2.6]} rotation={[0, 0, Math.PI / 2]} radius={4} noRegister opacity={0.25}><cylinderGeometry args={[0.3, 0.3, 8.5, 12]} /></Part>
      <Instances id="cellobiose" geometry={new THREE.TorusGeometry(0.17, 0.05, 6, 6)} color="#7cb0e0" items={rings} label="β(1→4)-glucose units — alternate units flipped 180° (cellobiose repeat)" radius={0.5} />
      <group position={[3.2, 0.9, -3]}>
        <Part id="plasmodesma" color="#8a7a5a" radius={0.6} opacity={0.6} side={THREE.DoubleSide}><cylinderGeometry args={[0.45, 0.45, 3.2, 16, 1, true]} /></Part>
        <Part id="er" color={CC.er} radius={0.3} noRegister label="Desmotubule (appressed ER)"><cylinderGeometry args={[0.12, 0.12, 3.4, 10]} /></Part>
      </group>
      <Part id="cesa" color="#4a7ad0" position={[-3, -0.35, 3]} radius={0.7} label="Cellulose synthase complex (rosette) — PDB 6WLB trimer"><cylinderGeometry args={[0.6, 0.6, 0.5, 6]} /></Part>
      <Tag position={[-4.6, 3.4, 0]} text="Primary cell wall (schematic)" sub="microfibrils in crossed layers · hemicellulose tethers · pectin matrix · middle lamella · plasmodesma" offset={[-0.4, 0.8, 0]} />
    </group>
  );
}
