import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import * as THREE from 'three';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { Html, Line } from '@react-three/drei';
import { useStore, QUALITY_PRESETS } from '@/store';
import { NODE_MAP } from '@/data/nodes';
import { rng } from '@/data/core';

// ─── scene context ───────────────────────────────────────────────────────────
export interface SceneInfo { id: string; metersPerUnit: number; defaultDistance: number; minDistance: number; maxDistance: number; target?: [number, number, number]; up?: boolean }
export const SceneCtx = createContext<SceneInfo>({ id: 'plant', metersPerUnit: 0.1, defaultDistance: 10, minDistance: 1, maxDistance: 40 });
export const useSceneInfo = () => useContext(SceneCtx);
export const useQuality = () => QUALITY_PRESETS[useStore((s) => s.quality)];

// ─── part registry (world positions for camera focus) ───────────────────────
export const partRegistry = new Map<string, { pos: THREE.Vector3; radius: number }>();
export const registerPart = (id: string, pos: THREE.Vector3, radius: number) => partRegistry.set(id, { pos: pos.clone(), radius });

// ─── Part ────────────────────────────────────────────────────────────────────
export interface PartProps {
  id: string; label?: string; color: string; children?: ReactNode; geometry?: THREE.BufferGeometry;
  position?: [number, number, number]; rotation?: [number, number, number]; scale?: number | [number, number, number];
  explodeDir?: [number, number, number]; opacity?: number; roughness?: number; metalness?: number; emissive?: string; emissiveIntensity?: number;
  side?: THREE.Side; radius?: number; alwaysLabel?: boolean; labelOffset?: [number, number, number]; noRegister?: boolean; flatShading?: boolean;
  castShadow?: boolean; receiveShadow?: boolean; transmission?: number; clearcoat?: number; sheen?: number; wireframe?: boolean; renderOrder?: number; depthWrite?: boolean;
  onClick?: (e: ThreeEvent<MouseEvent>) => void; instanced?: boolean; ignoreFocus?: boolean;
  /** outer shell: gets cut open (front half removed) when the CUTAWAY view layer is active */
  shell?: boolean;
}
export const CUT_PLANE = new THREE.Plane(new THREE.Vector3(0, 0, -1), 0);

export function Part(p: PartProps) {
  const ref = useRef<THREE.Mesh>(null!);
  const groupRef = useRef<THREE.Group>(null!);
  const selectedId = useStore((s) => s.selectedId);
  const hoveredId = useStore((s) => s.hoveredId);
  const viewLayer = useStore((s) => s.viewLayer);
  const explode = useStore((s) => s.explode);
  const focusMode = useStore((s) => s.focusMode);
  const highContrast = useStore((s) => s.highContrast);
  const measureActive = useStore((s) => s.measureActive);
  const scene = useSceneInfo();
  const [hover, setHover] = useState(false);
  const selected = selectedId === p.id;
  const hovered = hover || hoveredId === p.id;

  useEffect(() => {
    if (p.noRegister || !groupRef.current) return;
    const v = new THREE.Vector3();
    groupRef.current.getWorldPosition(v);
    let r = p.radius;
    if (r === undefined && ref.current) { ref.current.geometry.computeBoundingSphere(); r = (ref.current.geometry.boundingSphere?.radius ?? 1) * (typeof p.scale === 'number' ? p.scale : 1); }
    registerPart(p.id, v, r ?? 1);
  });

  const baseOpacity = p.opacity ?? 1;
  let opacity = baseOpacity;
  let emissiveI = p.emissiveIntensity ?? 0;
  if (viewLayer === 'xray') { opacity = Math.min(baseOpacity, 0.22); emissiveI += 0.35; }
  if (viewLayer === 'transparent') opacity = Math.min(baseOpacity, 0.45);
  if (focusMode && selectedId && !selected && !p.ignoreFocus) opacity *= 0.12;
  if (hovered) emissiveI += 0.25;
  if (selected) emissiveI += highContrast ? 0.9 : 0.55;
  const transparent = opacity < 0.999 || viewLayer === 'xray';
  const emissiveColor = selected ? (highContrast ? '#ffffff' : '#7fe3ff') : hovered ? '#ffffff' : (p.emissive ?? p.color);

  const explodeOffset = useMemo<[number, number, number]>(() => {
    const d = p.explodeDir ?? [0, 0, 0];
    const f = viewLayer === 'exploded' ? Math.max(explode, 0.6) : explode;
    return [d[0] * f, d[1] * f, d[2] * f];
  }, [p.explodeDir, explode, viewLayer]);

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (measureActive) { useStore.getState().addMeasurePoint([e.point.x, e.point.y, e.point.z], scene.metersPerUnit, scene.id); return; }
    if (p.onClick) p.onClick(e);
    useStore.getState().select(p.id);
  };
  const onDouble = (e: ThreeEvent<MouseEvent>) => { e.stopPropagation(); if (NODE_MAP[p.id]) useStore.getState().navigate(p.id); };

  const showLabel = useStore((s) => s.showLabels) && (p.label || NODE_MAP[p.id]?.name) && (p.alwaysLabel || hovered || selected);

  const gprops: Record<string, unknown> = {};
  if (p.position) gprops.position = p.position; if (p.rotation) gprops.rotation = p.rotation; if (p.scale !== undefined) gprops.scale = p.scale;
  const mprops: Record<string, unknown> = {};
  if (p.geometry) mprops.geometry = p.geometry; if (p.renderOrder !== undefined) mprops.renderOrder = p.renderOrder;
  return (
    <group ref={groupRef} {...gprops}>
      <group position={explodeOffset}>
        <mesh ref={ref} {...mprops} castShadow={p.castShadow ?? true} receiveShadow={p.receiveShadow ?? true}
          onClick={onClick} onDoubleClick={onDouble}
          onPointerOver={(e) => { e.stopPropagation(); setHover(true); useStore.getState().hover(p.id); document.body.style.cursor = measureActive ? 'crosshair' : 'pointer'; }}
          onPointerOut={() => { setHover(false); if (useStore.getState().hoveredId === p.id) useStore.getState().hover(null); document.body.style.cursor = 'auto'; }}>
          {p.children}
          <meshPhysicalMaterial color={p.color} roughness={p.roughness ?? 0.6} metalness={p.metalness ?? 0} transparent={transparent} opacity={opacity}
            emissive={emissiveColor} emissiveIntensity={emissiveI} side={p.side ?? THREE.FrontSide} flatShading={p.flatShading} transmission={p.transmission ?? 0}
            clearcoat={p.clearcoat ?? 0} sheen={p.sheen ?? 0} wireframe={p.wireframe} depthWrite={p.depthWrite ?? (opacity > 0.5)}
            clippingPlanes={p.shell && viewLayer === 'cutaway' ? [CUT_PLANE] : null} />
        </mesh>
        {showLabel && <Label text={p.label ?? NODE_MAP[p.id]!.name} offset={p.labelOffset} selected={selected} />}
      </group>
    </group>
  );
}

// ─── Label with leader line ─────────────────────────────────────────────────
export function Label({ text, offset = [0.6, 0.7, 0], selected, sub, anchor = [0, 0, 0] }: { text: string; offset?: [number, number, number]; selected?: boolean; sub?: string; anchor?: [number, number, number] }) {
  const large = useStore((s) => s.largeLabels);
  const hc = useStore((s) => s.highContrast);
  const end: [number, number, number] = [anchor[0] + offset[0], anchor[1] + offset[1], anchor[2] + offset[2]];
  return (
    <group>
      <Line points={[anchor, end]} color={selected ? '#7fe3ff' : hc ? '#ffffff' : '#c9d6cf'} lineWidth={1} transparent opacity={0.8} />
      <mesh position={anchor}><sphereGeometry args={[0.03, 8, 8]} /><meshBasicMaterial color={selected ? '#7fe3ff' : '#e8f0ea'} /></mesh>
      <Html position={end} center zIndexRange={[10, 0]} style={{ pointerEvents: 'none' }}>
        <div className={`ps-label ${large ? 'ps-label-lg' : ''} ${selected ? 'ps-label-sel' : ''} ${hc ? 'ps-label-hc' : ''}`}>
          <div>{text}</div>
          {sub && <div className="ps-label-sub">{sub}</div>}
        </div>
      </Html>
    </group>
  );
}

// ─── Static label (no Part) ──────────────────────────────────────────────────
export function Tag({ position, text, sub, offset }: { position: [number, number, number]; text: string; sub?: string; offset?: [number, number, number] }) {
  const show = useStore((s) => s.showLabels);
  if (!show) return null;
  return <group position={position}><Label text={text} sub={sub} offset={offset} /></group>;
}

// ─── Flow particles along curves ─────────────────────────────────────────────
export function FlowParticles({ curves, count = 200, color = '#6ec6ff', size = 0.08, speed = 0.15, spread = 0.05, reverse = false, seed = 1 }:
  { curves: THREE.Curve<THREE.Vector3>[]; count?: number; color?: string; size?: number; speed?: number; spread?: number; reverse?: boolean; seed?: number }) {
  const q = useQuality();
  const reduced = useStore((s) => s.reducedMotion);
  const n = Math.max(8, Math.floor(count * q.particles));
  const ref = useRef<THREE.Points>(null!);
  const data = useMemo(() => {
    const r = rng(seed);
    const t = new Float32Array(n); const ci = new Uint16Array(n); const off = new Float32Array(n * 3); const sp = new Float32Array(n);
    for (let i = 0; i < n; i++) { t[i] = r(); ci[i] = Math.floor(r() * curves.length); off[i * 3] = (r() - 0.5) * spread; off[i * 3 + 1] = (r() - 0.5) * spread; off[i * 3 + 2] = (r() - 0.5) * spread; sp[i] = 0.7 + r() * 0.6; }
    return { t, ci, off, sp, pos: new Float32Array(n * 3) };
  }, [n, curves, spread, seed]);
  const v = useMemo(() => new THREE.Vector3(), []);
  useFrame((_, dt) => {
    if (!curves.length) return;
    const step = reduced ? 0 : Math.min(dt, 0.05) * speed;
    for (let i = 0; i < n; i++) {
      data.t[i] = (data.t[i] + step * data.sp[i]) % 1;
      const tt = reverse ? 1 - data.t[i] : data.t[i];
      curves[data.ci[i] % curves.length].getPointAt(Math.min(0.999, Math.max(0.001, tt)), v);
      data.pos[i * 3] = v.x + data.off[i * 3]; data.pos[i * 3 + 1] = v.y + data.off[i * 3 + 1]; data.pos[i * 3 + 2] = v.z + data.off[i * 3 + 2];
    }
    const attr = ref.current.geometry.getAttribute('position') as THREE.BufferAttribute;
    attr.needsUpdate = true;
  });
  return (
    <points ref={ref} frustumCulled={false}>
      <bufferGeometry><bufferAttribute attach="attributes-position" args={[data.pos, 3]} /></bufferGeometry>
      <pointsMaterial color={color} size={size} sizeAttenuation transparent opacity={0.9} depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

// ─── Brownian jitter group ───────────────────────────────────────────────────
export function Jitter({ children, amount = 0.02, speed = 1, seed = 0 }: { children: ReactNode; amount?: number; speed?: number; seed?: number }) {
  const ref = useRef<THREE.Group>(null!);
  const reduced = useStore((s) => s.reducedMotion);
  const living = useStore((s) => s.living);
  useFrame(({ clock }) => {
    if (reduced || !living) return;
    const t = clock.elapsedTime * speed + seed;
    ref.current.position.set(Math.sin(t * 1.3 + seed) * amount, Math.cos(t * 1.7 + seed * 2) * amount, Math.sin(t * 0.9 + seed * 3) * amount);
  });
  return <group ref={ref}>{children}</group>;
}

// ─── Geometry builders ───────────────────────────────────────────────────────
export function taperedTube(curve: THREE.Curve<THREE.Vector3>, r0: number, r1: number, tubular = 24, radial = 10, wobble = 0): THREE.BufferGeometry {
  const frames = curve.computeFrenetFrames(tubular, false);
  const pos: number[] = []; const nor: number[] = []; const uv: number[] = []; const idx: number[] = [];
  const P = new THREE.Vector3(); const N = new THREE.Vector3(); const B = new THREE.Vector3();
  for (let i = 0; i <= tubular; i++) {
    const u = i / tubular; curve.getPointAt(u, P);
    N.copy(frames.normals[i]); B.copy(frames.binormals[i]);
    const r = THREE.MathUtils.lerp(r0, r1, u);
    for (let j = 0; j <= radial; j++) {
      const v = (j / radial) * Math.PI * 2;
      const rr = r * (1 + wobble * Math.sin(v * 4 + u * 6));
      const cx = -rr * Math.cos(v), cy = rr * Math.sin(v);
      const nx = cx * N.x + cy * B.x, ny = cx * N.y + cy * B.y, nz = cx * N.z + cy * B.z;
      pos.push(P.x + nx, P.y + ny, P.z + nz); nor.push(nx / rr, ny / rr, nz / rr); uv.push(u, j / radial);
    }
  }
  for (let i = 0; i < tubular; i++) for (let j = 0; j < radial; j++) {
    const a = (radial + 1) * i + j, b = (radial + 1) * (i + 1) + j, c = b + 1, d = a + 1;
    idx.push(a, b, d, b, c, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  return g;
}

export function blob(radius: number, noise = 0.15, seed = 1, detail = 3): THREE.BufferGeometry {
  const g = new THREE.IcosahedronGeometry(radius, detail);
  const p = g.getAttribute('position') as THREE.BufferAttribute;
  const r = rng(seed);
  const a = r() * 6, b = r() * 6, c = r() * 6;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const f = 1 + noise * (Math.sin(x * 2.1 + a) * Math.cos(y * 1.7 + b) + Math.sin(z * 2.4 + c) * 0.7) * 0.5;
    p.setXYZ(i, x * f, y * f, z * f);
  }
  g.computeVertexNormals();
  return g;
}

export function ellipsoid(rx: number, ry: number, rz: number, seg = 24): THREE.BufferGeometry {
  const g = new THREE.SphereGeometry(1, seg, Math.max(8, seg / 2)); g.scale(rx, ry, rz); return g;
}

/** leaf outline as ShapeGeometry lying in XY plane, tip toward +Y, with gentle curvature in Z */
export function leafGeometry(kind: string, length: number, width: number, curl = 0.15, segs = 12): THREE.BufferGeometry {
  const s = new THREE.Shape();
  const half = width / 2;
  const prof = (t: number) => { // half-width profile along 0..1
    switch (kind) {
      case 'linear': return Math.sin(Math.PI * Math.min(1, t * 1.15)) ** 0.5 * 0.5 + 0.5 * (1 - t) * (t > 0.02 ? 1 : 0.2);
      case 'lanceolate': return Math.sin(Math.PI * t ** 0.7);
      case 'cordate': return t < 0.15 ? 0.6 + 2.5 * t : Math.sin(Math.PI * (0.15 + (t - 0.15) * 0.9)) * 1.05;
      case 'frond': return Math.sin(Math.PI * t ** 0.8) * (1 + 0.35 * Math.sin(t * 60));
      case 'pinnate': return Math.sin(Math.PI * t ** 0.85) * (1 + 0.5 * Math.abs(Math.sin(t * 22)));
      default: return Math.sin(Math.PI * t ** 0.8); // ovate
    }
  };
  s.moveTo(0, 0);
  const N = 40;
  for (let i = 1; i <= N; i++) { const t = i / N; s.lineTo(half * prof(t), length * t); }
  for (let i = N - 1; i >= 0; i--) { const t = i / N; s.lineTo(-half * prof(t), length * t); }
  const g = new THREE.ShapeGeometry(s, segs);
  const p = g.getAttribute('position') as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i);
    const t = y / length;
    p.setZ(i, -curl * length * (t * t) + Math.abs(x) * 0.5 * curl * 2 + (kind === 'frond' ? Math.sin(t * 60) * 0.01 * length : 0));
  }
  g.computeVertexNormals();
  return g;
}

export function petalGeometry(length: number, width: number, cup = 0.4): THREE.BufferGeometry {
  const g = leafGeometry('ovate', length, width, 0, 8);
  const p = g.getAttribute('position') as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); const t = y / length; p.setZ(i, cup * length * (t * t) - (x * x) / (width) * cup); }
  g.computeVertexNormals();
  return g;
}

// ─── instanced helper ────────────────────────────────────────────────────────
export function Instances({ id, geometry, color, items, label, opacity, roughness = 0.6, emissive, explodeDir, alwaysLabel, radius, onClickItem, ignoreFocus, flatShading }:
  { id: string; geometry: THREE.BufferGeometry; color: string; items: { pos: [number, number, number]; rot?: [number, number, number]; scale?: [number, number, number] | number; color?: string }[]; label?: string; opacity?: number; roughness?: number; emissive?: string; explodeDir?: [number, number, number]; alwaysLabel?: boolean; radius?: number; onClickItem?: (i: number) => void; ignoreFocus?: boolean; flatShading?: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null!);
  const selectedId = useStore((s) => s.selectedId); const hoveredId = useStore((s) => s.hoveredId);
  const viewLayer = useStore((s) => s.viewLayer); const explode = useStore((s) => s.explode); const focusMode = useStore((s) => s.focusMode);
  const measureActive = useStore((s) => s.measureActive); const scene = useSceneInfo(); const show = useStore((s) => s.showLabels);
  const [hover, setHover] = useState(false);
  const selected = selectedId === id; const hovered = hover || hoveredId === id;
  const hasColors = items.some((it) => it.color);
  useEffect(() => {
    const m = new THREE.Matrix4(); const q = new THREE.Quaternion(); const e = new THREE.Euler(); const s = new THREE.Vector3(); const c = new THREE.Color();
    items.forEach((it, i) => {
      e.set(...(it.rot ?? [0, 0, 0])); q.setFromEuler(e);
      const sc = it.scale ?? 1; s.set(...(typeof sc === 'number' ? [sc, sc, sc] as [number, number, number] : sc));
      m.compose(new THREE.Vector3(...it.pos), q, s); ref.current.setMatrixAt(i, m);
      if (hasColors) { c.set(it.color ?? color); ref.current.setColorAt(i, c); }
    });
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
    const center = items.reduce((acc, it) => [acc[0] + it.pos[0] / items.length, acc[1] + it.pos[1] / items.length, acc[2] + it.pos[2] / items.length], [0, 0, 0]);
    const v = new THREE.Vector3(...center); ref.current.parent?.updateWorldMatrix(true, false); ref.current.parent?.localToWorld(v); registerPart(id, v, radius ?? 2);
  }, [items, color, hasColors, id, radius, geometry]);
  let op = opacity ?? 1; let em = 0;
  if (viewLayer === 'xray') { op = Math.min(op, 0.22); em += 0.3; }
  if (viewLayer === 'transparent') op = Math.min(op, 0.45);
  if (focusMode && selectedId && !selected && !ignoreFocus) op *= 0.12;
  if (hovered) em += 0.25; if (selected) em += 0.55;
  const off: [number, number, number] = explodeDir ? [explodeDir[0] * (viewLayer === 'exploded' ? Math.max(explode, 0.6) : explode), explodeDir[1] * (viewLayer === 'exploded' ? Math.max(explode, 0.6) : explode), explodeDir[2] * (viewLayer === 'exploded' ? Math.max(explode, 0.6) : explode)] : [0, 0, 0];
  const center = items.length ? items[Math.floor(items.length / 2)].pos : [0, 0, 0] as [number, number, number];
  return (
    <group position={off}>
      <instancedMesh ref={ref} args={[geometry, undefined, items.length]} castShadow receiveShadow frustumCulled={false}
        onClick={(e) => { e.stopPropagation(); if (measureActive) { useStore.getState().addMeasurePoint([e.point.x, e.point.y, e.point.z], scene.metersPerUnit, scene.id); return; } onClickItem?.(e.instanceId ?? 0); useStore.getState().select(id); }}
        onDoubleClick={(e) => { e.stopPropagation(); if (NODE_MAP[id]) useStore.getState().navigate(id); }}
        onPointerOver={(e) => { e.stopPropagation(); setHover(true); useStore.getState().hover(id); document.body.style.cursor = 'pointer'; }}
        onPointerOut={() => { setHover(false); if (useStore.getState().hoveredId === id) useStore.getState().hover(null); document.body.style.cursor = 'auto'; }}>
        <meshPhysicalMaterial color={hasColors ? '#ffffff' : color} roughness={roughness} transparent={op < 0.999} opacity={op} emissive={selected ? '#7fe3ff' : hovered ? '#ffffff' : (emissive ?? color)} emissiveIntensity={em} depthWrite={op > 0.5} flatShading={flatShading} />
      </instancedMesh>
      {show && (label || NODE_MAP[id]?.name) && (alwaysLabel || hovered || selected) && <group position={center}><Label text={label ?? NODE_MAP[id]!.name} selected={selected} /></group>}
    </group>
  );
}

export const deg = (d: number) => (d * Math.PI) / 180;
export const V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
