// ─── PLANTSCAPE core types, versions, element table, scale helpers ───────────

export const APP_VERSION = '1.0.0';
export const DATASET_VERSION = '2026.09.04';
export const MODEL_VERSION = 'procedural-anatomy-v1';

export type NodeType =
  | 'plant' | 'organ' | 'organ-part' | 'tissue' | 'cell' | 'organelle'
  | 'macromolecule' | 'molecule' | 'atom' | 'reference';

export type SciStatus =
  | 'OBSERVED STRUCTURE'
  | 'SCIENTIFIC MODEL'
  | '3D RECONSTRUCTION'
  | 'SCHEMATIC VISUALIZATION'
  | 'SIMULATED STRUCTURE'
  | 'MOLECULAR MODEL'
  | 'THEORETICAL / APPROXIMATED';

export type SceneKind =
  | 'plant' | 'root' | 'stem' | 'leaf' | 'stoma' | 'flower' | 'seed' | 'fruit'
  | 'tissue' | 'cell' | 'chloroplast' | 'thylakoid' | 'mitochondrion' | 'nucleus'
  | 'membrane' | 'wall' | 'molecule' | 'protein' | 'dna' | 'rna' | 'atom';

export interface Source {
  name: string;          // e.g. "PubChem", "RCSB PDB", "NIST CCCBDB", "Textbook anatomy"
  id?: string;           // identifier
  url?: string;
  license?: string;
  species?: string;
  resolution?: string;   // e.g. "2.5 Å X-ray"
  modelType?: string;    // e.g. "X-ray crystal structure", "computed 3D conformer"
  updated?: string;
}

export interface SciNode {
  id: string;
  name: string;
  type: NodeType;
  level: number;                 // 0 plant … 8 chemistry
  scaleM: number;                // characteristic size in metres
  parent?: string;               // canonical parent
  children: string[];
  scene: SceneKind;
  sceneParam?: string;           // cell type / molecule id / pdb id / element
  focusPart?: string;            // part id inside parent scene
  enterChild?: string;           // default child when zooming in
  status: SciStatus;
  description: string;
  fn: string;                    // function
  madeOf?: string;
  source?: Source;
  related?: string[];
  requires?: 'flower' | 'fruit' | 'seed' | 'dicot' | 'monocot' | 'secondary-growth' | 'non-grass';
  formula?: string;
}

export const LEVELS = [
  { level: 0, name: 'WHOLE PLANT', scale: '1 m' },
  { level: 1, name: 'ORGANS', scale: '10 cm' },
  { level: 2, name: 'TISSUES', scale: '1 mm – 100 µm' },
  { level: 3, name: 'CELLS', scale: '10–100 µm' },
  { level: 4, name: 'ORGANELLES', scale: '1 µm' },
  { level: 5, name: 'MACROMOLECULES', scale: '10 nm' },
  { level: 6, name: 'MOLECULES', scale: '1 nm' },
  { level: 7, name: 'ATOMS', scale: 'Å' },
  { level: 8, name: 'CHEMISTRY', scale: 'structure' },
];

export interface ElementInfo {
  symbol: string; name: string; Z: number; mass: number;
  covalent: number; vdw: number; color: string; valence: number; role: string;
}

// CPK/Jmol colouring convention; radii in Å (Cordero 2008 covalent; Bondi/Mantina vdW)
export const ELEMENTS: Record<string, ElementInfo> = {
  H:  { symbol: 'H', name: 'Hydrogen', Z: 1, mass: 1.008, covalent: 0.31, vdw: 1.10, color: '#e8e8e8', valence: 1, role: 'Present in nearly every biomolecule; water and reductant (NADPH) chemistry.' },
  C:  { symbol: 'C', name: 'Carbon', Z: 6, mass: 12.011, covalent: 0.76, vdw: 1.70, color: '#565656', valence: 4, role: 'Backbone of organic molecules; fixed from CO₂ by RuBisCO.' },
  N:  { symbol: 'N', name: 'Nitrogen', Z: 7, mass: 14.007, covalent: 0.71, vdw: 1.55, color: '#3050f8', valence: 3, role: 'Amino acids, nucleotides, chlorophyll; taken up as nitrate or ammonium.' },
  O:  { symbol: 'O', name: 'Oxygen', Z: 8, mass: 15.999, covalent: 0.66, vdw: 1.52, color: '#ff0d0d', valence: 2, role: 'Water, carbohydrates; O₂ released by water-splitting in photosystem II.' },
  P:  { symbol: 'P', name: 'Phosphorus', Z: 15, mass: 30.974, covalent: 1.07, vdw: 1.80, color: '#ff8000', valence: 5, role: 'Nucleic-acid backbone, ATP, phospholipids; macronutrient.' },
  S:  { symbol: 'S', name: 'Sulfur', Z: 16, mass: 32.06, covalent: 1.05, vdw: 1.80, color: '#ffff30', valence: 2, role: 'Cysteine/methionine, Fe–S clusters, glucosinolates.' },
  Mg: { symbol: 'Mg', name: 'Magnesium', Z: 12, mass: 24.305, covalent: 1.41, vdw: 1.73, color: '#8aff00', valence: 2, role: 'Central ion of chlorophyll; RuBisCO activation; macronutrient.' },
  K:  { symbol: 'K', name: 'Potassium', Z: 19, mass: 39.098, covalent: 2.03, vdw: 2.75, color: '#8f40d4', valence: 1, role: 'Major osmoticum; drives guard-cell swelling and stomatal opening.' },
  Ca: { symbol: 'Ca', name: 'Calcium', Z: 20, mass: 40.078, covalent: 1.76, vdw: 2.31, color: '#3dff00', valence: 2, role: 'Cell-wall pectin cross-linking; second messenger.' },
  Fe: { symbol: 'Fe', name: 'Iron', Z: 26, mass: 55.845, covalent: 1.32, vdw: 2.04, color: '#e06633', valence: 3, role: 'Cytochromes, ferredoxin, Fe–S clusters of electron transport.' },
  Mn: { symbol: 'Mn', name: 'Manganese', Z: 25, mass: 54.938, covalent: 1.39, vdw: 2.05, color: '#9c7ac7', valence: 2, role: 'Mn₄CaO₅ cluster of the oxygen-evolving complex (PSII).' },
  Cl: { symbol: 'Cl', name: 'Chlorine', Z: 17, mass: 35.45, covalent: 1.02, vdw: 1.75, color: '#1ff01f', valence: 1, role: 'Chloride: osmotic balance; cofactor in oxygen evolution.' },
  Na: { symbol: 'Na', name: 'Sodium', Z: 11, mass: 22.990, covalent: 1.66, vdw: 2.27, color: '#ab5cf2', valence: 1, role: 'Beneficial ion for some plants; excess is toxic.' },
  Zn: { symbol: 'Zn', name: 'Zinc', Z: 30, mass: 65.38, covalent: 1.22, vdw: 2.10, color: '#7d80b0', valence: 2, role: 'Enzyme cofactor; zinc-finger transcription factors.' },
  Cu: { symbol: 'Cu', name: 'Copper', Z: 29, mass: 63.546, covalent: 1.32, vdw: 1.96, color: '#c88033', valence: 2, role: 'Plastocyanin electron carrier; micronutrient.' },
};
export const elementOf = (sym: string): ElementInfo => {
  const s = sym.length > 1 ? sym[0].toUpperCase() + sym.slice(1).toLowerCase() : sym.toUpperCase();
  return ELEMENTS[s] ?? { symbol: s, name: s, Z: 0, mass: 0, covalent: 0.8, vdw: 1.6, color: '#ff69b4', valence: 0, role: 'No entry in the local element table.' };
};

// ─── scale formatting ────────────────────────────────────────────────────────
export function formatMeters(m: number, digits = 2): string {
  if (!isFinite(m) || m <= 0) return '—';
  const units: [number, string][] = [
    [1, 'm'], [1e-2, 'cm'], [1e-3, 'mm'], [1e-6, 'µm'], [1e-9, 'nm'], [1e-10, 'Å'], [1e-12, 'pm'],
  ];
  for (const [f, u] of units) {
    const v = m / f;
    if (v >= 1) return `${trim(v, digits)} ${u}`;
  }
  return `${trim(m / 1e-12, digits)} pm`;
}
export function formatArea(m2: number): string {
  const units: [number, string][] = [[1, 'm²'], [1e-4, 'cm²'], [1e-6, 'mm²'], [1e-12, 'µm²'], [1e-18, 'nm²'], [1e-20, 'Å²']];
  for (const [f, u] of units) { const v = m2 / f; if (v >= 1) return `${trim(v, 2)} ${u}`; }
  return `${trim(m2 / 1e-20, 2)} Å²`;
}
function trim(v: number, d: number) {
  return v >= 100 ? Math.round(v).toString() : v.toFixed(v >= 10 ? 1 : d);
}
export const nearestScaleLabel = (m: number) => {
  const marks = [10, 1, 0.1, 0.01, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10];
  let best = marks[0];
  for (const k of marks) if (Math.abs(Math.log10(k) - Math.log10(m)) < Math.abs(Math.log10(best) - Math.log10(m))) best = k;
  return best === 1e-10 ? 'Å-scale' : formatMeters(best, 0);
};

// Seeded PRNG (mulberry32)
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const STATUS_HINT: Record<SciStatus, string> = {
  'OBSERVED STRUCTURE': 'Anatomy documented by light/electron microscopy; the 3D geometry here is a reconstruction of that anatomy, not a micrograph.',
  'SCIENTIFIC MODEL': 'A consensus scientific model; geometry is illustrative.',
  '3D RECONSTRUCTION': 'Procedural reconstruction from published anatomical proportions.',
  'SCHEMATIC VISUALIZATION': 'Simplified diagrammatic 3D representation for education.',
  'SIMULATED STRUCTURE': 'Generated procedurally; not measured from a specimen.',
  'MOLECULAR MODEL': 'Atomic coordinates from an authoritative database or experimental geometry.',
  'THEORETICAL / APPROXIMATED': 'Idealised or approximated; treat quantitatively with caution.',
};
