import type { Source } from './core';

export type MolCategory =
  | 'PHOTOSYNTHETIC MOLECULES' | 'CARBOHYDRATES' | 'LIPIDS' | 'PROTEINS' | 'NUCLEIC ACIDS'
  | 'PIGMENTS' | 'HORMONES' | 'SECONDARY METABOLITES' | 'MINERAL NUTRIENTS' | 'GASES & WATER' | 'ENERGY CARRIERS';

export interface HardGeometry {
  atoms: [string, number, number, number][];   // element, x, y, z  (Å)
  bonds: [number, number, number][];            // i, j, order
  source: Source;
}

export interface MoleculeDef {
  id: string;
  name: string;
  formula: string;
  cid?: number;                    // PubChem CID (3D conformer + 2D depiction)
  pdbLigand?: { pdb: string; resName: string; label: string };   // extract from PDB crystal structure
  hard?: HardGeometry;             // experimental small-molecule geometry
  category: MolCategory;
  role: string;
  localization: string;            // where in the plant / cell
  context: string[];               // node id chain for "species context"
  scaleM: number;
  no3d?: string;                   // reason when no 3D conformer is expected
  chebi?: string;
  speciesNote?: string;
}

const PUBCHEM: Source = { name: 'PubChem (NCBI)', license: 'Public domain (U.S. Government work)', modelType: 'Computed 3D conformer (PubChem3D) + 2D depiction', updated: 'live API' };
const cccbdb = (id: string): Source => ({ name: 'NIST CCCBDB experimental geometry', id, url: 'https://cccbdb.nist.gov/', license: 'Public domain (NIST)', modelType: 'Experimental gas-phase geometry', updated: '2026' });

// Experimental geometries (NIST CCCBDB): H2O r(OH)=0.9575 Å, ∠HOH=104.51°; CO2 r(CO)=1.1600 Å; O2 r=1.2075 Å; C2H4 r(CC)=1.339, r(CH)=1.086 Å, ∠HCC=121.2°
const H2O: HardGeometry = {
  atoms: [['O', 0, 0, 0], ['H', 0.7571, 0.5862, 0], ['H', -0.7571, 0.5862, 0]],
  bonds: [[0, 1, 1], [0, 2, 1]], source: cccbdb('H2O'),
};
const CO2: HardGeometry = {
  atoms: [['C', 0, 0, 0], ['O', 1.16, 0, 0], ['O', -1.16, 0, 0]],
  bonds: [[0, 1, 2], [0, 2, 2]], source: cccbdb('CO2'),
};
const O2: HardGeometry = { atoms: [['O', 0.60375, 0, 0], ['O', -0.60375, 0, 0]], bonds: [[0, 1, 2]], source: cccbdb('O2') };
const C2H4: HardGeometry = {
  atoms: [['C', 0.6695, 0, 0], ['C', -0.6695, 0, 0], ['H', 1.2322, 0.9289, 0], ['H', 1.2322, -0.9289, 0], ['H', -1.2322, 0.9289, 0], ['H', -1.2322, -0.9289, 0]],
  bonds: [[0, 1, 2], [0, 2, 1], [0, 3, 1], [1, 4, 1], [1, 5, 1]], source: cccbdb('C2H4'),
};

export const MOLECULES: MoleculeDef[] = [
  // gases & water
  { id: 'water', name: 'Water', formula: 'H₂O', cid: 962, hard: H2O, category: 'GASES & WATER', role: 'Solvent of life; electron donor split by photosystem II; drives turgor and transpiration stream.', localization: 'Everywhere: vacuole, cytosol, xylem sap, apoplast.', context: ['plant', 'root-system', 'root-hair-cell', 'plasma-membrane', 'water'], scaleM: 2.8e-10, chebi: 'CHEBI:15377' },
  { id: 'carbon-dioxide', name: 'Carbon dioxide', formula: 'CO₂', cid: 280, hard: CO2, category: 'GASES & WATER', role: 'Carbon source fixed by RuBisCO in the Calvin cycle; enters leaves through stomata.', localization: 'Intercellular air spaces → chloroplast stroma.', context: ['plant', 'leaf', 'stoma', 'palisade-cell', 'chloroplast', 'stroma', 'carbon-dioxide'], scaleM: 3.3e-10, chebi: 'CHEBI:16526' },
  { id: 'oxygen', name: 'Dioxygen', formula: 'O₂', cid: 977, hard: O2, category: 'GASES & WATER', role: 'By-product of water oxidation at the oxygen-evolving complex; terminal electron acceptor in respiration.', localization: 'Thylakoid lumen → stroma → air spaces → atmosphere.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'thylakoid', 'oxygen'], scaleM: 3e-10, chebi: 'CHEBI:15379' },
  // carbohydrates
  { id: 'glucose', name: 'D-Glucose (pyranose)', formula: 'C₆H₁₂O₆', cid: 5793, category: 'CARBOHYDRATES', role: 'Primary hexose; monomer of cellulose and starch; substrate of glycolysis.', localization: 'Cytosol, vacuole, apoplast.', context: ['plant', 'leaf', 'palisade-cell', 'cytoplasm', 'glucose'], scaleM: 7e-10, chebi: 'CHEBI:4167' },
  { id: 'sucrose', name: 'Sucrose', formula: 'C₁₂H₂₂O₁₁', cid: 5988, category: 'CARBOHYDRATES', role: 'Main long-distance transport sugar loaded into phloem sieve tubes.', localization: 'Cytosol of mesophyll; phloem sap; vacuole (storage).', context: ['plant', 'leaf', 'leaf-vascular', 'phloem', 'sieve-tube-element', 'sucrose'], scaleM: 1e-9, chebi: 'CHEBI:17992' },
  { id: 'cellobiose', name: 'Cellobiose (cellulose repeat unit)', formula: 'C₁₂H₂₂O₁₁', cid: 439178, category: 'CARBOHYDRATES', role: 'β(1→4)-linked glucose dimer: the repeating unit of cellulose chains in the cell wall.', localization: 'Cell wall microfibrils (as polymer).', context: ['plant', 'stem', 'parenchyma-cell', 'cell-wall', 'cellulose', 'cellobiose'], scaleM: 1e-9, chebi: 'CHEBI:17057' },
  { id: 'maltose', name: 'Maltose (starch breakdown unit)', formula: 'C₁₂H₂₂O₁₁', cid: 439186, category: 'CARBOHYDRATES', role: 'α(1→4)-linked glucose dimer; main product of nocturnal starch degradation exported from chloroplasts.', localization: 'Chloroplast stroma → cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'stroma', 'starch-grain', 'maltose'], scaleM: 1e-9, chebi: 'CHEBI:17306' },
  { id: 'rubp', name: 'Ribulose-1,5-bisphosphate', formula: 'C₅H₁₂O₁₁P₂', cid: 123658, category: 'PHOTOSYNTHETIC MOLECULES', role: 'CO₂ acceptor of the Calvin cycle (RuBisCO substrate).', localization: 'Chloroplast stroma.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'stroma', 'rubp'], scaleM: 1e-9, chebi: 'CHEBI:16710' },
  { id: '3pga', name: '3-Phosphoglycerate', formula: 'C₃H₇O₇P', cid: 724, category: 'PHOTOSYNTHETIC MOLECULES', role: 'First stable product of CO₂ fixation (C₃ photosynthesis).', localization: 'Chloroplast stroma.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'stroma', '3pga'], scaleM: 8e-10, chebi: 'CHEBI:17794' },
  { id: 'g3p', name: 'Glyceraldehyde-3-phosphate', formula: 'C₃H₇O₆P', cid: 729, category: 'PHOTOSYNTHETIC MOLECULES', role: 'Triose phosphate exported from the chloroplast to build sucrose.', localization: 'Stroma → cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'stroma', 'g3p'], scaleM: 8e-10, chebi: 'CHEBI:29052' },
  // energy carriers
  { id: 'atp', name: 'ATP (adenosine triphosphate)', formula: 'C₁₀H₁₆N₅O₁₃P₃', cid: 5957, category: 'ENERGY CARRIERS', role: 'Universal energy currency, made by ATP synthase in chloroplasts and mitochondria.', localization: 'Stroma, matrix, cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'mitochondrion', 'matrix', 'atp'], scaleM: 1.4e-9, chebi: 'CHEBI:15422' },
  { id: 'nadp', name: 'NADP⁺', formula: 'C₂₁H₂₉N₇O₁₇P₃', cid: 5886, category: 'ENERGY CARRIERS', role: 'Final electron acceptor of the light reactions (reduced to NADPH by ferredoxin-NADP⁺ reductase).', localization: 'Chloroplast stroma.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'thylakoid', 'nadp'], scaleM: 1.6e-9, chebi: 'CHEBI:18009' },
  { id: 'nad', name: 'NAD⁺', formula: 'C₂₁H₂₈N₇O₁₄P₂', cid: 5893, category: 'ENERGY CARRIERS', role: 'Electron carrier of glycolysis and the TCA cycle.', localization: 'Cytosol, mitochondrial matrix.', context: ['plant', 'root-system', 'parenchyma-cell', 'mitochondrion', 'matrix', 'nad'], scaleM: 1.6e-9, chebi: 'CHEBI:15846' },
  { id: 'pyruvate', name: 'Pyruvic acid', formula: 'C₃H₄O₃', cid: 1060, category: 'ENERGY CARRIERS', role: 'End product of glycolysis imported into mitochondria.', localization: 'Cytosol → mitochondrial matrix.', context: ['plant', 'root-system', 'parenchyma-cell', 'mitochondrion', 'matrix', 'pyruvate'], scaleM: 6e-10, chebi: 'CHEBI:32816' },
  { id: 'citric-acid', name: 'Citric acid', formula: 'C₆H₈O₇', cid: 311, category: 'SECONDARY METABOLITES', role: 'TCA-cycle intermediate; accumulates in vacuoles of many fruits (tomato, citrus, mango) giving sourness.', localization: 'Mitochondrial matrix; fruit vacuoles.', context: ['plant', 'fruit', 'parenchyma-cell', 'vacuole', 'citric-acid'], scaleM: 8e-10, chebi: 'CHEBI:30769' },
  // pigments
  { id: 'chlorophyll-a', name: 'Chlorophyll a', formula: 'C₅₅H₇₂MgN₄O₅', cid: 12085802, pdbLigand: { pdb: '2BHW', resName: 'CLA', label: 'Chlorophyll a (CLA) ligand extracted from pea LHCII crystal structure 2BHW' }, category: 'PIGMENTS', role: 'Primary photosynthetic pigment: absorbs red/blue light; special-pair chlorophylls perform charge separation in PSII (P680) and PSI (P700).', localization: 'Thylakoid membrane, bound in light-harvesting and reaction-centre complexes.', context: ['plant', 'leaf', 'mesophyll', 'palisade-cell', 'chloroplast', 'thylakoid', 'lhcii', 'chlorophyll-a'], scaleM: 2e-9, no3d: 'PubChem does not compute 3D conformers for Mg-containing compounds; the 3D coordinates shown come from the crystal structure of LHCII (PDB 2BHW).', chebi: 'CHEBI:18230' },
  { id: 'beta-carotene', name: 'β-Carotene', formula: 'C₄₀H₅₆', cid: 5280489, category: 'PIGMENTS', role: 'Accessory light-harvesting pigment and photoprotectant (quenches singlet oxygen); provitamin A; orange colour of mango flesh.', localization: 'Thylakoid membranes; chromoplasts of fruit.', context: ['plant', 'fruit', 'parenchyma-cell', 'chloroplast', 'thylakoid', 'beta-carotene'], scaleM: 3e-9, chebi: 'CHEBI:17579' },
  { id: 'lutein', name: 'Lutein', formula: 'C₄₀H₅₆O₂', cid: 5281243, pdbLigand: { pdb: '2BHW', resName: 'LUT', label: 'Lutein (LUT) ligand extracted from pea LHCII crystal structure 2BHW' }, category: 'PIGMENTS', role: 'Most abundant xanthophyll in LHCII; structural role and triplet-chlorophyll quenching.', localization: 'Bound in LHCII trimers.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'thylakoid', 'lhcii', 'lutein'], scaleM: 3e-9, chebi: 'CHEBI:28838' },
  { id: 'lycopene', name: 'Lycopene', formula: 'C₄₀H₅₆', cid: 446925, category: 'PIGMENTS', role: 'Linear carotene responsible for the red colour of ripe tomato fruit; accumulates in chromoplasts.', localization: 'Chromoplasts of ripe fruit pericarp.', context: ['plant', 'fruit', 'parenchyma-cell', 'lycopene'], scaleM: 3e-9, speciesNote: 'tomato', chebi: 'CHEBI:15948' },
  { id: 'cyanidin', name: 'Cyanidin (anthocyanidin)', formula: 'C₁₅H₁₁O₆⁺', cid: 128861, category: 'PIGMENTS', role: 'Aglycone of the red–purple anthocyanins of rose petals and many fruits; stored as glycosides in the vacuole.', localization: 'Vacuole of epidermal cells (petals, fruit skin, red leaves).', context: ['plant', 'flower', 'petal', 'epidermal-cell', 'vacuole', 'cyanidin'], scaleM: 1.1e-9, speciesNote: 'rose', chebi: 'CHEBI:27843' },
  // hormones
  { id: 'iaa', name: 'Indole-3-acetic acid (auxin)', formula: 'C₁₀H₉NO₂', cid: 802, category: 'HORMONES', role: 'Principal natural auxin: apical dominance, tropisms, cell elongation, vascular patterning, root initiation.', localization: 'Synthesised in shoot apex and young leaves; polar transport via PIN carriers.', context: ['plant', 'stem', 'meristem', 'meristematic-cell', 'iaa'], scaleM: 9e-10, chebi: 'CHEBI:16411' },
  { id: 'gibberellin-a3', name: 'Gibberellin A₃ (gibberellic acid)', formula: 'C₁₉H₂₂O₆', cid: 6466, category: 'HORMONES', role: 'Promotes stem elongation, seed germination (α-amylase induction in cereal aleurone) and flowering.', localization: 'Developing seeds, young leaves, internodes.', context: ['plant', 'seed', 'embryo', 'gibberellin-a3'], scaleM: 1e-9, chebi: 'CHEBI:28833' },
  { id: 'zeatin', name: 'trans-Zeatin (cytokinin)', formula: 'C₁₀H₁₃N₅O', cid: 449093, category: 'HORMONES', role: 'Promotes cell division, shoot initiation and delays leaf senescence; first isolated from maize endosperm.', localization: 'Root tips (synthesis), transported in xylem.', context: ['plant', 'root-system', 'root-tip', 'meristematic-cell', 'zeatin'], scaleM: 1e-9, speciesNote: 'maize', chebi: 'CHEBI:16522' },
  { id: 'abscisic-acid', name: 'Abscisic acid (ABA)', formula: 'C₁₅H₂₀O₄', cid: 5280896, category: 'HORMONES', role: 'Drought signal: closes stomata via guard-cell ion efflux; maintains seed dormancy.', localization: 'Guard cells, seeds, roots under water stress.', context: ['plant', 'leaf', 'stoma', 'guard-cell', 'abscisic-acid'], scaleM: 1e-9, chebi: 'CHEBI:22152' },
  { id: 'ethylene', name: 'Ethylene', formula: 'C₂H₄', cid: 6325, hard: C2H4, category: 'HORMONES', role: 'Gaseous hormone: fruit ripening (climacteric fruits such as tomato, mango), leaf abscission, stress responses.', localization: 'Produced from ACC in ripening fruit and senescing tissue.', context: ['plant', 'fruit', 'ethylene'], scaleM: 4e-10, chebi: 'CHEBI:18153' },
  // amino acids & nucleotides
  { id: 'glycine', name: 'Glycine', formula: 'C₂H₅NO₂', cid: 750, category: 'PROTEINS', role: 'Simplest amino acid; key intermediate of photorespiration in mitochondria.', localization: 'Cytosol, peroxisome, mitochondrion.', context: ['plant', 'leaf', 'palisade-cell', 'mitochondrion', 'glycine'], scaleM: 5e-10, chebi: 'CHEBI:15428' },
  { id: 'alanine', name: 'L-Alanine', formula: 'C₃H₇NO₂', cid: 5950, category: 'PROTEINS', role: 'Proteinogenic amino acid; example of a chiral α-amino acid.', localization: 'Cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'cytoplasm', 'alanine'], scaleM: 5e-10, chebi: 'CHEBI:16977' },
  { id: 'cysteine', name: 'L-Cysteine', formula: 'C₃H₇NO₂S', cid: 5862, category: 'PROTEINS', role: 'Sulfur amino acid; forms disulfide bonds; ligand for Fe–S clusters (e.g. ferredoxin).', localization: 'Plastid (synthesis), cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'stroma', 'cysteine'], scaleM: 6e-10, chebi: 'CHEBI:17561' },
  { id: 'damp', name: "2'-Deoxyadenosine 5'-monophosphate (dAMP)", formula: 'C₁₀H₁₄N₅O₆P', cid: 12599, category: 'NUCLEIC ACIDS', role: 'A DNA nucleotide: phosphate + deoxyribose + adenine.', localization: 'Nucleus (DNA), plastid and mitochondrial genomes.', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'chromatin', 'dna', 'damp'], scaleM: 1e-9, chebi: 'CHEBI:17713' },
  { id: 'adenine', name: 'Adenine', formula: 'C₅H₅N₅', cid: 190, category: 'NUCLEIC ACIDS', role: 'Purine base; pairs with thymine (DNA) or uracil (RNA); part of ATP.', localization: 'Nucleus, all nucleotides.', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'chromatin', 'dna', 'adenine'], scaleM: 6e-10, chebi: 'CHEBI:16708' },
  { id: 'thymine', name: 'Thymine', formula: 'C₅H₆N₂O₂', cid: 1135, category: 'NUCLEIC ACIDS', role: 'Pyrimidine base of DNA; pairs with adenine via two hydrogen bonds.', localization: 'Nucleus.', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'chromatin', 'dna', 'thymine'], scaleM: 6e-10, chebi: 'CHEBI:17821' },
  { id: 'guanine', name: 'Guanine', formula: 'C₅H₅N₅O', cid: 135, category: 'NUCLEIC ACIDS', role: 'Purine base; pairs with cytosine via three hydrogen bonds.', localization: 'Nucleus.', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'chromatin', 'dna', 'guanine'], scaleM: 6e-10, chebi: 'CHEBI:16235' },
  { id: 'cytosine', name: 'Cytosine', formula: 'C₄H₅N₃O', cid: 597, category: 'NUCLEIC ACIDS', role: 'Pyrimidine base; cytosine methylation is a major plant epigenetic mark.', localization: 'Nucleus.', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'chromatin', 'dna', 'cytosine'], scaleM: 6e-10, chebi: 'CHEBI:16040' },
  { id: 'uracil', name: 'Uracil', formula: 'C₄H₄N₂O₂', cid: 1174, category: 'NUCLEIC ACIDS', role: 'RNA base replacing thymine.', localization: 'Nucleus, cytosol (RNA).', context: ['plant', 'leaf', 'palisade-cell', 'nucleus', 'nucleolus', 'uracil'], scaleM: 6e-10, chebi: 'CHEBI:17568' },
  // lipids
  { id: 'palmitic-acid', name: 'Palmitic acid (16:0)', formula: 'C₁₆H₃₂O₂', cid: 985, category: 'LIPIDS', role: 'Saturated fatty acid synthesised in plastids; acyl chain of membrane lipids and cuticular wax precursors.', localization: 'Plastid stroma (synthesis); membranes; cuticle.', context: ['plant', 'leaf', 'epidermal-cell', 'plasma-membrane', 'palmitic-acid'], scaleM: 2e-9, chebi: 'CHEBI:15756' },
  { id: 'linoleic-acid', name: 'Linoleic acid (18:2)', formula: 'C₁₈H₃₂O₂', cid: 5280450, category: 'LIPIDS', role: 'Polyunsaturated fatty acid abundant in sunflower seed oil (triacylglycerol storage).', localization: 'Oil bodies of seeds; membranes.', context: ['plant', 'seed', 'cotyledon', 'linoleic-acid'], scaleM: 2.2e-9, speciesNote: 'sunflower', chebi: 'CHEBI:17351' },
  { id: 'glycerol', name: 'Glycerol', formula: 'C₃H₈O₃', cid: 753, category: 'LIPIDS', role: 'Backbone of glycerolipids (phospholipids, galactolipids, triacylglycerols).', localization: 'All membranes (as part of lipids).', context: ['plant', 'leaf', 'palisade-cell', 'plasma-membrane', 'glycerol'], scaleM: 5e-10, chebi: 'CHEBI:17754' },
  // secondary metabolites
  { id: 'menthol', name: '(−)-Menthol', formula: 'C₁₀H₂₀O', cid: 16666, category: 'SECONDARY METABOLITES', role: 'Monoterpene alcohol giving peppermint its cooling scent; made and stored in peltate glandular trichomes.', localization: 'Glandular trichomes on leaf epidermis.', context: ['plant', 'leaf', 'upper-epidermis', 'epidermal-cell', 'menthol'], scaleM: 8e-10, speciesNote: 'mint', chebi: 'CHEBI:15409' },
  { id: 'geraniol', name: 'Geraniol', formula: 'C₁₀H₁₈O', cid: 637566, category: 'SECONDARY METABOLITES', role: 'Acyclic monoterpene alcohol; major component of rose scent, emitted from petal epidermis.', localization: 'Petal epidermal cells.', context: ['plant', 'flower', 'petal', 'epidermal-cell', 'geraniol'], scaleM: 1e-9, speciesNote: 'rose', chebi: 'CHEBI:17447' },
  { id: 'salicylic-acid', name: 'Salicylic acid', formula: 'C₇H₆O₃', cid: 338, category: 'SECONDARY METABOLITES', role: 'Phenolic defence hormone (systemic acquired resistance).', localization: 'Cytosol; apoplast during pathogen response.', context: ['plant', 'leaf', 'palisade-cell', 'cytoplasm', 'salicylic-acid'], scaleM: 7e-10, chebi: 'CHEBI:16914' },
  { id: 'coniferyl-alcohol', name: 'Coniferyl alcohol (lignin monomer)', formula: 'C₁₀H₁₂O₃', cid: 1549095, category: 'SECONDARY METABOLITES', role: 'Monolignol polymerised into lignin, stiffening secondary walls of xylem and fibres.', localization: 'Secondary cell walls (xylem, sclerenchyma).', context: ['plant', 'stem', 'xylem', 'vessel-element', 'cell-wall', 'coniferyl-alcohol'], scaleM: 1e-9, chebi: 'CHEBI:17745' },
  { id: 'caffeine', name: 'Caffeine', formula: 'C₈H₁₀N₄O₂', cid: 2519, category: 'SECONDARY METABOLITES', role: 'Purine alkaloid (coffee, tea, cacao) – herbivore deterrent. Shown as an example alkaloid; not produced by the species in this atlas.', localization: 'Vacuoles of leaves and seeds (in producing species).', context: ['plant', 'leaf', 'palisade-cell', 'vacuole', 'caffeine'], scaleM: 8e-10, chebi: 'CHEBI:27732' },
  // minerals
  { id: 'nitrate', name: 'Nitrate ion', formula: 'NO₃⁻', cid: 943, category: 'MINERAL NUTRIENTS', role: 'Main nitrogen source taken up by roots (NRT transporters); reduced to nitrite and ammonium.', localization: 'Soil solution → root hair → xylem → leaf.', context: ['plant', 'root-system', 'root-hair-cell', 'nitrate'], scaleM: 4e-10, chebi: 'CHEBI:17632' },
  { id: 'ammonium', name: 'Ammonium ion', formula: 'NH₄⁺', cid: 223, category: 'MINERAL NUTRIENTS', role: 'Reduced nitrogen assimilated into glutamine by GS/GOGAT.', localization: 'Root cells; plastids.', context: ['plant', 'root-system', 'root-hair-cell', 'ammonium'], scaleM: 3.5e-10, chebi: 'CHEBI:28938' },
  { id: 'phosphate', name: 'Phosphate ion', formula: 'PO₄³⁻', cid: 1061, category: 'MINERAL NUTRIENTS', role: 'Phosphorus source; component of ATP, nucleic acids and phospholipids.', localization: 'Soil → root (PHT transporters) → vacuole/cytosol.', context: ['plant', 'root-system', 'root-hair-cell', 'phosphate'], scaleM: 4e-10, chebi: 'CHEBI:18367' },
  { id: 'potassium-ion', name: 'Potassium ion', formula: 'K⁺', cid: 813, category: 'MINERAL NUTRIENTS', role: 'Dominant intracellular cation; guard-cell osmoticum driving stomatal opening.', localization: 'Vacuole, cytosol, guard cells.', context: ['plant', 'leaf', 'stoma', 'guard-cell', 'vacuole', 'potassium-ion'], scaleM: 2.8e-10, chebi: 'CHEBI:29103' },
  { id: 'magnesium-ion', name: 'Magnesium ion', formula: 'Mg²⁺', cid: 888, category: 'MINERAL NUTRIENTS', role: 'Centre of the chlorophyll chlorin ring; cofactor of RuBisCO and ATP-dependent enzymes.', localization: 'Chloroplast, cytosol.', context: ['plant', 'leaf', 'palisade-cell', 'chloroplast', 'thylakoid', 'chlorophyll-a', 'magnesium-ion'], scaleM: 1.7e-10, chebi: 'CHEBI:18420' },
  { id: 'calcium-ion', name: 'Calcium ion', formula: 'Ca²⁺', cid: 271, category: 'MINERAL NUTRIENTS', role: 'Cross-links pectin in the middle lamella; cytosolic second messenger.', localization: 'Cell wall, vacuole, ER.', context: ['plant', 'stem', 'parenchyma-cell', 'cell-wall', 'calcium-ion'], scaleM: 2.3e-10, chebi: 'CHEBI:29108' },
];
export const moleculeById = (id: string) => MOLECULES.find((m) => m.id === id);
export const PUBCHEM_SOURCE = PUBCHEM;

// ─── Proteins / macromolecular structures (RCSB PDB) ─────────────────────────
export interface ProteinDef {
  id: string; pdb: string; name: string; organism: string; method: string; resolution: string;
  role: string; localization: string; approxAtoms: number; heavy?: boolean; category: string;
  citation: string; ligands?: string[]; scaleM: number; note?: string;
}
export const PROTEINS: ProteinDef[] = [
  { id: 'lhcii', pdb: '2BHW', name: 'Light-harvesting complex II (LHCII) trimer', organism: 'Pisum sativum (pea)', method: 'X-ray diffraction', resolution: '2.5 Å', role: 'Main antenna complex of PSII: binds 14 chlorophylls (8 Chl a, 6 Chl b) and 4 carotenoids per monomer; funnels excitation energy to reaction centres.', localization: 'Thylakoid membrane (grana).', approxAtoms: 7400, category: 'photosynthetic', citation: 'Standfuss J, et al. (2005) EMBO J 24:919–928', ligands: ['CLA', 'CHL', 'LUT', 'NEX', 'XAT'], scaleM: 7e-9 },
  { id: 'rubisco', pdb: '8RUC', name: 'RuBisCO (L₈S₈) with CABP', organism: 'Spinacia oleracea (spinach)', method: 'X-ray diffraction', resolution: '1.6 Å', role: 'Ribulose-1,5-bisphosphate carboxylase/oxygenase: fixes CO₂ onto RuBP; the most abundant enzyme on Earth.', localization: 'Chloroplast stroma.', approxAtoms: 37000, heavy: true, category: 'enzyme', citation: 'Andersson I. (1996) J Mol Biol 259:160–174', ligands: ['CAP', 'MG'], scaleM: 1.2e-8 },
  { id: 'aquaporin', pdb: '1Z98', name: 'Aquaporin SoPIP2;1 (closed)', organism: 'Spinacia oleracea (spinach)', method: 'X-ray diffraction', resolution: '2.1 Å', role: 'Plasma-membrane water channel; gating by phosphorylation/pH regulates water permeability of root and leaf cells.', localization: 'Plasma membrane.', approxAtoms: 8500, category: 'membrane', citation: 'Törnroth-Horsefield S, et al. (2006) Nature 439:688–694', scaleM: 7e-9 },
  { id: 'plastocyanin', pdb: '1AG6', name: 'Plastocyanin', organism: 'Spinacia oleracea (spinach)', method: 'X-ray diffraction', resolution: '1.7 Å', role: 'Small copper protein shuttling electrons from cytochrome b₆f to PSI in the thylakoid lumen.', localization: 'Thylakoid lumen.', approxAtoms: 900, category: 'photosynthetic', citation: 'Xue Y, et al. (1998) Protein Sci 7:2099–2105', ligands: ['CU'], scaleM: 3e-9 },
  { id: 'ferredoxin', pdb: '1A70', name: 'Ferredoxin (2Fe–2S)', organism: 'Spinacia oleracea (spinach)', method: 'X-ray diffraction', resolution: '1.7 Å', role: 'Accepts electrons from PSI and passes them to FNR (NADP⁺ reduction) and other stromal enzymes.', localization: 'Chloroplast stroma (thylakoid surface).', approxAtoms: 800, category: 'photosynthetic', citation: 'Binda C, et al. (1998) Acta Cryst D54:1353–1358', ligands: ['FES'], scaleM: 3e-9 },
  { id: 'psii', pdb: '3WU2', name: 'Photosystem II dimer', organism: 'Thermosynechococcus vulcanus (cyanobacterium)', method: 'X-ray diffraction (XFEL)', resolution: '1.95 Å', role: 'Water-splitting reaction centre with the Mn₄CaO₅ oxygen-evolving cluster. Shown as the highest-resolution model; plant PSII core is highly homologous.', localization: 'Thylakoid membrane (grana).', approxAtoms: 52000, heavy: true, category: 'photosynthetic', citation: 'Suga M, et al. (2015) Nature 517:99–103', ligands: ['CLA', 'PHO', 'BCR', 'OEX', 'PL9'], scaleM: 2e-8, note: 'Not a plant structure – labelled accordingly.' },
  { id: 'cytb6f', pdb: '6RQF', name: 'Cytochrome b₆f complex', organism: 'Spinacia oleracea (spinach)', method: 'Cryo-EM', resolution: '3.6 Å', role: 'Links PSII and PSI via plastoquinol oxidation; pumps protons into the lumen.', localization: 'Thylakoid membrane.', approxAtoms: 17000, heavy: true, category: 'photosynthetic', citation: 'Malone LA, et al. (2019) Nature 575:535–539', scaleM: 1e-8 },
  { id: 'cesa', pdb: '6WLB', name: 'Cellulose synthase CesA8 trimer', organism: 'Populus tremula × tremuloides (poplar)', method: 'Cryo-EM', resolution: '3.5 Å', role: 'Plasma-membrane enzyme that polymerises UDP-glucose into cellulose chains and extrudes them into the wall.', localization: 'Plasma membrane (cellulose synthase complex).', approxAtoms: 20000, heavy: true, category: 'structural', citation: 'Purushotham P, et al. (2020) Science 369:1089–1094', scaleM: 1.2e-8 },
  { id: 'dna-1bna', pdb: '1BNA', name: 'B-DNA dodecamer d(CGCGAATTCGCG)₂', organism: 'Synthetic oligonucleotide', method: 'X-ray diffraction', resolution: '1.9 Å', role: 'Classic Drew–Dickerson B-DNA double helix: 12 base pairs, ~one full helical turn.', localization: 'Reference structure for nuclear DNA.', approxAtoms: 570, category: 'nucleic-acid', citation: 'Drew HR, et al. (1981) PNAS 78:2179–2183', scaleM: 4e-9 },
  { id: 'trna', pdb: '1EHZ', name: 'Phenylalanine tRNA', organism: 'Saccharomyces cerevisiae (yeast)', method: 'X-ray diffraction', resolution: '1.93 Å', role: 'L-shaped adaptor RNA carrying an amino acid to the ribosome; anticodon loop pairs with mRNA.', localization: 'Cytosol (reference structure; plant tRNAs are homologous).', approxAtoms: 1650, category: 'nucleic-acid', citation: 'Shi H, Moore PB. (2000) RNA 6:1091–1105', scaleM: 7e-9, note: 'Not a plant structure – labelled accordingly.' },
];
export const proteinById = (id: string) => PROTEINS.find((p) => p.id === id);

// ─── Conceptual pathways ─────────────────────────────────────────────────────
export interface Pathway { id: string; name: string; where: string; steps: { label: string; node?: string }[]; note: string; }
export const PATHWAYS: Pathway[] = [
  { id: 'light-reactions', name: 'Photosynthesis · light reactions', where: 'Thylakoid membrane', steps: [
    { label: 'Photon absorbed by LHCII / chlorophyll a', node: 'lhcii' }, { label: 'PSII (P680) charge separation; water oxidised → O₂ + 4H⁺ + 4e⁻', node: 'psii' },
    { label: 'Plastoquinone carries e⁻ to cytochrome b₆f', node: 'cytb6f' }, { label: 'Plastocyanin carries e⁻ to PSI (P700)', node: 'plastocyanin' },
    { label: 'Ferredoxin → FNR reduces NADP⁺ to NADPH', node: 'ferredoxin' }, { label: 'Proton gradient drives ATP synthase → ATP', node: 'atp' }],
    note: 'CONCEPTUAL PATHWAY — the Z-scheme is well established; the animation is a visual simplification, not a kinetic simulation.' },
  { id: 'calvin', name: 'Photosynthesis · Calvin–Benson cycle', where: 'Chloroplast stroma', steps: [
    { label: 'RuBisCO carboxylates RuBP with CO₂', node: 'rubisco' }, { label: '2 × 3-phosphoglycerate formed', node: '3pga' },
    { label: 'Reduction to glyceraldehyde-3-phosphate using ATP + NADPH', node: 'g3p' }, { label: 'Regeneration of RuBP', node: 'rubp' },
    { label: 'Triose phosphate exported → sucrose (cytosol) or starch (stroma)', node: 'sucrose' }],
    note: 'CONCEPTUAL PATHWAY — stoichiometry summarised; 3 CO₂ per net triose phosphate.' },
  { id: 'respiration', name: 'Cellular respiration', where: 'Cytosol → mitochondrion', steps: [
    { label: 'Glycolysis: glucose → 2 pyruvate', node: 'glucose' }, { label: 'Pyruvate imported to matrix, oxidised to acetyl-CoA', node: 'pyruvate' },
    { label: 'TCA cycle: NADH, FADH₂, CO₂', node: 'citric-acid' }, { label: 'Electron transport chain on cristae; O₂ reduced to water', node: 'cristae' },
    { label: 'ATP synthase makes ATP', node: 'atp' }],
    note: 'CONCEPTUAL PATHWAY — plants also have alternative oxidase and photorespiratory glycine oxidation in the matrix.' },
  { id: 'starch', name: 'Starch metabolism', where: 'Chloroplast stroma', steps: [
    { label: 'Day: triose-P → fructose-6-P → glucose-1-P → ADP-glucose', node: 'g3p' }, { label: 'Starch synthases polymerise amylose/amylopectin (α1→4, α1→6)', node: 'starch-grain' },
    { label: 'Night: β-amylases release maltose', node: 'maltose' }, { label: 'Maltose exported to cytosol (MEX1) → sucrose', node: 'sucrose' }],
    note: 'CONCEPTUAL PATHWAY — transitory starch; storage starch in seeds/tubers uses amyloplasts.' },
  { id: 'sucrose-transport', name: 'Sucrose transport (source → sink)', where: 'Mesophyll → phloem → root/fruit', steps: [
    { label: 'Sucrose synthesised in mesophyll cytosol', node: 'sucrose' }, { label: 'Apoplastic loading by SWEET efflux + SUT/SUC H⁺-symport into companion cells', node: 'companion-cell' },
    { label: 'Pressure flow through sieve tubes', node: 'sieve-tube-element' }, { label: 'Unloading in sinks: growing roots, fruits, seeds', node: 'fruit' }],
    note: 'CONCEPTUAL FLOW VISUALIZATION — Münch pressure-flow hypothesis.' },
  { id: 'cellulose', name: 'Cellulose formation', where: 'Plasma membrane → cell wall', steps: [
    { label: 'UDP-glucose in cytosol', node: 'glucose' }, { label: 'Cellulose synthase complex (rosette of CesA trimers) polymerises β(1→4) glucan', node: 'cesa' },
    { label: 'Chains crystallise into microfibrils (~18 chains)', node: 'cellulose' }, { label: 'Microfibrils cross-linked by hemicellulose; embedded in pectin', node: 'cell-wall' }],
    note: 'CONCEPTUAL PATHWAY — microfibril chain number is still debated (18 vs 24 vs 36).' },
  { id: 'auxin', name: 'Auxin signalling', where: 'Nucleus', steps: [
    { label: 'IAA enters the cell (AUX1 influx, diffusion)', node: 'iaa' }, { label: 'IAA glues TIR1/AFB F-box to Aux/IAA repressors', node: 'nucleus' },
    { label: 'Aux/IAA ubiquitinated and degraded (26S proteasome)' }, { label: 'ARF transcription factors activate auxin-responsive genes', node: 'chromatin' }, { label: 'PIN efflux carriers create polar auxin flow', node: 'plasma-membrane' }],
    note: 'CONCEPTUAL PATHWAY — canonical TIR1/AFB pathway; non-canonical pathways exist.' },
];

// ─── Cinematic journeys ──────────────────────────────────────────────────────
export interface Journey { id: string; name: string; steps: { node: string; text: string }[]; }
export const JOURNEYS: Journey[] = [
  { id: 'plant-to-chloroplast', name: 'From plant to chloroplast', steps: [
    { node: 'plant', text: 'We begin with the whole plant, ~1 m tall, orbiting freely.' },
    { node: 'leaf', text: 'A leaf: the photosynthetic organ. Its blade is a few hundred micrometres thick.' },
    { node: 'mesophyll', text: 'Inside the leaf: mesophyll tissue — palisade columns on top, spongy cells below.' },
    { node: 'palisade-cell', text: 'A single palisade cell, ~50 µm long, packed with dozens of chloroplasts.' },
    { node: 'chloroplast', text: 'The chloroplast: double envelope, stroma, and stacks of thylakoid membranes.' }] },
  { id: 'leaf-to-chemistry', name: 'From leaf to chemistry', steps: [
    { node: 'leaf', text: 'Start at the leaf.' }, { node: 'mesophyll', text: 'Enter the mesophyll tissue.' }, { node: 'palisade-cell', text: 'Enter a palisade cell.' },
    { node: 'chloroplast', text: 'Enter a chloroplast.' }, { node: 'thylakoid', text: 'The thylakoid membrane hosts the photosystems.' },
    { node: 'lhcii', text: 'LHCII — a real crystal structure (PDB 2BHW) with its bound chlorophylls.' },
    { node: 'chlorophyll-a', text: 'Chlorophyll a extracted from that crystal: a Mg-centred chlorin ring with a phytol tail.' },
    { node: 'atom-Mg', text: 'At the centre: a single magnesium atom.' }] },
  { id: 'root-to-water', name: 'From root to water', steps: [
    { node: 'root-system', text: 'Roots anchor the plant and absorb water and minerals.' }, { node: 'root-epidermis', text: 'The root epidermis extends root hairs into the soil.' },
    { node: 'root-hair-cell', text: 'A root hair cell: a single epidermal cell with a long tubular extension.' }, { node: 'plasma-membrane', text: 'Water crosses the plasma membrane through aquaporin channels.' },
    { node: 'aquaporin', text: 'Spinach aquaporin SoPIP2;1 (PDB 1Z98) — a real membrane protein structure.' }, { node: 'water', text: 'A single water molecule: O–H 0.9575 Å, angle 104.5° (NIST experimental geometry).' }] },
  { id: 'nucleus-to-dna', name: 'From cell to DNA', steps: [
    { node: 'meristematic-cell', text: 'A dividing meristematic cell with a large nucleus.' }, { node: 'nucleus', text: 'The nucleus: double envelope with pores, chromatin, nucleolus.' },
    { node: 'chromatin', text: 'Chromatin: DNA wrapped around histone octamers.' }, { node: 'dna', text: 'The DNA double helix — idealised B-form and the 1BNA crystal structure.' },
    { node: 'damp', text: 'A nucleotide: phosphate, deoxyribose, base.' }, { node: 'atom-P', text: 'Down to a phosphorus atom of the backbone.' }] },
];

// ─── Compare presets ─────────────────────────────────────────────────────────
export const COMPARE_PRESETS: { name: string; a: string; b: string }[] = [
  { name: 'Leaf vs Root', a: 'leaf', b: 'root-system' },
  { name: 'Xylem vs Phloem', a: 'xylem', b: 'phloem' },
  { name: 'Plant cell vs Animal cell', a: 'parenchyma-cell', b: 'animal-cell' },
  { name: 'Chloroplast vs Mitochondrion', a: 'chloroplast', b: 'mitochondrion' },
  { name: 'Glucose vs Sucrose', a: 'glucose', b: 'sucrose' },
  { name: 'Cellulose unit vs Starch unit', a: 'cellobiose', b: 'maltose' },
  { name: 'Palisade vs Spongy cell', a: 'palisade-cell', b: 'spongy-cell' },
];

export const GLOSSARY: { term: string; def: string; node?: string }[] = [
  { term: 'Casparian strip', def: 'Suberin/lignin band in endodermal cell walls that blocks apoplastic flow into the stele.', node: 'endodermis' },
  { term: 'Kranz anatomy', def: 'C₄ leaf anatomy with a chloroplast-rich bundle sheath ring around each vein (maize).', node: 'bundle-sheath' },
  { term: 'Turgor', def: 'Hydrostatic pressure of the protoplast against the cell wall generated by vacuolar solutes.', node: 'vacuole' },
  { term: 'Transpiration stream', def: 'Continuous water column pulled from roots to leaves through xylem by evaporation.', node: 'xylem' },
  { term: 'Plasmodesmata', def: 'Cytoplasmic channels through cell walls connecting neighbouring plant cells (symplast).', node: 'plasmodesma' },
  { term: 'Photorespiration', def: 'RuBisCO oxygenase side-reaction recycled through peroxisome and mitochondrion.', node: 'peroxisome' },
  { term: 'Z-scheme', def: 'Energy diagram of the two photosystems in series during the light reactions.', node: 'thylakoid' },
];
