export type LeafShape = 'lanceolate' | 'ovate' | 'cordate' | 'linear' | 'frond' | 'pinnate';
export type FlowerType = 'composite' | 'rose' | 'star' | 'spike' | 'panicle' | 'verticillaster' | 'none';
export type FruitType = 'achene' | 'hip' | 'nutlet' | 'none' | 'drupe' | 'caryopsis' | 'cob' | 'berry';

export interface PlantParams {
  height: number;        // metres (mature)
  stemThickness: number; // metres (diameter)
  branchCount: number;
  leafCount: number;
  leafSize: number;      // metres
  leafAngle: number;     // degrees from stem
  rootSpread: number;    // metres
  rootDepth: number;
  flowerCount: number;
  fruitCount: number;
  growthStage: number;   // 0..1
  seed: number;
  leafShape: LeafShape;
  flowerType: FlowerType;
  fruitType: FruitType;
  stemColor: string;
  leafColor: string;
  petalColor: string;
  fruitColor: string;
  woody: boolean;
  fibrousRoots: boolean;
}

export interface Species {
  id: string;
  common: string;
  scientific: string;
  family: string;
  type: 'eudicot' | 'monocot' | 'fern' | 'custom';
  growthForm: string;
  lifeCycle: string;
  hasFlower: boolean; hasFruit: boolean; hasSeed: boolean; secondaryGrowth: boolean;
  organs: string[];
  tissues: string[];
  cells: string[];
  molecules: string[];       // highlighted molecule ids
  notes: string;
  params: PlantParams;
}

const base: PlantParams = {
  height: 1, stemThickness: 0.02, branchCount: 4, leafCount: 20, leafSize: 0.12, leafAngle: 50,
  rootSpread: 0.4, rootDepth: 0.5, flowerCount: 3, fruitCount: 3, growthStage: 1, seed: 7,
  leafShape: 'ovate', flowerType: 'star', fruitType: 'berry', stemColor: '#5c8a3a', leafColor: '#3f8a3a',
  petalColor: '#f5d13b', fruitColor: '#d8402c', woody: false, fibrousRoots: false,
};

export const SPECIES: Species[] = [
  {
    id: 'sunflower', common: 'Sunflower', scientific: 'Helianthus annuus', family: 'Asteraceae', type: 'eudicot',
    growthForm: 'Tall annual herb with a single dominant stem', lifeCycle: 'Annual',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'meristematic-cell'],
    molecules: ['chlorophyll-a', 'sucrose', 'linoleic-acid', 'iaa', 'lutein'],
    notes: 'The "flower" is a capitulum: an inflorescence of hundreds of disc florets ringed by sterile ray florets. The seeds are achenes (single-seeded dry fruits).',
    params: { ...base, height: 2.2, stemThickness: 0.035, branchCount: 0, leafCount: 22, leafSize: 0.22, leafAngle: 55, rootSpread: 0.5, rootDepth: 0.9, flowerCount: 1, fruitCount: 1, leafShape: 'cordate', flowerType: 'composite', fruitType: 'achene', petalColor: '#f4c430', fruitColor: '#3a2f2a', stemColor: '#6b8f3e' },
  },
  {
    id: 'rose', common: 'Garden rose', scientific: 'Rosa × hybrida', family: 'Rosaceae', type: 'eudicot',
    growthForm: 'Woody perennial shrub with prickles', lifeCycle: 'Perennial',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: true,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem', 'cork'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'fibre-cell'],
    molecules: ['geraniol', 'cyanidin', 'chlorophyll-a', 'sucrose', 'cellobiose'],
    notes: 'Compound pinnate leaves; flowers with many petals (in cultivars, stamens converted to petals). Fruit is a hip (fleshy hypanthium enclosing achenes). Woody stems show secondary xylem.',
    params: { ...base, height: 1.2, stemThickness: 0.015, branchCount: 6, leafCount: 30, leafSize: 0.09, leafAngle: 45, rootSpread: 0.5, rootDepth: 0.6, flowerCount: 5, fruitCount: 4, leafShape: 'pinnate', flowerType: 'rose', fruitType: 'hip', petalColor: '#d4304f', fruitColor: '#c8402a', stemColor: '#5f6b3a', woody: true },
  },
  {
    id: 'mint', common: 'Peppermint', scientific: 'Mentha × piperita', family: 'Lamiaceae', type: 'eudicot',
    growthForm: 'Aromatic herb with square stems and creeping rhizomes', lifeCycle: 'Perennial',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element'],
    molecules: ['menthol', 'chlorophyll-a', 'sucrose', 'water'],
    notes: 'Glandular trichomes on the leaf surface synthesise and store menthol-rich essential oil. Square stem with collenchyma at the corners. Peppermint is a sterile hybrid and rarely sets viable seed.',
    params: { ...base, height: 0.5, stemThickness: 0.006, branchCount: 5, leafCount: 40, leafSize: 0.06, leafAngle: 60, rootSpread: 0.35, rootDepth: 0.25, flowerCount: 6, fruitCount: 0, leafShape: 'ovate', flowerType: 'verticillaster', fruitType: 'nutlet', petalColor: '#b48be6', stemColor: '#6a4f7a', leafColor: '#2f7a35' },
  },
  {
    id: 'fern', common: 'Male fern', scientific: 'Dryopteris filix-mas', family: 'Dryopteridaceae', type: 'fern',
    growthForm: 'Rosette of fronds from a short rhizome', lifeCycle: 'Perennial (alternation of generations)',
    hasFlower: false, hasFruit: false, hasSeed: false, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf'],
    tissues: ['epidermis', 'parenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'tracheid', 'sieve-cell'],
    molecules: ['chlorophyll-a', 'water', 'cellobiose', 'beta-carotene'],
    notes: 'Ferns have no flowers, fruits or seeds: they reproduce via spores produced in sporangia (clustered in sori on the frond underside). The "stem" is a rhizome; xylem is composed of tracheids only (no vessels).',
    params: { ...base, height: 0.9, stemThickness: 0.03, branchCount: 0, leafCount: 12, leafSize: 0.6, leafAngle: 35, rootSpread: 0.3, rootDepth: 0.2, flowerCount: 0, fruitCount: 0, leafShape: 'frond', flowerType: 'none', fruitType: 'none', stemColor: '#5a4a32', leafColor: '#2f6e2c', fibrousRoots: true },
  },
  {
    id: 'mango', common: 'Mango', scientific: 'Mangifera indica', family: 'Anacardiaceae', type: 'eudicot',
    growthForm: 'Evergreen tree', lifeCycle: 'Perennial (decades)',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: true,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem', 'cork'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'fibre-cell'],
    molecules: ['beta-carotene', 'sucrose', 'chlorophyll-a', 'ethylene', 'citric-acid'],
    notes: 'Large tree with a woody trunk (secondary growth). Flowers in large panicles; the fruit is a drupe with a fibrous stone (endocarp) around a single large seed. Ripening is ethylene-regulated (climacteric).',
    params: { ...base, height: 3.5, stemThickness: 0.16, branchCount: 8, leafCount: 90, leafSize: 0.22, leafAngle: 40, rootSpread: 1.4, rootDepth: 1.2, flowerCount: 4, fruitCount: 6, leafShape: 'lanceolate', flowerType: 'panicle', fruitType: 'drupe', petalColor: '#f3e6b0', fruitColor: '#e0a12a', stemColor: '#6b5540', leafColor: '#2e6b2f', woody: true },
  },
  {
    id: 'wheat', common: 'Bread wheat', scientific: 'Triticum aestivum', family: 'Poaceae', type: 'monocot',
    growthForm: 'Tufted annual grass with hollow culms', lifeCycle: 'Annual',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'meristematic-cell'],
    molecules: ['maltose', 'sucrose', 'chlorophyll-a', 'gibberellin-a3', 'glycine'],
    notes: 'Monocot: fibrous root system, scattered vascular bundles in the culm, parallel-veined leaves, stomata with dumbbell-shaped guard cells. The grain is a caryopsis (fruit wall fused to seed coat) with a starchy endosperm.',
    params: { ...base, height: 0.9, stemThickness: 0.005, branchCount: 5, leafCount: 14, leafSize: 0.25, leafAngle: 30, rootSpread: 0.25, rootDepth: 0.6, flowerCount: 5, fruitCount: 5, leafShape: 'linear', flowerType: 'spike', fruitType: 'caryopsis', petalColor: '#d8c27a', fruitColor: '#c9a95a', stemColor: '#8fa64a', leafColor: '#5c9a3c', fibrousRoots: true },
  },
  {
    id: 'maize', common: 'Maize (corn)', scientific: 'Zea mays', family: 'Poaceae', type: 'monocot',
    growthForm: 'Tall annual grass with a solid stalk and prop roots', lifeCycle: 'Annual',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'meristematic-cell'],
    molecules: ['maltose', 'sucrose', 'chlorophyll-a', 'zeatin', 'iaa'],
    notes: 'C₄ grass with Kranz leaf anatomy (bundle-sheath cells rich in chloroplasts around each vein). Separate male (tassel) and female (ear) inflorescences. Trans-zeatin was first isolated from maize endosperm.',
    params: { ...base, height: 2.4, stemThickness: 0.03, branchCount: 0, leafCount: 16, leafSize: 0.7, leafAngle: 40, rootSpread: 0.6, rootDepth: 1.0, flowerCount: 1, fruitCount: 2, leafShape: 'linear', flowerType: 'spike', fruitType: 'cob', petalColor: '#d9c98a', fruitColor: '#e8c447', stemColor: '#6f9a3f', leafColor: '#3f8f3a', fibrousRoots: true },
  },
  {
    id: 'tomato', common: 'Tomato', scientific: 'Solanum lycopersicum', family: 'Solanaceae', type: 'eudicot',
    growthForm: 'Sprawling herbaceous vine', lifeCycle: 'Annual (perennial in frost-free climates)',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'meristematic-cell'],
    molecules: ['lycopene', 'citric-acid', 'sucrose', 'chlorophyll-a', 'ethylene', 'abscisic-acid'],
    notes: 'Bicollateral vascular bundles (phloem on both sides of xylem). Yellow star-shaped flowers; the fruit is a berry whose red colour comes from lycopene accumulating in chromoplasts as chloroplasts are remodelled during ripening.',
    params: { ...base, height: 1.3, stemThickness: 0.014, branchCount: 6, leafCount: 34, leafSize: 0.14, leafAngle: 55, rootSpread: 0.5, rootDepth: 0.5, flowerCount: 6, fruitCount: 8, leafShape: 'pinnate', flowerType: 'star', fruitType: 'berry', petalColor: '#f2d13c', fruitColor: '#d8402c', stemColor: '#5c8a3a' },
  },
  {
    id: 'custom', common: 'Custom procedural plant', scientific: '— (procedural)', family: '—', type: 'custom',
    growthForm: 'User-defined', lifeCycle: '—',
    hasFlower: true, hasFruit: true, hasSeed: true, secondaryGrowth: false,
    organs: ['root-system', 'stem', 'leaf', 'flower', 'fruit', 'seed'],
    tissues: ['epidermis', 'parenchyma', 'collenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'meristem'],
    cells: ['palisade-cell', 'spongy-cell', 'epidermal-cell', 'guard-cell', 'root-hair-cell', 'vessel-element', 'sieve-tube-element', 'meristematic-cell'],
    molecules: ['chlorophyll-a', 'glucose', 'water', 'carbon-dioxide', 'oxygen'],
    notes: 'A generic eudicot body plan built by the Plant Builder. Anatomy shown is generic eudicot anatomy; it is not a real species.',
    params: { ...base },
  },
];

export const speciesById = (id: string) => SPECIES.find((s) => s.id === id) ?? SPECIES[0];

export const GROWTH_STAGES = [
  { t: 0.0, name: 'SEED', desc: 'Dormant embryo enclosed in seed coat with stored reserves.' },
  { t: 0.08, name: 'GERMINATION', desc: 'Water uptake (imbibition); radicle emerges first.' },
  { t: 0.2, name: 'SEEDLING', desc: 'Shoot emerges; first leaves expand and photosynthesis begins.' },
  { t: 0.4, name: 'VEGETATIVE GROWTH', desc: 'Apical meristems add leaves, nodes and roots.' },
  { t: 0.7, name: 'FLOWERING', desc: 'Shoot meristem switches to reproductive development.' },
  { t: 0.85, name: 'FRUITING', desc: 'Fertilised ovaries develop into fruits; seeds mature.' },
  { t: 0.97, name: 'MATURE', desc: 'Full-size plant with ripe fruit / seed.' },
];
export const growthStageAt = (t: number) => {
  let s = GROWTH_STAGES[0];
  for (const g of GROWTH_STAGES) if (t >= g.t) s = g;
  return s;
};
