import { useEffect, useState } from 'react';
import { useStore, useCurrentNode, useSpecies, type ViewLayer, type Representation } from '@/store';
import { NODE_MAP, scaleLevelName } from '@/data/nodes';
import { formatMeters, STATUS_HINT, APP_VERSION, DATASET_VERSION, MODEL_VERSION, elementOf } from '@/data/core';
import { moleculeById, proteinById } from '@/data/molecules';
import { pubchem2DUrl, cachedKeys } from '@/lib/loaders';
import { useMolStore } from '@/three/MolecularScenes';

const CONCEPT_PARTS: Record<string, string> = { psi: 'Photosystem I — conceptual shape. A pea PSI–LHCI structure exists (PDB 4XK8) but is not streamed here.', 'atp-synthase': 'Chloroplast ATP synthase (CF₁F₀) — conceptual shape. Spinach structure: PDB 6FKF (cryo-EM).' };

export default function Inspector() {
  const open = useStore((s) => s.rightOpen); const presentation = useStore((s) => s.presentation);
  if (presentation || !open) return null;
  return (
    <aside className="ps-panel ps-right" aria-label="Inspector">
      <div className="ps-scroll space-y-3">
        <WhereAmI />
        <ObjectInfo />
        <Controls />
        <Tools />
        <Provenance />
      </div>
    </aside>
  );
}

function WhereAmI() {
  const path = useStore((s) => s.path); const sp = useSpecies(); const navigate = useStore((s) => s.navigate); const fov = useStore((s) => s.fovMeters); const node = useCurrentNode();
  return (
    <section className="ps-card">
      <div className="ps-section-title">WHERE AM I?</div>
      <ol className="ps-crumbs" aria-label="Location">
        <li><button onClick={() => navigate('plant')}>{sp.common}</button></li>
        {path.slice(1).map((id) => <li key={id}><span aria-hidden>→</span><button onClick={() => navigate(id)}>{NODE_MAP[id]?.name ?? id}</button></li>)}
      </ol>
      <div className="grid grid-cols-2 gap-1 mt-2 text-[11px]">
        <div><span className="ps-muted">LEVEL</span><br />{scaleLevelName(node.level)}</div>
        <div><span className="ps-muted">OBJECT SIZE</span><br />≈ {formatMeters(node.scaleM)}</div>
        <div><span className="ps-muted">FIELD OF VIEW</span><br />≈ {formatMeters(fov)} (approx.)</div>
        <div><span className="ps-muted">REPRESENTATION</span><br />{node.status}</div>
      </div>
    </section>
  );
}

function ObjectInfo() {
  const selectedId = useStore((s) => s.selectedId); const cur = useCurrentNode(); const navigate = useStore((s) => s.navigate); const requestCamera = useStore((s) => s.requestCamera);
  const mode = useStore((s) => s.mode); const notes = useStore((s) => s.notes); const setNote = useStore((s) => s.setNote); const set = useStore((s) => s.set);
  const compareA = useStore((s) => s.compareA); const picked = useMolStore((s) => s.picked); const structure = useMolStore((s) => s.structure); const loading = useMolStore((s) => s.loading);
  const [explain, setExplain] = useState(mode === 'education');
  useEffect(() => { if (mode === 'education') setExplain(true); }, [mode]);
  const id = selectedId ?? cur.id; const node = NODE_MAP[id];
  const mol = node ? moleculeById(node.sceneParam ?? '') : undefined; const prot = node ? proteinById(node.sceneParam ?? '') : undefined;
  const isCurrent = node?.id === cur.id;
  if (!node) return <section className="ps-card"><div className="ps-section-title">SELECTED PART</div><div className="font-medium">{id}</div><p className="text-[11px] text-zinc-300 mt-1">{CONCEPT_PARTS[id] ?? 'Conceptual part of the current scene.'}</p></section>;
  const src = structure && (isCurrent || node.scene === 'molecule' || node.scene === 'protein') ? structure.source : node.source;
  return (
    <section className="ps-card">
      <div className="flex items-start justify-between gap-2">
        <div><div className="ps-section-title">{isCurrent ? 'CURRENT OBJECT' : 'SELECTED'}</div><h2 className="text-[15px] font-semibold leading-tight">{node.name}</h2>
          <div className="text-[10px] uppercase tracking-wider text-zinc-400 mt-0.5">{node.type} · ≈ {formatMeters(node.scaleM)}{node.formula ? ` · ${node.formula}` : ''}</div></div>
        <span className={`ps-status s-${node.status.split(' ')[0].toLowerCase().replace('/', '')}`} title={STATUS_HINT[node.status]}>{node.status}</span>
      </div>
      <div className="flex flex-wrap gap-1 mt-2">
        {!isCurrent && <button className="ps-btn ps-btn-primary" onClick={() => navigate(node.id)}>ENTER →</button>}
        {!isCurrent && <button className="ps-btn" onClick={() => requestCamera({ type: 'focus', partId: `${node.focusPart ?? node.id}|${node.id}` })}>FOCUS</button>}
        {isCurrent && node.parent && <button className="ps-btn" onClick={() => navigate(node.parent!)}>↑ OUT</button>}
        {isCurrent && node.children.length > 0 && <button className="ps-btn ps-btn-primary" onClick={() => useStore.getState().descend()}>DEEPER ↓</button>}
        <button className={`ps-btn ${explain ? 'ps-chip-on' : ''}`} onClick={() => setExplain(!explain)}>EXPLAIN</button>
        <button className="ps-btn" onClick={() => set({ compareA: compareA && compareA !== node.id ? compareA : node.id, compareB: compareA && compareA !== node.id ? node.id : useStore.getState().compareB, dialog: 'compare' })} title="Add to comparison">⇄ COMPARE</button>
        <button className="ps-btn" onClick={() => useStore.getState().addBookmark()} title="Bookmark this location">🔖</button>
      </div>
      <p className="text-[12px] leading-relaxed text-zinc-200 mt-2">{node.description}</p>
      <dl className="ps-dl mt-2">
        <dt>FUNCTION</dt><dd>{node.fn}</dd>
        {node.madeOf && <><dt>MADE OF</dt><dd>{node.madeOf}</dd></>}
        {mol && <><dt>LOCALIZATION</dt><dd>{mol.localization}</dd><dt>CATEGORY</dt><dd>{mol.category}{mol.chebi ? ` · ${mol.chebi}` : ''}</dd></>}
        {prot && <><dt>ORGANISM</dt><dd>{prot.organism}</dd><dt>METHOD</dt><dd>{prot.method} · {prot.resolution}</dd><dt>CITATION</dt><dd>{prot.citation}</dd></>}
        <dt>SCIENTIFIC STATUS</dt><dd>{STATUS_HINT[node.status]}</dd>
        {src && <><dt>SOURCE</dt><dd>{src.name}{src.id ? ` · ${src.id}` : ''}{src.url && <> · <a className="underline text-sky-300" href={src.url} target="_blank" rel="noreferrer">open ↗</a></>}<br />{src.modelType && <span className="ps-muted">{src.modelType}</span>}{src.resolution && <span className="ps-muted"> · {src.resolution}</span>}{src.species && <span className="ps-muted"> · {src.species}</span>}{src.license && <span className="ps-muted"> · {src.license}</span>}{src.updated && <span className="ps-muted"> · updated {src.updated}</span>}</dd></>}
      </dl>
      {isCurrent && (node.scene === 'molecule' || node.scene === 'protein' || node.scene === 'dna') && <div className="mt-2 text-[11px]">
        {loading && <div className="ps-loading-inline">Loading structure…</div>}
        {structure && structure.status === 'ok' && <div className="ps-muted">{structure.atoms.length.toLocaleString()} atoms{structure.bonds.length ? ` · ${structure.bonds.length} bonds (database bond orders)` : ' · bonds perceived by interatomic distance'}{structure.chains ? ` · ${structure.chains.length} chains · ${structure.residues} residues` : ''}</div>}
        {structure && structure.status === 'unavailable' && <div className="text-amber-300">{structure.message}</div>}
      </div>}
      {picked && <div className="mt-2 p-2 rounded bg-sky-500/10 border border-sky-400/20 text-[11px]">
        <div className="font-semibold">Atom: {elementOf(picked.el).name} ({picked.el}) — Z {elementOf(picked.el).Z}</div>
        <div className="ps-muted">position (model Å): {picked.pos.map((v) => v.toFixed(2)).join(', ')}{picked.res ? ` · residue ${picked.res} ${picked.chain}${picked.resSeq}` : ''}</div>
        <div>bonds: {picked.neighbors.length ? picked.neighbors.map((n, i) => <span key={i} className="mr-2">{picked.el}–{n.el} {n.dist.toFixed(2)} Å{n.order === 2 ? ' (double)' : n.order === 3 ? ' (triple)' : n.order === 4 ? ' (aromatic)' : ''}</span>) : 'none in model'}</div>
        <div className="ps-muted">mass {elementOf(picked.el).mass} u · covalent r {elementOf(picked.el).covalent} Å · vdW r {elementOf(picked.el).vdw} Å</div>
        <button className="ps-btn mt-1" onClick={() => navigate(`atom-${elementOf(picked.el).symbol}`)}>ZOOM INTO ATOM →</button>
      </div>}
      {explain && <Education node={node} />}
      {node.related && node.related.length > 0 && <div className="mt-2"><div className="ps-section-title">RELATED STRUCTURES</div><div className="flex flex-wrap gap-1">{node.related.filter((r) => NODE_MAP[r]).map((r) => <button key={r} className="ps-chip" onClick={() => navigate(r)}>{NODE_MAP[r].name}</button>)}</div></div>}
      {node.children.length > 0 && <div className="mt-2"><div className="ps-section-title">CONTAINS</div><div className="flex flex-wrap gap-1">{node.children.filter((c) => NODE_MAP[c]).slice(0, 14).map((c) => <button key={c} className="ps-chip" onClick={() => navigate(c)}>{NODE_MAP[c].name}</button>)}</div></div>}
      <div className="mt-2"><div className="ps-section-title">MY NOTES</div><textarea className="ps-input w-full text-[11px]" rows={2} placeholder="Personal note (stored locally)…" value={notes[node.id] ?? ''} onChange={(e) => setNote(node.id, e.target.value)} aria-label="Personal note" /></div>
    </section>
  );
}

function Education({ node }: { node: ReturnType<typeof useCurrentNode> }) {
  const path = useStore((s) => s.path); const sp = useSpecies();
  const where = path.includes(node.id) ? path.slice(0, path.indexOf(node.id) + 1) : [...path, node.id];
  return (
    <div className="mt-2 p-2 rounded bg-emerald-500/10 border border-emerald-400/20 text-[11px] space-y-1">
      <div><b>What is it?</b> {node.description}</div>
      <div><b>Where is it?</b> {sp.common} → {where.slice(1).map((id) => NODE_MAP[id]?.name ?? id).join(' → ') || 'whole plant'}</div>
      <div><b>What does it do?</b> {node.fn}</div>
      <div><b>What is it made of?</b> {node.madeOf ?? (node.children.length ? node.children.filter((c) => NODE_MAP[c]).map((c) => NODE_MAP[c].name).join(', ') : '—')}</div>
      <div><b>What is its scale?</b> ≈ {formatMeters(node.scaleM)} ({scaleLevelName(node.level)})</div>
      <div><b>What model am I seeing?</b> {node.status}: {STATUS_HINT[node.status]}{node.source ? ` Source: ${node.source.name}${node.source.id ? ' ' + node.source.id : ''}.` : ''}</div>
    </div>
  );
}

function Controls() {
  const cur = useCurrentNode(); const st = useStore();
  const isMol = cur.scene === 'molecule' || cur.scene === 'protein' || cur.scene === 'dna' || cur.scene === 'rna';
  const mol = moleculeById(cur.sceneParam ?? '');
  return (
    <section className="ps-card">
      <div className="ps-section-title">VIEW</div>
      <div className="flex flex-wrap gap-1" role="group" aria-label="View layer">
        {(['normal', 'cutaway', 'xray', 'transparent', 'exploded'] as ViewLayer[]).map((v) => <button key={v} className={`ps-chip ${st.viewLayer === v ? 'ps-chip-on' : ''}`} onClick={() => st.set({ viewLayer: v })}>{v.toUpperCase()}</button>)}
        <button className={`ps-chip ${st.focusMode ? 'ps-chip-on' : ''}`} onClick={() => st.set({ focusMode: !st.focusMode })} title="Subdue everything except the selected object">FOCUS MODE</button>
        <button className={`ps-chip ${st.showLabels ? 'ps-chip-on' : ''}`} onClick={() => st.set({ showLabels: !st.showLabels })}>LABELS</button>
      </div>
      <p className="ps-note">Visualization modes only — “x-ray” and “transparent” are rendering styles, not imaging modalities.</p>
      {!isMol && <label className="ps-slider"><span>Explode</span><input type="range" min={0} max={1} step={0.01} value={st.explode} onChange={(e) => st.set({ explode: parseFloat(e.target.value) })} aria-label="Exploded view amount" /><span className="ps-val">{Math.round(st.explode * 100)}%</span></label>}
      {isMol && <>
        <div className="ps-section-title mt-2">REPRESENTATION</div>
        <div className="flex flex-wrap gap-1">{(['ballstick', 'spacefill', 'wire', 'surface'] as Representation[]).map((r) => <button key={r} className={`ps-chip ${st.representation === r ? 'ps-chip-on' : ''}`} onClick={() => st.set({ representation: r })}>{r === 'ballstick' ? 'BALL & STICK' : r === 'spacefill' ? 'SPACE-FILLING' : r.toUpperCase()}</button>)}
          {mol?.cid && <button className={`ps-chip ${st.show2D ? 'ps-chip-on' : ''}`} onClick={() => st.set({ show2D: !st.show2D })}>2D STRUCTURE</button>}
          {cur.scene === 'molecule' && <button className={`ps-chip ${st.showHydrogens ? 'ps-chip-on' : ''}`} onClick={() => st.set({ showHydrogens: !st.showHydrogens })}>HYDROGENS</button>}
          {cur.scene === 'protein' && <>{(['atoms', 'backbone'] as const).map((m) => <button key={m} className={`ps-chip ${st.proteinMode === m ? 'ps-chip-on' : ''}`} onClick={() => st.set({ proteinMode: m })}>{m.toUpperCase()}</button>)}{(['element', 'chain', 'residue'] as const).map((c) => <button key={c} className={`ps-chip ${st.colorBy === c ? 'ps-chip-on' : ''}`} onClick={() => st.set({ colorBy: c })}>colour: {c}</button>)}</>}
          {cur.scene === 'dna' && (['ideal', 'crystal'] as const).map((m) => <button key={m} className={`ps-chip ${st.dnaMode === m ? 'ps-chip-on' : ''}`} onClick={() => st.set({ dnaMode: m })}>{m === 'ideal' ? 'IDEALISED B-DNA' : 'CRYSTAL (PDB 1BNA)'}</button>)}
        </div>
        {st.show2D && mol?.cid && <figure className="mt-2 bg-white rounded p-1"><img src={pubchem2DUrl(mol.cid)} alt={`2D chemical structure diagram of ${mol.name}`} className="w-full" onError={(e) => { (e.target as HTMLImageElement).alt = '2D depiction unavailable (network)'; }} /><figcaption className="text-[10px] text-zinc-600 px-1">2D depiction: PubChem CID {mol.cid} · {mol.formula} · public domain</figcaption></figure>}
        <div className="ps-legend mt-2"><span className="ps-section-title">CPK ELEMENT COLOURS</span>{['H', 'C', 'N', 'O', 'P', 'S', 'Mg', 'Fe', 'Cu', 'Mn'].map((e) => <span key={e} className="ps-legend-item"><i style={{ background: elementOf(e).color }} />{e}</span>)}<span className="ps-muted">bonds: single · double (2 rods) · triple (3) · aromatic (rod + thin rod)</span></div>
      </>}
      {cur.scene === 'atom' && <>
        <div className="ps-section-title mt-2">ELECTRON DENSITY (MODEL)</div>
        <label className="ps-slider"><span>Density threshold</span><input type="range" min={0.05} max={0.98} step={0.01} value={st.electron.threshold} onChange={(e) => st.set({ electron: { ...st.electron, threshold: parseFloat(e.target.value) } })} /><span className="ps-val">{st.electron.threshold.toFixed(2)}</span></label>
        <label className="ps-slider"><span>Surface opacity</span><input type="range" min={0.05} max={1} step={0.01} value={st.electron.opacity} onChange={(e) => st.set({ electron: { ...st.electron, opacity: parseFloat(e.target.value) } })} /><span className="ps-val">{st.electron.opacity.toFixed(2)}</span></label>
        <label className="ps-check"><input type="checkbox" checked={st.electron.orbital} onChange={(e) => st.set({ electron: { ...st.electron, orbital: e.target.checked } })} /> Show schematic p-orbital lobes</label>
        <p className="ps-note">Conceptual visualisation: hydrogen-like radial form scaled by element radius. Not a quantum-chemical calculation; electrons are not orbiting balls.</p>
      </>}
    </section>
  );
}

function Tools() {
  const st = useStore(); const cur = useCurrentNode();
  const exp = st.mode !== 'observe';
  return (
    <section className="ps-card">
      <div className="ps-section-title">CROSS-SECTION TOOL</div>
      <label className="ps-check"><input type="checkbox" checked={st.clip.enabled} onChange={(e) => st.set({ clip: { ...st.clip, enabled: e.target.checked } })} /> Slice the scene with a clipping plane</label>
      {st.clip.enabled && <>
        <label className="ps-slider"><span>Plane angle</span><input type="range" min={-180} max={180} value={st.clip.angle} onChange={(e) => st.set({ clip: { ...st.clip, angle: +e.target.value } })} /><span className="ps-val">{st.clip.angle}°</span></label>
        <label className="ps-slider"><span>Plane tilt</span><input type="range" min={-90} max={90} value={st.clip.tilt} onChange={(e) => st.set({ clip: { ...st.clip, tilt: +e.target.value } })} /><span className="ps-val">{st.clip.tilt}°</span></label>
        <label className="ps-slider"><span>Clip depth</span><input type="range" min={-1} max={1} step={0.01} value={st.clip.offset} onChange={(e) => st.set({ clip: { ...st.clip, offset: +e.target.value } })} /><span className="ps-val">{st.clip.offset.toFixed(2)}</span></label>
        <div className="flex gap-1"><button className="ps-btn" onClick={() => st.set({ clip: { enabled: true, angle: 0, tilt: 0, offset: 0 } })}>RESET</button><button className="ps-btn" onClick={() => st.set({ clip: { ...st.clip, angle: 90, tilt: 0 } })}>LONGITUDINAL</button><button className="ps-btn" onClick={() => st.set({ clip: { ...st.clip, angle: 0, tilt: 90 } })}>TRANSVERSE</button></div>
      </>}
      <div className="ps-section-title mt-3">MEASURE</div>
      <div className="flex gap-1 items-center"><button className={`ps-btn ${st.measureActive ? 'ps-chip-on' : ''}`} onClick={() => st.set({ measureActive: !st.measureActive, measurePoints: [] })}>{st.measureActive ? 'MEASURING — click two points' : 'START MEASURING'}</button><button className="ps-btn" onClick={st.clearMeasure}>CLEAR</button></div>
      {st.measurePoints.length === 1 && <div className="text-[11px] text-amber-300 mt-1">First point set — click the second point.</div>}
      {st.measurements.length > 0 && <ul className="text-[11px] mt-1 space-y-0.5">{st.measurements.slice().reverse().map((m) => <li key={m.id} className="flex justify-between"><span className="ps-muted">{m.scene.split(':')[0]}</span><span className="font-mono text-amber-200">{m.label}</span></li>)}</ul>}
      <p className="ps-note">Distances are measured on the 3D model and converted with the scene’s model scale ({formatMeters(sceneUnit(cur.scene, cur.scaleM))} per unit). They describe the model, not a specimen.</p>
      <div className="ps-section-title mt-3">{exp ? 'EXPERIMENT MODE — CONCEPTUAL SIMULATIONS' : 'LIVING PLANT & CONCEPTUAL FLOWS'}</div>
      <div className="flex flex-wrap gap-1">
        <button className={`ps-chip ${st.living ? 'ps-chip-on' : ''}`} onClick={() => st.set({ living: !st.living })}>LIVING MOTION</button>
        <button className={`ps-chip ${st.transport ? 'ps-chip-on' : ''}`} onClick={() => st.set({ transport: !st.transport })}>XYLEM / PHLOEM TRANSPORT</button>
        <button className={`ps-chip ${st.nutrients ? 'ps-chip-on' : ''}`} onClick={() => st.set({ nutrients: !st.nutrients })}>NUTRIENT UPTAKE (N·P·K)</button>
        <button className={`ps-chip ${st.gasExchange ? 'ps-chip-on' : ''}`} onClick={() => st.set({ gasExchange: !st.gasExchange })}>GAS EXCHANGE</button>
        <button className={`ps-chip ${st.photosynthesis ? 'ps-chip-on' : ''}`} onClick={() => st.set({ photosynthesis: !st.photosynthesis })}>PHOTOSYNTHESIS / RESPIRATION PATHWAY</button>
      </div>
      <label className="ps-slider mt-1"><span>Light angle</span><input type="range" min={5} max={175} value={st.lightAngle} onChange={(e) => st.set({ lightAngle: +e.target.value })} /><span className="ps-val">{st.lightAngle}°</span></label>
      <label className="ps-slider"><span>Light intensity</span><input type="range" min={0.2} max={2} step={0.05} value={st.lightIntensity} onChange={(e) => st.set({ lightIntensity: +e.target.value })} /><span className="ps-val">{st.lightIntensity.toFixed(2)}</span></label>
      {cur.scene === 'stoma' && <label className="ps-slider"><span>Stomatal aperture</span><input type="range" min={0} max={1} step={0.01} value={st.stomaAperture} onChange={(e) => st.set({ stomaAperture: +e.target.value })} /><span className="ps-val">{Math.round(st.stomaAperture * 100)}%</span></label>}
      <p className="ps-note">All flows are CONCEPTUAL visualizations of well-established processes, not quantitative physiology.</p>
    </section>
  );
}
function sceneUnit(scene: string, scaleM: number) { switch (scene) { case 'molecule': case 'dna': case 'rna': case 'atom': return 1e-10; case 'cell': return scaleM / 6; case 'leaf': return 6.7e-5; case 'tissue': return 4.5e-5; case 'root': return 2.5e-4; case 'chloroplast': case 'nucleus': return 8.3e-7; case 'thylakoid': return 6.25e-8; case 'mitochondrion': return 2e-7; case 'membrane': return 1e-9; case 'wall': return 1e-8; case 'stoma': return 5e-6; case 'flower': return 5e-3; case 'seed': return 1e-3; case 'fruit': return 1e-2; default: return 0.1; } }

function Provenance() {
  const [open, setOpen] = useState(false);
  return (
    <section className="ps-card">
      <button className="ps-section-title w-full text-left" onClick={() => setOpen(!open)} aria-expanded={open}>DATA & VERSIONS {open ? '▾' : '▸'}</button>
      {open && <div className="text-[11px] space-y-1 text-zinc-300">
        <div>App {APP_VERSION} · dataset {DATASET_VERSION} · anatomy model {MODEL_VERSION}</div>
        <div>Small molecules: PubChem PUG REST (3D conformers, 2D depictions; public domain). Gas-phase geometries of H₂O, CO₂, O₂, C₂H₄: NIST CCCBDB.</div>
        <div>Macromolecules: RCSB PDB files (CC0). Ligand coordinates (chlorophyll a, lutein) extracted from PDB 2BHW.</div>
        <div>Anatomy: procedural reconstructions of textbook plant anatomy (Esau; Evert & Eichhorn). Cellular/organelle scenes are schematic 3D models.</div>
        <div>Element data: IUPAC atomic weights; Cordero 2008 covalent radii; Mantina 2009 vdW radii; CPK colours.</div>
        <div>Cached structures (offline-ready, local): {cachedKeys().length} · <button className="underline" onClick={() => { import('@/lib/loaders').then((m) => { m.clearStructureCache(); location.reload(); }); }}>clear cache</button></div>
      </div>}
    </section>
  );
}
