import { useEffect, useMemo, useRef, useState } from 'react';
import { useStore, allSpeciesOptions, useSpecies, type Quality } from '@/store';
import { NODES, NODE_MAP, nodeApplies } from '@/data/nodes';
import { MOLECULES, PROTEINS, GLOSSARY, PATHWAYS } from '@/data/molecules';
import { formatMeters } from '@/data/core';

interface Hit { id: string; title: string; category: string; source: string; sub?: string; action: () => void; score: number }

export function useSearchIndex() {
  const sp = useSpecies();
  return useMemo(() => {
    const st = useStore.getState;
    const hits: Omit<Hit, 'score'>[] = [];
    for (const s of allSpeciesOptions()) hits.push({ id: 's:' + s.id, title: `${s.common} (${s.scientific})`, category: 'PLANT', source: s.family, sub: s.growthForm, action: () => st().setSpecies(s.id) });
    for (const n of NODES) {
      if (!nodeApplies(n, sp)) continue;
      const cat = n.type === 'organ-part' ? 'ORGAN' : n.type === 'macromolecule' ? (PROTEINS.some((p) => p.id === n.id) ? 'PROTEIN' : 'MACROMOLECULE') : n.type.toUpperCase();
      hits.push({ id: n.id, title: n.name, category: cat, source: n.source?.name ?? '—', sub: `${n.status} · ≈ ${formatMeters(n.scaleM)}${n.formula ? ' · ' + n.formula : ''}`, action: () => st().navigate(n.id) });
    }
    for (const m of MOLECULES) hits.push({ id: 'chem:' + m.id, title: `${m.name} — ${m.category}`, category: 'CHEMICAL', source: m.cid ? `PubChem CID ${m.cid}` : 'experimental geometry', sub: m.localization, action: () => st().navigate(m.id) });
    for (const g of GLOSSARY) hits.push({ id: 'term:' + g.term, title: g.term, category: 'SCIENTIFIC TERM', source: 'glossary', sub: g.def, action: () => g.node && st().navigate(g.node) });
    for (const p of PATHWAYS) hits.push({ id: 'pw:' + p.id, title: p.name, category: 'PATHWAY', source: 'conceptual pathway', sub: p.where, action: () => st().set({ dialog: 'pathways' }) });
    return hits;
  }, [sp]);
}

export function runSearch(index: Omit<Hit, 'score'>[], q: string): Hit[] {
  const s = q.trim().toLowerCase(); if (!s) return [];
  const terms = s.split(/\s+/);
  return index.map((h) => { const hay = `${h.title} ${h.category} ${h.sub ?? ''} ${h.source}`.toLowerCase(); let score = 0; for (const t of terms) { if (h.title.toLowerCase().startsWith(t)) score += 6; else if (h.title.toLowerCase().includes(t)) score += 4; else if (hay.includes(t)) score += 1; else return null; } return { ...h, score }; }).filter((x): x is Hit => !!x).sort((a, b) => b.score - a.score).slice(0, 14);
}

export default function TopBar() {
  const speciesId = useStore((s) => s.speciesId); const setSpecies = useStore((s) => s.setSpecies);
  const mode = useStore((s) => s.mode); const set = useStore((s) => s.set); const quality = useStore((s) => s.quality);
  const presentation = useStore((s) => s.presentation); const leftOpen = useStore((s) => s.leftOpen); const rightOpen = useStore((s) => s.rightOpen);
  const saved = useStore((s) => s.savedSpecies);
  const [q, setQ] = useState(''); const [open, setOpen] = useState(false); const [cursor, setCursor] = useState(0);
  const index = useSearchIndex(); const hits = useMemo(() => runSearch(index, q), [index, q]);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { const onKey = (e: KeyboardEvent) => { if ((e.key === '/' || (e.key === 'k' && (e.metaKey || e.ctrlKey))) && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') { e.preventDefault(); inputRef.current?.focus(); } }; window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey); }, []);
  if (presentation) return null;
  return (
    <header className="ps-topbar" role="banner">
      <button className="ps-icon-btn md:hidden" aria-label="Toggle navigator" onClick={() => set({ leftOpen: !leftOpen })}>☰</button>
      <div className="flex items-center gap-2 mr-2 select-none">
        <span className="text-emerald-400 text-lg" aria-hidden>🌱</span>
        <div className="leading-tight"><div className="font-semibold tracking-wide text-[13px]">PLANTSCAPE</div><div className="text-[9px] uppercase tracking-[0.18em] text-emerald-300/70">Multiscale plant anatomy explorer</div></div>
      </div>
      <label className="sr-only" htmlFor="species">Plant species</label>
      <select id="species" className="ps-select" value={speciesId} onChange={(e) => setSpecies(e.target.value)}>
        {allSpeciesOptions().map((s) => <option key={s.id} value={s.id}>{s.common} · {s.scientific}</option>)}
        {saved.length > 0 && <optgroup label="Saved plants (Plant Builder)">{saved.map((s) => <option key={s.id} value={s.id}>{s.common}</option>)}</optgroup>}
      </select>
      <div className="relative flex-1 max-w-xl" role="search">
        <input ref={inputRef} className="ps-input w-full" placeholder="Search plant, organ, tissue, cell, organelle, protein, molecule, term…  ( / )" value={q} aria-label="Global search" aria-expanded={open && hits.length > 0} aria-controls="search-results"
          onChange={(e) => { setQ(e.target.value); setOpen(true); setCursor(0); }} onFocus={() => setOpen(true)} onBlur={() => setTimeout(() => setOpen(false), 150)}
          onKeyDown={(e) => { if (e.key === 'ArrowDown') { e.preventDefault(); setCursor((c) => Math.min(hits.length - 1, c + 1)); } if (e.key === 'ArrowUp') { e.preventDefault(); setCursor((c) => Math.max(0, c - 1)); } if (e.key === 'Enter' && hits[cursor]) { hits[cursor].action(); setQ(''); setOpen(false); inputRef.current?.blur(); } if (e.key === 'Escape') { setOpen(false); inputRef.current?.blur(); } }} />
        {open && hits.length > 0 && (
          <ul id="search-results" role="listbox" className="ps-dropdown">
            {hits.map((h, i) => <li key={h.id} role="option" aria-selected={i === cursor} className={`ps-hit ${i === cursor ? 'ps-hit-active' : ''}`} onMouseDown={() => { h.action(); setQ(''); setOpen(false); }} onMouseEnter={() => setCursor(i)}>
              <div className="flex items-center gap-2"><span className={`ps-cat ps-cat-${h.category.split(' ')[0].toLowerCase()}`}>{h.category}</span><span className="font-medium truncate">{h.title}</span></div>
              <div className="text-[10px] text-zinc-400 truncate">{h.sub} · <span className="text-zinc-500">{h.source}</span></div>
            </li>)}
            <li className="px-3 py-1 text-[10px] text-zinc-500 border-t border-white/5">Enter: FIND → SELECT → FOCUS. Details and “EXPLAIN” appear in the inspector.</li>
          </ul>
        )}
      </div>
      <div className="hidden lg:flex items-center gap-1 ml-2" role="group" aria-label="Application mode">
        {(['observe', 'experiment', 'education'] as const).map((m) => <button key={m} className={`ps-chip ${mode === m ? 'ps-chip-on' : ''}`} onClick={() => set({ mode: m, rightOpen: true })} title={m === 'observe' ? 'Explore, inspect, measure, compare — no manipulation' : m === 'experiment' ? 'Toggle conceptual simulations (transport, photosynthesis, gas exchange)' : 'Guided explanations for every structure'}>{m.toUpperCase()}</button>)}
      </div>
      <select className="ps-select hidden md:block" value={quality} onChange={(e) => set({ quality: e.target.value as Quality })} aria-label="Quality preset" title="Rendering quality">
        {['ultra', 'high', 'balanced', 'performance', 'accessibility'].map((qq) => <option key={qq} value={qq}>{qq.toUpperCase()}</option>)}
      </select>
      <button className="ps-icon-btn" title="Bookmarks" aria-label="Bookmarks" onClick={() => set({ dialog: 'bookmarks' })}>🔖</button>
      <button className="ps-icon-btn" title="Compare" aria-label="Compare" onClick={() => set({ dialog: 'compare' })}>⇄</button>
      <button className="ps-icon-btn" title="Settings & accessibility" aria-label="Settings" onClick={() => set({ dialog: 'settings' })}>⚙</button>
      <button className="ps-icon-btn" title="Help" aria-label="Help" onClick={() => set({ dialog: 'help' })}>?</button>
      <button className="ps-icon-btn" title="Presentation mode (P)" aria-label="Presentation mode" onClick={() => set({ presentation: true })}>⛶</button>
      <button className="ps-icon-btn xl:hidden" aria-label="Toggle inspector" onClick={() => set({ rightOpen: !rightOpen })}>ⓘ</button>
    </header>
  );
}

export const speciesName = (id: string) => allSpeciesOptions().find((s) => s.id === id)?.common ?? NODE_MAP[id]?.name ?? id;
