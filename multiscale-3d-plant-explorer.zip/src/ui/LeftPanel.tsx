import { useMemo, useState } from 'react';
import { useStore, useCurrentNode, useSpecies, useParams } from '@/store';
import { LEVELS, formatMeters } from '@/data/core';
import { NODE_MAP, childrenOf } from '@/data/nodes';
import { MOLECULES, PROTEINS, PATHWAYS, JOURNEYS, type MolCategory } from '@/data/molecules';
import { GROWTH_STAGES, growthStageAt, type LeafShape, type FlowerType, type FruitType } from '@/data/species';
import type { SciNode } from '@/data/core';

export default function LeftPanel() {
  const open = useStore((s) => s.leftOpen); const presentation = useStore((s) => s.presentation); const tab = useStore((s) => s.leftTab); const set = useStore((s) => s.set);
  if (presentation || !open) return null;
  return (
    <aside className="ps-panel ps-left" aria-label="Navigation">
      <ScaleNavigator />
      <div className="ps-tabs" role="tablist">
        {(['tree', 'library', 'builder'] as const).map((t) => <button key={t} role="tab" aria-selected={tab === t} className={`ps-tab ${tab === t ? 'ps-tab-on' : ''}`} onClick={() => set({ leftTab: t })}>{t === 'tree' ? 'ANATOMY' : t === 'library' ? 'LIBRARIES' : 'BUILDER'}</button>)}
      </div>
      <div className="ps-scroll">
        {tab === 'tree' && <Tree />}
        {tab === 'library' && <Libraries />}
        {tab === 'builder' && <Builder />}
      </div>
    </aside>
  );
}

function ScaleNavigator() {
  const node = useCurrentNode(); const jump = useStore((s) => s.jumpLevel); const set = useStore((s) => s.set); const show2D = useStore((s) => s.show2D);
  return (
    <nav className="ps-scale-nav" aria-label="Scale navigator">
      {LEVELS.map((l) => { const active = l.level === node.level || (l.level === 8 && show2D); return (
        <button key={l.level} className={`ps-scale-btn ${active ? 'ps-scale-on' : ''} ${l.level < node.level ? 'ps-scale-passed' : ''}`} onClick={() => l.level === 8 ? set({ show2D: true, rightOpen: true }) : jump(l.level)} aria-current={active ? 'step' : undefined} title={`${l.name} · ${l.scale}`}>
          <span className="ps-scale-dot" aria-hidden /><span className="ps-scale-name">{l.name}</span><span className="ps-scale-val">{l.scale}</span>
        </button>); })}
    </nav>
  );
}

function Tree() {
  const sp = useSpecies(); const path = useStore((s) => s.path); const navigate = useStore((s) => s.navigate); const selected = useStore((s) => s.selectedId);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ plant: true, leaf: true });
  const cur = path[path.length - 1];
  const render = (n: SciNode, depth: number, seen: Set<string>): React.ReactNode => {
    if (depth > 9 || seen.has(n.id)) return null;
    const kids = childrenOf(n.id, sp).filter((k) => k.level >= n.level && !seen.has(k.id));
    const isOpen = expanded[n.id] ?? path.includes(n.id);
    const next = new Set(seen); next.add(n.id);
    return (
      <li key={n.id} role="treeitem" aria-expanded={kids.length ? isOpen : undefined} aria-selected={cur === n.id}>
        <div className={`ps-tree-row ${cur === n.id ? 'ps-tree-cur' : ''} ${selected === n.id ? 'ps-tree-sel' : ''}`} style={{ paddingLeft: depth * 12 + 4 }}>
          <button className="ps-tree-toggle" aria-label={isOpen ? 'Collapse' : 'Expand'} onClick={() => setExpanded((e) => ({ ...e, [n.id]: !isOpen }))} disabled={!kids.length}>{kids.length ? (isOpen ? '▾' : '▸') : '·'}</button>
          <button className="ps-tree-label" onClick={() => navigate(n.id)} title={`${n.type} · ≈ ${formatMeters(n.scaleM)}`}><span className={`ps-type-dot t-${n.type}`} aria-hidden />{n.name}</button>
          <span className="ps-tree-scale">{formatMeters(n.scaleM, 0)}</span>
        </div>
        {isOpen && kids.length > 0 && <ul role="group">{kids.map((k) => render(k, depth + 1, next))}</ul>}
      </li>
    );
  };
  return (
    <div>
      <div className="ps-section-title">{sp.common.toUpperCase()} — ANATOMICAL TREE</div>
      <ul role="tree" className="ps-tree">{render(NODE_MAP.plant, 0, new Set())}</ul>
      {sp.type === 'fern' && <p className="ps-note">Ferns have no flowers, fruit or seeds; those branches are hidden for this species.</p>}
    </div>
  );
}

function Libraries() {
  const sp = useSpecies(); const navigate = useStore((s) => s.navigate); const set = useStore((s) => s.set); const startJourney = useStore((s) => s.startJourney);
  const [cat, setCat] = useState<MolCategory | 'ALL'>('ALL');
  const cats = useMemo(() => Array.from(new Set(MOLECULES.map((m) => m.category))), []);
  const tissues = ['epidermis', 'meristem', 'parenchyma', 'collenchyma', 'sclerenchyma', 'xylem', 'phloem', 'mesophyll', 'endodermis', 'cork'].map((t) => ({ t, node: t === 'epidermis' ? 'upper-epidermis' : t === 'parenchyma' ? 'root-cortex' : t === 'collenchyma' ? 'cortex' : t })).filter((x) => NODE_MAP[x.node] && (x.t !== 'cork' || sp.secondaryGrowth) && (x.t !== 'collenchyma' || sp.tissues.includes('collenchyma')));
  const cells = sp.cells.map((c) => NODE_MAP[c]).filter(Boolean).concat([NODE_MAP['animal-cell']]);
  return (
    <div className="space-y-4">
      <section><div className="ps-section-title">CINEMATIC JOURNEYS</div>
        <div className="grid gap-1">{JOURNEYS.map((j) => <button key={j.id} className="ps-list-btn" onClick={() => startJourney(j.id)}>▶ {j.name}<span className="ps-muted"> · {j.steps.length} stops</span></button>)}</div></section>
      <section><div className="ps-section-title">TISSUE LIBRARY</div>
        <div className="grid grid-cols-2 gap-1">{tissues.map((x) => <button key={x.t} className="ps-list-btn" onClick={() => navigate(x.node)}>{x.t.toUpperCase()}</button>)}</div></section>
      <section><div className="ps-section-title">CELL DATABASE</div>
        <div className="grid gap-1">{cells.map((c) => <button key={c.id} className="ps-list-btn" onClick={() => navigate(c.id)}>{c.name}<span className="ps-muted"> · {formatMeters(c.scaleM, 0)}</span></button>)}</div>
        <p className="ps-note">Each model is type-specific; no single generic cell stands for all plant cells.</p></section>
      <section><div className="ps-section-title">PLANT CHEMISTRY EXPLORER</div>
        <div className="flex flex-wrap gap-1 mb-2"><button className={`ps-chip ${cat === 'ALL' ? 'ps-chip-on' : ''}`} onClick={() => setCat('ALL')}>ALL</button>{cats.map((c) => <button key={c} className={`ps-chip ${cat === c ? 'ps-chip-on' : ''}`} onClick={() => setCat(c)}>{c}</button>)}</div>
        <div className="grid gap-1">{MOLECULES.filter((m) => cat === 'ALL' || m.category === cat).map((m) => <button key={m.id} className={`ps-list-btn ${sp.molecules.includes(m.id) ? 'ring-1 ring-emerald-500/40' : ''}`} onClick={() => navigate(m.id)}><span className="font-mono text-emerald-300/80 mr-1">{m.formula}</span>{m.name}{sp.molecules.includes(m.id) && <span className="ps-muted"> · highlighted for {sp.common}</span>}</button>)}</div>
        {cat === 'ALL' || cat === 'PROTEINS' ? <div className="grid gap-1 mt-2">{PROTEINS.map((p) => <button key={p.id} className="ps-list-btn" onClick={() => navigate(p.id)}><span className="font-mono text-sky-300/80 mr-1">{p.pdb}</span>{p.name}<span className="ps-muted"> · {p.organism.split(' (')[0]}{p.heavy ? ' · large download' : ''}</span></button>)}</div> : null}
        <p className="ps-note">Curated list: only structures with authoritative identifiers (PubChem CID, PDB ID, NIST geometry). Nothing here is invented.</p></section>
      <section><div className="ps-section-title">CHEMICAL PATHWAYS (CONCEPTUAL)</div>
        <div className="grid gap-1">{PATHWAYS.map((p) => <button key={p.id} className="ps-list-btn" onClick={() => set({ dialog: 'pathways' })}>{p.name}<span className="ps-muted"> · {p.where}</span></button>)}</div></section>
    </div>
  );
}

function Builder() {
  const p = useParams(); const sp = useSpecies(); const setParams = useStore((s) => s.setParams); const randomize = useStore((s) => s.randomize); const resetParams = useStore((s) => s.resetParams); const saveSpecies = useStore((s) => s.saveSpecies);
  const growth = useStore((s) => s.growth); const growthMode = useStore((s) => s.growthMode); const setGrowth = useStore((s) => s.setGrowth); const set = useStore((s) => s.set); const node = useCurrentNode(); const navigate = useStore((s) => s.navigate);
  const saved = useStore((s) => s.savedSpecies); const del = useStore((s) => s.deleteSavedSpecies); const setSpecies = useStore((s) => s.setSpecies);
  const [name, setName] = useState('');
  const stage = growthStageAt(growth);
  return (
    <div className="space-y-4">
      {node.scene !== 'plant' && <button className="ps-btn w-full" onClick={() => navigate('plant')}>← Return to whole plant to see changes</button>}
      <section><div className="ps-section-title">GROWTH MODE</div>
        <label className="ps-check"><input type="checkbox" checked={growthMode} onChange={(e) => set({ growthMode: e.target.checked })} /> Show developmental progression</label>
        {growthMode && <>
          <input type="range" min={0} max={1} step={0.005} value={growth} onChange={(e) => setGrowth(parseFloat(e.target.value))} className="w-full" aria-label="Growth stage" />
          <div className="flex flex-wrap gap-1 mt-1">{GROWTH_STAGES.map((g) => <button key={g.name} className={`ps-chip ${stage.name === g.name ? 'ps-chip-on' : ''}`} onClick={() => setGrowth(g.t + 0.01)}>{g.name}</button>)}</div>
          <p className="ps-note mt-1"><b>{stage.name}</b>: {stage.desc}<br />Developmental sequence only — no species-specific timing is claimed.</p></>}
      </section>
      <section><div className="ps-section-title">PLANT BUILDER — {sp.common.toUpperCase()}</div>
        <S p={p} setParams={setParams} k="height" label="Height" min={0.1} max={6} step={0.05} unit=" m" /><S p={p} setParams={setParams} k="stemThickness" label="Stem diameter" min={0.003} max={0.4} step={0.001} unit=" m" />
        <S p={p} setParams={setParams} k="branchCount" label="Branches" min={0} max={14} /><S p={p} setParams={setParams} k="leafCount" label="Leaves" min={4} max={120} /><S p={p} setParams={setParams} k="leafSize" label="Leaf size" min={0.02} max={1} step={0.01} unit=" m" /><S p={p} setParams={setParams} k="leafAngle" label="Leaf angle" min={10} max={85} unit="°" />
        <S p={p} setParams={setParams} k="rootSpread" label="Root spread" min={0.1} max={2} step={0.05} unit=" m" /><S p={p} setParams={setParams} k="rootDepth" label="Root depth" min={0.1} max={2} step={0.05} unit=" m" /><S p={p} setParams={setParams} k="flowerCount" label="Flowers" min={0} max={12} /><S p={p} setParams={setParams} k="fruitCount" label="Fruits" min={0} max={12} /><S p={p} setParams={setParams} k="seed" label="Random seed" min={1} max={9999} />
        <div className="grid grid-cols-3 gap-1 mt-2">
          <select className="ps-select" value={p.leafShape} onChange={(e) => setParams({ leafShape: e.target.value as LeafShape })} aria-label="Leaf shape">{['ovate', 'lanceolate', 'cordate', 'linear', 'pinnate', 'frond'].map((x) => <option key={x}>{x}</option>)}</select>
          <select className="ps-select" value={p.flowerType} onChange={(e) => setParams({ flowerType: e.target.value as FlowerType })} aria-label="Flower type">{['star', 'rose', 'composite', 'spike', 'panicle', 'verticillaster', 'none'].map((x) => <option key={x}>{x}</option>)}</select>
          <select className="ps-select" value={p.fruitType} onChange={(e) => setParams({ fruitType: e.target.value as FruitType })} aria-label="Fruit type">{['berry', 'drupe', 'achene', 'hip', 'caryopsis', 'cob', 'nutlet', 'none'].map((x) => <option key={x}>{x}</option>)}</select>
        </div>
        <div className="grid grid-cols-3 gap-1 mt-2">
          <label className="ps-color">leaf<input type="color" value={p.leafColor} onChange={(e) => setParams({ leafColor: e.target.value })} /></label>
          <label className="ps-color">petal<input type="color" value={p.petalColor} onChange={(e) => setParams({ petalColor: e.target.value })} /></label>
          <label className="ps-color">fruit<input type="color" value={p.fruitColor} onChange={(e) => setParams({ fruitColor: e.target.value })} /></label>
        </div>
        <div className="flex gap-1 mt-2"><button className="ps-btn flex-1" onClick={randomize}>RANDOMIZE</button><button className="ps-btn flex-1" onClick={() => setParams({ seed: p.seed + 1 })}>REGENERATE</button><button className="ps-btn" onClick={resetParams} title="Reset to species defaults">RESET</button></div>
        <div className="flex gap-1 mt-2"><input className="ps-input flex-1" placeholder="Name this plant…" value={name} onChange={(e) => setName(e.target.value)} aria-label="Plant name" /><button className="ps-btn" onClick={() => { saveSpecies(name || `${sp.common} variant`); setName(''); }}>SAVE PLANT</button></div>
        {saved.length > 0 && <div className="mt-2 grid gap-1">{saved.map((s) => <div key={s.id} className="flex items-center gap-1"><button className="ps-list-btn flex-1" onClick={() => setSpecies(s.id)}>{s.common}<span className="ps-muted"> · {s.params.height} m</span></button><button className="ps-icon-btn" aria-label="Delete" onClick={() => del(s.id)}>✕</button></div>)}</div>}
        <p className="ps-note">Builder changes geometry only. Anatomy, tissues and molecules remain those of the selected species type ({sp.type}).</p>
      </section>
    </div>
  );
}

function S({ p, setParams, k, label, min, max, step = 1, unit = '' }: { p: ReturnType<typeof useParams>; setParams: (x: Partial<ReturnType<typeof useParams>>) => void; k: keyof ReturnType<typeof useParams>; label: string; min: number; max: number; step?: number; unit?: string }) {
  const v = p[k] as number;
  return <label className="ps-slider"><span>{label}</span><input type="range" min={min} max={max} step={step} value={v} onChange={(e) => setParams({ [k]: parseFloat(e.target.value) })} aria-label={label} /><span className="ps-val">{v < 1 && step < 1 ? v.toFixed(3) : v}{unit}</span></label>;
}
