import { useEffect, useState } from 'react';
import { useStore, useCurrentNode, useSpecies, type Quality } from '@/store';
import { NODE_MAP, childrenOf } from '@/data/nodes';
import { formatMeters, nearestScaleLabel, STATUS_HINT } from '@/data/core';
import { JOURNEYS, COMPARE_PRESETS, PATHWAYS, moleculeById } from '@/data/molecules';
import { TISSUE_COLORS } from '@/three/OrganScenes';

export default function HUD() {
  const st = useStore(); const node = useCurrentNode(); const sp = useSpecies();
  const kids = childrenOf(node.id, sp);
  const enter = st.selectedId && kids.some((k) => k.id === st.selectedId) ? NODE_MAP[st.selectedId] : (node.enterChild && NODE_MAP[node.enterChild]) || kids[0];
  const parent = st.path.length > 1 ? NODE_MAP[st.path[st.path.length - 2]] : null;
  const journey = st.journey ? JOURNEYS.find((j) => j.id === st.journey!.id) : null;
  return (
    <>
      <div className="ps-hud" role="status" aria-live="polite">
        <div className="ps-hud-left">
          <button className="ps-icon-btn" onClick={st.back} disabled={!st.past.length} title="Back (Alt+←)" aria-label="Back">←</button>
          <button className="ps-icon-btn" onClick={st.forward} disabled={!st.future.length} title="Forward (Alt+→)" aria-label="Forward">→</button>
          <button className="ps-icon-btn" onClick={() => st.set({ dialog: 'history' })} title="History" aria-label="History">🕘</button>
          <span className="ps-hud-sep" />
          <button className="ps-btn" onClick={st.ascend} disabled={!parent} title="Zoom out one level (Backspace)">↑ {parent ? parent.name : 'top'}</button>
          <button className="ps-btn ps-btn-primary" onClick={st.descend} disabled={!enter} title="Zoom in one level (Enter)">↓ {enter ? enter.name : 'deepest'}</button>
        </div>
        <div className="ps-hud-center">
          <div className="ps-scalebar" aria-label={`Approximate field of view ${formatMeters(st.fovMeters)}`}>
            <div className="ps-scalebar-line" /><div className="ps-scalebar-text"><b>{nearestScaleLabel(st.fovMeters)}</b><span className="ps-muted"> · field of view ≈ {formatMeters(st.fovMeters)} · {node.name} ≈ {formatMeters(node.scaleM)}</span></div>
          </div>
          <div className="text-[10px] text-zinc-400 mt-0.5">{node.status} — <span title={STATUS_HINT[node.status]}>scale is an approximate model scale, not a microscope resolution</span></div>
        </div>
        <div className="ps-hud-right">
          <Legend />
          {st.presentation && <button className="ps-btn" onClick={() => st.set({ presentation: false })}>EXIT PRESENTATION</button>}
        </div>
      </div>
      {st.zoomHint && <div className="ps-zoomhint" aria-live="polite"><div className="ps-ring" style={{ ['--p' as string]: st.zoomHint.progress }} /><div>{st.zoomHint.dir === 'in' ? `keep zooming to enter ${enter?.name ?? ''}` : `keep zooming out to return to ${parent?.name ?? ''}`}</div></div>}
      <Transition />
      {st.toast && <div className="ps-toast" role="status">{st.toast}</div>}
      {journey && st.journey && <div className="ps-journey" role="region" aria-label="Journey">
        <div className="text-[10px] uppercase tracking-widest text-emerald-300">Journey · {journey.name} · {st.journey.step + 1}/{journey.steps.length}</div>
        <div className="text-[13px] mt-0.5">{journey.steps[st.journey.step].text}</div>
        <div className="flex gap-1 mt-1"><button className="ps-btn" onClick={() => st.journeyStep(-1)} disabled={st.journey.step === 0}>◀ PREV</button><button className="ps-btn ps-btn-primary" onClick={() => st.journeyStep(1)}>{st.journey.step + 1 === journey.steps.length ? 'FINISH' : 'NEXT ▶'}</button><button className="ps-btn" onClick={st.stopJourney}>✕</button></div>
      </div>}
      <Dialogs />
    </>
  );
}

function Legend() {
  const node = useCurrentNode(); const [open, setOpen] = useState(false);
  const items = node.level <= 2 ? [['Epidermis', TISSUE_COLORS.epidermis], ['Cortex / parenchyma', TISSUE_COLORS.parenchyma], ['Endodermis', TISSUE_COLORS.endodermis], ['Casparian strip', TISSUE_COLORS.casparian], ['Xylem', TISSUE_COLORS.xylem], ['Phloem', TISSUE_COLORS.phloem], ['Cambium', TISSUE_COLORS.cambium], ['Pith', TISSUE_COLORS.pith], ['Palisade', TISSUE_COLORS.palisade], ['Spongy', TISSUE_COLORS.spongy], ['Meristem', TISSUE_COLORS.meristem]]
    : node.level <= 4 ? [['Cell wall', '#d9c9a0'], ['Plasma membrane', '#f0b46a'], ['Vacuole', '#cfe8f7'], ['Nucleus', '#7b5aa6'], ['Chloroplast / thylakoid', '#2f8f3a'], ['Mitochondrion', '#e0603a'], ['ER', '#d8a0c0'], ['Golgi', '#e8c46a'], ['Ribosomes', '#5b5b7a'], ['Starch', '#f4f4f0']]
    : [['H', '#e8e8e8'], ['C', '#565656'], ['N', '#3050f8'], ['O', '#ff0d0d'], ['P', '#ff8000'], ['S', '#ffff30'], ['Mg', '#8aff00'], ['Fe', '#e06633'], ['selected atom', '#7fe3ff']];
  return (
    <div className="relative">
      <button className="ps-btn" onClick={() => setOpen(!open)} aria-expanded={open}>LEGEND</button>
      {open && <div className="ps-legend-pop">{items.map(([n, c]) => <span key={n} className="ps-legend-item"><i style={{ background: c }} />{n}</span>)}<div className="ps-note">Colours follow one consistent mapping per scale (tissues · organelles · CPK elements). They are conventions, not measured colours.</div></div>}
    </div>
  );
}

function Transition() {
  const t = useStore((s) => s.transition); const [vis, setVis] = useState(false); const reduced = useStore((s) => s.reducedMotion);
  useEffect(() => { if (!t) return; setVis(true); const id = setTimeout(() => setVis(false), reduced ? 900 : 1600); return () => clearTimeout(id); }, [t, reduced]);
  if (!t || !vis) return null;
  return <div className="ps-transition" aria-hidden><div className="ps-transition-label">{t.label}</div><div className="ps-transition-sub">{t.sub}</div></div>;
}

function Dialogs() {
  const dialog = useStore((s) => s.dialog); const set = useStore((s) => s.set);
  useEffect(() => { const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') set({ dialog: null }); }; window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey); }, [set]);
  if (!dialog) return null;
  return (
    <div className="ps-modal-bg" onClick={() => set({ dialog: null })}>
      <div className="ps-modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <button className="ps-icon-btn absolute right-2 top-2" aria-label="Close" onClick={() => set({ dialog: null })}>✕</button>
        {dialog === 'compare' && <Compare />}
        {dialog === 'bookmarks' && <Bookmarks />}
        {dialog === 'settings' && <Settings />}
        {dialog === 'help' && <Help />}
        {dialog === 'pathways' && <Pathways />}
        {dialog === 'history' && <History />}
      </div>
    </div>
  );
}

function Compare() {
  const a = useStore((s) => s.compareA); const b = useStore((s) => s.compareB); const set = useStore((s) => s.set); const navigate = useStore((s) => s.navigate);
  const A = a ? NODE_MAP[a] : null; const B = b ? NODE_MAP[b] : null;
  const rows: [string, (n: NonNullable<typeof A>) => string][] = [['Type', (n) => n.type], ['Scale level', (n) => ['whole plant', 'organ', 'tissue', 'cell', 'organelle', 'macromolecule', 'molecule', 'atom'][n.level] ?? ''], ['Characteristic size', (n) => '≈ ' + formatMeters(n.scaleM)], ['Function', (n) => n.fn], ['Made of', (n) => n.madeOf ?? (n.children.filter((c) => NODE_MAP[c]).map((c) => NODE_MAP[c].name).join(', ') || '—')], ['Formula', (n) => n.formula ?? '—'], ['Scientific status', (n) => n.status], ['Source', (n) => `${n.source?.name ?? '—'}${n.source?.id ? ' · ' + n.source.id : ''}`], ['Description', (n) => n.description]];
  const ratio = A && B ? A.scaleM / B.scaleM : null;
  return (
    <div>
      <h2 className="ps-modal-title">COMPARE STRUCTURES</h2>
      <div className="flex flex-wrap gap-1 mb-3">{COMPARE_PRESETS.map((p) => <button key={p.name} className="ps-chip" onClick={() => set({ compareA: p.a, compareB: p.b })}>{p.name}</button>)}</div>
      <div className="grid grid-cols-2 gap-2 mb-2">
        {[['A', A, 'compareA'], ['B', B, 'compareB']].map(([k, n, key]) => <div key={k as string} className="ps-card"><div className="ps-section-title">{k as string}</div>{n ? <><div className="font-semibold">{(n as NonNullable<typeof A>).name}</div><button className="ps-btn mt-1" onClick={() => { navigate((n as NonNullable<typeof A>).id); set({ dialog: null }); }}>GO</button></> : <div className="ps-muted text-[11px]">Select an object and press ⇄ COMPARE, or pick a preset.</div>}<button className="ps-btn mt-1 ml-1" onClick={() => set({ [key as string]: useStore.getState().selectedId ?? useStore.getState().path.slice(-1)[0] })}>USE CURRENT</button></div>)}
      </div>
      {A && B && <table className="ps-table"><tbody>
        {rows.map(([label, fn]) => { const va = fn(A), vb = fn(B); return <tr key={label} className={va !== vb ? 'ps-diff' : ''}><th>{label}</th><td>{va}</td><td>{vb}</td></tr>; })}
        {ratio && <tr className="ps-diff"><th>Size ratio</th><td colSpan={2}>{A.name} is {ratio >= 1 ? `≈ ${ratio >= 100 ? ratio.toExponential(1) : ratio.toFixed(1)}× larger` : `≈ ${(1 / ratio) >= 100 ? (1 / ratio).toExponential(1) : (1 / ratio).toFixed(1)}× smaller`} than {B.name} (characteristic sizes)</td></tr>}
      </tbody></table>}
      <p className="ps-note">Highlighted rows differ. Sizes are characteristic textbook values, not measurements of a specimen.</p>
    </div>
  );
}

function Bookmarks() {
  const bm = useStore((s) => s.bookmarks); const go = useStore((s) => s.gotoBookmark); const rm = useStore((s) => s.removeBookmark); const add = useStore((s) => s.addBookmark); const set = useStore((s) => s.set); const notes = useStore((s) => s.notes); const navigate = useStore((s) => s.navigate); const ms = useStore((s) => s.measurements);
  const [name, setName] = useState('');
  return (
    <div>
      <h2 className="ps-modal-title">BOOKMARKS · NOTES · MEASUREMENTS</h2>
      <div className="flex gap-1 mb-2"><input className="ps-input flex-1" placeholder="Bookmark name (current location + camera)" value={name} onChange={(e) => setName(e.target.value)} /><button className="ps-btn ps-btn-primary" onClick={() => { add(name); setName(''); }}>SAVE</button></div>
      {bm.length === 0 && <p className="ps-muted text-[11px]">No bookmarks yet.</p>}
      <ul className="space-y-1">{bm.map((b) => <li key={b.id} className="flex items-center gap-2 ps-card"><div className="flex-1"><div className="font-medium text-[12px]">{b.name}</div><div className="ps-muted text-[10px]">{b.path.map((p) => NODE_MAP[p]?.name ?? p).join(' → ')}{b.camera ? ' · camera saved' : ''} · {new Date(b.created).toLocaleString()}</div></div><button className="ps-btn" onClick={() => { go(b); set({ dialog: null }); }}>GO</button><button className="ps-icon-btn" aria-label="Delete" onClick={() => rm(b.id)}>✕</button></li>)}</ul>
      {Object.keys(notes).length > 0 && <><div className="ps-section-title mt-3">NOTES</div><ul className="space-y-1">{Object.entries(notes).map(([id, t]) => <li key={id} className="ps-card text-[11px]"><button className="font-medium underline" onClick={() => { navigate(id); set({ dialog: null }); }}>{NODE_MAP[id]?.name ?? id}</button><div className="text-zinc-300">{t}</div></li>)}</ul></>}
      {ms.length > 0 && <><div className="ps-section-title mt-3">MEASUREMENTS (this session)</div><ul className="text-[11px]">{ms.map((m) => <li key={m.id}>{m.scene} · <span className="font-mono text-amber-200">{m.label}</span></li>)}</ul></>}
      <p className="ps-note">Stored in this browser only (localStorage).</p>
    </div>
  );
}

function Settings() {
  const st = useStore();
  return (
    <div>
      <h2 className="ps-modal-title">SETTINGS & ACCESSIBILITY</h2>
      <div className="ps-section-title">QUALITY</div>
      <div className="flex flex-wrap gap-1 mb-3">{(['ultra', 'high', 'balanced', 'performance', 'accessibility'] as Quality[]).map((q) => <button key={q} className={`ps-chip ${st.quality === q ? 'ps-chip-on' : ''}`} onClick={() => st.set({ quality: q })}>{q.toUpperCase()}</button>)}</div>
      <p className="ps-note mb-3">Adjusts resolution, shadows, geometry detail, particle counts, instance counts and the maximum atoms rendered as spheres before switching proteins to backbone traces.</p>
      <div className="ps-section-title">ACCESSIBILITY</div>
      <label className="ps-check"><input type="checkbox" checked={st.reducedMotion} onChange={(e) => st.set({ reducedMotion: e.target.checked })} /> Reduced motion (no sway, spin, particles frozen, instant camera moves)</label>
      <label className="ps-check"><input type="checkbox" checked={st.highContrast} onChange={(e) => st.set({ highContrast: e.target.checked })} /> High contrast (black background, brighter selection outlines & labels)</label>
      <label className="ps-check"><input type="checkbox" checked={st.largeLabels} onChange={(e) => st.set({ largeLabels: e.target.checked })} /> Larger 3D labels</label>
      <label className="ps-check"><input type="checkbox" checked={st.showLabels} onChange={(e) => st.set({ showLabels: e.target.checked })} /> Show 3D labels</label>
      <div className="ps-section-title mt-3">KEYBOARD</div>
      <table className="ps-table text-[11px]"><tbody>
        <tr><th>/</th><td>focus search</td><th>Enter</th><td>zoom in one level</td></tr>
        <tr><th>Backspace</th><td>zoom out one level</td><th>Alt + ← / →</th><td>history back / forward</td></tr>
        <tr><th>[ ]</th><td>previous / next sibling</td><th>1–9</th><td>jump to scale level</td></tr>
        <tr><th>P</th><td>presentation mode</td><th>L</th><td>toggle labels</td></tr>
        <tr><th>B</th><td>bookmark</td><th>M</th><td>measure</td></tr>
        <tr><th>Esc</th><td>close dialog / deselect</td><th>arrow keys</th><td>orbit (canvas focused)</td></tr>
      </tbody></table>
      <p className="ps-note">Selection is indicated by glow, label and inspector text — never by colour alone. The 3D view has an aria-live description of the current location.</p>
    </div>
  );
}

function Pathways() {
  const navigate = useStore((s) => s.navigate); const set = useStore((s) => s.set); const [active, setActive] = useState(PATHWAYS[0].id);
  const p = PATHWAYS.find((x) => x.id === active)!;
  return (
    <div>
      <h2 className="ps-modal-title">CHEMICAL PATHWAYS — CONCEPTUAL</h2>
      <div className="flex flex-wrap gap-1 mb-3">{PATHWAYS.map((x) => <button key={x.id} className={`ps-chip ${active === x.id ? 'ps-chip-on' : ''}`} onClick={() => setActive(x.id)}>{x.name}</button>)}</div>
      <div className="ps-muted text-[11px] mb-2">{p.where}</div>
      <ol className="space-y-1">{p.steps.map((s, i) => <li key={i} className="ps-card flex items-center gap-2"><span className="ps-step">{i + 1}</span><span className="flex-1 text-[12px]">{s.label}</span>{s.node && NODE_MAP[s.node] && <button className="ps-btn" onClick={() => { navigate(s.node!); set({ dialog: null, photosynthesis: true, transport: true }); }}>SHOW IN 3D</button>}</li>)}</ol>
      <p className="ps-note mt-2">{p.note}</p>
    </div>
  );
}

function History() {
  const past = useStore((s) => s.past); const future = useStore((s) => s.future); const path = useStore((s) => s.path); const navigate = useStore((s) => s.navigate); const set = useStore((s) => s.set);
  const row = (p: string[], k: string, cls = '') => <li key={k} className={`ps-card flex items-center gap-2 ${cls}`}><span className="flex-1 text-[11px]">{p.map((x) => NODE_MAP[x]?.name ?? x).join(' → ')}</span><button className="ps-btn" onClick={() => { navigate(p[p.length - 1]); set({ dialog: null }); }}>GO</button></li>;
  return <div><h2 className="ps-modal-title">EXPLORATION HISTORY</h2><ul className="space-y-1">{past.map((p, i) => row(p, 'p' + i))}{row(path, 'cur', 'ring-1 ring-emerald-400/50')}{future.map((p, i) => row(p, 'f' + i, 'opacity-60'))}</ul></div>;
}

function Help() {
  const sp = useSpecies(); const m = moleculeById('chlorophyll-a');
  return (
    <div className="text-[12px] space-y-2">
      <h2 className="ps-modal-title">HOW TO TRAVEL THROUGH A PLANT</h2>
      <p>Orbit with drag, zoom with wheel/pinch, pan with right-drag or two fingers. <b>Keep zooming in</b> at the closest distance to enter the selected (or default) structure; keep zooming out at the farthest distance to return outward. Click a part to select it, double-click to enter it.</p>
      <p>The <b>scale navigator</b> (left) jumps between WHOLE PLANT → ORGANS → TISSUES → CELLS → ORGANELLES → MACROMOLECULES → MOLECULES → ATOMS → CHEMISTRY. The <b>anatomical tree</b> navigates any branch of {sp.common}. <b>Search</b> finds plants, organs, tissues, cells, organelles, proteins, molecules and terms.</p>
      <p>Every object shows its <b>scientific status</b>: OBSERVED STRUCTURE (documented anatomy, reconstructed in 3D), 3D RECONSTRUCTION, SCHEMATIC VISUALIZATION, SCIENTIFIC MODEL, SIMULATED STRUCTURE, MOLECULAR MODEL (real coordinates from PubChem / RCSB PDB / NIST), or THEORETICAL / APPROXIMATED. Flows, photosynthesis and gas exchange are labelled CONCEPTUAL; nothing is a quantitative simulation.</p>
      <p>Example: {m?.name} — {m?.no3d}</p>
      <p>Tools: view layers (cutaway, x-ray, transparent, exploded), focus mode, cross-section plane, measurement (auto units m → Å), compare, bookmarks with camera, personal notes, history, cinematic journeys, plant builder and growth mode.</p>
      <p className="ps-note">Data sources require network access on first use; loaded structures are cached locally for later offline viewing. Large PDB entries (RuBisCO, PSII, cyt b₆f, CesA) are several MB.</p>
    </div>
  );
}
