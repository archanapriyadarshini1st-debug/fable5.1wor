// Lazy, cached loaders for authoritative molecular data (PubChem PUG REST, RCSB PDB files).
import { moleculeById, proteinById } from '@/data/molecules';
import type { Source } from '@/data/core';

export interface Atom { el: string; x: number; y: number; z: number; name?: string; res?: string; chain?: string; resSeq?: number; hetero?: boolean }
export interface Bond { a: number; b: number; order: number }
export interface Structure {
  atoms: Atom[]; bonds: Bond[]; source: Source; title: string; center: [number, number, number]; radius: number;
  chains?: string[]; residues?: number; ligandResidues?: Record<string, number>; status: 'ok' | 'unavailable'; message?: string;
}

const mem = new Map<string, Promise<Structure>>();
const LS_PREFIX = 'plantscape.cache.v1.';

function lsGet(key: string): string | null { try { return localStorage.getItem(LS_PREFIX + key); } catch { return null; } }
function lsSet(key: string, v: string) { try { if (v.length < 400_000) localStorage.setItem(LS_PREFIX + key, v); } catch { /* quota */ } }

async function fetchText(url: string, cacheKey: string): Promise<string> {
  const cached = lsGet(cacheKey);
  if (cached) return cached;
  const res = await fetch(url, { mode: 'cors' });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  const t = await res.text();
  lsSet(cacheKey, t);
  return t;
}

function finalize(atoms: Atom[], bonds: Bond[], source: Source, title: string, extra: Partial<Structure> = {}): Structure {
  let cx = 0, cy = 0, cz = 0;
  for (const a of atoms) { cx += a.x; cy += a.y; cz += a.z; }
  const n = Math.max(1, atoms.length);
  cx /= n; cy /= n; cz /= n;
  let r = 0;
  for (const a of atoms) r = Math.max(r, Math.hypot(a.x - cx, a.y - cy, a.z - cz));
  return { atoms, bonds, source, title, center: [cx, cy, cz], radius: Math.max(r, 1), status: 'ok', ...extra };
}

// ─── SDF (MDL molfile V2000) ─────────────────────────────────────────────────
export function parseSDF(text: string): { atoms: Atom[]; bonds: Bond[]; title: string } {
  const lines = text.split(/\r?\n/);
  const title = lines[0]?.trim() ?? '';
  const counts = lines[3] ?? '';
  const nAtoms = parseInt(counts.slice(0, 3), 10);
  const nBonds = parseInt(counts.slice(3, 6), 10);
  const atoms: Atom[] = [];
  const bonds: Bond[] = [];
  for (let i = 0; i < nAtoms; i++) {
    const l = lines[4 + i] ?? '';
    atoms.push({ x: parseFloat(l.slice(0, 10)), y: parseFloat(l.slice(10, 20)), z: parseFloat(l.slice(20, 30)), el: l.slice(31, 34).trim() });
  }
  for (let i = 0; i < nBonds; i++) {
    const l = lines[4 + nAtoms + i] ?? '';
    bonds.push({ a: parseInt(l.slice(0, 3), 10) - 1, b: parseInt(l.slice(3, 6), 10) - 1, order: parseInt(l.slice(6, 9), 10) || 1 });
  }
  return { atoms, bonds, title };
}

// ─── PDB ─────────────────────────────────────────────────────────────────────
export function parsePDB(text: string, opts: { skipWater?: boolean; firstModelOnly?: boolean } = { skipWater: true, firstModelOnly: true }) {
  const atoms: Atom[] = [];
  const conect: Bond[] = [];
  const chains = new Set<string>();
  const residues = new Set<string>();
  const ligandResidues: Record<string, number> = {};
  let title = '';
  const lines = text.split('\n');
  for (const l of lines) {
    const rec = l.slice(0, 6);
    if (rec === 'TITLE ') title += l.slice(10).trim() + ' ';
    else if (rec === 'ENDMDL' && opts.firstModelOnly) break;
    else if (rec === 'ATOM  ' || rec === 'HETATM') {
      const res = l.slice(17, 20).trim();
      if (opts.skipWater && (res === 'HOH' || res === 'WAT')) continue;
      const altLoc = l[16];
      if (altLoc !== ' ' && altLoc !== 'A' && altLoc !== '1') continue;
      let el = l.slice(76, 78).trim();
      if (!el) el = l.slice(12, 14).trim().replace(/[0-9]/g, '');
      const chain = l[21];
      const resSeq = parseInt(l.slice(22, 26), 10);
      const hetero = rec === 'HETATM';
      atoms.push({ el: el.length > 1 ? el[0] + el[1].toLowerCase() : el, x: parseFloat(l.slice(30, 38)), y: parseFloat(l.slice(38, 46)), z: parseFloat(l.slice(46, 54)), name: l.slice(12, 16).trim(), res, chain, resSeq, hetero });
      chains.add(chain);
      residues.add(`${chain}:${resSeq}`);
      if (hetero) ligandResidues[res] = (ligandResidues[res] ?? 0) + 1;
    }
  }
  return { atoms, bonds: conect, title: title.trim(), chains: Array.from(chains), residues: residues.size, ligandResidues };
}

/** distance-based bond perception (covalent radii sum × 1.15) for small sets */
export function perceiveBonds(atoms: Atom[], covalent: (el: string) => number): Bond[] {
  const bonds: Bond[] = [];
  const n = atoms.length;
  if (n > 4000) return bonds;
  // spatial hash for speed
  const cell = 2.2;
  const grid = new Map<string, number[]>();
  const key = (x: number, y: number, z: number) => `${Math.floor(x / cell)},${Math.floor(y / cell)},${Math.floor(z / cell)}`;
  atoms.forEach((a, i) => { const k = key(a.x, a.y, a.z); (grid.get(k) ?? grid.set(k, []).get(k)!).push(i); });
  for (let i = 0; i < n; i++) {
    const a = atoms[i];
    const gx = Math.floor(a.x / cell), gy = Math.floor(a.y / cell), gz = Math.floor(a.z / cell);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
      const list = grid.get(`${gx + dx},${gy + dy},${gz + dz}`);
      if (!list) continue;
      for (const j of list) {
        if (j <= i) continue;
        const b = atoms[j];
        const d = Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
        const max = (covalent(a.el) + covalent(b.el)) * 1.15 + 0.1;
        if (d < max && d > 0.4) bonds.push({ a: i, b: j, order: 1 });
      }
    }
  }
  return bonds;
}

// ─── public API ──────────────────────────────────────────────────────────────
export function loadMolecule(id: string, covalent: (el: string) => number): Promise<Structure> {
  const k = 'mol:' + id;
  if (mem.has(k)) return mem.get(k)!;
  const p = (async (): Promise<Structure> => {
    const m = moleculeById(id);
    if (!m) return { atoms: [], bonds: [], source: { name: '—' }, title: id, center: [0, 0, 0], radius: 1, status: 'unavailable', message: 'Unknown molecule id.' };
    if (m.hard) return finalize(m.hard.atoms.map(([el, x, y, z]) => ({ el, x, y, z })), m.hard.bonds.map(([a, b, order]) => ({ a, b, order })), m.hard.source, m.name);
    if (m.pdbLigand) {
      try {
        const pdbText = await fetchText(`https://files.rcsb.org/download/${m.pdbLigand.pdb}.pdb`, `pdb:${m.pdbLigand.pdb}`);
        const all = parsePDB(pdbText);
        const first = all.atoms.find((a) => a.res === m.pdbLigand!.resName);
        if (first) {
          const atoms = all.atoms.filter((a) => a.res === m.pdbLigand!.resName && a.chain === first.chain && a.resSeq === first.resSeq);
          const bonds = perceiveBonds(atoms, covalent);
          return finalize(atoms, bonds, { name: 'RCSB PDB (ligand extracted from crystal structure)', id: `${m.pdbLigand.pdb} · ${m.pdbLigand.resName} ${first.chain}${first.resSeq}`, url: `https://www.rcsb.org/structure/${m.pdbLigand.pdb}`, license: 'CC0 1.0 (wwPDB)', modelType: 'X-ray crystal structure; hydrogens absent; bonds perceived by distance', updated: 'live download' }, m.pdbLigand.label);
        }
      } catch (e) { console.warn('ligand extraction failed', e); }
    }
    if (m.cid) {
      try {
        const sdf = await fetchText(`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${m.cid}/SDF?record_type=3d`, `sdf3d:${m.cid}`);
        const { atoms, bonds } = parseSDF(sdf);
        if (atoms.length) return finalize(atoms, bonds, { name: 'PubChem (NCBI)', id: `CID ${m.cid}`, url: `https://pubchem.ncbi.nlm.nih.gov/compound/${m.cid}`, license: 'Public domain', modelType: 'PubChem3D computed conformer (MMFF94s), record_type=3d', updated: new Date().toISOString().slice(0, 10) }, m.name);
      } catch (e) {
        console.warn('PubChem 3D unavailable', e);
        return { atoms: [], bonds: [], source: { name: 'PubChem (NCBI)', id: `CID ${m.cid}` }, title: m.name, center: [0, 0, 0], radius: 1, status: 'unavailable', message: `3D STRUCTURE NOT AVAILABLE — PubChem 3D conformer could not be retrieved (${(e as Error).message}). ${m.no3d ?? 'Check network access; the 2D depiction and formula remain available.'}` };
      }
    }
    return { atoms: [], bonds: [], source: { name: '—' }, title: m.name, center: [0, 0, 0], radius: 1, status: 'unavailable', message: `STRUCTURE NOT AVAILABLE. ${m.no3d ?? ''}` };
  })();
  mem.set(k, p);
  return p;
}

export function loadProtein(id: string): Promise<Structure> {
  const k = 'prot:' + id;
  if (mem.has(k)) return mem.get(k)!;
  const p = (async (): Promise<Structure> => {
    const def = proteinById(id);
    if (!def) return { atoms: [], bonds: [], source: { name: '—' }, title: id, center: [0, 0, 0], radius: 1, status: 'unavailable', message: 'Unknown structure id.' };
    try {
      const text = await fetchText(`https://files.rcsb.org/download/${def.pdb}.pdb`, `pdb:${def.pdb}`);
      const parsed = parsePDB(text);
      if (!parsed.atoms.length) throw new Error('no atoms parsed');
      return finalize(parsed.atoms, [], { name: 'RCSB Protein Data Bank', id: def.pdb, url: `https://www.rcsb.org/structure/${def.pdb}`, license: 'CC0 1.0 (wwPDB)', species: def.organism, resolution: def.resolution, modelType: def.method, updated: new Date().toISOString().slice(0, 10) }, parsed.title || def.name, { chains: parsed.chains, residues: parsed.residues, ligandResidues: parsed.ligandResidues });
    } catch (e) {
      return { atoms: [], bonds: [], source: { name: 'RCSB PDB', id: def.pdb }, title: def.name, center: [0, 0, 0], radius: 1, status: 'unavailable', message: `STRUCTURE NOT AVAILABLE — could not download PDB ${def.pdb} (${(e as Error).message}). A conceptual placeholder is shown; no atomic detail is implied.` };
    }
  })();
  mem.set(k, p);
  return p;
}

export const pubchem2DUrl = (cid: number) => `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/PNG?image_size=400x400`;
export const clearStructureCache = () => { mem.clear(); try { Object.keys(localStorage).filter((k) => k.startsWith(LS_PREFIX)).forEach((k) => localStorage.removeItem(k)); } catch { /* ignore */ } };
export const cachedKeys = () => { try { return Object.keys(localStorage).filter((k) => k.startsWith(LS_PREFIX)).map((k) => k.slice(LS_PREFIX.length)); } catch { return []; } };
