import { useEffect, Component, type ReactNode } from 'react';
import Viewport from '@/three/Viewport';
import TopBar from '@/ui/TopBar';
import LeftPanel from '@/ui/LeftPanel';
import Inspector from '@/ui/Inspector';
import HUD from '@/ui/HUD';
import { useStore, useCurrentNode, useSpecies } from '@/store';
import { NODE_MAP, childrenOf } from '@/data/nodes';
import { formatMeters } from '@/data/core';

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (this.state.error) return <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#0e1a14] text-white p-6 text-center"><div className="text-lg font-semibold">The 3D view hit an error.</div><div className="text-xs text-zinc-400 max-w-md">{String(this.state.error.message)}</div><button className="ps-btn" onClick={() => { useStore.getState().navigate('plant'); this.setState({ error: null }); }}>Return to whole plant</button></div>;
    return this.props.children;
  }
}

function useKeyboard() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (document.activeElement?.tagName ?? '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      const st = useStore.getState();
      if (e.key === 'Enter') { e.preventDefault(); st.descend(); }
      else if (e.key === 'Backspace') { e.preventDefault(); st.ascend(); }
      else if (e.altKey && e.key === 'ArrowLeft') st.back();
      else if (e.altKey && e.key === 'ArrowRight') st.forward();
      else if (e.key === 'p' || e.key === 'P') st.set({ presentation: !st.presentation });
      else if (e.key === 'l' || e.key === 'L') st.set({ showLabels: !st.showLabels });
      else if (e.key === 'b' || e.key === 'B') st.addBookmark();
      else if (e.key === 'm' || e.key === 'M') st.set({ measureActive: !st.measureActive, measurePoints: [] });
      else if (e.key === 'Escape') { if (st.dialog) st.set({ dialog: null }); else if (st.presentation) st.set({ presentation: false }); else st.select(null); }
      else if (/^[1-9]$/.test(e.key)) st.jumpLevel(parseInt(e.key, 10) - 1);
      else if (e.key === '[' || e.key === ']') {
        const cur = st.path[st.path.length - 1]; const parent = st.path[st.path.length - 2]; if (!parent) return;
        const sibs = childrenOf(parent, useSpeciesSnapshot()); const i = sibs.findIndex((s) => s.id === cur); if (i < 0) return;
        const n = sibs[(i + (e.key === ']' ? 1 : sibs.length - 1)) % sibs.length]; if (n) st.navigate(n.id);
      }
    };
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey);
  }, []);
}
import { speciesById } from '@/data/species';
const useSpeciesSnapshot = () => speciesById(useStore.getState().speciesId);

function LiveRegion() {
  const node = useCurrentNode(); const sp = useSpecies(); const selected = useStore((s) => s.selectedId); const path = useStore((s) => s.path);
  const sel = selected ? NODE_MAP[selected] : null;
  return <div className="sr-only" aria-live="polite" aria-atomic="true">{`${sp.common}: ${path.map((p) => NODE_MAP[p]?.name).join(', ')}. Current: ${node.name}, approximately ${formatMeters(node.scaleM)}, ${node.status}. ${node.description}${sel && sel.id !== node.id ? ` Selected: ${sel.name}. ${sel.fn}` : ''}`}</div>;
}

export default function App() {
  useKeyboard();
  const hc = useStore((s) => s.highContrast); const large = useStore((s) => s.largeLabels); const presentation = useStore((s) => s.presentation); const measure = useStore((s) => s.measureActive);
  useEffect(() => { document.documentElement.classList.toggle('hc', hc); document.documentElement.classList.toggle('lg', large); }, [hc, large]);
  return (
    <div className={`ps-app ${presentation ? 'ps-presentation' : ''} ${measure ? 'cursor-crosshair' : ''}`}>
      <a href="#inspector" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:p-2 focus:bg-emerald-600">Skip to inspector</a>
      <ErrorBoundary><Viewport /></ErrorBoundary>
      <TopBar />
      <LeftPanel />
      <div id="inspector"><Inspector /></div>
      <HUD />
      <LiveRegion />
    </div>
  );
}
