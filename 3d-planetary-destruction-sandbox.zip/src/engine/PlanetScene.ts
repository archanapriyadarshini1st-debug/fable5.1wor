import * as THREE from 'three';
import TerrainWorker from './terrain.worker?worker&inline';
import { CameraRig } from './CameraRig';
import { DebrisSystem } from './Debris';
import { bus, simEvent } from './EventBus';
import { RNG, clamp } from './noise';
import { Planet } from './Planet';
import { ParticleSystem } from './Particles';
import { PostFX, type DistortionSource } from './PostFX';
import { SpaceBackground, StarObject } from './Space';
import { starForPlanet } from './planets';
import { generateHeightField, type HeightField } from './terrain';
import { TOOL_BY_ID, craterAngle } from './tools';
import type { DebugInfo, PlanetDef, PlanetStats, Quality, Replay, ReplayAction, ReplayCameraKey, Settings, Snapshot, ToolId } from './types';

type Stage = (label: string, progress: number) => void;

interface Effect { update(dt: number, t: number): boolean }

const HEIGHT_RES: Record<Quality, [number, number]> = { cinematic: [1536, 768], high: [1280, 640], balanced: [1024, 512], performance: [768, 384] };
const PARTICLE_CAP: Record<Quality, number> = { cinematic: 60000, high: 40000, balanced: 24000, performance: 10000 };
const DEBRIS_CAP: Record<Quality, number> = { cinematic: 2400, high: 1600, balanced: 1000, performance: 400 };
const INTEGRITY_BUDGET = 0.02; // fraction of planetary volume whose removal destabilises the body (game rule)

export const SIM_SPEEDS = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 100];

/**
 * Planet-scale sandbox engine. Owns the renderer, the simulation clock, the planet, all effect systems and the
 * destruction pipeline. React never touches particles or geometry - it only sends commands and reads stats.
 */
export class PlanetScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly rig: CameraRig;
  readonly space: SpaceBackground;
  readonly particles: ParticleSystem;
  readonly debris: DebrisSystem;
  readonly fragments: DebrisSystem;
  planet: Planet | null = null;
  star: StarObject;
  private post: PostFX;
  private container: HTMLElement;
  private settings: Settings;
  private raf = 0;
  private lastWall = performance.now();
  private wallTime = 0;
  simTime = 0;
  speed = 1;
  paused = false;
  private effects: Effect[] = [];
  private attractors = new Map<string, { pos: THREE.Vector3; strength: number; radius: number }>();
  private distortions = new Map<string, { world: THREE.Vector3; strength: number; radius: number }>();
  private sunDir = new THREE.Vector3(1, 0.15, 0.35).normalize();
  private sunLight: THREE.DirectionalLight;
  private reticle: THREE.Group;
  private reticleRing: THREE.Mesh;
  private reticleDisc: THREE.Mesh;
  private beamGroup = new THREE.Group();
  private ro: ResizeObserver;
  private statsTimer = 0;
  private lastPhysicsMs = 0;
  private fps = 60;
  private worker: Worker | null = null;
  private job = 0;
  private broken = false;
  private breakupT = -1;
  private eventCount = 0;
  private atmosphereDisturbance = 0;
  private tempDelta = 0;
  private currentDef: PlanetDef | null = null;
  // replay
  recording: { actions: ReplayAction[]; camera: ReplayCameraKey[] } = { actions: [], camera: [] };
  private replaying: Replay | null = null;
  private replayIdx = 0;
  private lastCamKey = -1;
  snapshots: Snapshot[] = [];
  currentSnapshot: string | null = null;
  toolId: ToolId = 'asteroid';
  toolParams: Record<string, number> = {};
  hover: ReturnType<Planet['pick']> = null;
  onDebug?: (d: DebugInfo) => void;
  onStats?: (s: PlanetStats) => void;
  onHover?: (h: ReturnType<Planet['pick']>) => void;
  disposed = false;

  constructor(container: HTMLElement, settings: Settings) {
    this.container = container;
    this.settings = settings;
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { antialias: true, powerPreference: 'high-performance' });
    if (!gl) throw new Error('WebGL2 is not available on this device/browser.');
    this.renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: true, powerPreference: 'high-performance' });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setClearColor(0x000000, 1);
    container.appendChild(canvas);
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); bus.emit('toast', { text: 'Graphics context lost - attempting recovery', kind: 'error' }); });
    canvas.addEventListener('webglcontextrestored', () => bus.emit('toast', { text: 'Graphics context restored' }));

    this.camera = new THREE.PerspectiveCamera(42, 1, 0.01, 3000);
    this.rig = new CameraRig(this.camera, canvas);
    this.rig.setView(0.9, 1.25, 3.4, true);
    this.rig.shakeIntensity = settings.cameraShake;
    this.rig.reducedMotion = settings.reducedMotion;
    this.rig.invertZoom = settings.invertZoom;

    this.space = new SpaceBackground(1337, '#2a1a4a', '#0c2440', settings.quality === 'performance' ? 0.5 : 1);
    this.scene.add(this.space.group);
    this.star = new StarObject(starForPlanet({ type: 'rocky' } as PlanetDef), 2.2);
    this.scene.add(this.star.group);
    this.sunLight = new THREE.DirectionalLight(0xffffff, 2.5);
    this.scene.add(this.sunLight);
    this.scene.add(new THREE.AmbientLight(0x223344, 0.15));
    this.placeStar();

    this.particles = new ParticleSystem(Math.floor(PARTICLE_CAP[settings.quality] * settings.particleScale));
    this.scene.add(this.particles.points);
    this.debris = new DebrisSystem(Math.floor(DEBRIS_CAP[settings.quality] * settings.particleScale));
    this.scene.add(this.debris.mesh);
    this.fragments = new DebrisSystem(64);
    this.scene.add(this.fragments.mesh);
    this.scene.add(this.beamGroup);

    // targeting reticle
    this.reticle = new THREE.Group();
    this.reticleRing = new THREE.Mesh(new THREE.RingGeometry(0.94, 1, 96), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthTest: false }));
    this.reticleDisc = new THREE.Mesh(new THREE.CircleGeometry(0.94, 64), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthTest: false }));
    const cross = new THREE.Mesh(new THREE.RingGeometry(0.02, 0.05, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, depthTest: false }));
    this.reticle.add(this.reticleRing, this.reticleDisc, cross);
    this.reticle.renderOrder = 20;
    this.reticle.visible = false;
    this.scene.add(this.reticle);

    this.post = new PostFX(this.renderer, this.scene, this.camera, settings.quality);
    this.post.enabled = settings.postProcessing;
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    this.resize();
    this.loop();
  }

  private placeStar() {
    this.star.group.position.copy(this.sunDir).multiplyScalar(90);
    this.sunLight.position.copy(this.sunDir).multiplyScalar(10);
  }

  resize() {
    const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1;
    const q = this.settings.quality;
    const pr = Math.min(window.devicePixelRatio || 1, q === 'cinematic' ? 2 : q === 'high' ? 1.75 : q === 'balanced' ? 1.5 : 1);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.post.setSize(w, h, pr);
    this.particles.setPixelRatio(pr);
    this.space.setPixelRatio(pr);
    this.planet?.setPixelRatio(pr);
  }

  applySettings(s: Settings) {
    const needsRebuild = s.quality !== this.settings.quality || s.particleScale !== this.settings.particleScale;
    this.settings = s;
    this.rig.shakeIntensity = s.cameraShake;
    this.rig.reducedMotion = s.reducedMotion;
    this.rig.invertZoom = s.invertZoom;
    this.post.enabled = s.postProcessing;
    this.post.setQuality(s.quality);
    this.planet?.setCloudShadows(s.shadows);
    this.planet?.setAccessibility(s.highContrast, s.reducedFlashing);
    this.resize();
    if (needsRebuild && this.currentDef) void this.loadPlanet(this.currentDef, undefined, true);
  }

  // ------------------------------------------------------------------ loading
  private generateField(def: PlanetDef, onProgress: (p: number) => void): Promise<HeightField> {
    const [w, h] = HEIGHT_RES[this.settings.quality];
    return new Promise((resolve) => {
      const job = ++this.job;
      const fallback = () => { try { resolve(generateHeightField(def, w, h, onProgress)); } catch (e) { console.error(e); resolve(generateHeightField(def, 512, 256)); } };
      try {
        if (!this.worker) this.worker = new TerrainWorker();
        const worker = this.worker;
        const handler = (e: MessageEvent) => {
          if (e.data.job !== job) return;
          if (e.data.progress !== undefined) onProgress(e.data.progress);
          if (e.data.done) { worker.removeEventListener('message', handler); resolve({ width: e.data.width, height: e.data.height, data: e.data.data, seaLevel: e.data.seaLevel }); }
          if (e.data.error) { worker.removeEventListener('message', handler); console.warn('worker failed', e.data.error); fallback(); }
        };
        worker.addEventListener('message', handler);
        worker.onerror = () => { worker.removeEventListener('message', handler); this.worker = null; fallback(); };
        worker.postMessage({ def, width: w, height: h, job });
      } catch (err) {
        console.warn('worker unavailable, generating on main thread', err);
        fallback();
      }
    });
  }

  async loadPlanet(def: PlanetDef, stage?: Stage, keepCamera = false) {
    stage?.('Initializing engine', 0.05);
    this.currentDef = def;
    const field = await this.generateField(def, (p) => stage?.('Building terrain', 0.1 + p * 0.55));
    if (this.disposed || this.currentDef !== def) return;
    stage?.('Generating planet', 0.7);
    this.clearAll();
    if (this.planet) { this.scene.remove(this.planet.root); this.planet.dispose(); }
    this.planet = new Planet(def, field, this.settings.quality, { cloudShadows: this.settings.shadows, highContrast: this.settings.highContrast, reducedFlashing: this.settings.reducedFlashing, linearFloat: this.renderer.extensions.has('OES_texture_float_linear') });
    this.scene.add(this.planet.root);
    stage?.('Initializing atmosphere', 0.82);
    // star for this world
    this.scene.remove(this.star.group); this.star.dispose();
    const sd = starForPlanet(def);
    this.star = new StarObject(sd, 2.2 * sd.radius ** 0.5);
    this.scene.add(this.star.group);
    this.placeStar();
    const sunColor = new THREE.Color(sd.color).lerp(new THREE.Color(1, 1, 1), 0.5);
    this.planet.setSun(this.sunDir, sunColor);
    this.debris.setSun(this.sunDir, sunColor);
    this.fragments.setSun(this.sunDir, sunColor);
    this.debris.setHotColor(this.planet.palette.mantle); this.fragments.setHotColor(this.planet.palette.mantle);
    const g = 0.25 * clamp(this.planet.gravity, 0.2, 3);
    this.debris.gravity = g; this.fragments.gravity = g; this.particles.setGravity(g * 0.6);
    this.debris.surfaceRadius = 1; this.fragments.surfaceRadius = 0.55; this.particles.setSurface(1 + this.planet.amp * 0.5);
    this.rig.minDist = 1 + this.planet.amp + 0.02;
    this.rig.maxDist = 40;
    if (!keepCamera) { this.rig.setView(0.9, 1.25, 3.4, true); this.rig.focusOn(new THREE.Vector3(0, 0, 0)); }
    stage?.('Initializing particles', 0.92);
    this.simTime = 0; this.broken = false; this.breakupT = -1; this.eventCount = 0; this.atmosphereDisturbance = 0; this.tempDelta = 0;
    this.recording = { actions: [], camera: [] }; this.lastCamKey = -1;
    this.snapshots = []; this.currentSnapshot = null;
    this.renderer.compile(this.scene, this.camera);
    stage?.('Ready', 1);
    simEvent('WORLD_CREATED', 0, `${def.name} generated (seed ${def.seed})`, { planet: def.id });
    this.pushStats();
  }

  /** Planet Lab: re-apply cheap params live, regenerate terrain when structural params change. */
  updateLiveParams(def: PlanetDef) { this.currentDef = def; this.planet?.applyLiveParams(def); }

  private clearAll() {
    this.effects.length = 0;
    this.attractors.clear(); this.distortions.clear();
    this.debris.attractors = []; this.fragments.attractors = [];
    this.particles.clear(); this.debris.clear(); this.fragments.clear();
    this.beamGroup.clear();
    this.post.setDistortions([]);
    this.star.setFlare(0);
  }

  // ------------------------------------------------------------------ simulation control
  setSpeed(s: number) { this.speed = s; }
  setPaused(p: boolean) { this.paused = p; }
  reset() {
    if (!this.planet) return;
    this.clearAll();
    this.planet.resetDamage();
    this.simTime = 0; this.broken = false; this.breakupT = -1; this.atmosphereDisturbance = 0; this.tempDelta = 0;
    this.recording = { actions: [], camera: [] }; this.lastCamKey = -1;
    this.replaying = null;
    simEvent('RESET', 0, 'World restored to original state');
    this.pushStats();
  }

  // ------------------------------------------------------------------ snapshots
  saveSnapshot(name?: string): Snapshot {
    const p = this.planet!;
    const snap: Snapshot = { id: `s${Date.now().toString(36)}${Math.floor(Math.random() * 1e4)}`, name: name ?? `Experiment ${String.fromCharCode(65 + (this.snapshots.length % 26))}`, parent: this.currentSnapshot, time: this.simTime, integrity: this.stats().integrity, removedVolume: p.removedVolume, damage: p.snapshotDamage(), broken: this.broken, createdAt: Date.now() };
    (snap as unknown as { debris: unknown }).debris = this.debris.serialize();
    if (this.snapshots.length >= 10) this.snapshots.shift();
    this.snapshots.push(snap);
    this.currentSnapshot = snap.id;
    simEvent('SNAPSHOT', this.simTime, `State saved: ${snap.name}`);
    return snap;
  }
  restoreSnapshot(id: string) {
    const s = this.snapshots.find((x) => x.id === id);
    if (!s || !this.planet) return;
    this.clearAll();
    this.planet.resetDamage();
    this.planet.restoreDamage(s.damage, s.removedVolume);
    this.simTime = s.time; this.broken = s.broken; this.breakupT = -1;
    if (s.broken) { this.planet.setBreak(1); }
    this.debris.deserialize(((s as unknown as { debris: ReturnType<DebrisSystem['serialize']> }).debris) ?? []);
    this.currentSnapshot = s.id;
    simEvent('SNAPSHOT', this.simTime, `State restored: ${s.name}`);
    this.pushStats();
  }
  duplicateSnapshot(id: string) {
    const s = this.snapshots.find((x) => x.id === id);
    if (!s) return;
    const c: Snapshot = { ...s, id: `s${Date.now().toString(36)}${Math.floor(Math.random() * 1e4)}`, name: s.name + ' copy', parent: s.id, damage: new Float32Array(s.damage), createdAt: Date.now() };
    (c as unknown as { debris: unknown }).debris = (s as unknown as { debris: unknown }).debris;
    this.snapshots.push(c);
  }
  deleteSnapshot(id: string) { this.snapshots = this.snapshots.filter((s) => s.id !== id); if (this.currentSnapshot === id) this.currentSnapshot = null; }

  // ------------------------------------------------------------------ replay
  buildReplay(name: string): Replay | null {
    if (!this.currentDef || this.recording.actions.length === 0) return null;
    return { id: `r${Date.now().toString(36)}`, name, planetId: this.currentDef.id, planet: this.currentDef, actions: [...this.recording.actions], camera: [...this.recording.camera], duration: this.simTime + 6, createdAt: Date.now() };
  }
  playReplay(r: Replay) {
    this.reset();
    this.replaying = r; this.replayIdx = 0;
    this.rig.mode = 'orbit';
    this.paused = false;
    simEvent('REPLAY', 0, `Replay started: ${r.name}`);
  }
  stopReplay() { this.replaying = null; }
  get isReplaying() { return !!this.replaying; }

  // ------------------------------------------------------------------ targeting
  pickScreen(x: number, y: number) {
    if (!this.planet) return null;
    const ndc = new THREE.Vector2((x / this.container.clientWidth) * 2 - 1, -(y / this.container.clientHeight) * 2 + 1);
    const rc = new THREE.Raycaster();
    rc.setFromCamera(ndc, this.camera);
    return this.planet.pick(rc.ray);
  }
  setHover(x: number | null, y: number | null) {
    if (x === null || y === null || !this.planet || this.broken) { this.hover = null; this.reticle.visible = false; this.onHover?.(null); return; }
    const h = this.pickScreen(x, y);
    this.hover = h;
    this.onHover?.(h);
    if (!h) { this.reticle.visible = false; return; }
    const tool = TOOL_BY_ID[this.toolId];
    const km = tool.previewRadius(this.toolParams);
    const ang = km > 0 ? clamp((km / this.planet.def.radius), 0.01, 1.3) : 0.015;
    const worldR = Math.sin(Math.min(ang, Math.PI / 2)) * h.surfaceR;
    this.reticle.visible = true;
    this.reticle.position.copy(h.point).addScaledVector(h.normal, 0.003);
    this.reticle.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), h.normal);
    this.reticle.scale.setScalar(Math.max(worldR, 0.004));
    (this.reticleRing.material as THREE.MeshBasicMaterial).color.set(tool.color);
    (this.reticleDisc.material as THREE.MeshBasicMaterial).color.set(tool.color);
  }

  // ------------------------------------------------------------------ tools
  trigger(toolId: ToolId, params: Record<string, number>, dirObj: THREE.Vector3, seed = Math.floor(Math.random() * 1e9), fromReplay = false) {
    if (!this.planet || this.broken) return;
    const tool = TOOL_BY_ID[toolId];
    const p = { ...Object.fromEntries(tool.params.map((x) => [x.key, x.default])), ...params };
    if (!fromReplay && !this.replaying) {
      const lat = Math.asin(clamp(dirObj.y, -1, 1)), lon = Math.atan2(dirObj.z, dirObj.x);
      this.recording.actions.push({ time: this.simTime, tool: toolId, params: p, lat, lon, seed });
    }
    this.eventCount++;
    simEvent('EVENT_TRIGGERED', this.simTime, `${tool.name} initiated`, { tool: toolId, params: p });
    bus.emit('audio', { cue: toolId === 'exotic-strike' ? 'charge' : 'whoosh', intensity: 0.5 });
    const rng = new RNG(seed);
    const planet = this.planet;
    const R = planet.def.radius;
    switch (toolId) {
      case 'asteroid': this.launchAsteroid(dirObj, p.size, p.speed, p.angle, rng); break;
      case 'meteor-swarm': {
        let launched = 0, acc = 0;
        const interval = p.duration / p.count;
        this.effects.push({ update: (dt) => { acc += dt; while (acc >= interval && launched < p.count) { acc -= interval; launched++; const d = this.randomDirNear(dirObj, THREE.MathUtils.degToRad(p.spread), rng); this.launchAsteroid(d, p.size * (0.5 + rng.next()), 25 + rng.next() * 30, rng.range(0, 50), rng, 0.6 + rng.next() * 0.6); } return launched >= p.count; } });
        break;
      }
      case 'energy-pulse': this.energyPulse(dirObj, clamp(p.radius / R, 0.005, 0.5), p.power, p.duration); break;
      case 'plasma-burst': this.plasmaBurst(dirObj, clamp(p.radius / R, 0.02, 1.2), p.power); break;
      case 'gravity-anomaly': this.gravityAnomaly(dirObj, clamp(p.radius / R, 0.04, 1.0), p.strength, p.duration, rng); break;
      case 'spatial-distortion': this.spatialDistortion(dirObj, clamp(p.radius / R, 0.05, 1.2), p.strength, p.duration); break;
      case 'stellar-flare': this.stellarFlare(p.power, p.duration, rng); break;
      case 'cosmic-shockwave': this.shockwave(dirObj, p.power, p.speed, THREE.MathUtils.degToRad(p.reach)); break;
      case 'matter-displacement': this.matterDisplacement(dirObj, clamp(p.radius / R, 0.008, 0.5), p.depth); break;
      case 'exotic-strike': this.exoticStrike(dirObj, clamp(p.size / R, 0.02, 1.2), p.power, p.charge, rng); break;
    }
  }

  private randomDirNear(dir: THREE.Vector3, spread: number, rng: RNG) {
    const t = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).cross(dir).normalize();
    const a = Math.sqrt(rng.next()) * spread;
    const rot = new THREE.Quaternion().setFromAxisAngle(t, a);
    const rot2 = new THREE.Quaternion().setFromAxisAngle(dir, rng.next() * Math.PI * 2);
    return dir.clone().applyQuaternion(rot).applyQuaternion(rot2).normalize();
  }

  /** Material response palette for a given surface hit. */
  private materialResponse(dirObj: THREE.Vector3) {
    const planet = this.planet!;
    const s = planet.surfaceAt(dirObj);
    const type = planet.def.type;
    const water = !planet.isGas && s.height < planet.field.seaLevel && s.damage < 0.002;
    const ice = type === 'ice' || (planet.def.iceCoverage > 0.4 && Math.abs(dirObj.y) > 0.6);
    let dust = planet.palette.highland.clone().lerp(new THREE.Color('#8a7a68'), 0.5);
    let rock = planet.palette.crust.clone().lerp(planet.palette.mountain, 0.4);
    let kind: 0 | 2 = 0; let steam = 0; let heat = 0.6; let debrisMul = 1; let brightness = 1;
    if (type === 'gas') { dust = planet.palette.highland.clone(); kind = 2; steam = 1; debrisMul = 0; heat = 0.3; }
    else if (water && type === 'lava') { dust = planet.palette.mantle.clone(); rock = planet.palette.mantle.clone(); heat = 1; }
    else if (water) { dust = new THREE.Color('#dfeaf2'); rock = planet.palette.crust.clone(); kind = 2; steam = 0.8; debrisMul = 0.4; heat = 0.2; }
    else if (ice) { dust = new THREE.Color('#eaf6ff'); rock = new THREE.Color('#d8ecff'); heat = 0.15; brightness = 1.4; debrisMul = 1.3; }
    else if (type === 'lava') { dust = planet.palette.mantle.clone().lerp(new THREE.Color('#3a2a22'), 0.4); rock = planet.palette.mantle.clone(); heat = 1; }
    else if (type === 'alien') { dust = planet.palette.shallow.clone(); rock = planet.palette.crust.clone().lerp(planet.palette.mountain, 0.5); heat = 0.7; }
    return { dust, rock, kind, steam, heat, debrisMul, brightness, water };
  }

  /**
   * The reusable destruction pipeline:
   * TARGET -> IMPACT -> ENERGY EFFECT -> TERRAIN DEFORMATION -> MATERIAL REMOVAL -> HEAT -> DEBRIS -> ATMOSPHERE -> STATE
   */
  impact(dirObj: THREE.Vector3, angR: number, depth: number, o: { profile?: 'crater' | 'bore' | 'flat'; fracture?: number; flash?: number; debrisSpeed?: number; label?: string; heat?: boolean; ejectDir?: THREE.Vector3; silent?: boolean; noDebris?: boolean }) {
    const planet = this.planet;
    if (!planet) return;
    const t = this.simTime;
    const mat = this.materialResponse(dirObj);
    const surf = planet.surfaceAt(dirObj);
    const point = planet.dirToWorld(dirObj, surf.r);
    const normal = dirObj.clone().transformDirection(planet.spin.matrixWorld);
    const removed = planet.applyDamage(dirObj, { angRadius: angR, depth, profile: o.profile ?? 'crater', time: t, heat: o.heat ?? true, fracture: o.fracture ?? clamp(depth * 6, 0, 1), rim: true });
    const energy = clamp(angR * 6 + depth * 4, 0.05, 4);
    const flash = (o.flash ?? 1) * energy;
    const ejectDir = o.ejectDir ?? normal;
    const pscale = this.settings.particleScale;
    // energy flash
    if (!mat.water || planet.def.type === 'lava') this.particles.burst(point, normal, Math.floor(40 * flash * pscale + 10), t, { speed: 0.25 * energy, spread: 1.2, life: 0.9, size: 0.05 * energy, color: mat.heat > 0.5 ? planet.palette.mantle.clone().lerp(new THREE.Color(1, 1, 0.9), 0.4) : new THREE.Color('#fff2d0'), kind: 1 });
    // dust / steam plume
    this.particles.burst(point, ejectDir, Math.floor(160 * energy * pscale + 30), t, { speed: 0.18 * energy + 0.05, spread: 0.9, life: 8 + energy * 8, size: 0.09 * energy + 0.02, color: mat.dust.multiplyScalar(mat.brightness), kind: mat.kind, colorJitter: 0.25 });
    if (mat.steam > 0) this.particles.burst(point, normal, Math.floor(120 * energy * pscale * mat.steam), t, { speed: 0.12 * energy, spread: 1.4, life: 12, size: 0.14 * energy, color: new THREE.Color('#e9f2f6'), kind: 2 });
    // solid debris (instanced, physically integrated)
    let debrisN = 0;
    if (!o.noDebris && mat.debrisMul > 0) {
      debrisN = Math.floor(clamp(20 + angR * 700, 20, 420) * mat.debrisMul * pscale);
      const esc = Math.sqrt((2 * this.debris.gravity) / 1);
      this.debris.eject(point, ejectDir, debrisN, (o.debrisSpeed ?? 0.75) * esc * (0.6 + energy * 0.25), 0.004 + angR * 0.03, mat.heat * clamp(depth * 12, 0.2, 1), mat.rock, 0.5);
      // deep impacts also throw molten mantle
      if (depth > 0.05) this.debris.eject(point, ejectDir, Math.floor(debrisN * 0.35), esc * 0.9, 0.004 + angR * 0.02, 1, planet.palette.mantle, 0.6);
    }
    // atmosphere
    if (planet.def.atmosphereDensity > 0.05) { planet.addPlume(dirObj, energy * 0.6, t); this.atmosphereDisturbance = clamp(this.atmosphereDisturbance + energy * 0.08, 0, 1); }
    if (planet.def.hasRings && angR > 0.15) planet.disruptRings(dirObj, energy * 0.3);
    this.tempDelta += energy * 2.5;
    // camera + audio
    const camDir = this.camera.position.clone().sub(point).normalize();
    this.rig.shake(clamp(energy * 0.6, 0.1, 2.5), 0.5 + energy * 0.3, new THREE.Vector3(camDir.x, 0.5, 0));
    if (!o.silent) bus.emit('audio', { cue: 'impact', intensity: clamp(energy / 2.5, 0.1, 1) });
    // events
    const label = o.label ?? 'Impact';
    simEvent('PLANET_IMPACT', t, `${label} at ${this.fmtLatLon(dirObj)}`, { lat: surf.lat, lon: surf.lon, radius: angR, depth, intensity: energy });
    simEvent('TERRAIN_DAMAGED', t, `${(angR * planet.def.radius * 2).toFixed(0)} km ${o.profile === 'bore' ? 'bore' : 'crater'} · ${(depth * planet.def.radius).toFixed(0)} km deep`, { removed });
    if (debrisN > 0) simEvent('DEBRIS_GENERATED', t, `${debrisN} fragments ejected`, { count: debrisN });
    if (planet.def.atmosphereDensity > 0.05 && energy > 0.6) simEvent('ATMOSPHERE_DISTURBED', t, `Atmospheric plume, ${Math.round(energy * 40)}% local disturbance`);
    this.checkIntegrity();
    this.pushStats();
  }

  fmtLatLon(dir: THREE.Vector3) {
    const lat = THREE.MathUtils.radToDeg(Math.asin(clamp(dir.y, -1, 1)));
    const lon = THREE.MathUtils.radToDeg(Math.atan2(dir.z, dir.x));
    return `${Math.abs(lat).toFixed(1)}°${lat >= 0 ? 'N' : 'S'} ${Math.abs(lon).toFixed(1)}°${lon >= 0 ? 'E' : 'W'}`;
  }

  private launchAsteroid(dirObj: THREE.Vector3, sizeKm: number, speed: number, angleDeg: number, rng: RNG, scale = 1) {
    const planet = this.planet!;
    const angR = craterAngle(sizeKm, planet.def.radius, 0.7 + speed / 60);
    const depth = clamp(angR * 0.42 * (0.55 + speed / 70) * (1 - angleDeg / 160), 0.003, 0.9);
    const size = clamp(angR * 0.28, 0.006, 0.25) * scale;
    // approach direction: tilt from the surface normal by the approach angle, random azimuth
    const normalW = dirObj.clone().transformDirection(planet.spin.matrixWorld);
    const tangent = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).cross(normalW).normalize();
    const approach = normalW.clone().multiplyScalar(Math.cos(THREE.MathUtils.degToRad(angleDeg))).addScaledVector(tangent, Math.sin(THREE.MathUtils.degToRad(angleDeg))).normalize();
    const startDist = 7;
    const geo = new THREE.IcosahedronGeometry(size, 2);
    const pa = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pa.count; i++) { const k = 0.75 + rng.next() * 0.5; pa.setXYZ(i, pa.getX(i) * k, pa.getY(i) * k, pa.getZ(i) * k); }
    geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ color: 0x6b5a4a, roughness: 0.95, emissive: new THREE.Color(0xff5a10), emissiveIntensity: 0 });
    const mesh = new THREE.Mesh(geo, mat);
    this.scene.add(mesh);
    const travel = (startDist - 1) / (0.8 + speed / 25);
    let tt = 0;
    const spin = new THREE.Vector3(rng.next(), rng.next(), rng.next());
    const responseCol = this.materialResponse(dirObj);
    this.effects.push({
      update: (dt, t) => {
        tt += dt;
        const surf = planet.surfaceAt(dirObj);
        const target = planet.dirToWorld(dirObj, surf.r);
        const k = clamp(tt / travel, 0, 1);
        const d = startDist - (startDist - surf.r) * k;
        mesh.position.copy(target).addScaledVector(approach, d - surf.r);
        mesh.rotation.x += spin.x * dt * 2; mesh.rotation.y += spin.y * dt * 2;
        const alt = d - 1;
        const heat = clamp(1 - alt / (0.25 + planet.def.atmosphereDensity * 0.3), 0, 1) * (0.3 + planet.def.atmosphereDensity);
        mat.emissiveIntensity = heat * 3;
        if (heat > 0.05 && dt > 0) this.particles.burst(mesh.position, approach, Math.ceil(6 * this.settings.particleScale), t, { speed: 0.15, spread: 0.4, life: 1.6, size: size * 3, color: new THREE.Color('#ffb070'), kind: 1 });
        if (dt > 0 && k > 0.2) this.particles.burst(mesh.position, approach, 2, t, { speed: 0.05, spread: 0.6, life: 4, size: size * 2.5, color: new THREE.Color('#9a8a7a'), kind: 2 });
        if (k >= 1) {
          this.scene.remove(mesh); geo.dispose(); mat.dispose();
          this.impact(dirObj, angR, depth, { label: `Asteroid (${sizeKm.toFixed(0)} km)`, ejectDir: approach.clone().multiplyScalar(-0.6).add(dirObj.clone().transformDirection(planet.spin.matrixWorld)).normalize(), flash: 1 + speed / 60 });
          void responseCol;
          return true;
        }
        return false;
      },
    });
  }

  private makeBeam(color: THREE.ColorRepresentation, radius: number) {
    const g = new THREE.CylinderGeometry(radius, radius * 0.6, 8, 24, 1, true);
    g.translate(0, 4, 0);
    const m = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(g, m);
    this.beamGroup.add(mesh);
    return { mesh, m, g, remove: () => { this.beamGroup.remove(mesh); g.dispose(); m.dispose(); } };
  }

  private energyPulse(dirObj: THREE.Vector3, angR: number, power: number, duration: number) {
    const planet = this.planet!;
    const beam = this.makeBeam(0x7fd7ff, Math.sin(angR) * 0.9);
    let tt = 0, acc = 0, depth = 0;
    const rate = 0.04 + power * 0.14; // planet radii per second of boring
    this.effects.push({
      update: (dt, t) => {
        tt += dt; acc += dt;
        const surf = planet.surfaceAt(dirObj);
        const normalW = dirObj.clone().transformDirection(planet.spin.matrixWorld);
        beam.mesh.position.copy(planet.dirToWorld(dirObj, surf.r));
        beam.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normalW);
        beam.m.opacity = 0.35 + 0.25 * Math.sin(t * 40) + (tt < 0.3 ? tt / 0.3 - 1 : 0);
        depth = Math.min(depth + rate * dt, 0.95);
        if (acc > 0.12 && dt > 0) {
          acc = 0;
          planet.applyDamage(dirObj, { angRadius: angR, depth, profile: 'bore', time: t, fracture: clamp(depth * 3, 0, 0.8), rim: false });
          const p = planet.dirToWorld(dirObj, surf.r);
          const mat = this.materialResponse(dirObj);
          this.particles.burst(p, normalW, Math.ceil(30 * this.settings.particleScale), t, { speed: 0.25 + depth * 0.4, spread: 0.6, life: 1.2, size: 0.03, color: depth > 0.05 ? planet.palette.mantle : new THREE.Color('#bfe8ff'), kind: 1 });
          this.particles.burst(p, normalW, Math.ceil(25 * this.settings.particleScale), t, { speed: 0.08, spread: 1.2, life: 6, size: 0.08, color: mat.dust, kind: mat.kind });
          if (depth > 0.03 && mat.debrisMul > 0) this.debris.eject(p, normalW, 6, 0.55, 0.006 + angR * 0.02, 1, planet.palette.mantle, 0.4);
          this.rig.shake(0.15 + power * 0.2, 0.2);
          planet.addPlume(dirObj, 0.4, t);
        }
        if (tt >= duration) {
          beam.remove();
          this.impact(dirObj, angR * 1.15, depth, { profile: 'bore', label: 'Energy pulse bore', flash: 0.6, debrisSpeed: 0.9, fracture: clamp(depth * 2, 0.2, 1) });
          return true;
        }
        return false;
      },
    });
    bus.emit('audio', { cue: 'charge', intensity: power });
  }

  private plasmaBurst(dirObj: THREE.Vector3, angR: number, power: number) {
    const planet = this.planet!;
    const surf = planet.surfaceAt(dirObj);
    const point = planet.dirToWorld(dirObj, surf.r);
    const sphereM = new THREE.MeshBasicMaterial({ color: 0xff9a5a, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), sphereM);
    sphere.position.copy(point);
    this.scene.add(sphere);
    const maxR = Math.sin(angR) * 1.4;
    let tt = 0;
    this.effects.push({ update: (dt) => { tt += dt; const k = clamp(tt / 0.7, 0, 1); sphere.scale.setScalar(0.01 + maxR * Math.sqrt(k)); sphereM.opacity = 0.8 * (1 - k); if (k >= 1) { this.scene.remove(sphere); sphere.geometry.dispose(); sphereM.dispose(); return true; } return false; } });
    this.impact(dirObj, angR, 0.012 + power * 0.06, { profile: 'flat', fracture: 0.5 + power * 0.5, flash: 2 * power + 0.5, debrisSpeed: 1.1, label: 'Plasma burst' });
    planet.glowAtmosphere(power * 0.8);
  }

  private gravityAnomaly(dirObj: THREE.Vector3, angR: number, strength: number, duration: number, rng: RNG) {
    const planet = this.planet!;
    const id = `g${Date.now()}${rng.int(0, 999)}`;
    const height = 0.35 + angR * 0.5;
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.03 + angR * 0.08, 32, 24), new THREE.MeshBasicMaterial({ color: 0x000000 }));
    const rimM = new THREE.ShaderMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide, uniforms: { uColor: { value: new THREE.Color('#b48cff') }, uT: { value: 0 } }, vertexShader: 'varying vec3 vN; varying vec3 vW; void main(){ vN = normalize(mat3(modelMatrix)*normal); vec4 wp = modelMatrix*vec4(position,1.0); vW = wp.xyz; gl_Position = projectionMatrix*viewMatrix*wp; }', fragmentShader: 'uniform vec3 uColor; uniform float uT; varying vec3 vN; varying vec3 vW; void main(){ vec3 V = normalize(cameraPosition - vW); float f = pow(1.0 - abs(dot(normalize(vN), V)), 2.5); gl_FragColor = vec4(uColor * f * (1.5 + 0.5*sin(uT*6.0)), f); }' });
    const rim = new THREE.Mesh(new THREE.SphereGeometry(0.05 + angR * 0.13, 32, 24), rimM);
    const grp = new THREE.Group(); grp.add(core, rim); this.scene.add(grp);
    const pos = new THREE.Vector3();
    let tt = 0, acc = 0;
    const att = { pos, strength: strength * 0.25, radius: angR };
    this.attractors.set(id, att);
    this.distortions.set(id, { world: pos, strength: strength * 0.9, radius: 0.12 + angR * 0.25 });
    this.rebuildAttractors();
    const upliftMax = -(0.008 + strength * 0.03);
    this.effects.push({
      update: (dt, t) => {
        tt += dt; acc += dt;
        const surf = planet.surfaceAt(dirObj);
        pos.copy(planet.dirToWorld(dirObj, surf.r + height));
        grp.position.copy(pos);
        rimM.uniforms.uT.value = t;
        const k = clamp(tt / duration, 0, 1);
        const normalW = dirObj.clone().transformDirection(planet.spin.matrixWorld);
        if (acc > 0.15 && dt > 0) {
          acc = 0;
          // crust is drawn upward progressively
          planet.applyDamage(dirObj, { angRadius: angR, depth: upliftMax * Math.min(1, tt / (duration * 0.6)), profile: 'uplift', time: t, heat: false, fracture: strength * 0.6 * k, rim: false });
          // dust streams lifted from the surface toward the anomaly
          const mat = this.materialResponse(dirObj);
          for (let i = 0; i < 6; i++) {
            const d = this.randomDirNear(dirObj, angR, rng);
            const sp = planet.dirToWorld(d, planet.surfaceAt(d).r + 0.003);
            const toA = pos.clone().sub(sp).normalize();
            this.particles.burst(sp, toA, Math.ceil(8 * this.settings.particleScale), t, { speed: 0.25 + strength * 0.3, spread: 0.15, life: 3, size: 0.05, color: mat.dust, kind: mat.kind });
          }
          if (mat.debrisMul > 0) { const sp = planet.dirToWorld(this.randomDirNear(dirObj, angR * 0.8, rng), surf.r + 0.002); this.debris.eject(sp, normalW, 3, 0.35 + strength * 0.4, 0.008 + angR * 0.015, 0.1, mat.rock, 0.2); }
          planet.disruptRings(dirObj, strength * 0.05);
          this.rig.shake(0.08 + strength * 0.1, 0.3);
        }
        if (k >= 1) {
          this.scene.remove(grp); core.geometry.dispose(); rim.geometry.dispose(); rimM.dispose();
          this.attractors.delete(id); this.distortions.delete(id); this.rebuildAttractors();
          // collapse: uplifted crust slams back and shatters
          this.impact(dirObj, angR * 1.05, 0.02 + strength * 0.08, { profile: 'flat', fracture: 0.6 + strength * 0.4, label: 'Gravitational collapse', debrisSpeed: 1.0, flash: 1.2 });
          return true;
        }
        return false;
      },
    });
  }

  private rebuildAttractors() {
    const list = [...this.attractors.values()];
    this.debris.attractors = list; this.fragments.attractors = list;
  }

  private spatialDistortion(dirObj: THREE.Vector3, angR: number, strength: number, duration: number) {
    const planet = this.planet!;
    const id = `d${Date.now()}`;
    const pos = new THREE.Vector3();
    this.distortions.set(id, { world: pos, strength: 0, radius: 0.15 + angR * 0.3 });
    let tt = 0, acc = 0, wave = 0;
    const att = { pos, strength: 0, radius: angR };
    this.attractors.set(id, att); this.rebuildAttractors();
    this.effects.push({
      update: (dt, t) => {
        tt += dt; acc += dt;
        const surf = planet.surfaceAt(dirObj);
        pos.copy(planet.dirToWorld(dirObj, surf.r + 0.15));
        const k = tt / duration;
        const env = Math.sin(Math.PI * clamp(k, 0, 1));
        const d = this.distortions.get(id)!; d.strength = strength * env * (0.7 + 0.3 * Math.sin(t * 9));
        att.strength = Math.sin(t * 5) * strength * 0.15 * env; // push/pull pulses on debris
        if (acc > 0.18 && dt > 0) {
          acc = 0; wave++;
          // concentric terrain ripples: alternating uplift / depression rings marching outward
          const r = (wave * 0.18 * 0.25 * angR * 4) % (angR * 1.2);
          planet.applyDamage(dirObj, { angRadius: Math.max(r, 0.01), depth: (wave % 2 ? 1 : -1) * 0.006 * strength, profile: 'ring', ringWidth: angR * 0.12, time: t, heat: false, fracture: strength * 0.25 });
          const mat = this.materialResponse(dirObj);
          const p = planet.dirToWorld(dirObj, surf.r);
          this.particles.burst(p, dirObj.clone().transformDirection(planet.spin.matrixWorld), Math.ceil(20 * this.settings.particleScale), t, { speed: 0.2, spread: 2.5, life: 3, size: 0.06, color: new THREE.Color('#8fffe0').lerp(mat.dust, 0.5), kind: 1 });
          this.rig.shake(0.1 * strength, 0.25);
        }
        if (k >= 1) { this.distortions.delete(id); this.attractors.delete(id); this.rebuildAttractors(); simEvent('TERRAIN_DAMAGED', t, 'Spatial distortion left rippled terrain'); this.pushStats(); return true; }
        return false;
      },
    });
  }

  private stellarFlare(power: number, duration: number, rng: RNG) {
    const planet = this.planet!;
    let tt = 0, acc = 0;
    const startPos = this.star.group.position.clone();
    this.effects.push({
      update: (dt, t) => {
        tt += dt; acc += dt;
        const k = clamp(tt / duration, 0, 1);
        const env = Math.sin(Math.PI * k);
        this.star.setFlare(env * power * 1.5);
        planet.glowAtmosphere(env * power * 1.2);
        if (dt > 0) {
          // stream of stellar particles racing toward the planet
          for (let i = 0; i < 6 * this.settings.particleScale; i++) {
            const off = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).multiplyScalar(3);
            const from = startPos.clone().multiplyScalar(0.15).add(off);
            const v = from.clone().negate().normalize().multiplyScalar(6 + rng.next() * 4);
            this.particles.emit(from, v, t, 2.2, 0.08, new THREE.Color(this.star.def.glow), 1);
          }
        }
        if (acc > 0.25 && dt > 0) {
          acc = 0;
          const sub = planet.worldToDir(this.sunDir.clone());
          planet.applyDamage(sub, { angRadius: 1.25, depth: 0.0015 * power, profile: 'flat', time: t, fracture: 0, rim: false });
          const d = this.randomDirNear(sub, 1.0, rng);
          const s = planet.surfaceAt(d);
          const p = planet.dirToWorld(d, s.r);
          const mat = this.materialResponse(d);
          this.particles.burst(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.ceil(30 * this.settings.particleScale), t, { speed: 0.12, spread: 0.8, life: 8, size: 0.1, color: mat.water ? new THREE.Color('#e8f0f4') : mat.dust, kind: 2 });
          this.tempDelta += power * 6 * 0.25;
          this.atmosphereDisturbance = clamp(this.atmosphereDisturbance + power * 0.03, 0, 1);
        }
        if (k >= 1) { this.star.setFlare(0); simEvent('ATMOSPHERE_DISTURBED', t, `Stellar flare scorched the day side (+${Math.round(power * 6 * duration / 4)} K)`); this.pushStats(); return true; }
        return false;
      },
    });
    simEvent('EVENT_TRIGGERED', this.simTime, 'Stellar flare ejected toward planet');
    bus.emit('audio', { cue: 'rumble', intensity: power });
  }

  private shockwave(dirObj: THREE.Vector3, power: number, speed: number, reach: number) {
    const planet = this.planet!;
    let r = 0.02, acc = 0;
    const vel = 0.35 * speed;
    const width = 0.04 + power * 0.04;
    this.impact(dirObj, 0.04 + power * 0.06, 0.02 + power * 0.05, { label: 'Shockwave origin', flash: 1.5, fracture: 1 });
    const rng = new RNG(Math.floor(r * 1e6) + 7);
    this.effects.push({
      update: (dt, t) => {
        r += vel * dt; acc += dt;
        planet.setShock(dirObj, r, width);
        if (acc > 0.1 && dt > 0) {
          acc = 0;
          planet.applyDamage(dirObj, { angRadius: r, depth: 0.004 + power * 0.012, profile: 'ring', ringWidth: width * 0.9, time: t, fracture: 0.4 + power * 0.6 });
          // dust bursts along the front
          const axis = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).cross(dirObj).normalize();
          for (let i = 0; i < 4; i++) {
            const q = new THREE.Quaternion().setFromAxisAngle(dirObj, rng.next() * Math.PI * 2);
            const d = dirObj.clone().applyAxisAngle(axis, r).applyQuaternion(q).normalize();
            const s = planet.surfaceAt(d);
            const p = planet.dirToWorld(d, s.r);
            const mat = this.materialResponse(d);
            this.particles.burst(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.ceil(14 * this.settings.particleScale), t, { speed: 0.12 + power * 0.1, spread: 0.7, life: 6, size: 0.08, color: mat.dust, kind: mat.kind });
            if (mat.debrisMul > 0 && rng.next() < 0.5) this.debris.eject(p, d.clone().transformDirection(planet.spin.matrixWorld), 3, 0.4, 0.006, 0.4, mat.rock, 0.5);
          }
          this.rig.shake(0.12 * power, 0.2);
          planet.addPlume(dirObj, 0.3 * power, t);
        }
        if (r >= reach) { planet.setShock(null, 0, 0); simEvent('TERRAIN_DAMAGED', t, `Shockwave dissipated after ${Math.round(THREE.MathUtils.radToDeg(reach))}°`); this.checkIntegrity(); this.pushStats(); return true; }
        return false;
      },
    });
  }

  private matterDisplacement(dirObj: THREE.Vector3, angR: number, depth: number) {
    const planet = this.planet!;
    const surf = planet.surfaceAt(dirObj);
    const p = planet.dirToWorld(dirObj, surf.r);
    const t = this.simTime;
    // implosion: particles rush inward
    for (let i = 0; i < 200 * this.settings.particleScale; i++) {
      const off = new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiplyScalar(0.05 + Math.random() * Math.sin(angR) * 2);
      const from = p.clone().add(off);
      this.particles.emit(from, off.clone().negate().multiplyScalar(4), t, 0.8, 0.04, new THREE.Color('#ff6ad5'), 1);
    }
    this.impact(dirObj, angR, Math.min(depth, 0.95), { profile: 'bore', heat: false, fracture: 0.25, flash: 0.4, debrisSpeed: 0.3, label: 'Matter displacement', noDebris: true });
    if (depth > 1) {
      const anti = dirObj.clone().negate();
      this.impact(anti, angR, Math.min(depth - 1 + 0.15, 0.95), { profile: 'bore', heat: true, fracture: 0.5, flash: 1.5, debrisSpeed: 1.4, label: 'Exit bore', ejectDir: anti.clone().transformDirection(planet.spin.matrixWorld) });
    }
  }

  private exoticStrike(dirObj: THREE.Vector3, angR: number, power: number, charge: number, rng: RNG) {
    const planet = this.planet!;
    const orbM = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    const orb = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), orbM);
    this.scene.add(orb);
    let tt = 0;
    const height = 0.6;
    this.effects.push({
      update: (dt, t) => {
        tt += dt;
        const surf = planet.surfaceAt(dirObj);
        const pos = planet.dirToWorld(dirObj, surf.r + height);
        orb.position.copy(pos);
        const k = clamp(tt / charge, 0, 1);
        orb.scale.setScalar(0.01 + k * 0.08 * (1 + power));
        if (dt > 0) for (let i = 0; i < 5; i++) { const off = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).normalize().multiplyScalar(0.3 + rng.next() * 0.5); this.particles.emit(pos.clone().add(off), off.clone().negate().multiplyScalar(1.6), t, 0.6, 0.03, new THREE.Color('#dff6ff'), 1); }
        if (k >= 1) {
          this.scene.remove(orb); orb.geometry.dispose(); orbM.dispose();
          const beam = this.makeBeam(0xffffff, Math.sin(angR) * 0.5);
          let bt = 0;
          this.effects.push({ update: (dt2) => { bt += dt2; const s = planet.surfaceAt(dirObj); beam.mesh.position.copy(planet.dirToWorld(dirObj, s.r)); beam.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dirObj.clone().transformDirection(planet.spin.matrixWorld)); beam.m.opacity = 0.9 * (1 - bt / 0.6); if (bt > 0.6) { beam.remove(); return true; } return false; } });
          this.impact(dirObj, angR, 0.12 + power * 0.55, { profile: 'crater', fracture: 1, flash: 3, debrisSpeed: 1.3, label: 'Exotic-energy strike' });
          planet.glowAtmosphere(1);
          if (power >= 0.85) this.startBreakup();
          bus.emit('audio', { cue: 'fracture', intensity: 1 });
          return true;
        }
        return false;
      },
    });
  }

  // ------------------------------------------------------------------ integrity + breakup
  private integrityValue() {
    const p = this.planet!;
    return clamp(1 - p.removedVolume / INTEGRITY_BUDGET - p.fractureTotal * 0.12, 0, 1);
  }
  private checkIntegrity() { if (!this.broken && this.integrityValue() <= 0) this.startBreakup(); }

  /** Cinematic planetary breakup: destabilisation -> global fractures -> crust fragmentation -> molten core exposed. */
  startBreakup() {
    if (this.broken || !this.planet) return;
    this.broken = true;
    this.breakupT = 0;
    this.reticle.visible = false;
    const planet = this.planet;
    simEvent('BODY_FRAGMENTED', this.simTime, `${planet.def.name} has lost structural integrity - fragmentation imminent`);
    bus.emit('audio', { cue: 'breakup', intensity: 1 });
    let spawned = false, acc = 0;
    const rng = new RNG(planet.def.seed + 42);
    this.effects.push({
      update: (dt, t) => {
        this.breakupT += dt; acc += dt;
        const bt = this.breakupT;
        const stage1 = clamp(bt / 2.5, 0, 1); // destabilisation
        const stage2 = clamp((bt - 2.5) / 2.5, 0, 1); // fragmentation
        planet.setBreak(stage1 * 0.3 + stage2 * 0.7);
        this.rig.shake(0.4 + stage1 * 0.6, 0.4);
        if (acc > 0.2 && dt > 0 && bt < 2.5) {
          acc = 0;
          for (let i = 0; i < 3; i++) {
            const d = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).normalize();
            planet.applyDamage(d, { angRadius: 0.15 + rng.next() * 0.2, depth: 0.05, profile: 'flat', time: t, fracture: 1 });
            const s = planet.surfaceAt(d);
            const p = planet.dirToWorld(d, s.r);
            this.particles.burst(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.ceil(60 * this.settings.particleScale), t, { speed: 0.3, spread: 0.7, life: 10, size: 0.12, color: planet.palette.mantle, kind: 1 });
          }
        }
        if (!spawned && bt >= 2.5) {
          spawned = true;
          // crust shatters into large simulated fragments
          const n = 44;
          for (let i = 0; i < n; i++) {
            const u = rng.next() * 2 - 1, th = rng.next() * Math.PI * 2, s = Math.sqrt(1 - u * u);
            const d = new THREE.Vector3(s * Math.cos(th), u, s * Math.sin(th));
            const pw = planet.dirToWorld(d, 0.85);
            const tangent = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).cross(d).normalize();
            const v = d.clone().transformDirection(planet.spin.matrixWorld).multiplyScalar(0.25 + rng.next() * 0.55).addScaledVector(tangent, 0.3 + rng.next() * 0.4);
            const tint = rng.next() < 0.35 ? planet.palette.mantle.clone() : planet.palette.crust.clone().lerp(planet.palette.mountain, rng.next());
            this.fragments.spawn(pw, v, 0.12 + rng.next() * 0.22, 0.8 + rng.next() * 0.2, tint, 1e9);
          }
          for (let i = 0; i < 12; i++) {
            const d = new THREE.Vector3(rng.next() - 0.5, rng.next() - 0.5, rng.next() - 0.5).normalize();
            const p = planet.dirToWorld(d, 1);
            this.debris.eject(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.floor(60 * this.settings.particleScale), 0.6, 0.02, 1, planet.palette.mantle, 0.8);
            this.particles.burst(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.floor(400 * this.settings.particleScale), t, { speed: 0.45, spread: 1.2, life: 25, size: 0.25, color: planet.palette.crust.clone().lerp(new THREE.Color('#aa9988'), 0.5), kind: 0 });
            this.particles.burst(p, d.clone().transformDirection(planet.spin.matrixWorld), Math.floor(150 * this.settings.particleScale), t, { speed: 0.6, spread: 1.5, life: 4, size: 0.12, color: planet.palette.mantle, kind: 1 });
          }
          this.rig.shake(3, 2);
          bus.emit('audio', { cue: 'collision', intensity: 1 });
          simEvent('BODY_FRAGMENTED', t, `Crust fragmented into ${n} major pieces · molten core exposed`, { fragments: n });
          simEvent('DEBRIS_GENERATED', t, `Debris cloud formed (${this.debris.count} tracked fragments)`);
          this.pushStats();
        }
        return bt > 5.2;
      },
    });
  }

  // ------------------------------------------------------------------ stats
  stats(): PlanetStats {
    const p = this.planet;
    if (!p) return { integrity: 1, removedVolume: 0, atmosphereDisturbance: 0, debrisCount: 0, interiorExposure: 0, surfaceTemperature: 0, fragmentation: 0, broken: false, events: 0 };
    return {
      integrity: this.broken ? 0 : this.integrityValue(),
      removedVolume: p.removedVolume,
      atmosphereDisturbance: this.atmosphereDisturbance,
      debrisCount: this.debris.count + this.fragments.count,
      interiorExposure: this.broken ? 1 : p.interiorExposure(),
      surfaceTemperature: p.def.temperature + this.tempDelta,
      fragmentation: this.broken ? 1 : clamp(p.fractureTotal * 0.3, 0, 1),
      broken: this.broken,
      events: this.eventCount,
    };
  }
  private pushStats() { this.onStats?.(this.stats()); }

  /** Snapshot of queryable engine state (AI / debugging hook). */
  getState() {
    return { planet: this.currentDef, simTime: this.simTime, speed: this.speed, paused: this.paused, stats: this.stats(), camera: this.rig.getView(), tool: this.toolId, toolParams: this.toolParams, snapshots: this.snapshots.map((s) => ({ id: s.id, name: s.name, parent: s.parent, time: s.time, integrity: s.integrity })), recordingActions: this.recording.actions.length };
  }

  // ------------------------------------------------------------------ main loop
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const wallDt = Math.min((now - this.lastWall) / 1000, 0.1);
    this.lastWall = now;
    this.wallTime += wallDt;
    this.fps = this.fps * 0.95 + (1 / Math.max(wallDt, 1e-3)) * 0.05;
    const simDt = this.paused ? 0 : wallDt * this.speed;
    const t0 = performance.now();

    if (simDt > 0) {
      this.simTime += simDt;
      // effects run in sub-steps so high speeds stay stable
      const sub = Math.min(Math.ceil(simDt / 0.05), 60);
      const h = simDt / sub;
      for (let s = 0; s < sub; s++) {
        const tNow = this.simTime - simDt + h * (s + 1);
        for (let i = this.effects.length - 1; i >= 0; i--) if (this.effects[i].update(h, tNow)) this.effects.splice(i, 1);
        this.debris.step(h);
        this.fragments.step(h);
      }
      if (this.fragments.count > 1) {
        const hits = this.fragments.collide();
        for (const hpt of hits.slice(0, 6)) this.particles.burst(hpt, new THREE.Vector3(0, 1, 0), Math.ceil(12 * this.settings.particleScale), this.simTime, { speed: 0.2, spread: 2, life: 1.5, size: 0.04, color: this.planet?.palette.mantle ?? new THREE.Color(1, 0.5, 0.2), kind: 1 });
      }
      this.tempDelta = Math.max(0, this.tempDelta - simDt * 0.4);
      this.atmosphereDisturbance = Math.max(0, this.atmosphereDisturbance - simDt * 0.004);
      // replay playback
      if (this.replaying) {
        const r = this.replaying;
        while (this.replayIdx < r.actions.length && r.actions[this.replayIdx].time <= this.simTime) {
          const a = r.actions[this.replayIdx++];
          const d = new THREE.Vector3(Math.cos(a.lat) * Math.cos(a.lon), Math.sin(a.lat), Math.cos(a.lat) * Math.sin(a.lon));
          this.trigger(a.tool, a.params, d, a.seed, true);
        }
        // camera keyframes
        const keys = r.camera;
        if (keys.length > 1) {
          let k = 0;
          while (k < keys.length - 2 && keys[k + 1].time < this.simTime) k++;
          const a = keys[k], b = keys[Math.min(k + 1, keys.length - 1)];
          const f = b.time > a.time ? clamp((this.simTime - a.time) / (b.time - a.time), 0, 1) : 0;
          this.rig.setView(a.theta + (b.theta - a.theta) * f, a.phi + (b.phi - a.phi) * f, a.dist + (b.dist - a.dist) * f);
        }
        if (this.simTime > r.duration) { this.replaying = null; simEvent('REPLAY', this.simTime, 'Replay finished'); }
      } else if (this.simTime - this.lastCamKey >= 0.5) {
        this.lastCamKey = this.simTime;
        const v = this.rig.getView();
        this.recording.camera.push({ time: this.simTime, ...v });
        if (this.recording.camera.length > 4000) this.recording.camera.shift();
      }
    }
    this.planet?.update(simDt, this.simTime);
    this.particles.update(this.simTime);
    this.debris.sync();
    this.fragments.sync();
    this.lastPhysicsMs = performance.now() - t0;

    this.rig.update(wallDt, this.wallTime);
    this.space.update(this.wallTime);
    this.star.update(this.wallTime);
    // spatial distortion sources -> screen space
    const ds: DistortionSource[] = [];
    for (const d of this.distortions.values()) {
      const v = d.world.clone().project(this.camera);
      if (v.z < 1) ds.push({ screen: new THREE.Vector2(v.x * 0.5 + 0.5, v.y * 0.5 + 0.5), strength: d.strength, radius: d.radius / Math.max(this.rig.dist * 0.5, 0.3) });
    }
    this.post.setDistortions(ds);
    this.reticle.visible = this.reticle.visible && !this.broken;
    this.post.render();

    this.statsTimer += wallDt;
    if (this.statsTimer > 0.25) {
      this.statsTimer = 0;
      this.pushStats();
      if (this.onDebug) {
        const info = this.renderer.info;
        this.onDebug({ fps: Math.round(this.fps), frameMs: +(wallDt * 1000).toFixed(1), drawCalls: info.render.calls, triangles: info.render.triangles, particles: this.particles.alive, debris: this.debris.count, fragments: this.fragments.count, chunks: this.planet ? 3 : 0, lod: this.planet?.currentLOD() ?? '-', simTime: this.simTime, physicsMs: +this.lastPhysicsMs.toFixed(2), camDist: +this.rig.dist.toFixed(3), gpu: 'WebGL2', quality: this.settings.quality });
      }
    }
  };

  private measureLine: THREE.Line | null = null;
  /** Draws a great-circle arc between two surface directions (measurement tool). */
  measureArc(a: THREE.Vector3, b: THREE.Vector3) {
    if (!this.planet) return;
    if (this.measureLine) { this.planet.spin.remove(this.measureLine); this.measureLine.geometry.dispose(); }
    const pts: THREE.Vector3[] = [];
    const q = new THREE.Quaternion().setFromUnitVectors(a, b);
    const ident = new THREE.Quaternion();
    for (let i = 0; i <= 64; i++) {
      const d = a.clone().applyQuaternion(ident.clone().slerp(q, i / 64)).normalize();
      pts.push(d.multiplyScalar(this.planet.surfaceAt(d).r + 0.006));
    }
    this.measureLine = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x8fffe0, depthTest: false }));
    this.measureLine.renderOrder = 25;
    this.planet.spin.add(this.measureLine);
    setTimeout(() => { if (this.measureLine && this.planet) { this.planet.spin.remove(this.measureLine); this.measureLine.geometry.dispose(); this.measureLine = null; } }, 12000);
  }

  /** Camera helpers used by commands */
  focusImpactSite(dirObj: THREE.Vector3, dist = 1.9) {
    if (!this.planet) return;
    const w = dirObj.clone().transformDirection(this.planet.spin.matrixWorld);
    this.rig.lookFromDirection(w, dist);
  }
  followLargestFragment() {
    const items = this.fragments.getItems().length ? this.fragments.getItems() : this.debris.getItems();
    if (!items.length) return false;
    let best = items[0];
    for (const it of items) if (it.scale > best.scale) best = it;
    this.rig.followFn = () => best.pos;
    this.rig.mode = 'follow';
    this.rig.zoomTo(Math.max(best.scale * 8, 0.6));
    return true;
  }
  stopFollow() { this.rig.followFn = null; this.rig.mode = 'orbit'; this.rig.focusOn(new THREE.Vector3(0, 0, 0)); }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.rig.dispose();
    this.worker?.terminate();
    this.clearAll();
    this.planet?.dispose();
    this.space.dispose(); this.star.dispose(); this.particles.dispose(); this.debris.dispose(); this.fragments.dispose(); this.post.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
