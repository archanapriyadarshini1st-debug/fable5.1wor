import * as THREE from 'three';
import { RNG } from './noise';
import { BILLBOARD_VERT, CORONA_FRAG, NEBULA_FRAG, NEBULA_VERT, STARS_FRAG, STARS_VERT, STAR_FRAG, STAR_VERT } from './shaders/effects';
import type { StarDef } from './types';

/** Layered starfield (three depth shells for parallax) + procedural nebula dome. */
export class SpaceBackground {
  readonly group = new THREE.Group();
  private starMats: THREE.ShaderMaterial[] = [];
  private nebulaMat: THREE.ShaderMaterial;

  constructor(seed: number, tintA = '#2a1a4a', tintB = '#0f2a44', density = 1) {
    const rng = new RNG(seed);
    const shells = [
      { r: 180, n: Math.floor(2200 * density), size: [1.2, 3.2] },
      { r: 600, n: Math.floor(5000 * density), size: [0.8, 2.4] },
      { r: 2400, n: Math.floor(9000 * density), size: [0.6, 1.8] },
    ];
    for (const sh of shells) {
      const pos = new Float32Array(sh.n * 3);
      const col = new Float32Array(sh.n * 3);
      const size = new Float32Array(sh.n);
      const phase = new Float32Array(sh.n);
      const c = new THREE.Color();
      for (let i = 0; i < sh.n; i++) {
        const u = rng.next() * 2 - 1, th = rng.next() * Math.PI * 2;
        const s = Math.sqrt(1 - u * u);
        const r = sh.r * (0.85 + rng.next() * 0.3);
        pos[i * 3] = s * Math.cos(th) * r; pos[i * 3 + 1] = u * r; pos[i * 3 + 2] = s * Math.sin(th) * r;
        const temp = rng.next();
        c.setHSL(temp < 0.3 ? 0.62 : temp < 0.75 ? 0.12 : 0.05, temp < 0.3 ? 0.5 : 0.35, 0.65 + rng.next() * 0.3);
        const bright = Math.pow(rng.next(), 3);
        col[i * 3] = c.r * (0.4 + bright); col[i * 3 + 1] = c.g * (0.4 + bright); col[i * 3 + 2] = c.b * (0.4 + bright);
        size[i] = sh.size[0] + Math.pow(rng.next(), 4) * (sh.size[1] - sh.size[0]) * 2;
        phase[i] = rng.next() * 6.28;
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
      g.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
      g.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
      const m = new THREE.ShaderMaterial({ vertexShader: STARS_VERT, fragmentShader: STARS_FRAG, uniforms: { uTime: { value: 0 }, uPixelRatio: { value: 1 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
      const pts = new THREE.Points(g, m);
      pts.frustumCulled = false;
      pts.renderOrder = -10;
      this.group.add(pts);
      this.starMats.push(m);
    }
    this.nebulaMat = new THREE.ShaderMaterial({
      vertexShader: NEBULA_VERT,
      fragmentShader: NEBULA_FRAG,
      uniforms: { uTime: { value: 0 }, uTintA: { value: new THREE.Color(tintA) }, uTintB: { value: new THREE.Color(tintB) }, uIntensity: { value: 0.75 } },
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
    });
    const dome = new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), this.nebulaMat);
    dome.renderOrder = -20;
    dome.frustumCulled = false;
    this.group.add(dome);
  }
  setPixelRatio(pr: number) { for (const m of this.starMats) m.uniforms.uPixelRatio.value = pr; }
  update(t: number) { for (const m of this.starMats) m.uniforms.uTime.value = t; this.nebulaMat.uniforms.uTime.value = t; }
  setIntensity(v: number) { this.nebulaMat.uniforms.uIntensity.value = v; }
  dispose() { this.group.traverse((o) => { if (o instanceof THREE.Mesh || o instanceof THREE.Points) { o.geometry.dispose(); (o.material as THREE.Material).dispose(); } }); }
}

/** A star: procedural photosphere + corona billboard + point light. */
export class StarObject {
  readonly group = new THREE.Group();
  readonly light: THREE.PointLight;
  private surfMat: THREE.ShaderMaterial;
  private coronaMat: THREE.ShaderMaterial;
  readonly def: StarDef;
  readonly color: THREE.Color;

  constructor(def: StarDef, radius: number) {
    this.def = def;
    this.color = new THREE.Color(def.color);
    this.surfMat = new THREE.ShaderMaterial({ vertexShader: STAR_VERT, fragmentShader: STAR_FRAG, uniforms: { uColor: { value: new THREE.Color(def.color) }, uGlow: { value: new THREE.Color(def.glow) }, uTime: { value: 0 }, uIntensity: { value: 3.0 } } });
    const s = new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 32), this.surfMat);
    this.group.add(s);
    this.coronaMat = new THREE.ShaderMaterial({ vertexShader: BILLBOARD_VERT, fragmentShader: CORONA_FRAG, uniforms: { uGlow: { value: new THREE.Color(def.glow) }, uTime: { value: 0 }, uIntensity: { value: 1.0 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const c = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.coronaMat);
    c.scale.setScalar(radius * 4.5);
    c.renderOrder = 2;
    this.group.add(c);
    this.light = new THREE.PointLight(def.color, 2, 0, 0);
    this.group.add(this.light);
  }
  update(t: number) { this.surfMat.uniforms.uTime.value = t; this.coronaMat.uniforms.uTime.value = t; }
  setFlare(v: number) { this.coronaMat.uniforms.uIntensity.value = 1 + v * 2.5; this.surfMat.uniforms.uIntensity.value = 3 + v * 3; }
  dispose() { this.group.traverse((o) => { if (o instanceof THREE.Mesh) o.geometry.dispose(); }); this.surfMat.dispose(); this.coronaMat.dispose(); }
}
