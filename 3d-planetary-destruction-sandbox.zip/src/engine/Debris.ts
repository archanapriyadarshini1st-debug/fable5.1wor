import * as THREE from 'three';
import { DEBRIS_FRAG, DEBRIS_VERT } from './shaders/effects';

interface DebrisItem {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  rot: THREE.Quaternion;
  ang: THREE.Vector3;
  scale: number;
  heat: number;
  life: number;
  mass: number;
}

export interface Attractor { pos: THREE.Vector3; strength: number; radius: number }

/**
 * Instanced debris simulation (CPU integrated, GPU instanced). Each fragment has position, velocity,
 * angular velocity, scale, heat and lifetime. Central gravity means slow fragments fall back,
 * fast fragments escape, and tangential fragments enter temporary orbits.
 */
export class DebrisSystem {
  readonly mesh: THREE.InstancedMesh;
  private items: DebrisItem[] = [];
  private pool: DebrisItem[] = [];
  private heat: Float32Array;
  private tint: Float32Array;
  readonly capacity: number;
  private dummy = new THREE.Object3D();
  private mat: THREE.ShaderMaterial;
  gravity = 0.25; // GM in scene units
  surfaceRadius = 1;
  attractors: Attractor[] = [];

  constructor(capacity: number) {
    this.capacity = capacity;
    const geo = new THREE.IcosahedronGeometry(1, 1);
    // jagged rock shape
    const p = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const s = 0.65 + Math.random() * 0.7;
      p.setXYZ(i, p.getX(i) * s, p.getY(i) * (0.5 + Math.random() * 0.8), p.getZ(i) * s);
    }
    geo.computeVertexNormals();
    this.heat = new Float32Array(capacity);
    this.tint = new Float32Array(capacity * 3);
    geo.setAttribute('aHeat', new THREE.InstancedBufferAttribute(this.heat, 1).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('aTint', new THREE.InstancedBufferAttribute(this.tint, 3).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({
      vertexShader: DEBRIS_VERT,
      fragmentShader: DEBRIS_FRAG,
      uniforms: { uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uSunColor: { value: new THREE.Color(1, 1, 1) }, uHot: { value: new THREE.Color('#ff6a1a') } },
    });
    this.mesh = new THREE.InstancedMesh(geo, this.mat, capacity);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.count = 0;
    this.mesh.frustumCulled = false;
  }

  get count() { return this.items.length; }

  setSun(dir: THREE.Vector3, color: THREE.Color) {
    this.mat.uniforms.uSunDir.value.copy(dir);
    this.mat.uniforms.uSunColor.value.copy(color);
  }
  setHotColor(c: THREE.Color) { this.mat.uniforms.uHot.value.copy(c); }

  spawn(pos: THREE.Vector3, vel: THREE.Vector3, scale: number, heat: number, tint: THREE.Color, life = 400) {
    let it: DebrisItem;
    if (this.items.length >= this.capacity) {
      it = this.items.shift()!;
    } else {
      it = this.pool.pop() ?? { pos: new THREE.Vector3(), vel: new THREE.Vector3(), rot: new THREE.Quaternion(), ang: new THREE.Vector3(), scale: 1, heat: 0, life: 0, mass: 1 };
    }
    it.pos.copy(pos);
    it.vel.copy(vel);
    it.rot.setFromEuler(new THREE.Euler(Math.random() * 6, Math.random() * 6, Math.random() * 6));
    it.ang.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(4);
    it.scale = scale;
    it.heat = heat;
    it.life = life;
    it.mass = scale * scale * scale;
    // store tint through a temp
    (it as unknown as { tint: THREE.Color }).tint = tint.clone();
    this.items.push(it);
  }

  /** Emits a shower of fragments from an impact point. */
  eject(origin: THREE.Vector3, normal: THREE.Vector3, count: number, speed: number, scale: number, heat: number, tint: THREE.Color, tangentialBias = 0.3) {
    const v = new THREE.Vector3();
    const t = new THREE.Vector3();
    for (let i = 0; i < count; i++) {
      t.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
      v.copy(normal).multiplyScalar(0.5 + Math.random()).add(t.multiplyScalar(0.5 + tangentialBias * 2 * Math.random())).normalize();
      v.multiplyScalar(speed * (0.35 + Math.random() * 1.0));
      this.spawn(origin, v, scale * (0.3 + Math.random() * 1.1), heat * (0.5 + Math.random() * 0.5), tint);
    }
  }

  step(dt: number) {
    if (dt <= 0) return;
    const g = this.gravity;
    const tmp = new THREE.Vector3();
    const q = new THREE.Quaternion();
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      const r2 = it.pos.lengthSq();
      const r = Math.sqrt(r2);
      // central gravity
      tmp.copy(it.pos).multiplyScalar(-g / (r2 * r));
      it.vel.addScaledVector(tmp, dt);
      // attractors (gravity anomalies)
      for (const a of this.attractors) {
        tmp.copy(a.pos).sub(it.pos);
        const d2 = Math.max(tmp.lengthSq(), a.radius * a.radius * 0.2);
        it.vel.addScaledVector(tmp.normalize(), (a.strength / d2) * dt);
      }
      it.pos.addScaledVector(it.vel, dt);
      it.heat = Math.max(0, it.heat - dt * 0.06);
      it.life -= dt;
      const rr = it.pos.length();
      const dead = rr < this.surfaceRadius * 0.98 || rr > 60 || it.life <= 0;
      if (dead) {
        this.items.splice(i, 1);
        this.pool.push(it);
        continue;
      }
      const angLen = it.ang.length() * dt;
      if (angLen > 0) {
        q.setFromAxisAngle(tmp.copy(it.ang).normalize(), angLen);
        it.rot.premultiply(q);
      }
    }
  }

  /** Writes instance data. Called every rendered frame. */
  sync() {
    const n = this.items.length;
    for (let i = 0; i < n; i++) {
      const it = this.items[i];
      this.dummy.position.copy(it.pos);
      this.dummy.quaternion.copy(it.rot);
      this.dummy.scale.setScalar(it.scale);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
      this.heat[i] = it.heat;
      const t = (it as unknown as { tint: THREE.Color }).tint;
      this.tint[i * 3] = t.r; this.tint[i * 3 + 1] = t.g; this.tint[i * 3 + 2] = t.b;
    }
    this.mesh.count = n;
    this.mesh.instanceMatrix.needsUpdate = true;
    (this.mesh.geometry.getAttribute('aHeat') as THREE.InstancedBufferAttribute).needsUpdate = true;
    (this.mesh.geometry.getAttribute('aTint') as THREE.InstancedBufferAttribute).needsUpdate = true;
  }

  /** Read-only access for camera follow / collisions. */
  getItems(): ReadonlyArray<{ pos: THREE.Vector3; vel: THREE.Vector3; scale: number; heat: number; mass: number }> { return this.items; }

  /**
   * Pairwise sphere collisions among fragments (used for the small number of large breakup pieces).
   * Returns collision points so the scene can spawn sparks.
   */
  collide(): THREE.Vector3[] {
    const hits: THREE.Vector3[] = [];
    const n = Math.min(this.items.length, 80);
    const d = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      const a = this.items[i];
      for (let j = i + 1; j < n; j++) {
        const b = this.items[j];
        d.subVectors(b.pos, a.pos);
        const minD = (a.scale + b.scale) * 0.8;
        const dist = d.length();
        if (dist < minD && dist > 1e-5) {
          d.divideScalar(dist);
          const rel = b.vel.dot(d) - a.vel.dot(d);
          if (rel < 0) {
            const ma = a.mass, mb = b.mass;
            const imp = (-(1 + 0.35) * rel) / (1 / ma + 1 / mb);
            a.vel.addScaledVector(d, -imp / ma);
            b.vel.addScaledVector(d, imp / mb);
            a.heat = Math.min(1, a.heat + 0.2); b.heat = Math.min(1, b.heat + 0.2);
            hits.push(a.pos.clone().addScaledVector(d, a.scale * 0.8));
          }
          const push = (minD - dist) * 0.5;
          a.pos.addScaledVector(d, -push); b.pos.addScaledVector(d, push);
        }
      }
    }
    return hits;
  }

  clear() {
    this.pool.push(...this.items);
    this.items.length = 0;
    this.mesh.count = 0;
  }

  /** Approximate serialisable state for snapshots. */
  serialize() {
    return this.items.map((it) => ({ p: it.pos.toArray(), v: it.vel.toArray(), s: it.scale, h: it.heat, l: it.life, t: (it as unknown as { tint: THREE.Color }).tint.getHex() }));
  }
  deserialize(data: ReturnType<DebrisSystem['serialize']>) {
    this.clear();
    const c = new THREE.Color();
    for (const d of data) this.spawn(new THREE.Vector3().fromArray(d.p), new THREE.Vector3().fromArray(d.v), d.s, d.h, c.setHex(d.t), d.l);
  }

  dispose() { this.mesh.geometry.dispose(); this.mat.dispose(); }
}
