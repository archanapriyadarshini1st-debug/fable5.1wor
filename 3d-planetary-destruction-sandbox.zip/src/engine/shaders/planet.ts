/**
 * Planet surface shader. The planet is a displaced sphere: radius = 1 + height*amp - damage.
 * Height comes from the procedural height field; damage from the dynamic destruction field.
 * Normals are reconstructed per-pixel from finite differences, so craters, rims, trenches and
 * bores light correctly and remain perfectly attached to the geometry.
 */

export const NOISE_GLSL = /* glsl */ `
float hash13(vec3 p){ p = fract(p*0.3183099+.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float vnoise(vec3 x){
  vec3 i=floor(x); vec3 f=fract(x); f=f*f*(3.-2.*f);
  return mix(mix(mix(hash13(i+vec3(0,0,0)),hash13(i+vec3(1,0,0)),f.x),mix(hash13(i+vec3(0,1,0)),hash13(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(hash13(i+vec3(0,0,1)),hash13(i+vec3(1,0,1)),f.x),mix(hash13(i+vec3(0,1,1)),hash13(i+vec3(1,1,1)),f.x),f.y),f.z);
}
float fbm3(vec3 p){ float a=0.5,s=0.0; for(int i=0;i<4;i++){ s+=a*vnoise(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5;} return s; }
vec2 sphereUV(vec3 n){ return vec2(atan(n.z, n.x) / 6.2831853 + 0.5, asin(clamp(n.y,-1.0,1.0)) / 3.14159265 + 0.5); }
`;

export const PLANET_COMMON = /* glsl */ `
uniform sampler2D uHeight;
uniform sampler2D uDamage;
uniform float uAmp;
uniform float uSeaLevel;
uniform float uIsGas;
uniform float uBreak;
uniform float uTime;
${NOISE_GLSL}
// Surface radius function shared by vertex displacement and normal reconstruction.
float surfaceR(vec2 uv, out float height, out float dmg){
  vec4 h = texture2D(uHeight, uv);
  vec4 d = texture2D(uDamage, uv);
  height = h.r; dmg = d.r;
  float surf = (dmg > 0.0015 || uIsGas > 0.5) ? height : max(height, uSeaLevel);
  float r = 1.0 + surf * uAmp * (1.0 - uIsGas) - dmg * (1.0 - uIsGas);
  return max(r, 0.10);
}
`;

export const PLANET_VERT = /* glsl */ `
${PLANET_COMMON}
varying vec3 vN;
varying vec3 vWorld;
varying vec3 vObj;
varying float vR;
void main(){
  vec3 n = normalize(position);
  vec2 uv = sphereUV(n);
  float h, d;
  float r = surfaceR(uv, h, d);
  vec3 p = n * r;
  if (uBreak > 0.0) {
    // breakup: crust cells drift outward along random directions before dissolving
    vec3 cell = floor(n * 5.0 + 0.5);
    vec3 dir = normalize(vec3(hash13(cell), hash13(cell + 7.1), hash13(cell + 13.7)) - 0.5 + n * 1.5);
    p += dir * uBreak * 0.45 + n * uBreak * 0.15;
  }
  vN = n; vObj = p; vR = r;
  vec4 wp = modelMatrix * vec4(p, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

export const PLANET_FRAG = /* glsl */ `
${PLANET_COMMON}
uniform vec2 uTexel;
uniform mat3 uModel;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 cOcean, cShallow, cLand, cHighland, cMountain, cIce, cAtmo, cCrust, cMantle, cCore;
uniform float uIce, uTemp, uAtmo, uCity, uLava, uMoistureBias;
uniform float uCoolTime;
uniform sampler2D uCloud;
uniform float uCloudRot;
uniform float uCloudCover;
uniform float uCloudShadow;
uniform vec4 uShock; // xyz dir, w angular radius
uniform float uShockWidth;
uniform float uHighContrast;
uniform float uFlash; // reduced flashing scale
varying vec3 vN;
varying vec3 vWorld;
varying vec3 vObj;
varying float vR;

void main(){
  vec3 n = normalize(vN);
  vec2 uv = sphereUV(n);
  float lat = asin(clamp(n.y, -1.0, 1.0));
  float cl = max(cos(lat), 0.05);
  vec4 H = texture2D(uHeight, uv);
  vec4 D = texture2D(uDamage, uv);
  float height = H.r; float dmg = D.r; float heatT = D.g; float frac = D.b;

  // dissolve during breakup
  if (uBreak > 0.0) { float dn = fbm3(n * 6.0); if (dn < uBreak * 1.15 - 0.08) discard; }

  // --- normal reconstruction (finite differences on the radius function) ---
  float h0,d0,h1,d1;
  float rE = surfaceR(uv + vec2(uTexel.x, 0.0), h0, d0);
  float rW = surfaceR(uv - vec2(uTexel.x, 0.0), h1, d1);
  float rN = surfaceR(uv + vec2(0.0, uTexel.y), h0, d0);
  float rS = surfaceR(uv - vec2(0.0, uTexel.y), h1, d1);
  float sE = (rE - rW) / (2.0 * uTexel.x * 6.2831853 * cl);
  float sN = (rN - rS) / (2.0 * uTexel.y * 3.14159265);
  vec3 east = normalize(vec3(-n.z, 0.0, n.x));
  vec3 north = cross(n, east);
  vec3 Nobj = normalize(n - sE * east - sN * north);
  vec3 N = normalize(uModel * Nobj);
  vec3 Ngeo = normalize(uModel * n);
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 L = normalize(uSunDir);

  float ndl = dot(N, L);
  float geo = dot(Ngeo, L);
  float day = smoothstep(-0.08, 0.25, geo);
  float diff = max(ndl, 0.0) * 0.85 + max(geo, 0.0) * 0.15;
  diff *= smoothstep(-0.2, 0.15, geo); // terminator softness

  bool isWater = (height < uSeaLevel) && dmg <= 0.0015 && uIsGas < 0.5;
  float above = (height - uSeaLevel) / max(1.0 - uSeaLevel, 0.05);
  float micro = H.b;
  float moisture = clamp(H.g + uMoistureBias, 0.0, 1.0);

  vec3 albedo; float spec = 0.0; float shininess = 20.0; vec3 emissive = vec3(0.0);

  if (uIsGas > 0.5) {
    float t = height * 0.5 + 0.5;
    vec3 b1 = mix(cLand, cHighland, smoothstep(0.2, 0.8, t));
    vec3 b2 = mix(cOcean, cShallow, H.g);
    albedo = mix(b1, b2, smoothstep(0.35, 0.65, fract(t * 2.0 + micro * 0.1)) * 0.5);
    albedo += (micro - 0.5) * 0.06;
    albedo = mix(albedo, cHighland * 1.1, H.a * 0.8);
    // storm scars from destructive events: darkening + heat swirl that decays
    float age = uTime - heatT; float heat = exp(-max(age, 0.0) / uCoolTime) * step(0.0, heatT);
    float swirl = vnoise(n * 40.0 + vec3(0.0, uTime * 0.05, 0.0));
    albedo = mix(albedo, albedo * 0.35, clamp(dmg * 4.0, 0.0, 1.0) * (0.6 + 0.4 * swirl));
    emissive += cMantle * heat * clamp(dmg * 6.0, 0.0, 1.0) * (0.5 + swirl) * 1.5;
  } else if (isWater) {
    float depth = clamp((uSeaLevel - height) * 6.0, 0.0, 1.0);
    albedo = mix(cShallow, cOcean, depth);
    spec = 1.0; shininess = 120.0;
    // wave normal perturbation
    vec3 wn = vec3(vnoise(vObj * 300.0 + uTime * 0.3), vnoise(vObj * 300.0 + 7.0 - uTime * 0.2), 0.0) - 0.5;
    N = normalize(N + (wn.x * east + wn.y * north) * 0.08);
    if (uLava > 0.5) { emissive = cOcean * (1.4 + 0.6 * fbm3(vObj * 80.0 + uTime * 0.1)); spec = 0.3; albedo = cOcean * 0.4; }
    // recent nearby impact: choppy, foamy water disturbance
    float age = uTime - heatT; float disturb = exp(-max(age, 0.0) / 25.0) * step(0.0, heatT);
    albedo = mix(albedo, vec3(0.85, 0.9, 0.95), disturb * (0.4 + 0.6 * vnoise(vObj * 200.0 - uTime)) * 0.7);
  } else {
    float slope = 1.0 - max(dot(Nobj, n), 0.0);
    vec3 low = mix(cLand, cHighland, smoothstep(0.05, 0.5, above) * (0.5 + 0.5 * (1.0 - moisture)));
    low = mix(low, cHighland * 0.9, (1.0 - moisture) * 0.35);
    vec3 rock = mix(low, cMountain, smoothstep(0.35, 0.75, above) + smoothstep(0.02, 0.09, slope) * 0.6);
    // beaches / coast
    rock = mix(mix(cShallow, cHighland, 0.6), rock, smoothstep(0.0, 0.03, above));
    // ice caps: latitude + altitude + global temperature
    float iceLine = 1.0 - uIce * 1.1;
    float iceF = smoothstep(iceLine - 0.08, iceLine + 0.05, abs(sin(lat)) + above * 0.35 + (H.g - 0.5) * 0.08);
    iceF = max(iceF, smoothstep(0.75, 0.95, above) * step(uTemp, 320.0));
    iceF *= 1.0 - smoothstep(0.0, 0.06, dmg);
    rock = mix(rock, cIce, iceF);
    rock += (micro - 0.5) * 0.08;
    albedo = rock;
    spec = iceF * 0.5; shininess = 40.0;
    // volcanic hot-spots
    float volc = H.a;
    if (uLava > 0.5) { emissive += cMantle * volc * (0.6 + 0.4 * vnoise(vObj * 120.0 + uTime * 0.2)); }
    else { albedo = mix(albedo, cCrust * 0.7, volc * 0.5); }
  }

  // ---------- destruction response: interior layers, heat, fractures ----------
  if (uIsGas < 0.5) {
    float age = uTime - heatT;
    float heat = exp(-max(age, 0.0) / uCoolTime) * step(0.0, heatT);
    float depthF = clamp(dmg / 0.9, 0.0, 1.0);
    float crustF = smoothstep(0.0, 0.03, dmg);
    float mantleF = smoothstep(0.03, 0.12, dmg);
    float coreF = smoothstep(0.55, 0.75, dmg);
    vec3 interior = mix(cCrust, cMantle, mantleF);
    interior = mix(interior, cCore, coreF);
    float moltenNoise = 0.6 + 0.4 * fbm3(vObj * 50.0 + vec3(0.0, uTime * 0.03, 0.0));
    albedo = mix(albedo, interior * 0.5, crustF);
    // molten mantle glows on its own; the crust glows only while hot
    emissive += cMantle * mantleF * moltenNoise * (0.5 + 1.5 * heat) * (1.0 - coreF);
    emissive += cCore * coreF * (1.2 + 0.6 * moltenNoise);
    emissive += cMantle * crustF * (1.0 - mantleF) * heat * 1.8 * uFlash;
    // fractures: ridged noise lines weighted by fracture field + global breakup
    float fr = max(frac, uBreak * 1.5);
    if (fr > 0.01) {
      float c1 = 1.0 - abs(vnoise(n * 55.0) * 2.0 - 1.0);
      float c2 = 1.0 - abs(vnoise(n * 130.0 + 3.0) * 2.0 - 1.0);
      float crack = smoothstep(0.88, 0.99, c1) + smoothstep(0.9, 0.99, c2) * 0.6;
      crack = clamp(crack, 0.0, 1.0) * clamp(fr, 0.0, 1.0);
      albedo = mix(albedo, cCrust * 0.3, crack);
      emissive += cMantle * crack * (0.6 + heat * 1.4 + uBreak * 1.5) * uFlash;
    }
    // uplifted terrain (negative damage) shows fresh rock
    albedo = mix(albedo, cCrust * 0.9, smoothstep(0.0, 0.01, -dmg) * 0.5);
    // ambient occlusion in deep pits
    diff *= mix(1.0, 0.55, depthF * (1.0 - coreF));
  }

  // ---------- shockwave front ----------
  if (uShock.w > 0.0) {
    float ang = acos(clamp(dot(n, uShock.xyz), -1.0, 1.0));
    float ring = smoothstep(uShock.w - uShockWidth, uShock.w, ang) * (1.0 - smoothstep(uShock.w, uShock.w + uShockWidth * 0.35, ang));
    emissive += vec3(1.0, 0.75, 0.45) * ring * 2.5 * uFlash;
  }

  // ---------- cloud shadows ----------
  if (uCloudShadow > 0.5 && uCloudCover > 0.0 && uIsGas < 0.5) {
    vec3 toSun = n + L * 0.03;
    vec2 cuv = sphereUV(normalize(toSun)); cuv.x += uCloudRot;
    float c = texture2D(uCloud, cuv).r;
    float cov = smoothstep(1.0 - uCloudCover * 0.95, 1.0 - uCloudCover * 0.95 + 0.25, c);
    diff *= 1.0 - cov * 0.45;
  }

  // ---------- lighting ----------
  vec3 Hh = normalize(L + V);
  float sp = pow(max(dot(N, Hh), 0.0), shininess) * spec * day;
  vec3 color = albedo * (diff * uSunColor + vec3(0.012, 0.014, 0.02));
  color += uSunColor * sp * 0.9;
  // atmosphere tint towards the limb (in-scatter approximation)
  float fres = pow(1.0 - max(dot(Ngeo, V), 0.0), 3.0);
  color += cAtmo * fres * uAtmo * 0.35 * (0.15 + day);
  color = mix(color, cAtmo * 0.3 * day, fres * uAtmo * 0.35);
  // night lights
  if (uCity > 0.5 && !isWater && uIsGas < 0.5 && dmg < 0.004) {
    float night = 1.0 - smoothstep(-0.25, 0.05, geo);
    float cells = vnoise(n * 220.0) * vnoise(n * 70.0 + 5.0);
    float lights = smoothstep(0.42, 0.6, cells) * smoothstep(0.35, 0.6, moisture) * (1.0 - smoothstep(0.3, 0.5, above)) * step(0.0, above);
    color += vec3(1.0, 0.8, 0.5) * lights * night * 1.6;
  }
  color += emissive;
  color = mix(color, (color - 0.5) * 1.25 + 0.5, uHighContrast * 0.5);
  gl_FragColor = vec4(color, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;
