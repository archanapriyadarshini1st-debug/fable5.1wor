import { NOISE_GLSL } from './planet';

/** Atmospheric shell: rim scattering + terminator warmth + disturbance plumes from destruction events. */
export const ATMO_VERT = /* glsl */ `
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
void main(){ vN = normalize(mat3(modelMatrix) * normal); vObj = normalize(position); vec4 wp = modelMatrix * vec4(position,1.0); vWorld = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
export const ATMO_FRAG = /* glsl */ `
uniform vec3 uSunDir; uniform vec3 uColor; uniform float uDensity; uniform float uTime; uniform float uFlash;
uniform vec4 uPlumes[8]; uniform float uPlumeStr[8]; uniform float uGlobalGlow;
${NOISE_GLSL}
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
void main(){
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 N = normalize(vN);
  float mu = dot(N, normalize(uSunDir));
  float day = smoothstep(-0.35, 0.3, mu);
  float rim = pow(1.0 - max(dot(N, V), 0.0), 3.2);
  float inner = smoothstep(0.0, 0.55, rim) * (1.0 - smoothstep(0.85, 1.0, rim));
  vec3 sunset = vec3(1.0, 0.45, 0.2);
  float term = (1.0 - smoothstep(0.0, 0.5, abs(mu))) * 0.6;
  vec3 col = mix(uColor, sunset, term);
  float a = inner * uDensity * (0.15 + day) * 1.6 + rim * uDensity * 0.25 * day;
  col *= a;
  // disturbance plumes: expanding shock-like ring + lingering glow at each impact direction
  for (int i = 0; i < 8; i++) {
    float s = uPlumeStr[i]; if (s <= 0.0) continue;
    float age = uTime - uPlumes[i].w; if (age < 0.0) continue;
    float ang = acos(clamp(dot(vObj, normalize(uPlumes[i].xyz)), -1.0, 1.0));
    float rr = 0.05 + age * 0.12 * s;
    float ring = exp(-pow((ang - rr) / (0.03 + rr * 0.25), 2.0)) * exp(-age / (6.0 * s)) * 1.6;
    float glow = exp(-ang * ang / (0.02 * s + 0.01)) * exp(-age / (18.0 * s)) * 0.9;
    float dust = (glow + ring) * (0.6 + 0.4 * vnoise(vObj * 40.0 + age * 0.3));
    col += mix(vec3(1.0, 0.7, 0.4), vec3(0.6, 0.5, 0.45), min(age / 8.0, 1.0)) * dust * s * uFlash;
  }
  col += uColor * uGlobalGlow * (0.3 + rim) * uFlash;
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Cloud shell: procedural coverage, sun lit, disrupted by destruction (cleared craters + dust plumes). */
export const CLOUD_VERT = /* glsl */ `
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
void main(){ vN = normalize(mat3(modelMatrix) * normal); vObj = normalize(position); vec4 wp = modelMatrix * vec4(position,1.0); vWorld = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
export const CLOUD_FRAG = /* glsl */ `
uniform sampler2D uCloud; uniform sampler2D uDamage; uniform float uRot; uniform float uCover; uniform vec3 uSunDir; uniform vec3 uColor; uniform float uTime; uniform float uCoolTime; uniform float uCrustHeat;
${NOISE_GLSL}
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
void main(){
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 N = normalize(vN);
  vec2 uv = sphereUV(vObj);
  vec2 cuv = vec2(uv.x + uRot, uv.y);
  float c = texture2D(uCloud, cuv).r;
  float c2 = texture2D(uCloud, cuv * 3.0 + vec2(uTime * 0.002, 0.0)).g;
  float cov = smoothstep(1.0 - uCover * 0.95, 1.0 - uCover * 0.95 + 0.3, c + (c2 - 0.5) * 0.25);
  vec4 D = texture2D(uDamage, uv);
  float age = uTime - D.g; float recent = exp(-max(age, 0.0) / (uCoolTime * 0.6)) * step(0.0, D.g);
  // craters punch holes in the cloud deck; hot zones lift dust/steam plumes above them
  cov *= 1.0 - smoothstep(0.0, 0.01, D.r) * (0.4 + 0.6 * recent);
  float plume = recent * (smoothstep(0.0, 0.02, D.r) + D.b * 0.6) * (0.5 + 0.5 * vnoise(vObj * 60.0 + uTime * 0.2));
  vec3 dustCol = mix(vec3(0.45, 0.32, 0.22), vec3(0.95, 0.9, 0.85), uCrustHeat);
  float mu = dot(N, normalize(uSunDir));
  float light = smoothstep(-0.2, 0.3, mu) * 0.95 + 0.04;
  float edge = pow(max(dot(N, V), 0.0), 0.6);
  vec3 col = mix(uColor * light, dustCol * light * 1.2, clamp(plume, 0.0, 1.0));
  float alpha = clamp(cov * 0.92 + plume * 0.9, 0.0, 1.0) * edge;
  gl_FragColor = vec4(col, alpha);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Star surface: animated granulation + limb darkening. */
export const STAR_VERT = /* glsl */ `
varying vec3 vN; varying vec3 vObj; varying vec3 vWorld;
void main(){ vN = normalize(mat3(modelMatrix) * normal); vObj = position; vec4 wp = modelMatrix * vec4(position,1.0); vWorld = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
export const STAR_FRAG = /* glsl */ `
uniform vec3 uColor; uniform vec3 uGlow; uniform float uTime; uniform float uIntensity;
${NOISE_GLSL}
varying vec3 vN; varying vec3 vObj; varying vec3 vWorld;
void main(){
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 p = normalize(vObj);
  float g1 = fbm3(p * 6.0 + vec3(uTime * 0.02, 0.0, uTime * 0.015));
  float g2 = vnoise(p * 30.0 + uTime * 0.08);
  float spots = smoothstep(0.62, 0.7, fbm3(p * 3.0 + 4.0 - uTime * 0.005));
  float limb = pow(max(dot(normalize(vN), V), 0.0), 0.55);
  vec3 col = mix(uGlow, uColor, g1 * 0.8 + g2 * 0.3) * (0.9 + 0.5 * g2);
  col = mix(col, uGlow * 0.35, spots * 0.8);
  col *= mix(0.55, 1.15, limb) * uIntensity;
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Corona billboard: radial falloff + animated streamers, additive. */
export const CORONA_FRAG = /* glsl */ `
uniform vec3 uGlow; uniform float uTime; uniform float uIntensity;
${NOISE_GLSL}
varying vec2 vUv;
void main(){
  vec2 c = vUv * 2.0 - 1.0;
  float r = length(c);
  float ang = atan(c.y, c.x);
  float streaks = fbm3(vec3(ang * 3.0, r * 6.0 - uTime * 0.15, uTime * 0.03));
  float core = exp(-r * r * 14.0);
  float halo = exp(-r * 3.2) * (0.6 + 0.6 * streaks);
  float a = (core * 2.5 + halo) * uIntensity * (1.0 - smoothstep(0.75, 1.0, r));
  gl_FragColor = vec4(uGlow * a, a);
}
`;
export const BILLBOARD_VERT = /* glsl */ `
varying vec2 vUv;
void main(){ vUv = uv; vec4 mv = modelViewMatrix * vec4(0.0,0.0,0.0,1.0); vec2 scale = vec2(length(modelMatrix[0].xyz), length(modelMatrix[1].xyz)); mv.xy += position.xy * scale; gl_Position = projectionMatrix * mv; }
`;

/** GPU particle system: fully analytic motion on the GPU (time uniform driven by simulation clock). */
export const PARTICLE_VERT = /* glsl */ `
attribute vec3 aVel; attribute float aStart; attribute float aLife; attribute float aSize; attribute vec3 aColor; attribute float aKind;
uniform float uTime; uniform float uGravity; uniform float uPixelRatio; uniform float uSurface;
varying vec3 vColor; varying float vAlpha; varying float vKind;
void main(){
  float age = uTime - aStart;
  float t = clamp(age / aLife, 0.0, 1.0);
  vAlpha = 0.0; vColor = aColor; vKind = aKind;
  if (age < 0.0 || age > aLife || aLife <= 0.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); gl_PointSize = 0.0; return; }
  float drag = aKind == 0.0 ? 1.4 : (aKind == 2.0 ? 0.8 : 0.3);
  vec3 p = position + aVel * (1.0 - exp(-drag * age)) / drag;
  // radial gravity toward the planet centre (approximate: constant direction from spawn point)
  vec3 g = -normalize(position) * uGravity;
  p += 0.5 * g * age * age * (aKind == 1.0 ? 1.0 : 0.35);
  float rr = length(p);
  if (rr < uSurface * 0.985) { p = normalize(p) * uSurface; vAlpha = 0.0; }
  else { vAlpha = (aKind == 2.0) ? (1.0 - t) * (1.0 - t) : sin(t * 3.14159) ; }
  float grow = aKind == 0.0 ? (1.0 + t * 2.5) : (aKind == 2.0 ? (1.0 + t * 1.5) : (1.0 - t * 0.5));
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = aSize * grow * uPixelRatio * 320.0 / max(-mv.z, 0.05);
  gl_PointSize = min(gl_PointSize, 160.0);
  gl_Position = projectionMatrix * mv;
}
`;
export const PARTICLE_FRAG = /* glsl */ `
varying vec3 vColor; varying float vAlpha; varying float vKind;
void main(){
  vec2 c = gl_PointCoord * 2.0 - 1.0; float r2 = dot(c, c); if (r2 > 1.0) discard;
  float soft = vKind == 1.0 ? pow(1.0 - r2, 0.6) : (1.0 - r2) * (1.0 - r2);
  float a = soft * vAlpha;
  gl_FragColor = vec4(vColor * a * (vKind == 1.0 ? 2.2 : 1.0), a);
}
`;

/** Instanced debris: sun-lit rock with per-instance heat glow. */
export const DEBRIS_VERT = /* glsl */ `
attribute float aHeat; attribute vec3 aTint;
varying vec3 vN; varying float vHeat; varying vec3 vTint; varying vec3 vPos;
void main(){
  vHeat = aHeat; vTint = aTint;
  mat3 nm = mat3(instanceMatrix);
  vN = normalize(mat3(modelMatrix) * (nm * normal));
  vPos = position;
  gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0);
}
`;
export const DEBRIS_FRAG = /* glsl */ `
uniform vec3 uSunDir; uniform vec3 uSunColor; uniform vec3 uHot;
varying vec3 vN; varying float vHeat; varying vec3 vTint; varying vec3 vPos;
void main(){
  float d = max(dot(normalize(vN), normalize(uSunDir)), 0.0);
  vec3 col = vTint * (d * uSunColor + 0.03);
  col += uHot * vHeat * (1.2 + 0.8 * fract(sin(dot(vPos.xy, vec2(12.9898, 78.233))) * 43758.5453));
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Ring particles: orbit analytically with Keplerian angular speed; shadowed by the planet. */
export const RING_VERT = /* glsl */ `
attribute float aRadius; attribute float aAngle; attribute float aSize; attribute float aY; attribute float aShade;
uniform float uTime; uniform float uPixelRatio; uniform float uDisrupt; uniform vec3 uDisruptDir;
varying float vShade; varying float vShadow;
uniform vec3 uSunDir;
void main(){
  float w = 0.35 / pow(aRadius, 1.5);
  float ang = aAngle + uTime * w;
  vec3 p = vec3(cos(ang) * aRadius, aY, sin(ang) * aRadius);
  // disruption: nearby event scatters ring particles outward/vertically
  if (uDisrupt > 0.0) { float dd = max(0.0, 1.0 - length(normalize(p) - uDisruptDir) * 1.5); p += (normalize(p) * 0.3 + vec3(0.0, sin(aAngle * 13.0), 0.0) * 0.25) * dd * uDisrupt; }
  vec3 wp = (modelMatrix * vec4(p, 1.0)).xyz;
  // planet shadow: project onto sun axis
  vec3 s = normalize(uSunDir);
  float along = dot(wp, s);
  float perp = length(wp - s * along);
  vShadow = (along < 0.0 && perp < 1.0) ? 0.08 : 1.0;
  vShade = aShade;
  vec4 mv = viewMatrix * vec4(wp, 1.0);
  gl_PointSize = aSize * uPixelRatio * 90.0 / max(-mv.z, 0.05);
  gl_Position = projectionMatrix * mv;
}
`;
export const RING_FRAG = /* glsl */ `
uniform vec3 uColor; varying float vShade; varying float vShadow;
void main(){ vec2 c = gl_PointCoord * 2.0 - 1.0; float r2 = dot(c,c); if (r2 > 1.0) discard; float a = (1.0 - r2) * 0.85; gl_FragColor = vec4(uColor * vShade * vShadow * a, a); }
`;

/** Deep-space background dome: nebula + distant galaxies, procedural. */
export const NEBULA_FRAG = /* glsl */ `
uniform float uTime; uniform vec3 uTintA; uniform vec3 uTintB; uniform float uIntensity;
${NOISE_GLSL}
varying vec3 vDir;
void main(){
  vec3 d = normalize(vDir);
  float n1 = fbm3(d * 2.2 + vec3(3.0, 1.0, 7.0));
  float n2 = fbm3(d * 5.5 + vec3(n1 * 2.0));
  float band = exp(-pow((d.y + 0.15 * n1) * 3.5, 2.0));
  float neb = smoothstep(0.42, 0.75, n1 * 0.6 + n2 * 0.5) * (0.4 + band);
  vec3 col = mix(uTintA, uTintB, n2) * neb * uIntensity;
  col += vec3(0.6, 0.65, 0.9) * band * 0.06 * uIntensity;
  // distant galaxies as faint elongated smudges
  float g = 0.0;
  for (int i = 0; i < 3; i++) {
    vec3 gd = normalize(vec3(sin(float(i) * 2.1 + 0.5), cos(float(i) * 1.3 + 0.2) * 0.6, cos(float(i) * 2.9)));
    float ang = acos(clamp(dot(d, gd), -1.0, 1.0));
    g += exp(-ang * ang * (250.0 + float(i) * 200.0)) * (0.5 + 0.5 * vnoise(d * 200.0));
  }
  col += vec3(0.9, 0.85, 0.8) * g * 0.5 * uIntensity;
  gl_FragColor = vec4(col, 1.0);
}
`;
export const NEBULA_VERT = /* glsl */ `
varying vec3 vDir;
void main(){ vDir = position; vec4 mv = viewMatrix * vec4(position + cameraPosition, 1.0); gl_Position = (projectionMatrix * mv).xyww; }
`;

/** Starfield points with twinkle + size by magnitude. */
export const STARS_VERT = /* glsl */ `
attribute float aSize; attribute vec3 aColor; attribute float aPhase;
uniform float uTime; uniform float uPixelRatio;
varying vec3 vColor; varying float vTw;
void main(){ vColor = aColor; vTw = 0.75 + 0.25 * sin(uTime * 1.5 + aPhase); vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_PointSize = aSize * uPixelRatio; gl_Position = projectionMatrix * mv; }
`;
export const STARS_FRAG = /* glsl */ `
varying vec3 vColor; varying float vTw;
void main(){ vec2 c = gl_PointCoord * 2.0 - 1.0; float r2 = dot(c,c); if (r2 > 1.0) discard; float a = pow(1.0 - r2, 2.0) * vTw; gl_FragColor = vec4(vColor * a, a); }
`;

/** Screen-space spatial distortion (lensing-inspired) post pass, up to 4 centres. */
export const DISTORT_SHADER = {
  uniforms: {
    tDiffuse: { value: null },
    uCenters: { value: [0, 0, 0, 0, 0, 0, 0, 0] },
    uStrength: { value: [0, 0, 0, 0] },
    uRadius: { value: [0, 0, 0, 0] },
    uAspect: { value: 1 },
    uChroma: { value: 0.0 },
  },
  vertexShader: /* glsl */ `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */ `
uniform sampler2D tDiffuse; uniform float uCenters[8]; uniform float uStrength[4]; uniform float uRadius[4]; uniform float uAspect; uniform float uChroma;
varying vec2 vUv;
void main(){
  vec2 uv = vUv; float dark = 0.0;
  for (int i = 0; i < 4; i++) {
    if (uStrength[i] <= 0.0) continue;
    vec2 c = vec2(uCenters[i*2], uCenters[i*2+1]);
    vec2 d = uv - c; d.x *= uAspect;
    float r = length(d);
    float R = uRadius[i];
    if (r < R) {
      float k = uStrength[i] * pow(1.0 - r / R, 2.0);
      // pull pixels toward the centre (gravitational lens-like), swirl slightly
      float a = k * 0.6;
      vec2 sw = vec2(cos(a) * d.x - sin(a) * d.y, sin(a) * d.x + cos(a) * d.y);
      vec2 nd = mix(d, sw, 0.5) * (1.0 - k * 0.55);
      nd.x /= uAspect;
      uv = c + nd;
      dark = max(dark, (1.0 - smoothstep(0.0, R * 0.18, r)) * uStrength[i]);
    }
  }
  vec3 col;
  if (uChroma > 0.0) { vec2 off = (uv - 0.5) * uChroma * 0.01; col = vec3(texture2D(tDiffuse, uv + off).r, texture2D(tDiffuse, uv).g, texture2D(tDiffuse, uv - off).b); }
  else col = texture2D(tDiffuse, uv).rgb;
  col *= 1.0 - dark;
  gl_FragColor = vec4(col, 1.0);
}`,
};

/** Simple lit shader for system-mode bodies with analytic eclipse shadows from other bodies. */
export const BODY_VERT = /* glsl */ `
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
uniform float uSeed;
${NOISE_GLSL}
void main(){ vObj = normalize(position); float h = fbm3(vObj * 4.0 + uSeed) - 0.5; vec3 p = position * (1.0 + h * 0.03); vN = normalize(mat3(modelMatrix) * normal); vec4 wp = modelMatrix * vec4(p,1.0); vWorld = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }
`;
export const BODY_FRAG = /* glsl */ `
uniform vec3 uSun; uniform vec3 uSunColor; uniform vec3 uColorA; uniform vec3 uColorB; uniform float uSeed; uniform float uEmissive; uniform float uGas; uniform float uTime;
uniform vec4 uOccluders[6]; uniform int uOccCount; uniform float uAtmo;
${NOISE_GLSL}
varying vec3 vN; varying vec3 vWorld; varying vec3 vObj;
void main(){
  vec3 N = normalize(vN);
  vec3 toSun = uSun - vWorld; float dist = length(toSun); vec3 L = toSun / dist;
  vec3 V = normalize(cameraPosition - vWorld);
  float ndl = max(dot(N, L), 0.0);
  // analytic shadow: is the segment to the star blocked by another sphere?
  float shadow = 1.0;
  for (int i = 0; i < 6; i++) {
    if (i >= uOccCount) break;
    vec3 oc = uOccluders[i].xyz - vWorld; float t = dot(oc, L);
    if (t > 0.0 && t < dist) { float perp = length(oc - L * t); shadow *= smoothstep(uOccluders[i].w * 0.9, uOccluders[i].w * 1.15, perp); }
  }
  float n1 = uGas > 0.5 ? (0.5 + 0.5 * sin(vObj.y * 18.0 + fbm3(vObj * 3.0 + uSeed) * 4.0)) : fbm3(vObj * 5.0 + uSeed);
  float n2 = vnoise(vObj * 25.0 + uSeed);
  vec3 alb = mix(uColorA, uColorB, smoothstep(0.35, 0.65, n1)) * (0.85 + 0.3 * n2);
  vec3 col = alb * (ndl * shadow * uSunColor + 0.015);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  col += uColorB * fres * uAtmo * ndl * shadow * 0.6;
  col += alb * uEmissive * (1.0 + 0.4 * fbm3(vObj * 8.0 + uTime * 0.05));
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Gravity-well grid: vertices sink according to potential of nearby masses (visualization only). */
export const GRID_VERT = /* glsl */ `
uniform vec4 uMasses[24]; uniform int uCount; uniform float uScale;
varying float vDepth;
void main(){
  vec3 p = position; float d = 0.0;
  for (int i = 0; i < 24; i++) { if (i >= uCount) break; vec2 dd = p.xz - uMasses[i].xz; float r = length(dd) + uMasses[i].w * 0.5 + 0.2; d += uMasses[i].w / r; }
  p.y -= d * uScale;
  vDepth = clamp(d * uScale * 0.4, 0.0, 1.0);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`;
export const GRID_FRAG = /* glsl */ `
varying float vDepth; uniform vec3 uColor;
void main(){ gl_FragColor = vec4(mix(uColor, vec3(1.0, 0.7, 0.4), vDepth) , 0.18 + vDepth * 0.5); }
`;
