import * as THREE from 'three';
import { CameraRig } from './CameraRig';
import { RNG } from './noise';
import { SpaceBackground } from './Space';
import { STARS_FRAG, STARS_VERT } from './shaders/effects';
import type { Settings } from './types';

export interface GalaxySystem { id: string; name: string; seed: number; pos: THREE.Vector3; starClass: string }

/** Procedural spiral galaxy: ~40k GPU points, a dust lane and a set of selectable named systems. */
export class GalaxyScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly rig: CameraRig;
  readonly systems: GalaxySystem[] = [];
  private space: SpaceBackground;
  private container: HTMLElement;
  private ro: ResizeObserver;
  private raf = 0;
  private last = performance.now();
  private t = 0;
  private galaxy: THREE.Points;
  private markers: THREE.Points;
  private mat: THREE.ShaderMaterial;
  private markerMat: THREE.ShaderMaterial;
  private highlight: THREE.Mesh;
  hovered: GalaxySystem | null = null;
  onLabels?: (l: { id: string; name: string; x: number; y: number; visible: boolean }[]) => void;
  disposed = false;

  constructor(container: HTMLElement, settings: Settings) {
    this.container = container;
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { antialias: true });
    if (!gl) throw new Error('WebGL2 is not available on this device/browser.');
    this.renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: true });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(canvas);
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 5000);
    this.rig = new CameraRig(this.camera, canvas);
    this.rig.minDist = 6; this.rig.maxDist = 120; this.rig.setView(0.4, 0.9, 60, true);
    this.rig.mode = 'cinematic'; this.rig.autoRotateSpeed = 0.02; this.rig.reducedMotion = settings.reducedMotion;
    this.space = new SpaceBackground(4242, '#1c1236', '#0a1a30', 0.5);
    this.scene.add(this.space.group);

    const rng = new RNG(77);
    const N = settings.quality === 'performance' ? 15000 : 42000;
    const pos = new Float32Array(N * 3), col = new Float32Array(N * 3), size = new Float32Array(N), phase = new Float32Array(N);
    const c = new THREE.Color();
    const arms = 4;
    for (let i = 0; i < N; i++) {
      const r = Math.pow(rng.next(), 0.6) * 30;
      const arm = Math.floor(rng.next() * arms);
      const spread = 0.35 + r * 0.02;
      const ang = (arm / arms) * Math.PI * 2 + r * 0.22 + (rng.next() - 0.5) * spread + rng.next() * rng.next() * 1.5;
      const y = (rng.next() - 0.5) * (0.4 + Math.exp(-r / 6) * 3.5);
      pos[i * 3] = Math.cos(ang) * r; pos[i * 3 + 1] = y; pos[i * 3 + 2] = Math.sin(ang) * r;
      const core = Math.exp(-r / 7);
      c.setHSL(core > 0.4 ? 0.09 : 0.55 + rng.next() * 0.1, 0.5, 0.55 + core * 0.3);
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
      size[i] = 1.2 + rng.next() * 2 + core * 3; phase[i] = rng.next() * 6.28;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aColor', new THREE.BufferAttribute(col, 3)); g.setAttribute('aSize', new THREE.BufferAttribute(size, 1)); g.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
    this.mat = new THREE.ShaderMaterial({ vertexShader: STARS_VERT, fragmentShader: STARS_FRAG, uniforms: { uTime: { value: 0 }, uPixelRatio: { value: 1 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.galaxy = new THREE.Points(g, this.mat); this.galaxy.frustumCulled = false;
    this.scene.add(this.galaxy);
    // named systems
    const NAMES = ['Kael', 'Vestra', 'Orunn', 'Thyra', 'Nuvex', 'Sarrow', 'Ilonis', 'Brygg', 'Quon', 'Zephar', 'Marduk', 'Elara', 'Drusa', 'Toriel', 'Hesper', 'Anvil', 'Cinder', 'Halcyon', 'Ossia', 'Pellum', 'Rhoan', 'Sable', 'Tamsin', 'Ursa', 'Veyle', 'Wren', 'Xolan', 'Yarrow', 'Zinnia', 'Aster'];
    const mp = new Float32Array(NAMES.length * 3), mc = new Float32Array(NAMES.length * 3), ms = new Float32Array(NAMES.length), mph = new Float32Array(NAMES.length);
    NAMES.forEach((name, i) => {
      const r = 5 + rng.next() * 22; const arm = i % arms; const ang = (arm / arms) * Math.PI * 2 + r * 0.22 + (rng.next() - 0.5) * 0.3;
      const p = new THREE.Vector3(Math.cos(ang) * r, (rng.next() - 0.5) * 0.5, Math.sin(ang) * r);
      const sc = ['red-dwarf', 'orange', 'sun-like', 'blue-white', 'giant'][i % 5];
      this.systems.push({ id: `sys-${i}`, name: `${name} System`, seed: 1000 + i * 977, pos: p, starClass: sc });
      mp[i * 3] = p.x; mp[i * 3 + 1] = p.y; mp[i * 3 + 2] = p.z; mc[i * 3] = 1; mc[i * 3 + 1] = 0.95; mc[i * 3 + 2] = 0.8; ms[i] = 9; mph[i] = i;
    });
    const mg = new THREE.BufferGeometry();
    mg.setAttribute('position', new THREE.BufferAttribute(mp, 3)); mg.setAttribute('aColor', new THREE.BufferAttribute(mc, 3)); mg.setAttribute('aSize', new THREE.BufferAttribute(ms, 1)); mg.setAttribute('aPhase', new THREE.BufferAttribute(mph, 1));
    this.markerMat = new THREE.ShaderMaterial({ vertexShader: STARS_VERT, fragmentShader: STARS_FRAG, uniforms: { uTime: { value: 0 }, uPixelRatio: { value: 1 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.markers = new THREE.Points(mg, this.markerMat); this.markers.frustumCulled = false;
    this.scene.add(this.markers);
    this.highlight = new THREE.Mesh(new THREE.RingGeometry(0.8, 0.9, 48), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.9, depthTest: false }));
    this.highlight.visible = false; this.scene.add(this.highlight);
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(container); this.resize();
    this.loop();
  }
  private resize() {
    const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1;
    const pr = Math.min(window.devicePixelRatio || 1, 1.5);
    this.renderer.setPixelRatio(pr); this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.mat.uniforms.uPixelRatio.value = pr; this.markerMat.uniforms.uPixelRatio.value = pr; this.space.setPixelRatio(pr);
  }
  /** nearest system marker to a screen position (in px), within 28px */
  pick(x: number, y: number): GalaxySystem | null {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    let best: GalaxySystem | null = null, bd = 28;
    for (const s of this.systems) {
      const v = s.pos.clone().applyMatrix4(this.galaxy.matrixWorld).project(this.camera);
      if (v.z > 1) continue;
      const sx = (v.x * 0.5 + 0.5) * w, sy = (-v.y * 0.5 + 0.5) * h;
      const d = Math.hypot(sx - x, sy - y);
      if (d < bd) { bd = d; best = s; }
    }
    return best;
  }
  setHover(s: GalaxySystem | null) { this.hovered = s; }
  focusSystem(s: GalaxySystem) { this.rig.mode = 'orbit'; this.rig.focusOn(s.pos.clone().applyMatrix4(this.galaxy.matrixWorld), 14); }
  unfocus() { this.rig.mode = 'cinematic'; this.rig.focusOn(new THREE.Vector3(), 60); }
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now(); const dt = Math.min((now - this.last) / 1000, 0.1); this.last = now; this.t += dt;
    this.galaxy.rotation.y += dt * 0.01; this.markers.rotation.y = this.galaxy.rotation.y;
    this.mat.uniforms.uTime.value = this.t; this.markerMat.uniforms.uTime.value = this.t;
    if (this.hovered) { this.highlight.visible = true; this.highlight.position.copy(this.hovered.pos).applyMatrix4(this.galaxy.matrixWorld); this.highlight.lookAt(this.camera.position); this.highlight.scale.setScalar(this.rig.dist * 0.02); } else this.highlight.visible = false;
    this.rig.update(dt, this.t); this.space.update(this.t);
    this.renderer.render(this.scene, this.camera);
    if (this.onLabels) { const w = this.container.clientWidth, h = this.container.clientHeight; this.onLabels(this.systems.map((s) => { const v = s.pos.clone().applyMatrix4(this.galaxy.matrixWorld).project(this.camera); return { id: s.id, name: s.name, x: (v.x * 0.5 + 0.5) * w, y: (-v.y * 0.5 + 0.5) * h, visible: v.z < 1 }; })); }
  };
  dispose() { this.disposed = true; cancelAnimationFrame(this.raf); this.ro.disconnect(); this.rig.dispose(); this.galaxy.geometry.dispose(); this.mat.dispose(); this.markers.geometry.dispose(); this.markerMat.dispose(); this.space.dispose(); this.renderer.dispose(); this.renderer.domElement.remove(); }
}
