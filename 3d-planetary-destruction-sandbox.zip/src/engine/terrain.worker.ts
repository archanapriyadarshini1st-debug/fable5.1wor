/// <reference lib="webworker" />
import { generateHeightField } from './terrain';
import type { PlanetDef } from './types';

/** Terrain generation runs off the main thread so the loading screen / UI stay responsive. */
self.onmessage = (e: MessageEvent<{ def: PlanetDef; width: number; height: number; job: number }>) => {
  const { def, width, height, job } = e.data;
  try {
    const field = generateHeightField(def, width, height, (p) => {
      (self as unknown as Worker).postMessage({ job, progress: p });
    });
    (self as unknown as Worker).postMessage({ job, done: true, width: field.width, height: field.height, seaLevel: field.seaLevel, data: field.data }, [field.data.buffer]);
  } catch (err) {
    (self as unknown as Worker).postMessage({ job, error: String(err) });
  }
};
