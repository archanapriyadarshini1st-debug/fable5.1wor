import { RNG, hashSeed } from './noise';
import type { PlanetDef, PlanetPalette, PlanetType, StarClass, StarDef } from './types';

const EARTH_RADIUS = 6371;

export const STAR_CLASSES: Record<StarClass, StarDef> = {
  'red-dwarf': { starClass: 'red-dwarf', name: 'Red Dwarf', color: '#ff6a3d', glow: '#ff3b1f', radius: 0.45, temperature: 3200 },
  orange: { starClass: 'orange', name: 'Orange Star', color: '#ffb066', glow: '#ff8a3a', radius: 0.8, temperature: 4800 },
  'sun-like': { starClass: 'sun-like', name: 'Sun-like Star', color: '#fff2c8', glow: '#ffc25a', radius: 1.0, temperature: 5800 },
  'blue-white': { starClass: 'blue-white', name: 'Blue-White Star', color: '#cfe4ff', glow: '#7fb4ff', radius: 1.6, temperature: 12000 },
  giant: { starClass: 'giant', name: 'Giant Star', color: '#ffd9a8', glow: '#ff9a4a', radius: 3.2, temperature: 4200 },
};

const PALETTES: Record<Exclude<PlanetType, 'custom'>, PlanetPalette> = {
  rocky: { ocean: '#0b2e5c', shallow: '#1b6fa8', land: '#3f6b2f', highland: '#7a6a3a', mountain: '#6b6560', ice: '#e9f2ff', atmosphere: '#6fb0ff', cloud: '#ffffff', crust: '#4a3a2c', mantle: '#ff5a1a', core: '#fff0a0' },
  ocean: { ocean: '#042a5e', shallow: '#0f7fb8', land: '#2f6f4a', highland: '#5c7a4b', mountain: '#7c8a80', ice: '#ecf6ff', atmosphere: '#66a8ff', cloud: '#ffffff', crust: '#2f3a44', mantle: '#ff6a24', core: '#ffe9a0' },
  desert: { ocean: '#5a3a25', shallow: '#8b5a3a', land: '#b8743c', highland: '#c9925a', mountain: '#8a5a3a', ice: '#f2e6d8', atmosphere: '#e9a070', cloud: '#f5dcc0', crust: '#5a2f1c', mantle: '#ff7a2a', core: '#ffe6a8' },
  ice: { ocean: '#1a3a5a', shallow: '#3a7aa8', land: '#c9dcea', highland: '#dfeaf4', mountain: '#9fb2c2', ice: '#f6fbff', atmosphere: '#a8c8ff', cloud: '#ffffff', crust: '#3b4a5a', mantle: '#4fb8ff', core: '#e8f8ff' },
  gas: { ocean: '#c9a070', shallow: '#e2c39a', land: '#b58a5a', highland: '#f0dcc0', mountain: '#8f6a4a', ice: '#ffffff', atmosphere: '#e8c9a0', cloud: '#ffffff', crust: '#8a6a4a', mantle: '#ffb060', core: '#fff0c0' },
  lava: { ocean: '#ff5a10', shallow: '#ff8a20', land: '#2a1a16', highland: '#3a2a24', mountain: '#1a1210', ice: '#ff9a40', atmosphere: '#ff7a30', cloud: '#5a4a44', crust: '#1a100c', mantle: '#ff4a00', core: '#ffffc0' },
  alien: { ocean: '#3a0a6a', shallow: '#7a2ab8', land: '#1f8a7a', highland: '#5ad0b0', mountain: '#e0ff90', ice: '#e0ffff', atmosphere: '#b070ff', cloud: '#e8d0ff', crust: '#241238', mantle: '#c040ff', core: '#ffffff' },
};

type MakeInput = Partial<Omit<PlanetDef, 'palette'>> & Pick<PlanetDef, 'id' | 'name' | 'type'> & { palette?: Partial<PlanetPalette> };
function make(partial: MakeInput): PlanetDef {
  const type = partial.type;
  const base: PlanetDef = {
    id: partial.id,
    name: partial.name,
    type,
    seed: hashSeed(partial.id),
    radius: 6371,
    mass: 1,
    rotationPeriod: 24,
    axialTilt: 23.4,
    oceanCoverage: 0.6,
    atmosphereDensity: 0.7,
    temperature: 288,
    terrainRoughness: 0.5,
    mountainFrequency: 0.5,
    craterDensity: 0.1,
    iceCoverage: 0.15,
    cloudCoverage: 0.5,
    magneticField: 0.6,
    hasRings: false,
    cityLights: false,
    palette: { ...PALETTES[type === 'custom' ? 'rocky' : type] },
    description: '',
    composition: 'Silicate rock, iron-nickel core',
    system: 'Local System',
    satellites: 0,
    orbit: 1,
    handcrafted: true,
  };
  return { ...base, ...partial, palette: { ...base.palette, ...(partial.palette ?? {}) } };
}

export const PLANET_PRESETS: PlanetDef[] = [
  make({
    id: 'terra', name: 'Terra Prime', type: 'rocky', description: 'A temperate ocean-and-continent world with a dense nitrogen–oxygen atmosphere, polar ice and glowing settlements on its night side.',
    cityLights: true, satellites: 1, orbit: 1.0, oceanCoverage: 0.66, iceCoverage: 0.14, cloudCoverage: 0.55, terrainRoughness: 0.5, mountainFrequency: 0.55, magneticField: 0.7,
  }),
  make({
    id: 'rubra', name: 'Rubra', type: 'desert', description: 'A cold, dusty desert world with a thin carbon-dioxide atmosphere, vast canyon systems and ancient impact basins.',
    radius: 3390, mass: 0.107, rotationPeriod: 24.6, axialTilt: 25.2, oceanCoverage: 0.0, atmosphereDensity: 0.15, temperature: 210, terrainRoughness: 0.6, mountainFrequency: 0.35, craterDensity: 0.6, iceCoverage: 0.06, cloudCoverage: 0.08, magneticField: 0.05, satellites: 2, orbit: 1.52,
    composition: 'Basaltic crust, iron-sulfide core', palette: { atmosphere: '#e29a6a' },
  }),
  make({
    id: 'thalassa', name: 'Thalassa', type: 'ocean', description: 'A super-ocean world: a single global sea hundreds of kilometres deep over a high-pressure ice mantle. Only scattered volcanic islands break the surface.',
    radius: 8200, mass: 2.4, rotationPeriod: 31, axialTilt: 8, oceanCoverage: 0.94, atmosphereDensity: 0.9, temperature: 296, terrainRoughness: 0.35, mountainFrequency: 0.7, craterDensity: 0.0, iceCoverage: 0.04, cloudCoverage: 0.7, magneticField: 0.8, orbit: 0.92,
    composition: 'Water, high-pressure ice VII, silicate core',
  }),
  make({
    id: 'glacia', name: 'Glacia', type: 'ice', description: 'A frozen world locked beneath kilometres of fractured ice. Tidal heating keeps a hidden liquid ocean warm beneath the crust.',
    radius: 2600, mass: 0.02, rotationPeriod: 85, axialTilt: 2, oceanCoverage: 0.3, atmosphereDensity: 0.05, temperature: 110, terrainRoughness: 0.3, mountainFrequency: 0.2, craterDensity: 0.35, iceCoverage: 0.95, cloudCoverage: 0.0, magneticField: 0.1, orbit: 5.2,
    composition: 'Water ice shell, subsurface ocean, rocky core', palette: { mantle: '#3ea6ff', core: '#d8f4ff' },
  }),
  make({
    id: 'pyros', name: 'Pyros', type: 'lava', description: 'A tidally-locked hellscape orbiting close to its star. Molten silicate oceans glow on the day side; a thin basalt crust floats over a churning mantle.',
    radius: 5900, mass: 0.9, rotationPeriod: 200, axialTilt: 0, oceanCoverage: 0.45, atmosphereDensity: 0.3, temperature: 1900, terrainRoughness: 0.7, mountainFrequency: 0.5, craterDensity: 0.05, iceCoverage: 0.0, cloudCoverage: 0.15, magneticField: 0.3, orbit: 0.05,
    composition: 'Molten silicates, iron core',
  }),
  make({
    id: 'aurelius', name: 'Aurelius', type: 'gas', description: 'A banded gas giant with a vast ring system. No solid surface: destructive events tear storms into its layered atmosphere rather than cratering it.',
    radius: 62000, mass: 318, rotationPeriod: 9.9, axialTilt: 3.1, oceanCoverage: 0, atmosphereDensity: 1.0, temperature: 130, terrainRoughness: 0.4, mountainFrequency: 0.3, craterDensity: 0, iceCoverage: 0, cloudCoverage: 0.9, magneticField: 1.0, hasRings: true, satellites: 79, orbit: 5.4,
    composition: 'Hydrogen, helium, metallic hydrogen interior',
  }),
  make({
    id: 'xenith', name: 'Xenith', type: 'alien', description: 'A violet-skied exoworld with bioluminescent continents and crystalline mountain ranges. Its exotic chemistry is entirely fictional.',
    radius: 7400, mass: 1.6, rotationPeriod: 17, axialTilt: 41, oceanCoverage: 0.5, atmosphereDensity: 0.8, temperature: 305, terrainRoughness: 0.75, mountainFrequency: 0.8, craterDensity: 0.1, iceCoverage: 0.05, cloudCoverage: 0.35, magneticField: 0.9, cityLights: true, satellites: 3, orbit: 1.3,
    composition: 'Silicon-carbide crust, exotic mantle (fictional)',
  }),
  make({
    id: 'demo', name: 'Proving Ground', type: 'rocky', description: 'A demonstration world tuned to show every layer of the engine: high relief, thin oceans, dense craters and an exaggerated molten interior.',
    radius: 5000, mass: 0.6, rotationPeriod: 12, axialTilt: 15, oceanCoverage: 0.4, atmosphereDensity: 0.5, temperature: 270, terrainRoughness: 0.9, mountainFrequency: 0.9, craterDensity: 0.8, iceCoverage: 0.1, cloudCoverage: 0.3, magneticField: 0.5, cityLights: true, orbit: 1.1,
    palette: { mantle: '#ff7a1a', core: '#ffffd0' },
  }),
];

const NAME_A = ['Ka', 'Vel', 'Or', 'Thy', 'Nu', 'Sar', 'Ilo', 'Bry', 'Quo', 'Zeph', 'Mar', 'Ela', 'Dru', 'Tor', 'Hesp'];
const NAME_B = ['ra', 'dun', 'ion', 'eth', 'ara', 'os', 'ix', 'una', 'vex', 'mir', 'tal', 'yss', 'gon', 'ael'];
const NAME_C = ['', '', ' II', ' IV', ' Prime', ' Minor', '-7', ' b', ' c'];

function hexLerp(a: string, b: string, t: number) {
  const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
  const r = Math.round(((pa >> 16) & 255) * (1 - t) + ((pb >> 16) & 255) * t);
  const g = Math.round(((pa >> 8) & 255) * (1 - t) + ((pb >> 8) & 255) * t);
  const bl = Math.round((pa & 255) * (1 - t) + (pb & 255) * t);
  return '#' + ((r << 16) | (g << 8) | bl).toString(16).padStart(6, '0');
}
function hsl(h: number, s: number, l: number) {
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    return Math.round(255 * c).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

/** Coherent procedural random world. Parameters are correlated (temperature drives ice/ocean etc). */
export function randomPlanet(seed = Math.floor(Math.random() * 1e9)): PlanetDef {
  const r = new RNG(seed);
  const types: PlanetType[] = ['rocky', 'rocky', 'ocean', 'desert', 'ice', 'gas', 'lava', 'alien'];
  const type = r.pick(types);
  const name = r.pick(NAME_A) + r.pick(NAME_B) + r.pick(NAME_C);
  const base = make({ id: `rnd-${seed}`, name, type, seed });
  base.handcrafted = false;
  base.system = `${r.pick(NAME_A)}${r.pick(NAME_B)} System`;
  const hue = r.range(0, 360);
  if (type === 'gas') {
    base.radius = r.range(25000, 80000);
    base.mass = (base.radius / 62000) ** 3 * r.range(200, 400);
    base.rotationPeriod = r.range(7, 18);
    base.hasRings = r.next() < 0.6;
    base.satellites = r.int(4, 90);
    base.temperature = r.range(80, 300);
    base.cloudCoverage = 1;
    base.atmosphereDensity = 1;
    base.oceanCoverage = 0;
    base.palette.land = hsl(hue, 0.35, 0.45);
    base.palette.highland = hsl(hue + r.range(-20, 20), 0.3, 0.75);
    base.palette.ocean = hsl(hue + 30, 0.4, 0.5);
    base.palette.shallow = hsl(hue - 20, 0.3, 0.65);
    base.palette.atmosphere = hsl(hue, 0.4, 0.7);
    base.orbit = r.range(3, 15);
  } else {
    base.radius = r.range(2200, 9500);
    const density = r.range(0.7, 1.3);
    base.mass = (base.radius / EARTH_RADIUS) ** 3 * density;
    base.rotationPeriod = r.next() < 0.1 ? -r.range(10, 60) : r.range(8, 90);
    base.axialTilt = r.range(0, 45);
    base.orbit = type === 'lava' ? r.range(0.03, 0.2) : type === 'ice' ? r.range(2, 8) : r.range(0.6, 1.8);
    base.temperature = type === 'lava' ? r.range(1200, 2400) : type === 'ice' ? r.range(60, 180) : r.range(220, 330);
    base.atmosphereDensity = type === 'ice' ? r.range(0, 0.3) : r.range(0.2, 1);
    base.terrainRoughness = r.range(0.25, 0.95);
    base.mountainFrequency = r.range(0.2, 0.95);
    base.craterDensity = base.atmosphereDensity < 0.3 ? r.range(0.3, 0.9) : r.range(0, 0.3);
    base.iceCoverage = base.temperature < 200 ? r.range(0.6, 1) : base.temperature < 290 ? r.range(0.05, 0.3) : r.range(0, 0.05);
    base.oceanCoverage = type === 'ocean' ? r.range(0.85, 0.98) : type === 'desert' ? r.range(0, 0.08) : type === 'lava' ? r.range(0.2, 0.6) : type === 'ice' ? r.range(0.1, 0.5) : r.range(0.3, 0.75);
    base.cloudCoverage = base.atmosphereDensity * r.range(0.3, 0.9);
    base.magneticField = r.range(0, 1);
    base.satellites = r.int(0, 4);
    base.cityLights = (type === 'rocky' || type === 'alien') && r.next() < 0.5;
    base.hasRings = r.next() < 0.12;
    if (type === 'alien') {
      base.palette.ocean = hsl(hue, 0.7, 0.2);
      base.palette.shallow = hsl(hue, 0.7, 0.45);
      base.palette.land = hsl(hue + 120, 0.5, 0.35);
      base.palette.highland = hsl(hue + 150, 0.45, 0.55);
      base.palette.mountain = hsl(hue + 180, 0.3, 0.7);
      base.palette.atmosphere = hsl(hue + 40, 0.6, 0.7);
      base.palette.mantle = hsl(hue + 60, 0.9, 0.55);
    } else if (type === 'rocky') {
      base.palette.land = hexLerp(base.palette.land, hsl(hue, 0.3, 0.35), 0.35);
      base.palette.highland = hexLerp(base.palette.highland, hsl(hue, 0.25, 0.5), 0.35);
    } else if (type === 'desert') {
      base.palette.land = hsl(r.range(15, 45), 0.5, 0.45);
      base.palette.highland = hsl(r.range(20, 50), 0.4, 0.6);
      base.palette.atmosphere = hsl(r.range(15, 45), 0.5, 0.65);
    }
  }
  base.description = `Procedurally generated ${TYPE_LABEL[type].toLowerCase()} world (seed ${seed}).`;
  return base;
}

export const TYPE_LABEL: Record<PlanetType, string> = {
  rocky: 'Rocky',
  ocean: 'Ocean',
  desert: 'Desert',
  ice: 'Ice',
  gas: 'Gas Giant',
  lava: 'Lava',
  alien: 'Alien',
  custom: 'Custom',
};

export function defaultPalette(type: PlanetType): PlanetPalette {
  return { ...PALETTES[type === 'custom' ? 'rocky' : type] };
}

/** Derived physical quantities (approximations for display). */
export function planetStats(def: PlanetDef) {
  const rEarth = def.radius / EARTH_RADIUS;
  const gravity = (def.mass / (rEarth * rEarth)) * 9.81; // m/s^2
  const volume = (4 / 3) * Math.PI * Math.pow(def.radius * 1e3, 3);
  const massKg = def.mass * 5.972e24;
  const density = massKg / volume / 1000; // g/cm3
  const escape = Math.sqrt((2 * 6.674e-11 * massKg) / (def.radius * 1e3)) / 1000; // km/s
  const dayLength = Math.abs(def.rotationPeriod);
  const surfaceArea = 4 * Math.PI * def.radius * def.radius; // km^2
  return { gravity, density, escape, dayLength, surfaceArea, massKg, volume };
}

export function starForPlanet(def: PlanetDef): StarDef {
  if (def.type === 'lava') return STAR_CLASSES['orange'];
  if (def.type === 'ice') return STAR_CLASSES['red-dwarf'];
  if (def.type === 'alien') return STAR_CLASSES['blue-white'];
  return STAR_CLASSES['sun-like'];
}

export function clonePlanet(def: PlanetDef): PlanetDef {
  return JSON.parse(JSON.stringify(def));
}
