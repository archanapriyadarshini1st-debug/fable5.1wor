/** Shared simulation / UI types. Simulation state is kept OUT of React; these types describe the boundary. */

export type PlanetType = 'rocky' | 'ocean' | 'desert' | 'ice' | 'gas' | 'lava' | 'alien' | 'custom';

export interface PlanetPalette {
  ocean: string;
  shallow: string;
  land: string;
  highland: string;
  mountain: string;
  ice: string;
  atmosphere: string;
  cloud: string;
  crust: string;
  mantle: string;
  core: string;
}

export interface PlanetDef {
  id: string;
  name: string;
  type: PlanetType;
  seed: number;
  /** km */
  radius: number;
  /** Earth masses */
  mass: number;
  /** hours per rotation (negative = retrograde) */
  rotationPeriod: number;
  /** degrees */
  axialTilt: number;
  oceanCoverage: number; // 0..1
  atmosphereDensity: number; // 0..1
  /** Kelvin (mean surface) */
  temperature: number;
  terrainRoughness: number; // 0..1
  mountainFrequency: number; // 0..1
  craterDensity: number; // 0..1
  iceCoverage: number; // 0..1
  cloudCoverage: number; // 0..1
  magneticField: number; // 0..1
  hasRings: boolean;
  cityLights: boolean;
  palette: PlanetPalette;
  description: string;
  composition: string;
  system: string;
  satellites: number;
  /** orbital distance, AU (informational) */
  orbit: number;
  handcrafted?: boolean;
}

export type StarClass = 'red-dwarf' | 'orange' | 'sun-like' | 'blue-white' | 'giant';

export interface StarDef {
  starClass: StarClass;
  color: string;
  glow: string;
  radius: number;
  temperature: number;
  name: string;
}

export type ToolCategory = 'impact' | 'energy' | 'gravity' | 'space' | 'anomaly' | 'cosmic' | 'special';

export type ToolId =
  | 'asteroid'
  | 'meteor-swarm'
  | 'energy-pulse'
  | 'plasma-burst'
  | 'gravity-anomaly'
  | 'spatial-distortion'
  | 'stellar-flare'
  | 'cosmic-shockwave'
  | 'matter-displacement'
  | 'exotic-strike';

export interface ToolParamDef {
  key: string;
  label: string;
  min: number;
  max: number;
  step: number;
  default: number;
  unit?: string;
}

export interface ToolDef {
  id: ToolId;
  name: string;
  category: ToolCategory;
  description: string;
  color: string;
  params: ToolParamDef[];
  /** approximate angular radius preview function (in planet radii of arc) */
  previewRadius: (p: Record<string, number>) => number;
  glyph: string;
}

export interface SimEvent {
  id: number;
  type:
    | 'WORLD_CREATED'
    | 'EVENT_TRIGGERED'
    | 'PLANET_IMPACT'
    | 'TERRAIN_DAMAGED'
    | 'ATMOSPHERE_DISTURBED'
    | 'DEBRIS_GENERATED'
    | 'BODY_FRAGMENTED'
    | 'COLLISION'
    | 'RESET'
    | 'SNAPSHOT'
    | 'BODY_ADDED'
    | 'BODY_REMOVED'
    | 'REPLAY';
  time: number; // simulation seconds
  wall: number; // Date.now()
  label: string;
  data?: Record<string, unknown>;
}

export interface ReplayAction {
  time: number;
  tool: ToolId;
  params: Record<string, number>;
  lat: number;
  lon: number;
  seed: number;
}
export interface ReplayCameraKey {
  time: number;
  theta: number;
  phi: number;
  dist: number;
}
export interface Replay {
  id: string;
  name: string;
  planetId: string;
  planet: PlanetDef;
  actions: ReplayAction[];
  camera: ReplayCameraKey[];
  duration: number;
  createdAt: number;
}

export interface Snapshot {
  id: string;
  name: string;
  parent: string | null;
  time: number;
  integrity: number;
  removedVolume: number;
  damage: Float32Array;
  broken: boolean;
  createdAt: number;
}

export interface PlanetStats {
  integrity: number; // 0..1
  removedVolume: number; // fraction of planet volume
  atmosphereDisturbance: number; // 0..1
  debrisCount: number;
  interiorExposure: number; // 0..1
  surfaceTemperature: number; // K
  fragmentation: number; // 0..1
  broken: boolean;
  events: number;
}

export type Quality = 'cinematic' | 'high' | 'balanced' | 'performance';

export interface Settings {
  quality: Quality;
  particleScale: number; // 0.25..2
  shadows: boolean;
  postProcessing: boolean;
  cameraShake: number; // 0..1
  reducedMotion: boolean;
  reducedFlashing: boolean;
  highContrast: boolean;
  uiScale: number; // 0.85..1.4
  musicVolume: number;
  sfxVolume: number;
  masterVolume: number;
  invertZoom: boolean;
  showHints: boolean;
  scientificMode: boolean;
}

export interface SystemBodyDef {
  id: string;
  name: string;
  kind: 'star' | 'planet' | 'moon' | 'rogue' | 'fragment';
  mass: number;
  radius: number;
  position: [number, number, number];
  velocity: [number, number, number];
  color: string;
  seed: number;
  starClass?: StarClass;
  parent?: string;
  planetType?: PlanetType;
}

export interface SystemDef {
  id: string;
  name: string;
  bodies: SystemBodyDef[];
  createdAt: number;
}

export interface DebugInfo {
  fps: number;
  frameMs: number;
  drawCalls: number;
  triangles: number;
  particles: number;
  debris: number;
  fragments: number;
  chunks: number;
  lod: string;
  simTime: number;
  physicsMs: number;
  camDist: number;
  gpu: string;
  quality: string;
}
