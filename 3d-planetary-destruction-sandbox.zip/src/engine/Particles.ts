import * as THREE from 'three';
import { PARTICLE_FRAG, PARTICLE_VERT } from './shaders/effects';

export type ParticleKind = 0 | 1 | 2; // 0 dust, 1 spark/ember, 2 steam/smoke

/**
 * GPU particle pool. Emission writes into a ring buffer of attributes; all motion is evaluated on the GPU
 * from the simulation clock, so pausing / slow-motion / fast-forward are free and exact.
 */
export class ParticleSystem {
  readonly points: THREE.Points;
  private geo: THREE.BufferGeometry;
  private mat: THREE.ShaderMaterial;
  private head = 0;
  private pos: Float32Array;
  private vel: Float32Array;
  private start: Float32Array;
  private life: Float32Array;
  private size: Float32Array;
  private color: Float32Array;
  private kind: Float32Array;
  private dirty = false;
  readonly capacity: number;
  alive = 0;
  private aliveUntil: Float32Array;

  constructor(capacity: number) {
    this.capacity = capacity;
    this.geo = new THREE.BufferGeometry();
    this.pos = new Float32Array(capacity * 3);
    this.vel = new Float32Array(capacity * 3);
    this.start = new Float32Array(capacity).fill(-1e9);
    this.life = new Float32Array(capacity);
    this.size = new Float32Array(capacity);
    this.color = new Float32Array(capacity * 3);
    this.kind = new Float32Array(capacity);
    this.aliveUntil = new Float32Array(capacity);
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aVel', new THREE.BufferAttribute(this.vel, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aStart', new THREE.BufferAttribute(this.start, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aLife', new THREE.BufferAttribute(this.life, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aSize', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aColor', new THREE.BufferAttribute(this.color, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('aKind', new THREE.BufferAttribute(this.kind, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.mat = new THREE.ShaderMaterial({
      vertexShader: PARTICLE_VERT,
      fragmentShader: PARTICLE_FRAG,
      uniforms: { uTime: { value: 0 }, uGravity: { value: 0.15 }, uPixelRatio: { value: 1 }, uSurface: { value: 1 } },
      transparent: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }

  setPixelRatio(pr: number) { this.mat.uniforms.uPixelRatio.value = pr; }
  setGravity(g: number) { this.mat.uniforms.uGravity.value = g; }
  setSurface(r: number) { this.mat.uniforms.uSurface.value = r; }

  emit(p: THREE.Vector3, v: THREE.Vector3, now: number, life: number, size: number, color: THREE.Color, kind: ParticleKind) {
    const i = this.head;
    this.head = (this.head + 1) % this.capacity;
    this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
    this.vel[i * 3] = v.x; this.vel[i * 3 + 1] = v.y; this.vel[i * 3 + 2] = v.z;
    this.start[i] = now; this.life[i] = life; this.size[i] = size; this.kind[i] = kind;
    this.color[i * 3] = color.r; this.color[i * 3 + 1] = color.g; this.color[i * 3 + 2] = color.b;
    this.aliveUntil[i] = now + life;
    this.dirty = true;
  }

  /** Emits a burst in a cone around `dir` from `origin`. */
  burst(origin: THREE.Vector3, dir: THREE.Vector3, count: number, now: number, opts: { speed: number; spread: number; life: number; size: number; color: THREE.Color; kind: ParticleKind; colorJitter?: number; sizeJitter?: number }) {
    const tmpV = new THREE.Vector3();
    const tmpC = new THREE.Color();
    const cj = opts.colorJitter ?? 0.15;
    for (let k = 0; k < count; k++) {
      tmpV.set(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiplyScalar(opts.spread);
      tmpV.add(dir).normalize().multiplyScalar(opts.speed * (0.35 + Math.random() * 0.9));
      tmpC.copy(opts.color).offsetHSL(0, 0, (Math.random() - 0.5) * cj);
      this.emit(origin, tmpV, now, opts.life * (0.6 + Math.random() * 0.8), opts.size * (1 - (opts.sizeJitter ?? 0.5) * Math.random()), tmpC, opts.kind);
    }
  }

  update(simTime: number) {
    this.mat.uniforms.uTime.value = simTime;
    if (this.dirty) {
      for (const name of ['position', 'aVel', 'aStart', 'aLife', 'aSize', 'aColor', 'aKind']) (this.geo.getAttribute(name) as THREE.BufferAttribute).needsUpdate = true;
      this.dirty = false;
    }
    // cheap alive count (sampled) for debug stats
    let a = 0;
    for (let i = 0; i < this.capacity; i += 16) if (this.aliveUntil[i] > simTime && this.start[i] <= simTime) a++;
    this.alive = a * 16;
  }

  clear() {
    this.start.fill(-1e9);
    this.aliveUntil.fill(0);
    this.dirty = true;
    this.alive = 0;
  }

  dispose() { this.geo.dispose(); this.mat.dispose(); }
}
