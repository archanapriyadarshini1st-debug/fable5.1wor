import * as THREE from 'three';
import { CameraRig } from './CameraRig';
import { bus, simEvent } from './EventBus';
import { RNG, clamp } from './noise';
import { ParticleSystem } from './Particles';
import { PostFX } from './PostFX';
import { SpaceBackground, StarObject } from './Space';
import { STAR_CLASSES } from './planets';
import { BODY_FRAG, BODY_VERT, GRID_FRAG, GRID_VERT } from './shaders/effects';
import type { DebugInfo, Settings, StarClass, SystemBodyDef, SystemDef } from './types';

const G = 1;
const SOFT = 0.05;
const TRAIL = 360;

export interface SystemBody {
  def: SystemBodyDef;
  id: string;
  name: string;
  kind: SystemBodyDef['kind'];
  mass: number;
  radius: number;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  acc: THREE.Vector3;
  mesh: THREE.Object3D;
  mat?: THREE.ShaderMaterial;
  star?: StarObject;
  trail: Float32Array;
  trailLen: number;
  trailLine: THREE.Line;
  color: THREE.Color;
  alive: boolean;
  baseRadius: number;
}

export type SystemTool = 'select' | 'add-planet' | 'add-moon' | 'add-rogue' | 'anomaly' | 'nudge' | 'measure';

export interface SystemOverlays { orbits: boolean; velocity: boolean; gravity: boolean; labels: boolean; distances: boolean }

/** Generates a coherent procedural star system. Units: 1 length unit ≈ 0.1 AU (display), G = 1. */
export function generateSystem(seed: number, name?: string): SystemDef {
  const r = new RNG(seed);
  const classes: StarClass[] = ['red-dwarf', 'orange', 'sun-like', 'sun-like', 'blue-white', 'giant'];
  const sc = r.pick(classes);
  const starMass = sc === 'red-dwarf' ? 400 : sc === 'orange' ? 700 : sc === 'sun-like' ? 1000 : sc === 'blue-white' ? 1800 : 1400;
  const bodies: SystemBodyDef[] = [{ id: 'star', name: name ?? 'Primary', kind: 'star', mass: starMass, radius: STAR_CLASSES[sc].radius * 1.4, position: [0, 0, 0], velocity: [0, 0, 0], color: STAR_CLASSES[sc].color, seed, starClass: sc }];
  const n = r.int(3, 7);
  let d = 5 + r.range(0, 3);
  const NAMES = ['Ael', 'Brix', 'Cor', 'Dai', 'Eno', 'Fyr', 'Gal', 'Hux', 'Ith', 'Jor'];
  for (let i = 0; i < n; i++) {
    const gas = d > 16 && r.next() < 0.6;
    const mass = gas ? r.range(3, 12) : r.range(0.2, 2);
    const radius = gas ? r.range(0.45, 0.8) : r.range(0.15, 0.32);
    const ang = r.range(0, Math.PI * 2);
    const v = Math.sqrt((G * starMass) / d) * r.range(0.96, 1.04);
    const hue = r.range(0, 360);
    const col = new THREE.Color().setHSL(hue / 360, gas ? 0.35 : 0.45, 0.5).getStyle();
    const id = `p${i}`;
    bodies.push({ id, name: `${NAMES[i]}${r.pick(['a', 'os', 'ia', 'en'])}`, kind: 'planet', mass, radius, position: [Math.cos(ang) * d, 0, Math.sin(ang) * d], velocity: [-Math.sin(ang) * v, 0, Math.cos(ang) * v], color: col, seed: seed + i * 7, planetType: gas ? 'gas' : r.pick(['rocky', 'ocean', 'desert', 'ice']) });
    if (r.next() < (gas ? 0.8 : 0.35)) {
      const md = radius * (3 + r.range(0, 3));
      const mv = Math.sqrt((G * mass) / md);
      const ma = r.range(0, Math.PI * 2);
      bodies.push({ id: `${id}m`, name: `${NAMES[i]} I`, kind: 'moon', parent: id, mass: mass * r.range(0.01, 0.05), radius: radius * r.range(0.22, 0.35), position: [Math.cos(ang) * d + Math.cos(ma) * md, 0, Math.sin(ang) * d + Math.sin(ma) * md], velocity: [-Math.sin(ang) * v - Math.sin(ma) * mv, 0, Math.cos(ang) * v + Math.cos(ma) * mv], color: '#9a948c', seed: seed + i * 13, planetType: 'rocky' });
    }
    d *= r.range(1.45, 1.9);
  }
  return { id: `sys-${seed}`, name: name ?? `System ${seed.toString(36).toUpperCase()}`, bodies, createdAt: Date.now() };
}

export class SystemScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly rig: CameraRig;
  readonly particles: ParticleSystem;
  private space: SpaceBackground;
  private post: PostFX;
  private container: HTMLElement;
  private settings: Settings;
  private ro: ResizeObserver;
  private raf = 0;
  private lastWall = performance.now();
  private wallTime = 0;
  simTime = 0;
  speed = 1;
  paused = false;
  bodies: SystemBody[] = [];
  private original: SystemDef;
  current: SystemDef;
  selectedId: string | null = null;
  tool: SystemTool = 'select';
  overlays: SystemOverlays = { orbits: true, velocity: false, gravity: false, labels: true, distances: false };
  private grid: THREE.Mesh;
  private gridMat: THREE.ShaderMaterial;
  private velLines: THREE.LineSegments;
  private distRings: THREE.Group;
  private selRing: THREE.Mesh;
  private anomalies: { pos: THREE.Vector3; mass: number; until: number; mesh: THREE.Mesh }[] = [];
  private measure: THREE.Vector3[] = [];
  private measureLine: THREE.Line;
  private statsTimer = 0;
  private fps = 60;
  private physMs = 0;
  onLabels?: (l: { id: string; name: string; x: number; y: number; visible: boolean; kind: string }[]) => void;
  onDebug?: (d: DebugInfo) => void;
  onChange?: () => void;
  onMeasure?: (m: { distance: number; points: number } | null) => void;
  disposed = false;
  collisions = 0;

  constructor(container: HTMLElement, settings: Settings, def: SystemDef) {
    this.container = container; this.settings = settings;
    this.original = JSON.parse(JSON.stringify(def)); this.current = JSON.parse(JSON.stringify(def));
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { antialias: true, powerPreference: 'high-performance' });
    if (!gl) throw new Error('WebGL2 is not available on this device/browser.');
    this.renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: true });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(canvas);
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
    this.camera = new THREE.PerspectiveCamera(45, 1, 0.05, 6000);
    this.rig = new CameraRig(this.camera, canvas);
    this.rig.minDist = 0.6; this.rig.maxDist = 220;
    this.rig.setView(0.7, 0.95, 34, true);
    this.rig.shakeIntensity = settings.cameraShake; this.rig.reducedMotion = settings.reducedMotion; this.rig.invertZoom = settings.invertZoom;
    this.space = new SpaceBackground(def.bodies[0]?.seed ?? 7, '#1a1440', '#0a2236', settings.quality === 'performance' ? 0.5 : 1);
    this.scene.add(this.space.group);
    this.particles = new ParticleSystem(settings.quality === 'performance' ? 6000 : 20000);
    this.particles.setGravity(0.0); this.particles.setSurface(0);
    this.scene.add(this.particles.points);

    this.gridMat = new THREE.ShaderMaterial({ vertexShader: GRID_VERT, fragmentShader: GRID_FRAG, transparent: true, depthWrite: false, uniforms: { uMasses: { value: Array.from({ length: 24 }, () => new THREE.Vector4()) }, uCount: { value: 0 }, uScale: { value: 0.012 }, uColor: { value: new THREE.Color('#5aa0ff') } }, wireframe: true });
    this.grid = new THREE.Mesh(new THREE.PlaneGeometry(160, 160, 120, 120).rotateX(-Math.PI / 2), this.gridMat);
    this.grid.position.y = -0.5; this.grid.visible = false; this.grid.frustumCulled = false;
    this.scene.add(this.grid);
    this.velLines = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xffc36b, transparent: true, opacity: 0.9 }));
    this.velLines.visible = false; this.velLines.frustumCulled = false;
    this.scene.add(this.velLines);
    this.distRings = new THREE.Group(); this.distRings.visible = false;
    for (let r = 10; r <= 80; r += 10) { const g = new THREE.BufferGeometry().setFromPoints(Array.from({ length: 129 }, (_, i) => new THREE.Vector3(Math.cos((i / 128) * Math.PI * 2) * r, 0, Math.sin((i / 128) * Math.PI * 2) * r))); this.distRings.add(new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0x8899aa, transparent: true, opacity: 0.18 }))); }
    this.scene.add(this.distRings);
    this.selRing = new THREE.Mesh(new THREE.RingGeometry(1.25, 1.32, 64), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthTest: false }));
    this.selRing.visible = false; this.selRing.renderOrder = 30;
    this.scene.add(this.selRing);
    this.measureLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0x8fffe0 }));
    this.measureLine.visible = false; this.measureLine.frustumCulled = false;
    this.scene.add(this.measureLine);

    this.build(this.current);
    this.post = new PostFX(this.renderer, this.scene, this.camera, settings.quality);
    this.post.enabled = settings.postProcessing;
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(container);
    this.resize();
    this.loop();
  }

  private resize() {
    const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1;
    const pr = Math.min(window.devicePixelRatio || 1, this.settings.quality === 'performance' ? 1 : 1.75);
    this.renderer.setPixelRatio(pr); this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.post.setSize(w, h, pr); this.particles.setPixelRatio(pr); this.space.setPixelRatio(pr);
  }
  applySettings(s: Settings) { this.settings = s; this.post.enabled = s.postProcessing; this.post.setQuality(s.quality); this.rig.shakeIntensity = s.cameraShake; this.rig.reducedMotion = s.reducedMotion; this.rig.invertZoom = s.invertZoom; this.resize(); }

  private clearBodies() {
    for (const b of this.bodies) { this.scene.remove(b.mesh); this.scene.remove(b.trailLine); b.trailLine.geometry.dispose(); b.mat?.dispose(); b.star?.dispose(); if (b.mesh instanceof THREE.Mesh) b.mesh.geometry.dispose(); }
    this.bodies = [];
    for (const a of this.anomalies) { this.scene.remove(a.mesh); }
    this.anomalies = [];
  }

  private build(def: SystemDef) {
    this.clearBodies();
    for (const b of def.bodies) this.addBodyInternal(b);
    this.onChange?.();
  }

  private addBodyInternal(d: SystemBodyDef): SystemBody {
    const color = new THREE.Color(d.color);
    let mesh: THREE.Object3D; let mat: THREE.ShaderMaterial | undefined; let star: StarObject | undefined;
    if (d.kind === 'star') {
      star = new StarObject(STAR_CLASSES[d.starClass ?? 'sun-like'], d.radius);
      mesh = star.group;
    } else {
      const seg = d.kind === 'moon' || d.kind === 'fragment' ? 24 : 48;
      const gas = d.planetType === 'gas';
      const colB = color.clone().offsetHSL(gas ? 0.02 : 0.08, 0, gas ? 0.2 : -0.2);
      mat = new THREE.ShaderMaterial({ vertexShader: BODY_VERT, fragmentShader: BODY_FRAG, uniforms: { uSun: { value: new THREE.Vector3() }, uSunColor: { value: new THREE.Color(1, 1, 1) }, uColorA: { value: color }, uColorB: { value: colB }, uSeed: { value: (d.seed % 100) * 0.37 }, uEmissive: { value: d.kind === 'fragment' ? 0.5 : 0 }, uGas: { value: gas ? 1 : 0 }, uTime: { value: 0 }, uOccluders: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uOccCount: { value: 0 }, uAtmo: { value: gas ? 0.6 : d.planetType === 'ocean' ? 0.8 : 0.3 } } });
      mesh = new THREE.Mesh(new THREE.SphereGeometry(d.radius, seg, seg / 2), mat);
    }
    mesh.position.fromArray(d.position);
    this.scene.add(mesh);
    const trail = new Float32Array(TRAIL * 3);
    const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(trail, 3)); tg.setDrawRange(0, 0);
    const trailLine = new THREE.Line(tg, new THREE.LineBasicMaterial({ color: d.kind === 'star' ? 0xffffff : color, transparent: true, opacity: d.kind === 'moon' ? 0.3 : 0.55 }));
    trailLine.frustumCulled = false;
    this.scene.add(trailLine);
    const body: SystemBody = { def: d, id: d.id, name: d.name, kind: d.kind, mass: d.mass, radius: d.radius, pos: new THREE.Vector3().fromArray(d.position), vel: new THREE.Vector3().fromArray(d.velocity), acc: new THREE.Vector3(), mesh, mat, star, trail, trailLen: 0, trailLine, color, alive: true, baseRadius: d.radius };
    this.bodies.push(body);
    return body;
  }

  // ------------------------------------------------------------ editor API
  addBody(d: Omit<SystemBodyDef, 'id'> & { id?: string }) {
    const def: SystemBodyDef = { ...d, id: d.id ?? `b${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}` };
    const b = this.addBodyInternal(def);
    this.current.bodies.push(def);
    simEvent('BODY_ADDED', this.simTime, `${def.name} added (${def.kind})`);
    this.onChange?.();
    return b;
  }
  removeBody(id: string) {
    const b = this.bodies.find((x) => x.id === id);
    if (!b || b.kind === 'star') return;
    b.alive = false;
    this.scene.remove(b.mesh); this.scene.remove(b.trailLine);
    this.bodies = this.bodies.filter((x) => x !== b);
    this.current.bodies = this.current.bodies.filter((x) => x.id !== id);
    if (this.selectedId === id) this.selectedId = null;
    simEvent('BODY_REMOVED', this.simTime, `${b.name} removed`);
    this.onChange?.();
  }
  updateBody(id: string, patch: Partial<{ name: string; mass: number; radius: number; speedScale: number; velocity: [number, number, number]; position: [number, number, number] }>) {
    const b = this.bodies.find((x) => x.id === id);
    if (!b) return;
    if (patch.name !== undefined) { b.name = patch.name; b.def.name = patch.name; }
    if (patch.mass !== undefined) { b.mass = Math.max(0.001, patch.mass); b.def.mass = b.mass; }
    if (patch.radius !== undefined) {
      b.radius = clamp(patch.radius, 0.03, 6); b.def.radius = b.radius;
      if (b.mesh instanceof THREE.Mesh) { b.mesh.geometry.dispose(); b.mesh.geometry = new THREE.SphereGeometry(b.radius, 48, 24); }
      else if (b.star) { b.mesh.scale.setScalar(b.radius / b.baseRadius); }
    }
    if (patch.speedScale !== undefined) b.vel.multiplyScalar(patch.speedScale);
    if (patch.velocity) b.vel.fromArray(patch.velocity);
    if (patch.position) { b.pos.fromArray(patch.position); b.trailLen = 0; }
    this.onChange?.();
  }
  /** Put the body on a circular orbit around the dominant mass. */
  circularize(id: string) {
    const b = this.bodies.find((x) => x.id === id); if (!b) return;
    const primary = this.dominant(b);
    if (!primary) return;
    const rel = b.pos.clone().sub(primary.pos);
    const d = rel.length();
    const v = Math.sqrt((G * primary.mass) / d);
    const dir = new THREE.Vector3(-rel.z, 0, rel.x).normalize();
    b.vel.copy(primary.vel).addScaledVector(dir, v);
    this.onChange?.();
  }
  private dominant(b: SystemBody) {
    let best: SystemBody | null = null, bestF = 0;
    for (const o of this.bodies) { if (o === b || !o.alive) continue; const f = o.mass / Math.max(o.pos.distanceToSquared(b.pos), 1e-4); if (f > bestF) { bestF = f; best = o; } }
    return best;
  }
  exportSystem(): SystemDef {
    return { ...this.current, bodies: this.bodies.map((b) => ({ ...b.def, name: b.name, mass: b.mass, radius: b.radius, position: b.pos.toArray() as [number, number, number], velocity: b.vel.toArray() as [number, number, number] })), createdAt: Date.now() };
  }
  loadSystem(def: SystemDef) { this.original = JSON.parse(JSON.stringify(def)); this.current = JSON.parse(JSON.stringify(def)); this.simTime = 0; this.collisions = 0; this.build(this.current); this.particles.clear(); this.selectedId = null; this.rig.followFn = null; this.rig.mode = 'orbit'; this.rig.focusOn(new THREE.Vector3()); simEvent('WORLD_CREATED', 0, `${def.name} loaded (${def.bodies.length} bodies)`); }
  reset() { this.loadSystem(this.original); simEvent('RESET', 0, 'System restored to initial configuration'); }
  setSpeed(s: number) { this.speed = s; }
  setPaused(p: boolean) { this.paused = p; }
  setOverlays(o: Partial<SystemOverlays>) { Object.assign(this.overlays, o); this.grid.visible = this.overlays.gravity; this.velLines.visible = this.overlays.velocity; this.distRings.visible = this.overlays.distances; for (const b of this.bodies) b.trailLine.visible = this.overlays.orbits; }
  select(id: string | null) { this.selectedId = id; this.onChange?.(); }
  focus(id: string, follow = true) {
    const b = this.bodies.find((x) => x.id === id); if (!b) return;
    this.rig.followFn = follow ? () => b.pos : null;
    this.rig.mode = follow ? 'follow' : 'orbit';
    this.rig.focusOn(b.pos.clone(), Math.max(b.radius * 7, 1.5));
  }
  stopFollow() { this.rig.followFn = null; this.rig.mode = 'orbit'; this.rig.focusOn(new THREE.Vector3()); }
  getState() { return { simTime: this.simTime, speed: this.speed, paused: this.paused, selected: this.selectedId, bodies: this.bodies.map((b) => ({ id: b.id, name: b.name, kind: b.kind, mass: b.mass, radius: b.radius, pos: b.pos.toArray(), vel: b.vel.toArray(), speed: b.vel.length() })), collisions: this.collisions }; }

  // ------------------------------------------------------------ interaction
  /** Ray from screen; returns body hit or point on ecliptic plane. */
  pickScreen(x: number, y: number) {
    const ndc = new THREE.Vector2((x / this.container.clientWidth) * 2 - 1, -(y / this.container.clientHeight) * 2 + 1);
    const rc = new THREE.Raycaster(); rc.setFromCamera(ndc, this.camera);
    let best: SystemBody | null = null, bestD = Infinity;
    const sph = new THREE.Sphere();
    for (const b of this.bodies) {
      const pickR = Math.max(b.radius * 1.5, this.rig.dist * 0.012);
      sph.set(b.pos, pickR);
      const hit = rc.ray.intersectSphere(sph, new THREE.Vector3());
      if (hit) { const d = hit.distanceTo(this.camera.position); if (d < bestD) { bestD = d; best = b; } }
    }
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const pt = rc.ray.intersectPlane(plane, new THREE.Vector3());
    return { body: best, point: pt };
  }
  click(x: number, y: number) {
    const { body, point } = this.pickScreen(x, y);
    const star = this.bodies.find((b) => b.kind === 'star');
    const sel = this.bodies.find((b) => b.id === this.selectedId) ?? null;
    switch (this.tool) {
      case 'select': this.select(body ? body.id : null); if (body) this.focus(body.id, true); break;
      case 'add-planet': {
        if (!point || !star) return;
        const rng = new RNG(Date.now());
        const rel = point.clone().sub(star.pos); const d = rel.length(); if (d < star.radius * 2) return;
        const v = Math.sqrt((G * star.mass) / d);
        const dir = new THREE.Vector3(-rel.z, 0, rel.x).normalize();
        const b = this.addBody({ name: `Planet ${this.bodies.length}`, kind: 'planet', mass: rng.range(0.3, 3), radius: rng.range(0.15, 0.4), position: point.toArray() as [number, number, number], velocity: star.vel.clone().addScaledVector(dir, v).toArray() as [number, number, number], color: new THREE.Color().setHSL(rng.next(), 0.5, 0.5).getStyle(), seed: rng.int(0, 1e6), planetType: rng.pick(['rocky', 'ocean', 'desert', 'ice']) });
        this.select(b.id); break;
      }
      case 'add-moon': {
        const host = body && body.kind !== 'star' ? body : sel;
        if (!host || !point) return;
        const rel = point.clone().sub(host.pos); let d = rel.length();
        if (d < host.radius * 2.2) { d = host.radius * 3; rel.set(d, 0, 0); }
        const v = Math.sqrt((G * host.mass) / d);
        const dir = new THREE.Vector3(-rel.z, 0, rel.x).normalize();
        this.addBody({ name: `${host.name} moon`, kind: 'moon', parent: host.id, mass: host.mass * 0.02, radius: Math.max(host.radius * 0.28, 0.05), position: host.pos.clone().add(rel).toArray() as [number, number, number], velocity: host.vel.clone().addScaledVector(dir, v).toArray() as [number, number, number], color: '#a09a90', seed: Date.now() % 1000, planetType: 'rocky' });
        break;
      }
      case 'add-rogue': {
        if (!point) return;
        const target = body ?? sel ?? star; if (!target) return;
        const dirV = target.pos.clone().sub(point).normalize();
        const speed = Math.sqrt((2 * G * (star?.mass ?? 1000)) / Math.max(point.length(), 1)) * 0.9;
        this.addBody({ name: 'Rogue body', kind: 'rogue', mass: 1.5, radius: 0.25, position: point.toArray() as [number, number, number], velocity: dirV.multiplyScalar(speed).toArray() as [number, number, number], color: '#c96a3a', seed: 99, planetType: 'rocky' });
        bus.emit('audio', { cue: 'whoosh', intensity: 0.6 });
        break;
      }
      case 'anomaly': {
        if (!point) return;
        const m = new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 16), new THREE.MeshBasicMaterial({ color: 0x000000 }));
        const rim = new THREE.Mesh(new THREE.SphereGeometry(0.75, 24, 16), new THREE.MeshBasicMaterial({ color: 0xb48cff, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, side: THREE.BackSide }));
        m.add(rim); m.position.copy(point); this.scene.add(m);
        this.anomalies.push({ pos: point.clone(), mass: (star?.mass ?? 1000) * 0.6, until: this.simTime + 6, mesh: m });
        simEvent('EVENT_TRIGGERED', this.simTime, 'Gravitational anomaly opened (6 s)');
        bus.emit('audio', { cue: 'charge', intensity: 0.7 });
        break;
      }
      case 'nudge': {
        if (!sel || !point) return;
        const d = point.clone().sub(sel.pos); const len = d.length(); if (len < 1e-3) return;
        sel.vel.addScaledVector(d.normalize(), Math.min(len * 0.25, 6));
        simEvent('EVENT_TRIGGERED', this.simTime, `${sel.name} nudged (Δv ${Math.min(len * 0.25, 6).toFixed(2)})`);
        break;
      }
      case 'measure': {
        const p = body ? body.pos.clone() : point; if (!p) return;
        if (this.measure.length >= 2) this.measure = [];
        this.measure.push(p);
        if (this.measure.length === 2) { this.measureLine.geometry.dispose(); this.measureLine.geometry = new THREE.BufferGeometry().setFromPoints(this.measure); this.measureLine.visible = true; this.onMeasure?.({ distance: this.measure[0].distanceTo(this.measure[1]), points: 2 }); }
        else { this.measureLine.visible = false; this.onMeasure?.({ distance: 0, points: 1 }); }
        break;
      }
    }
  }
  clearMeasure() { this.measure = []; this.measureLine.visible = false; this.onMeasure?.(null); }

  // ------------------------------------------------------------ physics
  private accelerations() {
    const bs = this.bodies;
    for (const b of bs) b.acc.set(0, 0, 0);
    const d = new THREE.Vector3();
    for (let i = 0; i < bs.length; i++) {
      const a = bs[i];
      for (let j = i + 1; j < bs.length; j++) {
        const b = bs[j];
        d.subVectors(b.pos, a.pos);
        const r2 = d.lengthSq() + SOFT * SOFT;
        const inv = 1 / (Math.sqrt(r2) * r2);
        a.acc.addScaledVector(d, G * b.mass * inv);
        b.acc.addScaledVector(d, -G * a.mass * inv);
      }
      for (const an of this.anomalies) { d.subVectors(an.pos, a.pos); const r2 = d.lengthSq() + 0.5; a.acc.addScaledVector(d, (G * an.mass) / (Math.sqrt(r2) * r2)); }
    }
  }
  /** Leapfrog (kick-drift-kick): symplectic, keeps orbits stable over long fast-forwards. */
  private step(dt: number) {
    const bs = this.bodies;
    for (const b of bs) b.vel.addScaledVector(b.acc, dt * 0.5);
    for (const b of bs) b.pos.addScaledVector(b.vel, dt);
    this.accelerations();
    for (const b of bs) b.vel.addScaledVector(b.acc, dt * 0.5);
    this.resolveCollisions();
  }
  private resolveCollisions() {
    const bs = this.bodies;
    for (let i = 0; i < bs.length; i++) {
      for (let j = i + 1; j < bs.length; j++) {
        const a = bs[i], b = bs[j];
        if (!a.alive || !b.alive) continue;
        if (a.pos.distanceTo(b.pos) < (a.radius + b.radius) * 0.85) { this.collide(a, b); return; }
      }
    }
  }
  private collide(a: SystemBody, b: SystemBody) {
    const big = a.mass >= b.mass ? a : b, small = big === a ? b : a;
    const relV = big.vel.clone().sub(small.vel);
    const speed = relV.length();
    const energy = 0.5 * ((big.mass * small.mass) / (big.mass + small.mass)) * speed * speed;
    const point = small.pos.clone().lerp(big.pos, small.radius / (small.radius + big.radius));
    this.collisions++;
    // flash + debris
    const t = this.simTime;
    const col = big.kind === 'star' ? new THREE.Color(big.def.color) : small.color.clone().lerp(new THREE.Color('#ffd7a0'), 0.5);
    this.particles.burst(point, relV.clone().normalize().negate(), Math.floor(600 * this.settings.particleScale), t, { speed: speed * 0.35 + 0.5, spread: 1.5, life: 12, size: 0.25 + small.radius, color: col, kind: 0, colorJitter: 0.3 });
    this.particles.burst(point, relV.clone().normalize().negate(), Math.floor(200 * this.settings.particleScale), t, { speed: speed * 0.5 + 0.8, spread: 1.6, life: 2, size: 0.3 + small.radius, color: new THREE.Color('#fff0d0'), kind: 1 });
    this.rig.shake(1.2, 0.8);
    bus.emit('audio', { cue: 'collision', intensity: 1 });
    // momentum conserving merge
    const total = big.mass + small.mass;
    big.vel.multiplyScalar(big.mass).addScaledVector(small.vel, small.mass).divideScalar(total);
    const ratio = small.mass / big.mass;
    // fragments when the impact is violent relative to the bodies
    const violent = big.kind !== 'star' && speed > 4 && ratio > 0.08;
    let fragN = 0;
    if (violent) {
      fragN = 3 + Math.min(4, Math.floor(ratio * 6));
      const fragMass = (small.mass * 0.6) / fragN;
      const rng = new RNG(Math.floor(t * 1000));
      for (let i = 0; i < fragN; i++) {
        const dir = new THREE.Vector3(rng.next() - 0.5, (rng.next() - 0.5) * 0.4, rng.next() - 0.5).normalize();
        const v = big.vel.clone().addScaledVector(dir, speed * (0.25 + rng.next() * 0.35));
        this.addBodyInternal({ id: `f${Date.now().toString(36)}${i}`, name: `${small.name} fragment ${i + 1}`, kind: 'fragment', mass: fragMass, radius: Math.max(0.05, small.radius * 0.35), position: point.clone().addScaledVector(dir, small.radius + big.radius * 0.5).toArray() as [number, number, number], velocity: v.toArray() as [number, number, number], color: '#ff8a4a', seed: i * 17 });
      }
      big.mass += small.mass * 0.4;
    } else {
      big.mass = total;
      const newR = Math.cbrt(big.radius ** 3 + small.radius ** 3 * 0.6);
      if (big.kind !== 'star' && big.mesh instanceof THREE.Mesh) { big.radius = newR; big.mesh.geometry.dispose(); big.mesh.geometry = new THREE.SphereGeometry(newR, 48, 24); }
    }
    big.def.mass = big.mass;
    if (big.mat) big.mat.uniforms.uEmissive.value = Math.max(big.mat.uniforms.uEmissive.value, 0.8);
    small.alive = false;
    this.scene.remove(small.mesh); this.scene.remove(small.trailLine);
    this.bodies = this.bodies.filter((x) => x !== small);
    this.current.bodies = this.current.bodies.filter((x) => x.id !== small.id);
    if (this.selectedId === small.id) this.selectedId = big.id;
    if (this.rig.followFn) { const followed = small; if (this.rig.followFn() === followed.pos) this.focus(big.id, true); }
    simEvent('COLLISION', t, `${small.name} struck ${big.name} at ${speed.toFixed(1)} u/s (≈${energy.toFixed(0)} energy units, simulation approximation)${fragN ? ` · ${fragN} fragments` : ' · bodies merged'}`, { speed, energy, fragments: fragN });
    this.onChange?.();
  }

  // ------------------------------------------------------------ loop
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const wallDt = Math.min((now - this.lastWall) / 1000, 0.1);
    this.lastWall = now; this.wallTime += wallDt;
    this.fps = this.fps * 0.95 + (1 / Math.max(wallDt, 1e-3)) * 0.05;
    const simDt = this.paused ? 0 : wallDt * this.speed;
    const t0 = performance.now();
    if (simDt > 0) {
      this.simTime += simDt;
      if (this.bodies.every((b) => b.acc.lengthSq() === 0)) this.accelerations();
      const steps = Math.min(Math.ceil(simDt / 0.004), 400);
      const h = simDt / steps;
      for (let i = 0; i < steps; i++) this.step(h);
      this.anomalies = this.anomalies.filter((a) => { if (a.until < this.simTime) { this.scene.remove(a.mesh); a.mesh.geometry.dispose(); return false; } return true; });
      // decay emissive glow from collisions
      for (const b of this.bodies) if (b.mat && b.mat.uniforms.uEmissive.value > 0 && b.kind !== 'fragment') b.mat.uniforms.uEmissive.value = Math.max(0, b.mat.uniforms.uEmissive.value - simDt * 0.1);
    }
    this.physMs = performance.now() - t0;
    // trails + meshes
    const star = this.bodies.find((b) => b.kind === 'star');
    const sunPos = star ? star.pos : new THREE.Vector3();
    const sunColor = star ? new THREE.Color(star.def.color).lerp(new THREE.Color(1, 1, 1), 0.5) : new THREE.Color(1, 1, 1);
    for (const b of this.bodies) {
      b.mesh.position.copy(b.pos);
      if (b.kind !== 'star') b.mesh.rotation.y += wallDt * 0.2;
      if (simDt > 0 || b.trailLen === 0) {
        if (b.trailLen < TRAIL) b.trailLen++;
        b.trail.copyWithin(3, 0, (b.trailLen - 1) * 3);
        b.trail[0] = b.pos.x; b.trail[1] = b.pos.y; b.trail[2] = b.pos.z;
        const attr = b.trailLine.geometry.getAttribute('position') as THREE.BufferAttribute;
        attr.needsUpdate = true; b.trailLine.geometry.setDrawRange(0, b.trailLen);
      }
      if (b.mat) {
        b.mat.uniforms.uSun.value.copy(sunPos); b.mat.uniforms.uSunColor.value.copy(sunColor); b.mat.uniforms.uTime.value = this.wallTime;
        // nearest occluders for analytic shadows
        const occ = b.mat.uniforms.uOccluders.value as THREE.Vector4[];
        let n = 0;
        const sorted = this.bodies.filter((o) => o !== b && o.kind !== 'star').sort((p, q) => p.pos.distanceToSquared(b.pos) - q.pos.distanceToSquared(b.pos));
        for (const o of sorted) { if (n >= 6) break; occ[n++].set(o.pos.x, o.pos.y, o.pos.z, o.radius); }
        b.mat.uniforms.uOccCount.value = n;
      }
      b.star?.update(this.wallTime);
    }
    // overlays
    if (this.overlays.gravity) {
      const m = this.gridMat.uniforms.uMasses.value as THREE.Vector4[];
      let n = 0;
      for (const b of this.bodies) { if (n >= 24) break; m[n++].set(b.pos.x, b.pos.y, b.pos.z, Math.sqrt(b.mass)); }
      this.gridMat.uniforms.uCount.value = n;
    }
    if (this.overlays.velocity) {
      const pts: number[] = [];
      for (const b of this.bodies) { if (b.kind === 'star') continue; pts.push(b.pos.x, b.pos.y, b.pos.z, b.pos.x + b.vel.x * 0.35, b.pos.y + b.vel.y * 0.35, b.pos.z + b.vel.z * 0.35); }
      this.velLines.geometry.dispose(); this.velLines.geometry = new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    }
    const sel = this.bodies.find((b) => b.id === this.selectedId);
    this.selRing.visible = !!sel;
    if (sel) { this.selRing.position.copy(sel.pos); this.selRing.scale.setScalar(sel.radius * 1.3 + this.rig.dist * 0.01); this.selRing.lookAt(this.camera.position); }
    this.particles.update(this.simTime);
    this.rig.update(wallDt, this.wallTime);
    this.space.update(this.wallTime);
    this.post.render();
    // labels
    if (this.onLabels && this.overlays.labels) {
      const w = this.container.clientWidth, h = this.container.clientHeight;
      this.onLabels(this.bodies.map((b) => { const v = b.pos.clone().project(this.camera); return { id: b.id, name: b.name, x: (v.x * 0.5 + 0.5) * w, y: (-v.y * 0.5 + 0.5) * h - Math.max(10, (b.radius / Math.max(this.rig.dist, 0.1)) * h * 0.6), visible: v.z < 1 && Math.abs(v.x) < 1.1 && Math.abs(v.y) < 1.1, kind: b.kind }; }));
    } else this.onLabels?.([]);
    this.statsTimer += wallDt;
    if (this.statsTimer > 0.25 && this.onDebug) { this.statsTimer = 0; const info = this.renderer.info; this.onDebug({ fps: Math.round(this.fps), frameMs: +(wallDt * 1000).toFixed(1), drawCalls: info.render.calls, triangles: info.render.triangles, particles: this.particles.alive, debris: 0, fragments: this.bodies.filter((b) => b.kind === 'fragment').length, chunks: this.bodies.length, lod: '-', simTime: this.simTime, physicsMs: +this.physMs.toFixed(2), camDist: +this.rig.dist.toFixed(2), gpu: 'WebGL2', quality: this.settings.quality }); }
  };

  dispose() {
    this.disposed = true; cancelAnimationFrame(this.raf); this.ro.disconnect(); this.rig.dispose();
    this.clearBodies(); this.space.dispose(); this.particles.dispose(); this.post.dispose(); this.gridMat.dispose(); this.grid.geometry.dispose();
    this.renderer.dispose(); this.renderer.domElement.remove();
  }
}
