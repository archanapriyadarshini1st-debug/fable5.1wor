import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { DISTORT_SHADER } from './shaders/effects';
import type { Quality } from './types';

export interface DistortionSource { screen: THREE.Vector2; strength: number; radius: number }

/** Bloom + spatial distortion + output (tone mapping / colour space). Can be bypassed entirely. */
export class PostFX {
  private composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private distort: ShaderPass;
  enabled = true;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.Camera;

  constructor(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera, quality: Quality) {
    this.renderer = renderer; this.scene = scene; this.camera = camera;
    this.composer = new EffectComposer(renderer);
    this.composer.addPass(new RenderPass(scene, camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.55, 0.6, 0.86);
    this.composer.addPass(this.bloom);
    this.distort = new ShaderPass(DISTORT_SHADER);
    this.composer.addPass(this.distort);
    this.composer.addPass(new OutputPass());
    this.setQuality(quality);
  }
  setQuality(q: Quality) {
    this.bloom.strength = q === 'cinematic' ? 0.7 : q === 'high' ? 0.55 : q === 'balanced' ? 0.45 : 0.3;
    this.bloom.radius = q === 'cinematic' ? 0.7 : 0.5;
    this.bloom.threshold = q === 'performance' ? 0.95 : 0.85;
    (this.distort.uniforms.uChroma as THREE.IUniform).value = q === 'cinematic' ? 0.4 : 0;
  }
  setSize(w: number, h: number, pr: number) {
    this.composer.setPixelRatio(pr);
    this.composer.setSize(w, h);
    (this.distort.uniforms.uAspect as THREE.IUniform).value = w / h;
  }
  setDistortions(list: DistortionSource[]) {
    const c = this.distort.uniforms.uCenters.value as number[];
    const s = this.distort.uniforms.uStrength.value as number[];
    const r = this.distort.uniforms.uRadius.value as number[];
    for (let i = 0; i < 4; i++) {
      const d = list[i];
      if (d) { c[i * 2] = d.screen.x; c[i * 2 + 1] = d.screen.y; s[i] = d.strength; r[i] = d.radius; } else s[i] = 0;
    }
  }
  render() {
    if (this.enabled) this.composer.render();
    else this.renderer.render(this.scene, this.camera);
  }
  dispose() { this.composer.dispose(); }
}
