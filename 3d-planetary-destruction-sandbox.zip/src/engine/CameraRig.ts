import * as THREE from 'three';

export type CameraMode = 'orbit' | 'cinematic' | 'follow' | 'free';

/**
 * Premium orbit camera: spherical coordinates with critically-damped smoothing, continuous zoom from
 * system scale down to the surface, pan, follow-target, cinematic auto-orbit and directional shake.
 * Handles mouse, wheel, keyboard-friendly API and multi-touch (1 finger orbit, 2 finger pinch/pan).
 */
export class CameraRig {
  readonly camera: THREE.PerspectiveCamera;
  target = new THREE.Vector3();
  private targetGoal = new THREE.Vector3();
  theta = 0.6; // azimuth
  phi = 1.2; // polar
  dist = 3.2;
  private thetaGoal = 0.6;
  private phiGoal = 1.2;
  private distGoal = 3.2;
  minDist = 1.05;
  maxDist = 40;
  mode: CameraMode = 'orbit';
  followFn: (() => THREE.Vector3) | null = null;
  autoRotateSpeed = 0.04;
  shakeIntensity = 1;
  reducedMotion = false;
  invertZoom = false;
  enabled = true;
  onUserInput?: () => void;

  private shakeT = 0;
  private shakeDur = 0;
  private shakeAmp = 0;
  private shakeDir = new THREE.Vector3(1, 0.4, 0);
  private velTheta = 0;
  private velPhi = 0;
  private dom: HTMLElement;
  private pointers = new Map<number, { x: number; y: number }>();
  private lastPinch = 0;
  private lastMid = { x: 0, y: 0 };
  private dragButton = -1;
  private moved = 0;
  private up = new THREE.Vector3(0, 1, 0);

  constructor(camera: THREE.PerspectiveCamera, dom: HTMLElement) {
    this.camera = camera;
    this.dom = dom;
    dom.addEventListener('pointerdown', this.onDown);
    window.addEventListener('pointermove', this.onMove);
    window.addEventListener('pointerup', this.onUp);
    window.addEventListener('pointercancel', this.onUp);
    dom.addEventListener('wheel', this.onWheel, { passive: false });
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    dom.style.touchAction = 'none';
  }

  /** whether the last press was a click (not a drag) */
  wasClick() { return this.moved < 6; }

  setView(theta: number, phi: number, dist: number, instant = false) {
    this.thetaGoal = theta; this.phiGoal = phi; this.distGoal = THREE.MathUtils.clamp(dist, this.minDist, this.maxDist);
    if (instant) { this.theta = theta; this.phi = phi; this.dist = this.distGoal; }
  }
  getView() { return { theta: this.theta, phi: this.phi, dist: this.dist }; }
  zoomTo(d: number) { this.distGoal = THREE.MathUtils.clamp(d, this.minDist, this.maxDist); }
  get zoomGoal() { return this.distGoal; }
  focusOn(p: THREE.Vector3, dist?: number) { this.targetGoal.copy(p); if (dist !== undefined) this.zoomTo(dist); }
  /** Aim the camera so that a direction (unit vector from target) faces the camera. */
  lookFromDirection(dir: THREE.Vector3, dist?: number) {
    const d = dir.clone().normalize();
    this.phiGoal = Math.acos(THREE.MathUtils.clamp(d.y, -1, 1));
    this.thetaGoal = Math.atan2(d.x, d.z);
    // shortest angular path
    while (this.thetaGoal - this.theta > Math.PI) this.thetaGoal -= Math.PI * 2;
    while (this.thetaGoal - this.theta < -Math.PI) this.thetaGoal += Math.PI * 2;
    if (dist !== undefined) this.zoomTo(dist);
  }
  shake(intensity: number, duration: number, dir?: THREE.Vector3) {
    if (this.reducedMotion) return;
    const amp = intensity * this.shakeIntensity;
    if (amp <= this.shakeAmp * 0.5 && this.shakeT < this.shakeDur) return;
    this.shakeAmp = amp; this.shakeDur = duration; this.shakeT = 0;
    if (dir) this.shakeDir.copy(dir).normalize(); else this.shakeDir.set(Math.random() - 0.5, Math.random() - 0.5, 0).normalize();
  }

  private onDown = (e: PointerEvent) => {
    if (!this.enabled) return;
    this.dom.setPointerCapture?.(e.pointerId);
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    this.moved = 0;
    this.dragButton = e.button;
    if (this.pointers.size === 2) {
      const [a, b] = [...this.pointers.values()];
      this.lastPinch = Math.hypot(a.x - b.x, a.y - b.y);
      this.lastMid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    }
    this.onUserInput?.();
  };
  private onMove = (e: PointerEvent) => {
    if (!this.pointers.has(e.pointerId)) return;
    const prev = this.pointers.get(e.pointerId)!;
    const dx = e.clientX - prev.x, dy = e.clientY - prev.y;
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    this.moved += Math.abs(dx) + Math.abs(dy);
    if (!this.enabled) return;
    if (this.pointers.size === 1) {
      if (this.dragButton === 2 || (this.dragButton === 0 && e.shiftKey) || this.dragButton === 1) this.pan(dx, dy);
      else this.rotate(dx, dy);
    } else if (this.pointers.size === 2) {
      const [a, b] = [...this.pointers.values()];
      const pinch = Math.hypot(a.x - b.x, a.y - b.y);
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      if (this.lastPinch > 0) this.dolly(Math.pow(0.995, pinch - this.lastPinch));
      this.pan(mid.x - this.lastMid.x, mid.y - this.lastMid.y);
      this.lastPinch = pinch; this.lastMid = mid;
    }
    if (this.mode === 'cinematic' && this.moved > 4) this.mode = 'orbit';
  };
  private onUp = (e: PointerEvent) => {
    this.pointers.delete(e.pointerId);
    if (this.pointers.size < 2) this.lastPinch = 0;
  };
  private onWheel = (e: WheelEvent) => {
    if (!this.enabled) return;
    e.preventDefault();
    const s = this.invertZoom ? -1 : 1;
    this.dolly(Math.pow(1.0015, e.deltaY * s));
    this.onUserInput?.();
  };

  rotate(dx: number, dy: number) {
    const k = 0.0045 * Math.min(1, (this.dist - this.minDist * 0.9) / 2 + 0.25);
    this.thetaGoal -= dx * k;
    this.phiGoal = THREE.MathUtils.clamp(this.phiGoal - dy * k, 0.03, Math.PI - 0.03);
    this.velTheta = -dx * k; this.velPhi = -dy * k;
  }
  pan(dx: number, dy: number) {
    const k = (this.dist - this.minDist * 0.8) * 0.0012;
    const right = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 0);
    const upv = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 1);
    this.targetGoal.addScaledVector(right, -dx * k).addScaledVector(upv, dy * k);
    if (this.mode === 'follow') { this.mode = 'orbit'; this.followFn = null; }
  }
  dolly(factor: number) {
    // zoom step proportional to distance above the surface for continuous scale transitions
    const above = this.distGoal - this.minDist;
    const next = this.minDist + above * factor;
    this.distGoal = THREE.MathUtils.clamp(next, this.minDist, this.maxDist);
  }

  update(dt: number, wallTime: number) {
    const damp = 1 - Math.exp(-dt * 9);
    if (this.mode === 'cinematic') {
      this.thetaGoal += this.autoRotateSpeed * dt * (this.reducedMotion ? 0.3 : 1);
      this.phiGoal += Math.sin(wallTime * 0.11) * dt * 0.02;
      this.phiGoal = THREE.MathUtils.clamp(this.phiGoal, 0.7, 2.2);
    } else if (this.mode === 'orbit' && this.pointers.size === 0) {
      // inertia
      this.thetaGoal += this.velTheta * 0.5;
      this.phiGoal = THREE.MathUtils.clamp(this.phiGoal + this.velPhi * 0.5, 0.03, Math.PI - 0.03);
      this.velTheta *= Math.exp(-dt * 6); this.velPhi *= Math.exp(-dt * 6);
    }
    if (this.followFn) this.targetGoal.copy(this.followFn());
    this.theta += (this.thetaGoal - this.theta) * damp;
    this.phi += (this.phiGoal - this.phi) * damp;
    this.dist += (this.distGoal - this.dist) * (1 - Math.exp(-dt * 6));
    this.dist = Math.max(this.dist, this.minDist);
    this.target.lerp(this.targetGoal, this.followFn ? 1 : damp);
    const sp = Math.sin(this.phi);
    const off = new THREE.Vector3(sp * Math.sin(this.theta), Math.cos(this.phi), sp * Math.cos(this.theta)).multiplyScalar(this.dist);
    this.camera.position.copy(this.target).add(off);
    // shake
    if (this.shakeT < this.shakeDur) {
      this.shakeT += dt;
      const k = 1 - this.shakeT / this.shakeDur;
      const a = this.shakeAmp * k * k * 0.05 * Math.min(this.dist, 3);
      const n = Math.sin(this.shakeT * 55) * a;
      const n2 = Math.cos(this.shakeT * 41 + 1.3) * a * 0.6;
      const right = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 0);
      const upv = new THREE.Vector3().setFromMatrixColumn(this.camera.matrix, 1);
      this.camera.position.addScaledVector(right, n * this.shakeDir.x + n2 * 0.3).addScaledVector(upv, n2 * this.shakeDir.y + n * 0.2);
    }
    this.camera.up.copy(this.up);
    this.camera.lookAt(this.target);
    // near/far adapt to scale so the surface stays crisp when very close
    const near = Math.max(0.0005, (this.dist - this.minDist) * 0.02 + 0.001);
    if (Math.abs(this.camera.near - near) > near * 0.2) { this.camera.near = near; this.camera.far = 3000; this.camera.updateProjectionMatrix(); }
  }

  dispose() {
    this.dom.removeEventListener('pointerdown', this.onDown);
    window.removeEventListener('pointermove', this.onMove);
    window.removeEventListener('pointerup', this.onUp);
    window.removeEventListener('pointercancel', this.onUp);
    this.dom.removeEventListener('wheel', this.onWheel);
  }
}
