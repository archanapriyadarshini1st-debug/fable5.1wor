import { RNG, Simplex3, clamp, smoothstep } from './noise';
import type { PlanetDef } from './types';

/**
 * Generates the base planetary height field as an equirectangular RGBA float texture.
 *  R = height (-1..1, 0 = reference geoid)      G = moisture / biome noise (0..1)
 *  B = micro-detail noise (0..1)                A = volcanic / hot-spot mask (0..1)
 * Sea level is derived from requested ocean coverage using an area-weighted histogram,
 * so the coverage slider produces the coverage it promises.
 */
export interface HeightField {
  width: number;
  height: number;
  data: Float32Array;
  seaLevel: number;
}

interface Crater {
  x: number; y: number; z: number; r: number; depth: number; lat: number;
}

export function generateHeightField(def: PlanetDef, width: number, height: number, onProgress?: (p: number) => void): HeightField {
  const data = new Float32Array(width * height * 4);
  const n1 = new Simplex3(def.seed);
  const n2 = new Simplex3(def.seed ^ 0x51f15e);
  const n3 = new Simplex3(def.seed ^ 0xa11ce);
  const rng = new RNG(def.seed ^ 0xc0ffee);
  const isGas = def.type === 'gas';

  // --- crater catalogue, binned by latitude band for cheap lookup ---
  const BINS = 36;
  const bins: Crater[][] = Array.from({ length: BINS }, () => []);
  const craterCount = isGas ? 0 : Math.floor(def.craterDensity * 220);
  for (let i = 0; i < craterCount; i++) {
    const u = rng.next() * 2 - 1;
    const th = rng.next() * Math.PI * 2;
    const s = Math.sqrt(1 - u * u);
    const c: Crater = { x: s * Math.cos(th), y: u, z: s * Math.sin(th), r: 0.012 + Math.pow(rng.next(), 2.5) * 0.11, depth: 0.15 + rng.next() * 0.45, lat: Math.asin(u) };
    const bMin = clamp(Math.floor(((c.lat - c.r * 1.3 + Math.PI / 2) / Math.PI) * BINS), 0, BINS - 1);
    const bMax = clamp(Math.floor(((c.lat + c.r * 1.3 + Math.PI / 2) / Math.PI) * BINS), 0, BINS - 1);
    for (let b = bMin; b <= bMax; b++) bins[b].push(c);
  }

  const rough = def.terrainRoughness;
  const mountF = def.mountainFrequency;
  const contScale = 1.1 + (1 - rough) * 0.6;
  const warpAmt = 0.35 * rough;

  for (let j = 0; j < height; j++) {
    const v = (j + 0.5) / height;
    const lat = (v - 0.5) * Math.PI;
    const cl = Math.cos(lat), sl = Math.sin(lat);
    const bin = clamp(Math.floor(v * BINS), 0, BINS - 1);
    const craters = bins[bin];
    for (let i = 0; i < width; i++) {
      const u = (i + 0.5) / width;
      const lon = (u - 0.5) * Math.PI * 2;
      const x = cl * Math.cos(lon), y = sl, z = cl * Math.sin(lon);
      const o = (j * width + i) * 4;

      if (isGas) {
        // Banded atmosphere: latitude bands warped by turbulence + storm cells
        const turb = n1.fbm(x * 3, y * 3, z * 3, 4) * 0.35 + n2.fbm(x * 9, y * 9, z * 9, 3) * 0.12;
        const band = Math.sin((y + turb) * (9 + mountF * 8) + n2.noise(x, y, z) * 2.0);
        const storms = Math.max(0, n3.ridged(x * 6 + 4, y * 14, z * 6, 3) - 0.55) * 3;
        data[o] = band * 0.8 + storms * 0.6 * (n1.noise(x * 20, y * 40, z * 20) + 0.4);
        data[o + 1] = 0.5 + 0.5 * n2.fbm(x * 5, y * 25, z * 5, 3);
        data[o + 2] = 0.5 + 0.5 * n3.noise(x * 40, y * 80, z * 40);
        data[o + 3] = clamp(storms, 0, 1);
        continue;
      }

      // domain warp for organic coastlines
      const wx = x + warpAmt * n2.noise(x * 1.7, y * 1.7, z * 1.7);
      const wy = y + warpAmt * n2.noise(x * 1.7 + 5.2, y * 1.7, z * 1.7);
      const wz = z + warpAmt * n2.noise(x * 1.7, y * 1.7 + 9.1, z * 1.7);
      let cont = n1.fbm(wx * contScale, wy * contScale, wz * contScale, 5, 2.1, 0.5); // -1..1
      cont = Math.sign(cont) * Math.pow(Math.abs(cont), 0.85);

      const landMask = smoothstep(-0.15, 0.25, cont);
      const ridge = n3.ridged(x * (2.5 + mountF * 3.5), y * (2.5 + mountF * 3.5), z * (2.5 + mountF * 3.5), 5, 2.15, 0.52);
      const mountainMask = smoothstep(0.3, 0.75, n2.fbm(x * 2.2 + 3, y * 2.2, z * 2.2, 3) * 0.5 + 0.5) * mountF;
      const mountains = ridge * ridge * mountainMask * landMask * (0.9 + rough * 0.6);
      const detail = n3.fbm(x * 14, y * 14, z * 14, 4, 2.2, 0.55) * 0.09 * (0.4 + rough);
      const fine = n1.fbm(x * 40, y * 40, z * 40, 3) * 0.025 * rough;

      let h = cont * 0.55 + mountains * 0.9 + detail + fine;
      // ocean floor: flatten deep ocean, add trenches
      if (h < -0.05) h = -0.05 + (h + 0.05) * 0.55;

      // craters
      let craterMask = 0;
      for (let c = 0; c < craters.length; c++) {
        const cr = craters[c];
        const dot = x * cr.x + y * cr.y + z * cr.z;
        if (dot < 0.9) continue;
        const d = Math.acos(clamp(dot, -1, 1));
        if (d < cr.r * 1.35) {
          const t = d / cr.r;
          const bowl = t < 1 ? -(1 - t * t) * cr.depth : 0;
          const rim = Math.exp(-Math.pow((t - 1.0) / 0.22, 2)) * cr.depth * 0.35;
          const floorNoise = t < 0.8 ? n2.noise(x * 60, y * 60, z * 60) * 0.03 * cr.depth : 0;
          h += (bowl + rim + floorNoise) * 0.45;
          craterMask = Math.max(craterMask, 1 - t / 1.35);
        }
      }

      data[o] = clamp(h, -1, 1);
      data[o + 1] = clamp(0.5 + 0.5 * n2.fbm(x * 2.8 + 11, y * 2.8, z * 2.8, 3) + craterMask * 0.1, 0, 1);
      data[o + 2] = 0.5 + 0.5 * n3.noise(x * 90, y * 90, z * 90);
      const volcanic = smoothstep(0.55, 0.85, n1.ridged(x * 4 + 20, y * 4, z * 4, 3)) * (def.type === 'lava' ? 1 : 0.35);
      data[o + 3] = clamp(volcanic, 0, 1);
    }
    if (onProgress && (j & 15) === 0) onProgress(j / height);
  }

  // --- sea level by area-weighted quantile ---
  let seaLevel = -2;
  if (!isGas && def.oceanCoverage > 0.001) {
    const HB = 512;
    const hist = new Float64Array(HB);
    let total = 0;
    for (let j = 0; j < height; j++) {
      const w = Math.cos(((j + 0.5) / height - 0.5) * Math.PI);
      for (let i = 0; i < width; i++) {
        const h = data[(j * width + i) * 4];
        hist[clamp(Math.floor((h + 1) * 0.5 * (HB - 1)), 0, HB - 1)] += w;
        total += w;
      }
    }
    const target = total * clamp(def.oceanCoverage, 0, 0.999);
    let acc = 0;
    for (let b = 0; b < HB; b++) {
      acc += hist[b];
      if (acc >= target) { seaLevel = (b / (HB - 1)) * 2 - 1; break; }
    }
  }
  onProgress?.(1);
  return { width, height, data, seaLevel };
}

/** Bilinear sample of the R channel at lat/lon (radians) - used by CPU picking. */
export function sampleHeight(field: HeightField, lat: number, lon: number): number {
  const u = ((lon / (Math.PI * 2) + 0.5) % 1 + 1) % 1;
  const v = clamp(lat / Math.PI + 0.5, 0, 0.9999);
  const fx = u * field.width - 0.5, fy = v * field.height - 0.5;
  const x0 = Math.floor(fx), y0 = Math.floor(fy);
  const tx = fx - x0, ty = fy - y0;
  const get = (x: number, y: number) => field.data[((clamp(y, 0, field.height - 1)) * field.width + ((x % field.width) + field.width) % field.width) * 4];
  const a = get(x0, y0), b = get(x0 + 1, y0), c = get(x0, y0 + 1), d = get(x0 + 1, y0 + 1);
  return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
}
