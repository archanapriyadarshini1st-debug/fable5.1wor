import * as THREE from 'three';
import { Simplex3, clamp } from './noise';
import { ATMO_FRAG, ATMO_VERT, CLOUD_FRAG, CLOUD_VERT, RING_FRAG, RING_VERT, STAR_FRAG, STAR_VERT } from './shaders/effects';
import { PLANET_FRAG, PLANET_VERT } from './shaders/planet';
import type { HeightField } from './terrain';
import type { PlanetDef, Quality } from './types';

export const DAMAGE_W = 1024;
export const DAMAGE_H = 512;
/** Visual time compression: 1 simulation second advances planetary rotation by this many seconds. */
export const ROTATION_TIME_SCALE = 120;

export interface DamageOptions {
  /** angular radius on the unit sphere (radians) */
  angRadius: number;
  /** depth in planet radii (positive removes material, negative uplifts) */
  depth: number;
  profile: 'crater' | 'bore' | 'flat' | 'ring' | 'uplift';
  time: number;
  heat?: boolean;
  fracture?: number;
  rim?: boolean;
  ringWidth?: number;
}

export interface PickResult {
  point: THREE.Vector3; // world
  dir: THREE.Vector3; // object-space unit direction
  normal: THREE.Vector3; // world approx
  lat: number;
  lon: number;
  surfaceR: number;
  height: number;
  damage: number;
}

const QUALITY_DETAIL: Record<Quality, [number, number, number]> = {
  cinematic: [7, 6, 4],
  high: [6, 5, 4],
  balanced: [6, 5, 3],
  performance: [5, 4, 3],
};

export class Planet {
  readonly root = new THREE.Group(); // tilt
  readonly spin = new THREE.Group(); // rotation
  readonly def: PlanetDef;
  readonly field: HeightField;
  readonly damage: Float32Array;
  private damageTex: THREE.DataTexture;
  private heightTex: THREE.DataTexture;
  private cloudTex: THREE.DataTexture;
  readonly material: THREE.ShaderMaterial;
  private atmoMat: THREE.ShaderMaterial;
  private cloudMat: THREE.ShaderMaterial;
  private ringMat: THREE.ShaderMaterial | null = null;
  private coreMat: THREE.ShaderMaterial;
  private lod: THREE.LOD;
  private atmo: THREE.Mesh;
  private clouds: THREE.Mesh;
  private core: THREE.Mesh;
  private damageDirty = false;
  readonly amp: number;
  removedVolume = 0;
  fractureTotal = 0;
  breakProgress = 0;
  cloudRot = 0;
  private plumes: { dir: THREE.Vector3; t: number; s: number }[] = [];
  readonly isGas: boolean;
  readonly gravity: number;
  readonly palette: Record<string, THREE.Color>;

  constructor(def: PlanetDef, field: HeightField, quality: Quality, opts: { cloudShadows: boolean; highContrast: boolean; reducedFlashing: boolean; linearFloat?: boolean }) {
    const filt = opts.linearFloat === false ? THREE.NearestFilter : THREE.LinearFilter;
    this.def = def;
    this.field = field;
    this.isGas = def.type === 'gas';
    this.amp = this.isGas ? 0 : 0.018 + def.terrainRoughness * 0.03;
    this.gravity = clamp(def.mass / Math.pow(def.radius / 6371, 2), 0.05, 6);
    const p = def.palette;
    this.palette = Object.fromEntries(Object.entries(p).map(([k, v]) => [k, new THREE.Color(v)]));

    this.heightTex = new THREE.DataTexture(field.data, field.width, field.height, THREE.RGBAFormat, THREE.FloatType);
    this.heightTex.wrapS = THREE.RepeatWrapping; this.heightTex.wrapT = THREE.ClampToEdgeWrapping;
    this.heightTex.minFilter = filt; this.heightTex.magFilter = filt;
    this.heightTex.generateMipmaps = false; this.heightTex.needsUpdate = true;

    this.damage = new Float32Array(DAMAGE_W * DAMAGE_H * 4);
    for (let i = 0; i < DAMAGE_W * DAMAGE_H; i++) this.damage[i * 4 + 1] = -1e6;
    this.damageTex = new THREE.DataTexture(this.damage, DAMAGE_W, DAMAGE_H, THREE.RGBAFormat, THREE.FloatType);
    this.damageTex.wrapS = THREE.RepeatWrapping; this.damageTex.wrapT = THREE.ClampToEdgeWrapping;
    this.damageTex.minFilter = filt; this.damageTex.magFilter = filt;
    this.damageTex.generateMipmaps = false; this.damageTex.needsUpdate = true;

    this.cloudTex = Planet.makeCloudTexture(def.seed);
    this.cloudTex.minFilter = filt; this.cloudTex.magFilter = filt;

    const sunColor = new THREE.Color(1, 1, 1);
    this.material = new THREE.ShaderMaterial({
      vertexShader: PLANET_VERT,
      fragmentShader: PLANET_FRAG,
      uniforms: {
        uHeight: { value: this.heightTex }, uDamage: { value: this.damageTex }, uCloud: { value: this.cloudTex },
        uAmp: { value: this.amp }, uSeaLevel: { value: field.seaLevel }, uIsGas: { value: this.isGas ? 1 : 0 }, uBreak: { value: 0 }, uTime: { value: 0 },
        uTexel: { value: new THREE.Vector2(1 / DAMAGE_W, 1 / DAMAGE_H) }, uModel: { value: new THREE.Matrix3() },
        uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uSunColor: { value: sunColor },
        cOcean: { value: this.palette.ocean }, cShallow: { value: this.palette.shallow }, cLand: { value: this.palette.land }, cHighland: { value: this.palette.highland }, cMountain: { value: this.palette.mountain }, cIce: { value: this.palette.ice }, cAtmo: { value: this.palette.atmosphere }, cCrust: { value: this.palette.crust }, cMantle: { value: this.palette.mantle }, cCore: { value: this.palette.core },
        uIce: { value: def.iceCoverage }, uTemp: { value: def.temperature }, uAtmo: { value: def.atmosphereDensity }, uCity: { value: def.cityLights ? 1 : 0 }, uLava: { value: def.type === 'lava' ? 1 : 0 }, uMoistureBias: { value: def.type === 'desert' ? -0.35 : 0 },
        uCoolTime: { value: 90 }, uCloudRot: { value: 0 }, uCloudCover: { value: def.cloudCoverage }, uCloudShadow: { value: opts.cloudShadows ? 1 : 0 },
        uShock: { value: new THREE.Vector4(0, 1, 0, 0) }, uShockWidth: { value: 0.05 }, uHighContrast: { value: opts.highContrast ? 1 : 0 }, uFlash: { value: opts.reducedFlashing ? 0.45 : 1 },
      },
    });

    const [hi, mid, lo] = QUALITY_DETAIL[quality];
    this.lod = new THREE.LOD();
    this.lod.addLevel(new THREE.Mesh(new THREE.IcosahedronGeometry(1, hi), this.material), 0);
    this.lod.addLevel(new THREE.Mesh(new THREE.IcosahedronGeometry(1, mid), this.material), 3.2);
    this.lod.addLevel(new THREE.Mesh(new THREE.IcosahedronGeometry(1, lo), this.material), 9);
    this.spin.add(this.lod);

    // molten core revealed during breakup
    this.coreMat = new THREE.ShaderMaterial({ vertexShader: STAR_VERT, fragmentShader: STAR_FRAG, uniforms: { uColor: { value: this.palette.core }, uGlow: { value: this.palette.mantle }, uTime: { value: 0 }, uIntensity: { value: 1.6 } } });
    this.core = new THREE.Mesh(new THREE.SphereGeometry(0.5, 48, 32), this.coreMat);
    this.core.visible = false;
    this.spin.add(this.core);

    // atmosphere shell
    const atmR = 1 + this.amp + 0.035 + def.atmosphereDensity * 0.035;
    this.atmoMat = new THREE.ShaderMaterial({
      vertexShader: ATMO_VERT, fragmentShader: ATMO_FRAG, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.FrontSide,
      uniforms: {
        uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uColor: { value: this.palette.atmosphere }, uDensity: { value: def.atmosphereDensity }, uTime: { value: 0 }, uGlobalGlow: { value: 0 }, uFlash: { value: opts.reducedFlashing ? 0.45 : 1 },
        uPlumes: { value: Array.from({ length: 8 }, () => new THREE.Vector4(0, 1, 0, -1e6)) }, uPlumeStr: { value: new Array(8).fill(0) },
      },
    });
    this.atmo = new THREE.Mesh(new THREE.SphereGeometry(atmR, 64, 48), this.atmoMat);
    this.atmo.renderOrder = 3;
    this.atmo.visible = def.atmosphereDensity > 0.02;
    this.spin.add(this.atmo);

    // cloud shell
    this.cloudMat = new THREE.ShaderMaterial({
      vertexShader: CLOUD_VERT, fragmentShader: CLOUD_FRAG, transparent: true, depthWrite: false,
      uniforms: { uCloud: { value: this.cloudTex }, uDamage: { value: this.damageTex }, uRot: { value: 0 }, uCover: { value: def.cloudCoverage }, uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uColor: { value: this.palette.cloud }, uTime: { value: 0 }, uCoolTime: { value: 90 }, uCrustHeat: { value: def.type === 'lava' ? 0.2 : def.type === 'ocean' ? 0.9 : 0.3 } },
    });
    this.clouds = new THREE.Mesh(new THREE.SphereGeometry(1 + this.amp + 0.012, 96, 64), this.cloudMat);
    this.clouds.renderOrder = 2;
    this.clouds.visible = def.cloudCoverage > 0.02 && !this.isGas;
    this.spin.add(this.clouds);

    if (def.hasRings) this.buildRings(quality);

    this.root.rotation.z = THREE.MathUtils.degToRad(def.axialTilt);
    this.root.add(this.spin);
  }

  private buildRings(quality: Quality) {
    const n = quality === 'cinematic' ? 60000 : quality === 'high' ? 40000 : quality === 'balanced' ? 24000 : 10000;
    const radius = new Float32Array(n), angle = new Float32Array(n), size = new Float32Array(n), y = new Float32Array(n), shade = new Float32Array(n);
    const noise = new Simplex3(this.def.seed + 99);
    let i = 0, guard = 0;
    while (i < n && guard++ < n * 20) {
      const r = 1.45 + Math.random() * 1.1;
      const density = 0.5 + 0.5 * noise.noise(r * 9, 0, 0) - (Math.abs(r - 2.05) < 0.05 ? 0.7 : 0); // gaps
      if (Math.random() > density) continue;
      radius[i] = r; angle[i] = Math.random() * Math.PI * 2; size[i] = 0.6 + Math.random() * 1.6; y[i] = (Math.random() - 0.5) * 0.008; shade[i] = 0.55 + 0.45 * Math.random();
      i++;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
    g.setAttribute('aRadius', new THREE.BufferAttribute(radius, 1));
    g.setAttribute('aAngle', new THREE.BufferAttribute(angle, 1));
    g.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    g.setAttribute('aY', new THREE.BufferAttribute(y, 1));
    g.setAttribute('aShade', new THREE.BufferAttribute(shade, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 4);
    this.ringMat = new THREE.ShaderMaterial({ vertexShader: RING_VERT, fragmentShader: RING_FRAG, transparent: true, depthWrite: false, uniforms: { uTime: { value: 0 }, uPixelRatio: { value: 1 }, uSunDir: { value: new THREE.Vector3(1, 0, 0) }, uColor: { value: this.palette.highland.clone().lerp(new THREE.Color('#cfc8bf'), 0.5) }, uDisrupt: { value: 0 }, uDisruptDir: { value: new THREE.Vector3(0, 1, 0) } } });
    const pts = new THREE.Points(g, this.ringMat);
    pts.renderOrder = 4;
    this.root.add(pts);
  }

  static makeCloudTexture(seed: number) {
    const w = 512, h = 256;
    const data = new Float32Array(w * h * 4);
    const n = new Simplex3(seed ^ 0xc10d);
    for (let j = 0; j < h; j++) {
      const lat = ((j + 0.5) / h - 0.5) * Math.PI;
      const cl = Math.cos(lat), sl = Math.sin(lat);
      for (let i = 0; i < w; i++) {
        const lon = ((i + 0.5) / w - 0.5) * Math.PI * 2;
        const x = cl * Math.cos(lon), y = sl, z = cl * Math.sin(lon);
        const o = (j * w + i) * 4;
        const stretch = 1 + Math.abs(sl) * 0.5;
        const c = n.fbm(x * 3 * stretch, y * 6, z * 3 * stretch, 5, 2.2, 0.55);
        const bands = Math.sin(y * 9) * 0.12;
        data[o] = clamp(0.5 + c * 0.85 + bands, 0, 1);
        data[o + 1] = 0.5 + 0.5 * n.noise(x * 20, y * 20, z * 20);
        data[o + 2] = 0; data[o + 3] = 1;
      }
    }
    const t = new THREE.DataTexture(data, w, h, THREE.RGBAFormat, THREE.FloatType);
    t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.ClampToEdgeWrapping;
    t.minFilter = THREE.LinearFilter; t.magFilter = THREE.LinearFilter; t.generateMipmaps = false; t.needsUpdate = true;
    return t;
  }

  setPixelRatio(pr: number) { if (this.ringMat) this.ringMat.uniforms.uPixelRatio.value = pr; }

  setSun(dirWorld: THREE.Vector3, color: THREE.Color) {
    this.material.uniforms.uSunDir.value.copy(dirWorld);
    this.material.uniforms.uSunColor.value.copy(color);
    this.atmoMat.uniforms.uSunDir.value.copy(dirWorld);
    this.cloudMat.uniforms.uSunDir.value.copy(dirWorld);
    if (this.ringMat) this.ringMat.uniforms.uSunDir.value.copy(dirWorld);
  }

  /** Advance rotation + time-driven uniforms. dt is simulation seconds. */
  update(dtSim: number, simTime: number) {
    const rate = (Math.PI * 2) / (this.def.rotationPeriod * 3600) * ROTATION_TIME_SCALE;
    this.spin.rotation.y += rate * dtSim;
    this.cloudRot += rate * dtSim * 0.18 / (Math.PI * 2);
    this.spin.updateMatrixWorld(true);
    (this.material.uniforms.uModel.value as THREE.Matrix3).setFromMatrix4(this.spin.matrixWorld);
    this.material.uniforms.uTime.value = simTime;
    this.material.uniforms.uCloudRot.value = this.cloudRot;
    this.cloudMat.uniforms.uRot.value = this.cloudRot;
    this.cloudMat.uniforms.uTime.value = simTime;
    this.atmoMat.uniforms.uTime.value = simTime;
    this.coreMat.uniforms.uTime.value = simTime;
    if (this.ringMat) {
      this.ringMat.uniforms.uTime.value = simTime;
      this.ringMat.uniforms.uDisrupt.value = Math.max(0, this.ringMat.uniforms.uDisrupt.value - dtSim * 0.02);
    }
    if (this.damageDirty) { this.damageTex.needsUpdate = true; this.damageDirty = false; }
    // plume uniforms
    const pu = this.atmoMat.uniforms.uPlumes.value as THREE.Vector4[];
    const ps = this.atmoMat.uniforms.uPlumeStr.value as number[];
    this.plumes = this.plumes.filter((p) => simTime - p.t < 40 * p.s);
    for (let i = 0; i < 8; i++) {
      const p = this.plumes[this.plumes.length - 1 - i];
      if (p) { pu[i].set(p.dir.x, p.dir.y, p.dir.z, p.t); ps[i] = p.s; } else ps[i] = 0;
    }
    this.atmoMat.uniforms.uGlobalGlow.value = Math.max(0, this.atmoMat.uniforms.uGlobalGlow.value - dtSim * 0.08);
  }

  addPlume(dirObj: THREE.Vector3, strength: number, time: number) {
    this.plumes.push({ dir: dirObj.clone().normalize(), s: clamp(strength, 0.2, 3), t: time });
    if (this.plumes.length > 16) this.plumes.shift();
  }
  glowAtmosphere(v: number) { this.atmoMat.uniforms.uGlobalGlow.value = Math.max(this.atmoMat.uniforms.uGlobalGlow.value, v); }
  disruptRings(dirObj: THREE.Vector3, v: number) { if (this.ringMat) { this.ringMat.uniforms.uDisrupt.value = Math.min(1, this.ringMat.uniforms.uDisrupt.value + v); this.ringMat.uniforms.uDisruptDir.value.copy(dirObj); } }
  setShock(dirObj: THREE.Vector3 | null, radius: number, width: number) {
    const u = this.material.uniforms.uShock.value as THREE.Vector4;
    if (!dirObj) { u.w = 0; return; }
    u.set(dirObj.x, dirObj.y, dirObj.z, radius);
    this.material.uniforms.uShockWidth.value = width;
  }
  setBreak(p: number) {
    this.breakProgress = p;
    this.material.uniforms.uBreak.value = p;
    this.core.visible = p > 0.05;
    const s = 0.5 + p * 0.1;
    this.core.scale.setScalar(s);
    this.clouds.visible = p < 0.6 && this.def.cloudCoverage > 0.02 && !this.isGas;
    this.atmoMat.uniforms.uDensity.value = this.def.atmosphereDensity * (1 - p * 0.9);
    this.lod.visible = p < 1;
  }

  // ---- CPU-side surface evaluation (mirrors the shader) ----
  private sampleField(arr: Float32Array, w: number, h: number, lat: number, lon: number, ch: number) {
    const u = ((lon / (Math.PI * 2) + 0.5) % 1 + 1) % 1;
    const v = clamp(lat / Math.PI + 0.5, 0, 0.9999);
    const fx = u * w - 0.5, fy = v * h - 0.5;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const tx = fx - x0, ty = fy - y0;
    const g = (x: number, y: number) => arr[(clamp(y, 0, h - 1) * w + (((x % w) + w) % w)) * 4 + ch];
    return (g(x0, y0) * (1 - tx) + g(x0 + 1, y0) * tx) * (1 - ty) + (g(x0, y0 + 1) * (1 - tx) + g(x0 + 1, y0 + 1) * tx) * ty;
  }
  surfaceAt(dirObj: THREE.Vector3) {
    const lat = Math.asin(clamp(dirObj.y, -1, 1));
    const lon = Math.atan2(dirObj.z, dirObj.x);
    const h = this.sampleField(this.field.data, this.field.width, this.field.height, lat, lon, 0);
    const d = this.sampleField(this.damage, DAMAGE_W, DAMAGE_H, lat, lon, 0);
    const surf = d > 0.0015 || this.isGas ? h : Math.max(h, this.field.seaLevel);
    const r = Math.max(1 + surf * this.amp - d * (this.isGas ? 0 : 1), 0.1);
    return { r, lat, lon, height: h, damage: d };
  }

  /** Ray-march the displaced surface for precise targeting. Returns null if the ray misses. */
  pick(ray: THREE.Ray): PickResult | null {
    this.spin.updateMatrixWorld(true);
    const inv = new THREE.Matrix4().copy(this.spin.matrixWorld).invert();
    const o = ray.origin.clone().applyMatrix4(inv);
    const d = ray.direction.clone().transformDirection(inv).normalize();
    const R = 1 + this.amp + 0.005;
    // ray-sphere
    const b = o.dot(d);
    const c = o.dot(o) - R * R;
    const disc = b * b - c;
    if (disc < 0) return null;
    let t = -b - Math.sqrt(disc);
    if (t < 0) t = 0;
    const tEnd = -b + Math.sqrt(disc);
    const p = new THREE.Vector3();
    const dir = new THREE.Vector3();
    let step = 0.0035;
    let last = t;
    let hit = false;
    let info = this.surfaceAt(dir.copy(o).addScaledVector(d, t).normalize());
    for (let i = 0; i < 900 && t <= tEnd; i++) {
      p.copy(o).addScaledVector(d, t);
      const len = p.length();
      dir.copy(p).divideScalar(len);
      info = this.surfaceAt(dir);
      if (len <= info.r) { hit = true; break; }
      last = t;
      t += step;
      if (len < 0.9) step = 0.006;
    }
    if (!hit) return null;
    // refine between last and t
    let lo = last, hi = t;
    for (let i = 0; i < 6; i++) {
      const m = (lo + hi) / 2;
      p.copy(o).addScaledVector(d, m);
      const len = p.length();
      dir.copy(p).divideScalar(len);
      info = this.surfaceAt(dir);
      if (len <= info.r) hi = m; else lo = m;
    }
    p.copy(o).addScaledVector(d, hi);
    dir.copy(p).normalize();
    const world = p.clone().applyMatrix4(this.spin.matrixWorld);
    const normal = dir.clone().transformDirection(this.spin.matrixWorld);
    return { point: world, dir: dir.clone(), normal, lat: info.lat, lon: info.lon, surfaceR: info.r, height: info.height, damage: info.damage };
  }

  dirToWorld(dirObj: THREE.Vector3, r = 1) { return dirObj.clone().multiplyScalar(r).applyMatrix4(this.spin.matrixWorld); }
  worldToDir(p: THREE.Vector3) { return p.clone().applyMatrix4(new THREE.Matrix4().copy(this.spin.matrixWorld).invert()).normalize(); }

  /**
   * Modifies the damage field in a dirty rectangle around the impact direction.
   * Returns the fraction of planetary volume removed by this call (approximate).
   */
  applyDamage(dirObj: THREE.Vector3, o: DamageOptions): number {
    const dmg = this.damage;
    const cx = dirObj.x, cy = dirObj.y, cz = dirObj.z;
    const lat0 = Math.asin(clamp(cy, -1, 1));
    const extend = o.angRadius * (o.profile === 'ring' ? 1.15 : 2.2);
    const jMin = clamp(Math.floor(((lat0 - extend) / Math.PI + 0.5) * DAMAGE_H), 0, DAMAGE_H - 1);
    const jMax = clamp(Math.ceil(((lat0 + extend) / Math.PI + 0.5) * DAMAGE_H), 0, DAMAGE_H - 1);
    const lon0 = Math.atan2(cz, cx);
    const fracture = o.fracture ?? 0;
    const rimH = o.rim === false ? 0 : Math.min(0.012, Math.abs(o.depth) * 0.12);
    const gas = this.isGas;
    let removed = 0;
    const pixArea = ((Math.PI * 2) / DAMAGE_W) * (Math.PI / DAMAGE_H);
    const ringW = o.ringWidth ?? o.angRadius * 0.12;
    for (let j = jMin; j <= jMax; j++) {
      const lat = ((j + 0.5) / DAMAGE_H - 0.5) * Math.PI;
      const cl = Math.cos(lat), sl = Math.sin(lat);
      let iMin = 0, iMax = DAMAGE_W - 1, wrap = false;
      if (cl > 0.03) {
        const dLon = extend / cl;
        if (dLon < Math.PI) {
          iMin = Math.floor(((lon0 - dLon) / (Math.PI * 2) + 0.5) * DAMAGE_W);
          iMax = Math.ceil(((lon0 + dLon) / (Math.PI * 2) + 0.5) * DAMAGE_W);
          wrap = true;
        }
      }
      for (let ii = iMin; ii <= iMax; ii++) {
        const i = wrap ? ((ii % DAMAGE_W) + DAMAGE_W) % DAMAGE_W : ii;
        const lon = ((i + 0.5) / DAMAGE_W - 0.5) * Math.PI * 2;
        const dot = cl * Math.cos(lon) * cx + sl * cy + cl * Math.sin(lon) * cz;
        if (dot < Math.cos(extend)) continue;
        const ang = Math.acos(clamp(dot, -1, 1));
        const t = ang / o.angRadius;
        const idx = (j * DAMAGE_W + i) * 4;
        const old = dmg[idx];
        let nd = old;
        if (o.profile === 'ring') {
          const rr = Math.abs(ang - o.angRadius) / ringW;
          if (rr < 1) nd = clamp(old + o.depth * (1 - rr * rr) * 0.5, -0.06, 0.95);
          if (rr < 1.5) { dmg[idx + 1] = o.time; dmg[idx + 2] = Math.max(dmg[idx + 2], fracture * (1 - rr / 1.5)); }
        } else if (t < 1) {
          let profile: number;
          if (o.profile === 'bore') profile = 1 - Math.pow(t, 6);
          else if (o.profile === 'flat') profile = 1 - Math.pow(t, 4);
          else if (o.profile === 'uplift') profile = (1 - t * t) * (1 - t * t); // callers pass negative depth to raise terrain
          else profile = (1 - t * t) * (1 - 0.25 * t); // crater bowl, slightly steeper walls
          // floor roughness
          profile *= 1 + (Math.sin(lat * 900 + lon * 700) * 0.5 + Math.sin(lat * 1700 - lon * 1300) * 0.5) * 0.06;
          const target = o.depth * profile;
          nd = gas ? Math.min(old + target * 0.5, 0.25) : o.depth < 0 ? Math.min(old, target) : Math.max(old, target);
          if (o.heat !== false) dmg[idx + 1] = o.time;
          if (fracture > 0) dmg[idx + 2] = Math.max(dmg[idx + 2], fracture);
        } else if (t < 2.2) {
          // rim + surrounding fracture / heat halo
          if (rimH > 0 && old <= 0.001 && !gas && o.depth > 0) {
            const rim = rimH * Math.exp(-Math.pow((t - 1.08) / 0.18, 2));
            nd = Math.min(old, -rim);
          }
          if (t < 1.35 && o.heat !== false) dmg[idx + 1] = Math.max(dmg[idx + 1], o.time);
          if (fracture > 0) dmg[idx + 2] = Math.max(dmg[idx + 2], fracture * (1 - (t - 1) / 1.2) * 0.85);
        }
        if (nd !== old) {
          dmg[idx] = nd;
          if (!gas) removed += Math.max(0, nd - Math.max(old, 0)) * pixArea * cl;
        }
      }
    }
    const volFrac = (removed * 3) / (4 * Math.PI);
    this.removedVolume += volFrac;
    this.fractureTotal += fracture * o.angRadius * o.angRadius;
    this.damageDirty = true;
    return volFrac;
  }

  /** Interior exposure: max damage depth sampled coarsely. */
  interiorExposure() {
    let m = 0;
    for (let i = 0; i < DAMAGE_W * DAMAGE_H; i += 37) m = Math.max(m, this.damage[i * 4]);
    return clamp(m / 0.75, 0, 1);
  }

  resetDamage() {
    const d = this.damage;
    for (let i = 0; i < DAMAGE_W * DAMAGE_H; i++) { d[i * 4] = 0; d[i * 4 + 1] = -1e6; d[i * 4 + 2] = 0; d[i * 4 + 3] = 0; }
    this.removedVolume = 0; this.fractureTotal = 0;
    this.damageDirty = true;
    this.plumes.length = 0;
    this.setShock(null, 0, 0);
    this.setBreak(0);
    this.atmoMat.uniforms.uGlobalGlow.value = 0;
    if (this.ringMat) this.ringMat.uniforms.uDisrupt.value = 0;
  }
  snapshotDamage() { return new Float32Array(this.damage); }
  restoreDamage(src: Float32Array, removedVolume: number) { this.damage.set(src); this.removedVolume = removedVolume; this.damageDirty = true; }

  setCloudShadows(v: boolean) { this.material.uniforms.uCloudShadow.value = v ? 1 : 0; }
  setAccessibility(highContrast: boolean, reducedFlashing: boolean) {
    this.material.uniforms.uHighContrast.value = highContrast ? 1 : 0;
    this.material.uniforms.uFlash.value = reducedFlashing ? 0.45 : 1;
    this.atmoMat.uniforms.uFlash.value = reducedFlashing ? 0.45 : 1;
  }
  /** Live parameter updates (Planet Lab) that don't require regeneration. */
  applyLiveParams(def: PlanetDef) {
    const u = this.material.uniforms;
    u.uIce.value = def.iceCoverage; u.uTemp.value = def.temperature; u.uAtmo.value = def.atmosphereDensity; u.uCity.value = def.cityLights ? 1 : 0;
    u.uCloudCover.value = def.cloudCoverage; this.cloudMat.uniforms.uCover.value = def.cloudCoverage;
    this.atmoMat.uniforms.uDensity.value = def.atmosphereDensity; this.atmo.visible = def.atmosphereDensity > 0.02;
    this.clouds.visible = def.cloudCoverage > 0.02 && !this.isGas;
    this.root.rotation.z = THREE.MathUtils.degToRad(def.axialTilt);
    for (const k of Object.keys(def.palette) as (keyof PlanetDef['palette'])[]) this.palette[k]?.set(def.palette[k]);
    (this.def as PlanetDef).rotationPeriod = def.rotationPeriod;
  }
  private magGroup: THREE.Group | null = null;
  /** Dipole field-line visualization (scientific overlay): r = L·cos²(λ), tilted 11° from the spin axis. */
  setMagneticField(visible: boolean) {
    if (!visible) { if (this.magGroup) this.magGroup.visible = false; return; }
    if (!this.magGroup) {
      const g = new THREE.Group();
      const strength = Math.max(this.def.magneticField, 0.02);
      const shells = [1.35, 1.7, 2.15, 2.7].slice(0, 1 + Math.round(strength * 3));
      const mat = new THREE.LineBasicMaterial({ color: 0x7fd7ff, transparent: true, opacity: 0.35 + strength * 0.4 });
      for (const L of shells) {
        for (let m = 0; m < 12; m++) {
          const lon = (m / 12) * Math.PI * 2;
          const pts: THREE.Vector3[] = [];
          for (let i = 0; i <= 96; i++) {
            const lam = -Math.PI / 2 + (i / 96) * Math.PI;
            const r = L * Math.cos(lam) * Math.cos(lam);
            if (r < 1.02) continue;
            pts.push(new THREE.Vector3(r * Math.cos(lam) * Math.cos(lon), r * Math.sin(lam), r * Math.cos(lam) * Math.sin(lon)));
          }
          if (pts.length > 2) g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
        }
      }
      // pole markers
      const poleMat = new THREE.MeshBasicMaterial({ color: 0x7fd7ff });
      for (const y of [1.06, -1.06]) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), poleMat); p.position.y = y; g.add(p); }
      g.rotation.z = THREE.MathUtils.degToRad(11);
      this.spin.add(g);
      this.magGroup = g;
    }
    this.magGroup.visible = true;
  }
  currentLOD() { return `L${this.lod.getCurrentLevel()}`; }

  dispose() {
    this.lod.levels.forEach((l) => (l.object as THREE.Mesh).geometry.dispose());
    this.material.dispose(); this.atmoMat.dispose(); this.cloudMat.dispose(); this.coreMat.dispose(); this.ringMat?.dispose();
    this.heightTex.dispose(); this.damageTex.dispose(); this.cloudTex.dispose();
    this.atmo.geometry.dispose(); this.clouds.geometry.dispose(); this.core.geometry.dispose();
  }
}
