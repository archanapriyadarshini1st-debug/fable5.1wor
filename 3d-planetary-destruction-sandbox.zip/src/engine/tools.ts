import type { ToolCategory, ToolDef, ToolId } from './types';
import { clamp } from './noise';

/** Convert an object size in km into an angular crater radius on a planet of the given radius (game scaling, not physics). */
export function craterAngle(sizeKm: number, planetRadiusKm: number, powerMul = 1) {
  return clamp((sizeKm * 11 * powerMul) / planetRadiusKm, 0.006, 1.3);
}

export const TOOLS: ToolDef[] = [
  {
    id: 'asteroid', name: 'Asteroid Event', category: 'impact', color: '#d9a066', glyph: '◉',
    description: 'A single rocky body on a collision trajectory. Crater size scales with mass and velocity; steep approach angles dig deeper.',
    params: [
      { key: 'size', label: 'Size', min: 2, max: 600, step: 1, default: 60, unit: 'km' },
      { key: 'speed', label: 'Velocity', min: 10, max: 90, step: 1, default: 30, unit: 'km/s' },
      { key: 'angle', label: 'Approach angle', min: 0, max: 75, step: 1, default: 20, unit: '°' },
    ],
    previewRadius: (p) => p.size * 11 * (0.7 + p.speed / 60),
  },
  {
    id: 'meteor-swarm', name: 'Meteor Swarm', category: 'impact', color: '#e8c07a', glyph: '⁘',
    description: 'A dispersed stream of small bodies rains down over the target region across several seconds.',
    params: [
      { key: 'count', label: 'Count', min: 4, max: 80, step: 1, default: 24 },
      { key: 'size', label: 'Body size', min: 1, max: 60, step: 1, default: 10, unit: 'km' },
      { key: 'spread', label: 'Spread', min: 2, max: 45, step: 1, default: 14, unit: '°' },
      { key: 'duration', label: 'Duration', min: 1, max: 12, step: 0.5, default: 4, unit: 's' },
    ],
    previewRadius: (p) => p.spread * 111 * 0.0175 * 6371 * 0.0157,
  },
  {
    id: 'energy-pulse', name: 'Localized Energy Pulse', category: 'energy', color: '#7fd7ff', glyph: '⟟',
    description: 'A sustained beam bores into the crust. Longer exposure drills deeper — long enough and it reaches the mantle.',
    params: [
      { key: 'radius', label: 'Beam radius', min: 20, max: 900, step: 5, default: 180, unit: 'km' },
      { key: 'power', label: 'Power', min: 0.1, max: 1, step: 0.05, default: 0.5 },
      { key: 'duration', label: 'Duration', min: 1, max: 10, step: 0.5, default: 4, unit: 's' },
    ],
    previewRadius: (p) => p.radius,
  },
  {
    id: 'plasma-burst', name: 'Plasma Burst', category: 'energy', color: '#ff8a5a', glyph: '✺',
    description: 'A wide, shallow superheated detonation. Vaporises surface material and leaves a glowing, fractured scar.',
    params: [
      { key: 'radius', label: 'Radius', min: 100, max: 3500, step: 10, default: 900, unit: 'km' },
      { key: 'power', label: 'Power', min: 0.1, max: 1, step: 0.05, default: 0.6 },
    ],
    previewRadius: (p) => p.radius,
  },
  {
    id: 'gravity-anomaly', name: 'Gravitational Anomaly', category: 'gravity', color: '#b48cff', glyph: '◎',
    description: 'A fictional point-mass appears above the surface: crust is drawn upward, debris and ring particles spiral in, space visibly bends.',
    params: [
      { key: 'strength', label: 'Strength', min: 0.1, max: 1, step: 0.05, default: 0.5 },
      { key: 'radius', label: 'Radius', min: 200, max: 3000, step: 10, default: 900, unit: 'km' },
      { key: 'duration', label: 'Duration', min: 2, max: 20, step: 0.5, default: 8, unit: 's' },
    ],
    previewRadius: (p) => p.radius,
  },
  {
    id: 'spatial-distortion', name: 'Spatial Distortion', category: 'space', color: '#8fffe0', glyph: '≋',
    description: 'A rippling fold in local space. Terrain heaves in concentric waves and light is bent around the disturbance. Visual approximation only.',
    params: [
      { key: 'strength', label: 'Strength', min: 0.1, max: 1, step: 0.05, default: 0.6 },
      { key: 'radius', label: 'Radius', min: 300, max: 4000, step: 10, default: 1500, unit: 'km' },
      { key: 'duration', label: 'Duration', min: 2, max: 12, step: 0.5, default: 5, unit: 's' },
    ],
    previewRadius: (p) => p.radius,
  },
  {
    id: 'stellar-flare', name: 'Stellar Flare', category: 'cosmic', color: '#ffd166', glyph: '☀',
    description: 'The host star ejects a flare toward the planet. The day side is scorched, the atmosphere glows and ice retreats.',
    params: [
      { key: 'power', label: 'Power', min: 0.1, max: 1, step: 0.05, default: 0.5 },
      { key: 'duration', label: 'Duration', min: 2, max: 12, step: 0.5, default: 5, unit: 's' },
    ],
    previewRadius: () => 0,
  },
  {
    id: 'cosmic-shockwave', name: 'Cosmic Shockwave', category: 'cosmic', color: '#ffb36b', glyph: '◌',
    description: 'A ring-shaped pressure front expands from the target point across the surface, shattering crust as it passes.',
    params: [
      { key: 'power', label: 'Power', min: 0.1, max: 1, step: 0.05, default: 0.5 },
      { key: 'speed', label: 'Front speed', min: 0.2, max: 2, step: 0.1, default: 0.8 },
      { key: 'reach', label: 'Reach', min: 20, max: 180, step: 5, default: 90, unit: '°' },
    ],
    previewRadius: (p) => p.reach * 0.0175 * 6371 * 0.5,
  },
  {
    id: 'matter-displacement', name: 'Matter Displacement', category: 'anomaly', color: '#ff6ad5', glyph: '⌀',
    description: 'A column of matter simply ceases to exist. Deep enough and it tunnels through the core and out the far side.',
    params: [
      { key: 'radius', label: 'Column radius', min: 50, max: 1500, step: 10, default: 400, unit: 'km' },
      { key: 'depth', label: 'Depth', min: 0.1, max: 2.2, step: 0.05, default: 0.8, unit: 'R' },
    ],
    previewRadius: (p) => p.radius,
  },
  {
    id: 'exotic-strike', name: 'Exotic-Energy Strike', category: 'special', color: '#ffffff', glyph: '✦',
    description: 'A charged lance of exotic energy. At full power it destabilises the whole body and triggers planetary breakup.',
    params: [
      { key: 'power', label: 'Power', min: 0.2, max: 1, step: 0.05, default: 0.6 },
      { key: 'size', label: 'Lance radius', min: 100, max: 4000, step: 10, default: 1200, unit: 'km' },
      { key: 'charge', label: 'Charge time', min: 0.5, max: 4, step: 0.1, default: 1.5, unit: 's' },
    ],
    previewRadius: (p) => p.size,
  },
];

export const TOOL_BY_ID: Record<ToolId, ToolDef> = Object.fromEntries(TOOLS.map((t) => [t.id, t])) as Record<ToolId, ToolDef>;

export const CATEGORY_LABEL: Record<ToolCategory, string> = {
  impact: 'Impact',
  energy: 'Energy',
  gravity: 'Gravity',
  space: 'Space',
  anomaly: 'Anomaly',
  cosmic: 'Cosmic',
  special: 'Special',
};

export function defaultParams(t: ToolDef) {
  return Object.fromEntries(t.params.map((p) => [p.key, p.default]));
}
