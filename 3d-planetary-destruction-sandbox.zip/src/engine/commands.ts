import * as THREE from 'three';
import type { PlanetScene } from './PlanetScene';
import type { SystemScene } from './SystemScene';
import type { PlanetDef, ToolId } from './types';
import { useStore } from '../state/store';
import { bus } from './EventBus';

/**
 * Centralised command layer. UI, keyboard shortcuts, replays and (future) AI agents all go through here,
 * so behaviour never depends on which button was pressed. Also exposed as window.__cosmos for inspection.
 */
export type Command =
  | { type: 'PAUSE_SIMULATION'; paused?: boolean }
  | { type: 'SET_SIMULATION_SPEED'; speed: number }
  | { type: 'RESET_WORLD' }
  | { type: 'TRIGGER_EVENT'; tool: ToolId; params?: Record<string, number>; lat: number; lon: number; seed?: number }
  | { type: 'SELECT_TOOL'; tool: ToolId }
  | { type: 'FOCUS_BODY'; id?: string; lat?: number; lon?: number }
  | { type: 'TOGGLE_ORBITS'; value?: boolean }
  | { type: 'TOGGLE_ATMOSPHERE' }
  | { type: 'SAVE_WORLD'; planet: PlanetDef }
  | { type: 'LOAD_WORLD'; id: string }
  | { type: 'CREATE_PLANET'; planet: PlanetDef }
  | { type: 'SAVE_STATE'; name?: string }
  | { type: 'RESTORE_STATE'; id: string }
  | { type: 'SET_CAMERA_MODE'; mode: 'orbit' | 'cinematic' | 'follow' }
  | { type: 'START_BREAKUP' };

class CommandBus {
  planetScene: PlanetScene | null = null;
  systemScene: SystemScene | null = null;
  private listeners = new Set<(c: Command) => void>();

  onCommand(fn: (c: Command) => void) { this.listeners.add(fn); return () => this.listeners.delete(fn); }

  dispatch(cmd: Command) {
    const ps = this.planetScene, ss = this.systemScene;
    switch (cmd.type) {
      case 'PAUSE_SIMULATION': { const p = cmd.paused ?? !(ps?.paused ?? ss?.paused ?? false); ps?.setPaused(p); ss?.setPaused(p); break; }
      case 'SET_SIMULATION_SPEED': ps?.setSpeed(cmd.speed); ss?.setSpeed(cmd.speed); break;
      case 'RESET_WORLD': ps?.reset(); ss?.reset(); break;
      case 'TRIGGER_EVENT': {
        if (!ps) break;
        const d = new THREE.Vector3(Math.cos(cmd.lat) * Math.cos(cmd.lon), Math.sin(cmd.lat), Math.cos(cmd.lat) * Math.sin(cmd.lon));
        ps.trigger(cmd.tool, cmd.params ?? {}, d, cmd.seed);
        break;
      }
      case 'SELECT_TOOL': if (ps) ps.toolId = cmd.tool; break;
      case 'FOCUS_BODY':
        if (ss && cmd.id) ss.focus(cmd.id, true);
        else if (ps && cmd.lat !== undefined && cmd.lon !== undefined) ps.focusImpactSite(new THREE.Vector3(Math.cos(cmd.lat) * Math.cos(cmd.lon), Math.sin(cmd.lat), Math.cos(cmd.lat) * Math.sin(cmd.lon)));
        else { ps?.stopFollow(); ss?.stopFollow(); }
        break;
      case 'TOGGLE_ORBITS': ss?.setOverlays({ orbits: cmd.value ?? !ss.overlays.orbits }); break;
      case 'TOGGLE_ATMOSPHERE': if (ps?.planet) { const a = ps.planet.root.getObjectByProperty('renderOrder', 3); if (a) a.visible = !a.visible; } break;
      case 'SAVE_WORLD': useStore.getState().saveWorld(cmd.planet); bus.emit('toast', { text: `Saved world "${cmd.planet.name}"` }); break;
      case 'LOAD_WORLD': { const w = useStore.getState().customWorlds.find((x) => x.id === cmd.id); if (w) { useStore.getState().setSelectedPlanet(w); useStore.getState().setScreen('smash'); } break; }
      case 'CREATE_PLANET': useStore.getState().setSelectedPlanet(cmd.planet); useStore.getState().setScreen('smash'); break;
      case 'SAVE_STATE': ps?.saveSnapshot(cmd.name); break;
      case 'RESTORE_STATE': ps?.restoreSnapshot(cmd.id); break;
      case 'SET_CAMERA_MODE': { const rig = ps?.rig ?? ss?.rig; if (rig) { rig.mode = cmd.mode; if (cmd.mode !== 'follow') rig.followFn = null; } break; }
      case 'START_BREAKUP': ps?.startBreakup(); break;
    }
    this.listeners.forEach((l) => l(cmd));
  }

  /** AI-ready query surface */
  getState() {
    return { screen: useStore.getState().screen, planet: this.planetScene?.getState() ?? null, system: this.systemScene?.getState() ?? null, settings: useStore.getState().settings };
  }
}

export const commands = new CommandBus();
(window as unknown as { __cosmos: unknown }).__cosmos = { dispatch: (c: Command) => commands.dispatch(c), getState: () => commands.getState() };
