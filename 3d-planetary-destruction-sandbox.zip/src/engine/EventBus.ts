import type { SimEvent } from './types';

type Handler<T> = (payload: T) => void;

/** Minimal typed event emitter used to synchronise simulation, effects, audio, timeline and replay. */
export class Emitter<Events extends Record<string, unknown>> {
  private map = new Map<keyof Events, Set<Handler<never>>>();
  on<K extends keyof Events>(type: K, fn: Handler<Events[K]>): () => void {
    if (!this.map.has(type)) this.map.set(type, new Set());
    this.map.get(type)!.add(fn as Handler<never>);
    return () => this.off(type, fn);
  }
  off<K extends keyof Events>(type: K, fn: Handler<Events[K]>) {
    this.map.get(type)?.delete(fn as Handler<never>);
  }
  emit<K extends keyof Events>(type: K, payload: Events[K]) {
    this.map.get(type)?.forEach((fn) => {
      try {
        (fn as Handler<Events[K]>)(payload);
      } catch (e) {
        console.error('[event handler]', type, e);
      }
    });
  }
  clear() {
    this.map.clear();
  }
}

export interface GlobalEvents extends Record<string, unknown> {
  sim: SimEvent;
  /** audio cues */
  audio: { cue: 'impact' | 'rumble' | 'fracture' | 'ui' | 'charge' | 'whoosh' | 'collision' | 'breakup'; intensity: number };
  /** short toast notifications */
  toast: { text: string; kind?: 'info' | 'warn' | 'error' };
  /** camera shake request */
  shake: { intensity: number; duration: number; dir?: [number, number, number] };
  stats: Record<string, unknown>;
}

export const bus = new Emitter<GlobalEvents>();

let eventId = 1;
export function simEvent(type: SimEvent['type'], time: number, label: string, data?: Record<string, unknown>): SimEvent {
  const ev: SimEvent = { id: eventId++, type, time, wall: Date.now(), label, data };
  bus.emit('sim', ev);
  return ev;
}
