import { bus } from '../engine/EventBus';

/**
 * Procedural WebAudio engine. No audio assets: every cue is synthesised (noise bursts, sub-bass thumps,
 * filtered drones). Music intensity follows simulation state (planet integrity) via a low-pass filter sweep.
 */
class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicGain!: GainNode;
  private sfxGain!: GainNode;
  private musicFilter!: BiquadFilterNode;
  private drones: OscillatorNode[] = [];
  private noiseBuf: AudioBuffer | null = null;
  private started = false;
  private unsub: (() => void) | null = null;
  volumes = { master: 0.8, music: 0.5, sfx: 0.8 };
  intensity = 0;

  /** Must be called from a user gesture. Safe to call repeatedly. */
  start() {
    if (this.started) { if (this.ctx?.state === 'suspended') void this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
    } catch { return; }
    const ctx = this.ctx;
    this.master = ctx.createGain(); this.master.connect(ctx.destination);
    this.musicGain = ctx.createGain(); this.sfxGain = ctx.createGain();
    this.musicFilter = ctx.createBiquadFilter(); this.musicFilter.type = 'lowpass'; this.musicFilter.frequency.value = 400; this.musicFilter.Q.value = 0.7;
    this.musicGain.connect(this.musicFilter).connect(this.master);
    this.sfxGain.connect(this.master);
    // noise buffer
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // ambient drone: detuned low oscillators + slow LFO
    const freqs = [55, 55.4, 82.5, 110.3];
    freqs.forEach((f, i) => {
      const o = ctx.createOscillator(); o.type = i % 2 ? 'sine' : 'triangle'; o.frequency.value = f;
      const g = ctx.createGain(); g.gain.value = i < 2 ? 0.08 : 0.035;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.05 + i * 0.023; const lg = ctx.createGain(); lg.gain.value = 0.02;
      lfo.connect(lg).connect(g.gain); lfo.start();
      o.connect(g).connect(this.musicGain); o.start();
      this.drones.push(o);
    });
    // soft shimmering high pad
    const pad = ctx.createOscillator(); pad.type = 'sine'; pad.frequency.value = 440; const pg = ctx.createGain(); pg.gain.value = 0.006;
    const plfo = ctx.createOscillator(); plfo.frequency.value = 0.11; const plg = ctx.createGain(); plg.gain.value = 3; plfo.connect(plg).connect(pad.frequency); plfo.start();
    pad.connect(pg).connect(this.musicGain); pad.start();
    this.applyVolumes();
    this.started = true;
    this.unsub = bus.on('audio', ({ cue, intensity }) => this.play(cue, intensity));
  }

  setVolumes(v: Partial<typeof this.volumes>) { Object.assign(this.volumes, v); this.applyVolumes(); }
  private applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.volumes.master, t, 0.05);
    this.musicGain.gain.setTargetAtTime(this.volumes.music * 0.9, t, 0.1);
    this.sfxGain.gain.setTargetAtTime(this.volumes.sfx, t, 0.05);
  }
  /** 0..1: raises music brightness/tension during major events. */
  setIntensity(v: number) {
    this.intensity = v;
    if (!this.ctx) return;
    this.musicFilter.frequency.setTargetAtTime(350 + v * 2200, this.ctx.currentTime, 0.6);
  }

  private noise(dur: number, gain: number, filterFreq: number, type: BiquadFilterType = 'lowpass', decay = dur) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource(); src.buffer = this.noiseBuf; src.loop = true;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = filterFreq;
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + decay);
    src.connect(f).connect(g).connect(this.sfxGain);
    src.start(); src.stop(ctx.currentTime + dur + 0.05);
    return f;
  }
  private tone(freq: number, dur: number, gain: number, type: OscillatorType = 'sine', sweepTo?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, ctx.currentTime);
    if (sweepTo) o.frequency.exponentialRampToValueAtTime(sweepTo, ctx.currentTime + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    o.connect(g).connect(this.sfxGain); o.start(); o.stop(ctx.currentTime + dur + 0.05);
  }

  play(cue: string, intensity = 0.5) {
    if (!this.ctx || this.ctx.state !== 'running') return;
    const k = Math.min(Math.max(intensity, 0.05), 1);
    switch (cue) {
      case 'impact': this.noise(1.2 + k * 1.5, 0.5 * k + 0.1, 300 + k * 900); this.tone(60 + k * 20, 0.8 + k, 0.5 * k, 'sine', 25); break;
      case 'rumble': this.noise(3 + k * 3, 0.25 * k, 120, 'lowpass', 4); this.tone(38, 3, 0.3 * k, 'triangle'); break;
      case 'fracture': this.noise(1.5, 0.35, 1800, 'bandpass', 1.2); this.tone(90, 1.5, 0.35, 'sawtooth', 30); break;
      case 'breakup': this.noise(6, 0.45, 200, 'lowpass', 6); this.tone(45, 6, 0.45, 'triangle', 20); this.tone(220, 2.5, 0.08, 'sawtooth', 40); break;
      case 'collision': this.noise(2.5, 0.5, 600, 'lowpass', 2.5); this.tone(70, 2, 0.4, 'sine', 24); break;
      case 'whoosh': { const f = this.noise(1.1, 0.18 * k + 0.05, 400, 'bandpass', 1.0); f.frequency.exponentialRampToValueAtTime(3000, this.ctx.currentTime + 0.9); break; }
      case 'charge': this.tone(120, 1.4, 0.12 * k + 0.03, 'sine', 900); this.noise(1.4, 0.06, 2500, 'highpass', 1.4); break;
      case 'ui': this.tone(1400, 0.07, 0.04, 'sine', 900); break;
    }
  }
  dispose() { this.unsub?.(); this.drones.forEach((d) => d.stop()); void this.ctx?.close(); this.ctx = null; this.started = false; }
}

export const audio = new AudioEngine();
