import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { PlanetDef, Replay, Settings, SystemDef } from '../engine/types';

export type Screen = 'menu' | 'select' | 'smash' | 'system' | 'lab' | 'galaxy' | 'worlds' | 'settings';

export const DEFAULT_SETTINGS: Settings = {
  quality: 'high',
  particleScale: 1,
  shadows: true,
  postProcessing: true,
  cameraShake: 0.7,
  reducedMotion: false,
  reducedFlashing: false,
  highContrast: false,
  uiScale: 1,
  musicVolume: 0.5,
  sfxVolume: 0.8,
  masterVolume: 0.8,
  invertZoom: false,
  showHints: true,
  scientificMode: false,
};

/** Detect a sensible default quality for the device. */
export function detectQuality(): Settings['quality'] {
  const cores = navigator.hardwareConcurrency || 4;
  const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 8;
  const mobile = /Mobi|Android/i.test(navigator.userAgent);
  if (mobile) return cores >= 8 && mem >= 6 ? 'balanced' : 'performance';
  if (cores >= 8 && mem >= 8) return 'high';
  if (cores >= 4) return 'balanced';
  return 'performance';
}

export interface CameraBookmark { id: string; name: string; theta: number; phi: number; dist: number; planetId: string }

interface UIState {
  screen: Screen;
  selectedPlanet: PlanetDef | null;
  selectedSystem: SystemDef | null;
  labPlanet: PlanetDef | null;
  settings: Settings;
  customWorlds: PlanetDef[];
  customSystems: SystemDef[];
  replays: Replay[];
  bookmarks: CameraBookmark[];
  debug: boolean;
  audioStarted: boolean;
  pendingReplay: Replay | null;
  setPendingReplay: (r: Replay | null) => void;
  setScreen: (s: Screen) => void;
  setSelectedPlanet: (p: PlanetDef | null) => void;
  setSelectedSystem: (s: SystemDef | null) => void;
  setLabPlanet: (p: PlanetDef | null) => void;
  updateSettings: (p: Partial<Settings>) => void;
  saveWorld: (p: PlanetDef) => void;
  deleteWorld: (id: string) => void;
  saveSystem: (s: SystemDef) => void;
  deleteSystem: (id: string) => void;
  saveReplay: (r: Replay) => void;
  deleteReplay: (id: string) => void;
  saveBookmark: (b: CameraBookmark) => void;
  deleteBookmark: (id: string) => void;
  toggleDebug: () => void;
  setAudioStarted: () => void;
}

export const useStore = create<UIState>()(
  persist(
    (set) => ({
      screen: 'menu',
      selectedPlanet: null,
      selectedSystem: null,
      labPlanet: null,
      settings: { ...DEFAULT_SETTINGS, quality: detectQuality() },
      customWorlds: [],
      customSystems: [],
      replays: [],
      bookmarks: [],
      debug: false,
      audioStarted: false,
      pendingReplay: null,
      setPendingReplay: (pendingReplay) => set({ pendingReplay }),
      setScreen: (screen) => set({ screen }),
      setSelectedPlanet: (selectedPlanet) => set({ selectedPlanet }),
      setSelectedSystem: (selectedSystem) => set({ selectedSystem }),
      setLabPlanet: (labPlanet) => set({ labPlanet }),
      updateSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      saveWorld: (p) => set((s) => ({ customWorlds: [...s.customWorlds.filter((w) => w.id !== p.id), p] })),
      deleteWorld: (id) => set((s) => ({ customWorlds: s.customWorlds.filter((w) => w.id !== id) })),
      saveSystem: (sys) => set((s) => ({ customSystems: [...s.customSystems.filter((w) => w.id !== sys.id), sys] })),
      deleteSystem: (id) => set((s) => ({ customSystems: s.customSystems.filter((w) => w.id !== id) })),
      saveReplay: (r) => set((s) => ({ replays: [...s.replays.filter((x) => x.id !== r.id), r].slice(-12) })),
      deleteReplay: (id) => set((s) => ({ replays: s.replays.filter((r) => r.id !== id) })),
      saveBookmark: (b) => set((s) => ({ bookmarks: [...s.bookmarks, b].slice(-30) })),
      deleteBookmark: (id) => set((s) => ({ bookmarks: s.bookmarks.filter((b) => b.id !== id) })),
      toggleDebug: () => set((s) => ({ debug: !s.debug })),
      setAudioStarted: () => set({ audioStarted: true }),
    }),
    {
      name: 'cosmos-sandbox-v1',
      partialize: (s) => ({ settings: s.settings, customWorlds: s.customWorlds, customSystems: s.customSystems, replays: s.replays, bookmarks: s.bookmarks }),
      // Corrupt saved data must never break the app
      merge: (persisted, current) => {
        try {
          const p = (persisted ?? {}) as Partial<UIState>;
          return { ...current, ...p, settings: { ...current.settings, ...(p.settings ?? {}) }, customWorlds: Array.isArray(p.customWorlds) ? p.customWorlds.filter((w) => w && w.id && w.palette) : [], customSystems: Array.isArray(p.customSystems) ? p.customSystems.filter((w) => w && Array.isArray(w.bodies)) : [], replays: Array.isArray(p.replays) ? p.replays.filter((r) => r && Array.isArray(r.actions)) : [], bookmarks: Array.isArray(p.bookmarks) ? p.bookmarks : [] };
        } catch {
          return current;
        }
      },
    },
  ),
);
