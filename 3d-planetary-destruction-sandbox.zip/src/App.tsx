import { useEffect, useMemo } from 'react';
import { audio } from './audio/AudioEngine';
import { PLANET_PRESETS } from './engine/planets';
import { generateSystem } from './engine/SystemScene';
import { useStore } from './state/store';
import { ErrorBoundary, Toasts, cx } from './ui/common';
import { CustomWorlds } from './ui/CustomWorlds';
import { GalaxyView } from './ui/GalaxyView';
import { MainMenu } from './ui/MainMenu';
import { PlanetLab } from './ui/PlanetLab';
import { PlanetSelect } from './ui/PlanetSelect';
import { PlanetSmash } from './ui/PlanetSmash';
import { SettingsPanel } from './ui/SettingsPanel';
import { SystemSmash } from './ui/SystemSmash';

function supportsWebGL2() {
  try { const c = document.createElement('canvas'); return !!c.getContext('webgl2'); } catch { return false; }
}

export default function App() {
  const screen = useStore((s) => s.screen);
  const selectedPlanet = useStore((s) => s.selectedPlanet);
  const selectedSystem = useStore((s) => s.selectedSystem);
  const settings = useStore((s) => s.settings);
  const setScreen = useStore((s) => s.setScreen);
  const ok = useMemo(supportsWebGL2, []);
  const planet = selectedPlanet ?? PLANET_PRESETS[0];
  const system = useMemo(() => selectedSystem ?? generateSystem(20260101, 'Home System'), [selectedSystem]);

  // audio must start on a user gesture; resume on any interaction afterwards
  useEffect(() => {
    const h = () => { if (useStore.getState().audioStarted) audio.start(); };
    window.addEventListener('pointerdown', h); window.addEventListener('keydown', h);
    return () => { window.removeEventListener('pointerdown', h); window.removeEventListener('keydown', h); };
  }, []);
  useEffect(() => { document.documentElement.style.setProperty('--ui-scale', String(settings.uiScale)); }, [settings.uiScale]);
  useEffect(() => { audio.setVolumes({ master: settings.masterVolume, music: settings.musicVolume, sfx: settings.sfxVolume }); }, [settings.masterVolume, settings.musicVolume, settings.sfxVolume]);

  if (!ok) {
    return (
      <div className="absolute inset-0 flex items-center justify-center p-6">
        <div className="panel max-w-md p-6"><div className="label text-[var(--danger)] mb-2">WebGL2 unavailable</div><p className="text-sm text-[var(--ink-dim)]">This simulation renders planets on the GPU and requires WebGL2. Please enable hardware acceleration or use a current version of Chrome, Edge, Firefox or Safari.</p></div>
      </div>
    );
  }

  return (
    <div className={cx('absolute inset-0 bg-[var(--bg)] text-[var(--ink)]', settings.reducedMotion && 'reduced-motion', settings.highContrast && 'hc')} style={{ ['--ui-scale' as string]: settings.uiScale }}>
      <ErrorBoundary key={screen} onReset={() => setScreen('menu')}>
        {screen === 'menu' && <MainMenu />}
        {screen === 'select' && <PlanetSelect />}
        {screen === 'smash' && <PlanetSmash key={planet.id + planet.seed} planet={planet} />}
        {screen === 'system' && <SystemSmash key={system.id} system={system} />}
        {screen === 'lab' && <PlanetLab />}
        {screen === 'galaxy' && <GalaxyView />}
        {screen === 'worlds' && <CustomWorlds />}
        {screen === 'settings' && <SettingsPanel />}
      </ErrorBoundary>
      <Toasts />
    </div>
  );
}
