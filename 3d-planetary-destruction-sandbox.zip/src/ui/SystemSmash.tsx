import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
const UP = new THREE.Vector3(0, 1, 0);
import { audio } from '../audio/AudioEngine';
import { commands } from '../engine/commands';
import { bus } from '../engine/EventBus';
import { SIM_SPEEDS } from '../engine/PlanetScene';
import { STAR_CLASSES } from '../engine/planets';
import { SystemScene, generateSystem, type SystemOverlays, type SystemTool } from '../engine/SystemScene';
import type { DebugInfo, SimEvent, StarClass, SystemDef } from '../engine/types';
import { useStore } from '../state/store';
import { Button, DebugOverlay, Kbd, Panel, Slider, Stat, Toggle, cx, fmt } from './common';

const TOOLS: { id: SystemTool; name: string; hint: string }[] = [
  { id: 'select', name: 'Select / follow', hint: 'Click a body to select and follow it' },
  { id: 'add-planet', name: 'Add planet', hint: 'Click empty space: circular orbit around the star' },
  { id: 'add-moon', name: 'Add moon', hint: 'Click near a planet (or with one selected)' },
  { id: 'add-rogue', name: 'Rogue body', hint: 'Click a launch point: aimed at the selected body' },
  { id: 'anomaly', name: 'Gravity anomaly', hint: 'Temporary massive point that bends every orbit' },
  { id: 'nudge', name: 'Nudge', hint: 'Push the selected body toward the clicked point' },
  { id: 'measure', name: 'Measure', hint: 'Click two bodies / points' },
];

export function SystemSmash({ system }: { system: SystemDef }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const labelsRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<SystemScene | null>(null);
  const { setScreen, settings, debug, toggleDebug, customSystems, saveSystem, deleteSystem } = useStore();
  const [error, setError] = useState<string | null>(null);
  const [dbg, setDbg] = useState<DebugInfo | null>(null);
  const [paused, setPaused] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(4);
  const [tool, setTool] = useState<SystemTool>('select');
  const [overlays, setOverlays] = useState<SystemOverlays>({ orbits: true, velocity: false, gravity: false, labels: true, distances: false });
  const [tick, setTick] = useState(0);
  const [events, setEvents] = useState<SimEvent[]>([]);
  const [panel, setPanel] = useState<'bodies' | 'timeline' | 'saved' | null>('bodies');
  const [measure, setMeasure] = useState<{ distance: number; points: number } | null>(null);
  const [name, setName] = useState(system.name);
  const [hideUI, setHideUI] = useState(false);

  useEffect(() => {
    const host = hostRef.current!;
    let scene: SystemScene;
    try { scene = new SystemScene(host, useStore.getState().settings, system); } catch (e) { setError((e as Error).message); return; }
    sceneRef.current = scene; commands.systemScene = scene;
    scene.onDebug = setDbg;
    scene.onChange = () => setTick((t) => t + 1);
    scene.onMeasure = setMeasure;
    // labels are positioned imperatively (no React re-render per frame)
    const nodes = new Map<string, HTMLSpanElement>();
    scene.onLabels = (list) => {
      const c = labelsRef.current; if (!c) return;
      const seen = new Set<string>();
      for (const l of list) {
        seen.add(l.id);
        let n = nodes.get(l.id);
        if (!n) { n = document.createElement('span'); n.className = 'absolute mono text-[0.62em] tracking-wider text-[var(--ink-dim)] -translate-x-1/2 -translate-y-full whitespace-nowrap pointer-events-none'; c.appendChild(n); nodes.set(l.id, n); }
        n.textContent = l.name.toUpperCase();
        n.style.transform = `translate(${l.x}px, ${l.y}px) translate(-50%, -100%)`;
        n.style.display = l.visible && (l.kind !== 'moon' || scene.rig.dist < 25) ? 'block' : 'none';
        n.style.color = l.id === scene.selectedId ? 'var(--accent)' : l.kind === 'star' ? 'var(--accent-2)' : '';
      }
      for (const [id, n] of nodes) if (!seen.has(id)) { n.remove(); nodes.delete(id); }
    };
    const unsub = bus.on('sim', (ev) => setEvents((e) => (ev.type === 'RESET' || ev.type === 'WORLD_CREATED' ? [ev] : [...e.slice(-79), ev])));
    return () => { unsub(); scene.dispose(); nodes.forEach((n) => n.remove()); if (commands.systemScene === scene) commands.systemScene = null; };
  }, [system]);
  useEffect(() => { sceneRef.current?.applySettings(settings); audio.setVolumes({ master: settings.masterVolume, music: settings.musicVolume, sfx: settings.sfxVolume }); }, [settings]);
  useEffect(() => { const s = sceneRef.current; if (s) { s.tool = tool; if (tool !== 'measure') s.clearMeasure(); } }, [tool]);
  useEffect(() => { sceneRef.current?.setOverlays(overlays); }, [overlays]);

  const setSpeed = useCallback((i: number) => { const idx = Math.max(0, Math.min(SIM_SPEEDS.length - 1, i)); setSpeedIdx(idx); commands.dispatch({ type: 'SET_SIMULATION_SPEED', speed: SIM_SPEEDS[idx] }); }, []);
  const togglePause = useCallback(() => setPaused((p) => { commands.dispatch({ type: 'PAUSE_SIMULATION', paused: !p }); return !p; }), []);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      switch (e.key) {
        case ' ': e.preventDefault(); togglePause(); break;
        case 'r': case 'R': commands.dispatch({ type: 'RESET_WORLD' }); break;
        case 'Escape': if (hideUI) setHideUI(false); else setScreen('menu'); break;
        case '[': setSpeed(speedIdx - 1); break;
        case ']': setSpeed(speedIdx + 1); break;
        case 'F3': e.preventDefault(); toggleDebug(); break;
        case 'h': case 'H': setHideUI((v) => !v); break;
        case 'f': case 'F': sceneRef.current?.stopFollow(); break;
        case 'o': case 'O': setOverlays((o) => ({ ...o, orbits: !o.orbits })); break;
        case 'Delete': if (sceneRef.current?.selectedId) sceneRef.current.removeBody(sceneRef.current.selectedId); break;
        default: { const n = parseInt(e.key, 10); if (n >= 1 && n <= TOOLS.length) setTool(TOOLS[n - 1].id); }
      }
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [togglePause, setSpeed, speedIdx, setScreen, toggleDebug, hideUI]);

  const onUp = (e: React.PointerEvent) => { const s = sceneRef.current; if (!s || !s.rig.wasClick() || e.button !== 0) return; s.click(e.clientX, e.clientY); };
  const scene = sceneRef.current;
  const sel = scene?.bodies.find((b) => b.id === scene.selectedId) ?? null;
  const star = scene?.bodies.find((b) => b.kind === 'star');
  void tick;

  return (
    <div className={cx('absolute inset-0 overflow-hidden select-none', settings.highContrast && 'hc', settings.reducedMotion && 'reduced-motion')} style={{ ['--ui-scale' as string]: settings.uiScale }}>
      <div ref={hostRef} className="absolute inset-0" onPointerUp={onUp} role="application" aria-label="3D star system simulation" />
      <div ref={labelsRef} className={cx('absolute inset-0 pointer-events-none transition-opacity', hideUI && 'opacity-0')} aria-hidden />
      {error && <div className="absolute inset-0 flex items-center justify-center bg-[var(--bg)] z-50"><div className="panel p-6 max-w-md"><div className="label text-[var(--danger)] mb-2">Renderer unavailable</div><p className="text-sm text-[var(--ink-dim)]">{error}</p><Button className="mt-4" variant="solid" onClick={() => setScreen('menu')}>Back</Button></div></div>}
      {debug && <DebugOverlay info={dbg} />}

      <div className={cx('absolute top-0 inset-x-0 z-30 flex flex-wrap items-start justify-between p-3 gap-2 pointer-events-none transition-opacity', hideUI && 'opacity-0')}>
        <div className="flex items-center gap-2 pointer-events-auto">
          <Button size="sm" onClick={() => setScreen('menu')} ariaLabel="Back">←</Button>
          <div className="panel px-3 py-1.5"><input aria-label="System name" className="!bg-transparent !border-transparent !p-0 text-[0.95em] w-40" value={name} onChange={(e) => setName(e.target.value)} /><div className="label">{scene?.bodies.length ?? 0} bodies · {star ? STAR_CLASSES[(star.def.starClass ?? 'sun-like') as StarClass].name : ''} · {scene?.collisions ?? 0} collisions</div></div>
        </div>
        <div className="panel flex items-center gap-1 px-1.5 py-1 pointer-events-auto" role="toolbar" aria-label="Simulation time">
          <Button size="sm" onClick={togglePause} ariaLabel={paused ? 'Play' : 'Pause'}>{paused ? '▶' : '❚❚'}</Button>
          <Button size="sm" onClick={() => setSpeed(speedIdx - 1)} ariaLabel="Slower">◂</Button>
          <select aria-label="Simulation speed" className="mono text-[0.75em] !py-0.5 !px-1 !border-transparent bg-transparent" value={speedIdx} onChange={(e) => setSpeed(parseInt(e.target.value, 10))}>{SIM_SPEEDS.map((s, i) => <option key={s} value={i} className="bg-black">{s}×</option>)}</select>
          <Button size="sm" onClick={() => setSpeed(speedIdx + 1)} ariaLabel="Faster">▸</Button>
          <span className="mono text-[0.72em] text-[var(--ink-dim)] w-16 text-center">{fmt.time(dbg?.simTime ?? 0)}</span>
          <span className="w-px h-4 bg-[var(--line)]" />
          <Button size="sm" onClick={() => commands.dispatch({ type: 'RESET_WORLD' })} title="R">Reset</Button>
          <Button size="sm" onClick={() => sceneRef.current?.stopFollow()} title="F">Frame system</Button>
        </div>
        <div className="panel flex items-center gap-1 px-1.5 py-1 pointer-events-auto">
          <Button size="sm" active={panel === 'bodies'} onClick={() => setPanel(panel === 'bodies' ? null : 'bodies')}>Bodies</Button>
          <Button size="sm" active={panel === 'timeline'} onClick={() => setPanel(panel === 'timeline' ? null : 'timeline')}>Timeline</Button>
          <Button size="sm" active={panel === 'saved'} onClick={() => setPanel(panel === 'saved' ? null : 'saved')}>Systems</Button>
          <Button size="sm" onClick={() => setScreen('settings')} ariaLabel="Settings">⚙</Button>
        </div>
      </div>

      {/* left: tools + overlays */}
      <div className={cx('absolute left-3 top-16 bottom-16 z-20 w-[250px] flex flex-col gap-2 pointer-events-none overflow-y-auto transition-opacity', hideUI && 'opacity-0')}>
        <Panel title="Interaction">
          <div className="flex flex-col gap-0.5" role="listbox">
            {TOOLS.map((t, i) => <button key={t.id} role="option" aria-selected={tool === t.id} onClick={() => setTool(t.id)} className={cx('flex items-start gap-2 text-left px-2 py-1.5 border transition-colors', tool === t.id ? 'border-[var(--line-strong)] bg-white/5' : 'border-transparent hover:bg-white/5')}><span className="mono text-[0.65em] text-[var(--ink-faint)] mt-1">{i + 1}</span><span><span className="block text-[0.85em]">{t.name}</span><span className="block text-[0.68em] text-[var(--ink-faint)] leading-snug">{t.hint}</span></span></button>)}
          </div>
          {measure && <div className="mt-2 pt-2 border-t hairline mono text-[0.75em]">{measure.points === 2 ? <>Distance <span className="text-[var(--accent)]">{measure.distance.toFixed(2)} u</span> ≈ {(measure.distance * 0.1).toFixed(2)} AU</> : 'Click second point…'}</div>}
        </Panel>
        <Panel title="Visualization">
          <Toggle label="Orbit trails" value={overlays.orbits} onChange={(v) => setOverlays((o) => ({ ...o, orbits: v }))} />
          <Toggle label="Velocity vectors" value={overlays.velocity} onChange={(v) => setOverlays((o) => ({ ...o, velocity: v }))} />
          <Toggle label="Gravity well" value={overlays.gravity} onChange={(v) => setOverlays((o) => ({ ...o, gravity: v }))} />
          <Toggle label="Body labels" value={overlays.labels} onChange={(v) => setOverlays((o) => ({ ...o, labels: v }))} />
          <Toggle label="Distance markers" hint="rings every 10 u (≈1 AU)" value={overlays.distances} onChange={(v) => setOverlays((o) => ({ ...o, distances: v }))} />
        </Panel>
        <Panel title="Showcase">
          <div className="flex flex-col gap-1">
            <Button size="sm" className="justify-start" onClick={() => { const s = sceneRef.current; if (!s) return; const planets = s.bodies.filter((b) => b.kind === 'planet'); const target = planets.sort((a, b) => b.mass - a.mass)[0]; if (!target) return; const from = target.pos.clone().multiplyScalar(1.6).add(target.vel.clone().multiplyScalar(-2)); const dir = target.pos.clone().sub(from).normalize(); s.addBody({ name: 'Impactor', kind: 'rogue', mass: target.mass * 0.4, radius: target.radius * 0.7, position: from.toArray() as [number, number, number], velocity: dir.multiplyScalar(6).add(target.vel.clone().multiplyScalar(0.6)).toArray() as [number, number, number], color: '#c96a3a', seed: 5 }); s.select(target.id); s.focus(target.id); }}>Planetary collision</Button>
            <Button size="sm" className="justify-start" onClick={() => { const s = sceneRef.current; if (!s) return; for (const b of s.bodies) if (b.kind !== 'star') b.vel.multiplyScalar(0.75 + Math.random() * 0.6).applyAxisAngle(UP, (Math.random() - 0.5) * 0.6); bus.emit('toast', { text: 'Orbits perturbed - watch the system evolve' }); }}>Star system chaos</Button>
            <Button size="sm" className="justify-start" onClick={() => { const s = sceneRef.current; if (!s || !star) return; s.addBody({ name: 'Wandering star', kind: 'star', starClass: 'red-dwarf', mass: star.mass * 0.35, radius: 0.7, position: [60, 4, -40], velocity: [-7, -0.4, 5], color: '#ff6a3d', seed: 11 }); bus.emit('toast', { text: 'A red dwarf is passing through the system' }); }}>Stellar flyby</Button>
            <Button size="sm" className="justify-start" onClick={() => { const s = sceneRef.current; if (!s) return; s.loadSystem(generateSystem(Math.floor(Math.random() * 1e9))); setName(s.current.name); }}>Random system</Button>
          </div>
        </Panel>
      </div>

      {/* right panels */}
      <div className={cx('absolute right-3 top-16 bottom-16 z-20 w-[300px] max-w-[calc(100vw-1.5rem)] flex flex-col gap-2 pointer-events-none overflow-hidden transition-opacity', hideUI && 'opacity-0', !panel && 'hidden')}>
        {panel === 'bodies' && scene && (
          <Panel title="Bodies" onClose={() => setPanel(null)} className="flex-1 min-h-0 flex flex-col [&>div]:flex-1 [&>div]:min-h-0 [&>div]:overflow-y-auto" right={<Button size="sm" variant="line" onClick={() => { saveSystem({ ...scene.exportSystem(), id: system.id.startsWith('custom') ? system.id : `custom-${Date.now()}`, name }); bus.emit('toast', { text: `System "${name}" saved` }); }}>Save system</Button>}>
            <ul className="flex flex-col">
              {scene.bodies.map((b) => (
                <li key={b.id}>
                  <button onClick={() => { scene.select(b.id); scene.focus(b.id); }} className={cx('w-full flex items-center gap-2 py-1.5 text-left border-b hairline hover:bg-white/5', scene.selectedId === b.id && 'text-[var(--accent)]')}>
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: b.def.color, boxShadow: b.kind === 'star' ? `0 0 8px ${b.def.color}` : undefined }} />
                    <span className="flex-1 text-[0.85em] truncate">{b.name}</span>
                    <span className="mono text-[0.65em] text-[var(--ink-faint)]">{b.kind} · m {fmt.mass(b.mass)}</span>
                  </button>
                  {sel?.id === b.id && (
                    <div className="py-2 pl-4 flex flex-col gap-2 fade-up">
                      <input aria-label="Body name" className="text-[0.85em]" value={sel.name} onChange={(e) => scene.updateBody(sel.id, { name: e.target.value })} />
                      <Slider label="Mass" min={0.01} max={sel.kind === 'star' ? 4000 : 50} step={0.01} value={sel.mass} onChange={(v) => scene.updateBody(sel.id, { mass: v })} format={(v) => fmt.mass(v)} />
                      <Slider label="Radius" min={0.03} max={sel.kind === 'star' ? 6 : 1.5} step={0.01} value={sel.radius} onChange={(v) => scene.updateBody(sel.id, { radius: v })} />
                      <div className="grid grid-cols-3 gap-2"><Stat label="Speed" value={sel.vel.length().toFixed(2)} unit="u/s" /><Stat label="Dist. to star" value={star ? sel.pos.distanceTo(star.pos).toFixed(1) : '-'} unit="u" /><Stat label="≈ AU" value={star ? (sel.pos.distanceTo(star.pos) * 0.1).toFixed(2) : '-'} /></div>
                      <div className="flex flex-wrap gap-1">
                        <Button size="sm" variant="line" onClick={() => scene.updateBody(sel.id, { speedScale: 1.1 })}>Speed +10%</Button>
                        <Button size="sm" variant="line" onClick={() => scene.updateBody(sel.id, { speedScale: 0.9 })}>Speed −10%</Button>
                        <Button size="sm" variant="line" onClick={() => scene.circularize(sel.id)}>Circular orbit</Button>
                        <Button size="sm" variant="line" onClick={() => scene.updateBody(sel.id, { position: sel.pos.clone().multiplyScalar(1.15).toArray() as [number, number, number] })}>Move out</Button>
                        <Button size="sm" variant="line" onClick={() => scene.updateBody(sel.id, { position: sel.pos.clone().multiplyScalar(0.87).toArray() as [number, number, number] })}>Move in</Button>
                        {sel.kind !== 'star' && <Button size="sm" variant="danger" onClick={() => scene.removeBody(sel.id)}>Delete</Button>}
                      </div>
                    </div>
                  )}
                </li>
              ))}
            </ul>
            <div className="flex gap-1 mt-2">
              <Button size="sm" variant="line" className="flex-1" onClick={() => setTool('add-planet')}>+ Planet</Button>
              <Button size="sm" variant="line" className="flex-1" onClick={() => setTool('add-moon')}>+ Moon</Button>
              <Button size="sm" variant="line" className="flex-1" onClick={() => { const s = sceneRef.current; if (!s) return; s.addBody({ name: 'Companion star', kind: 'star', starClass: 'orange', mass: (star?.mass ?? 1000) * 0.5, radius: 1.0, position: [45, 0, 0], velocity: [0, 0, Math.sqrt((star?.mass ?? 1000) / 45) * 0.9], color: '#ffb066', seed: 3 }); }}>+ Star</Button>
            </div>
            <p className="text-[0.68em] text-[var(--ink-faint)] mt-2 leading-snug">SIMULATION: symplectic leapfrog N-body integration with softening; collisions merge momentum-conservingly or fragment when violent. 1 u ≈ 0.1 AU (display only).</p>
          </Panel>
        )}
        {panel === 'timeline' && (
          <Panel title="Timeline" onClose={() => setPanel(null)} className="flex-1 min-h-0 flex flex-col [&>div]:flex-1 [&>div]:min-h-0 [&>div]:overflow-y-auto">
            <ol className="flex flex-col-reverse gap-1.5">{events.map((ev) => <li key={ev.id} className="flex gap-2 text-[0.75em]"><span className="mono text-[var(--ink-faint)] w-12 shrink-0">{fmt.time(ev.time)}</span><span><span className="label block">{ev.type.replace(/_/g, ' ')}</span>{ev.label}</span></li>)}</ol>
          </Panel>
        )}
        {panel === 'saved' && (
          <Panel title="Saved systems" onClose={() => setPanel(null)} className="overflow-y-auto">
            <ul className="flex flex-col gap-1">
              {customSystems.map((s) => <li key={s.id} className="flex items-center gap-2 text-[0.8em]"><span className="flex-1 truncate">{s.name} <span className="text-[var(--ink-faint)]">· {s.bodies.length} bodies</span></span><Button size="sm" onClick={() => { sceneRef.current?.loadSystem(s); setName(s.name); }}>Load</Button><Button size="sm" variant="danger" onClick={() => deleteSystem(s.id)}>✕</Button></li>)}
              {customSystems.length === 0 && <li className="text-[0.8em] text-[var(--ink-dim)]">No saved systems. Use “Save system” in the Bodies panel.</li>}
            </ul>
          </Panel>
        )}
      </div>

      <div className={cx('absolute bottom-3 inset-x-3 z-20 flex items-end justify-between pointer-events-none transition-opacity', hideUI && 'opacity-0')}>
        <div className="panel px-3 py-2 mono text-[0.72em]"><div className="label mb-1">{TOOLS.find((t) => t.id === tool)?.name}</div><div className="text-[var(--ink-dim)]">{TOOLS.find((t) => t.id === tool)?.hint}{sel ? ` · selected: ${sel.name}` : ''}</div></div>
        {settings.showHints && <div className="label hidden md:flex gap-4"><span>Drag orbit</span><span>Wheel zoom</span><span><Kbd>O</Kbd> orbits</span><span><Kbd>Del</Kbd> remove</span><span><Kbd>H</Kbd> hide UI</span></div>}
      </div>
      {hideUI && <button className="absolute bottom-3 right-3 z-30 label px-2 py-1 opacity-40 hover:opacity-100" onClick={() => setHideUI(false)}>Show UI (H)</button>}
    </div>
  );
}
