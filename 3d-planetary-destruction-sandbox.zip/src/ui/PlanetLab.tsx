import { useEffect, useMemo, useRef, useState } from 'react';
import { bus } from '../engine/EventBus';
import type { PlanetScene } from '../engine/PlanetScene';
import { PLANET_PRESETS, TYPE_LABEL, clonePlanet, defaultPalette, planetStats, randomPlanet } from '../engine/planets';
import type { PlanetDef, PlanetPalette, PlanetType } from '../engine/types';
import { useStore } from '../state/store';
import { Button, Panel, Slider, Stat, Toggle, cx, fmt } from './common';
import { PlanetSmash } from './PlanetSmash';

const STRUCTURAL: (keyof PlanetDef)[] = ['seed', 'type', 'terrainRoughness', 'mountainFrequency', 'craterDensity', 'oceanCoverage', 'hasRings', 'radius', 'mass', 'magneticField'];
const TYPES: PlanetType[] = ['rocky', 'ocean', 'desert', 'ice', 'gas', 'lava', 'alien'];

export function PlanetLab() {
  const { labPlanet, setScreen, setSelectedPlanet, saveWorld, setLabPlanet } = useStore();
  const initial = useMemo<PlanetDef>(() => clonePlanet(labPlanet ?? { ...PLANET_PRESETS[0], id: `lab-${Date.now()}`, name: 'New World', handcrafted: false }), []); // eslint-disable-line
  const [def, setDef] = useState<PlanetDef>(initial);
  const sceneRef = useRef<PlanetScene | null>(null);
  const [open, setOpen] = useState(true);
  const [regenerating, setRegenerating] = useState(false);
  const timer = useRef<number>(0);
  const st = planetStats(def);

  const update = (patch: Partial<PlanetDef>) => {
    setDef((d) => {
      const n = { ...d, ...patch };
      if (patch.type && patch.type !== d.type) n.palette = defaultPalette(patch.type);
      return n;
    });
  };
  // live vs structural updates
  const prev = useRef(def);
  useEffect(() => {
    const s = sceneRef.current; if (!s) { prev.current = def; return; }
    const structural = STRUCTURAL.some((k) => prev.current[k] !== def[k]) || JSON.stringify(prev.current.palette) !== JSON.stringify(def.palette) && prev.current.type !== def.type;
    prev.current = def;
    s.updateLiveParams(def);
    if (structural) {
      window.clearTimeout(timer.current);
      setRegenerating(true);
      timer.current = window.setTimeout(() => { void s.loadPlanet(def, undefined, true).then(() => setRegenerating(false)); }, 350);
    }
  }, [def]);

  const setPal = (k: keyof PlanetPalette, v: string) => update({ palette: { ...def.palette, [k]: v } });

  return (
    <div className="absolute inset-0">
      <PlanetSmash planet={initial} lab={{ onScene: (s) => { sceneRef.current = s; s.rig.mode = 'cinematic'; s.rig.zoomTo(3.0); } }} />
      <div className={cx('absolute left-1/2 -translate-x-1/2 top-3 z-40 panel px-3 py-1 label pointer-events-none', regenerating ? 'text-[var(--accent)]' : 'opacity-0')}>Regenerating terrain…</div>
      <div className={cx('absolute right-3 bottom-3 z-40 flex flex-col items-end gap-2 transition-transform', !open && 'translate-x-[calc(100%-2.5rem)]')} style={{ top: '4.2rem' }}>
        <div className="flex gap-1"><Button size="sm" onClick={() => setOpen((o) => !o)}>{open ? 'Hide lab ›' : '‹ Lab'}</Button></div>
        <Panel title="Planet lab" className="w-[320px] max-w-[calc(100vw-1.5rem)] flex-1 min-h-0 flex flex-col [&>div]:flex-1 [&>div]:min-h-0 [&>div]:overflow-y-auto" right={<span className="mono text-[0.65em] text-[var(--ink-faint)]">seed {def.seed}</span>}>
          <div className="flex flex-col gap-3">
            <div className="flex gap-2"><input aria-label="Name" className="flex-1" value={def.name} onChange={(e) => update({ name: e.target.value })} /><select aria-label="Planet type" value={def.type} onChange={(e) => update({ type: e.target.value as PlanetType })}>{TYPES.map((t) => <option key={t} value={t} className="bg-black">{TYPE_LABEL[t]}</option>)}</select></div>
            <div className="flex flex-wrap gap-1">
              <Button size="sm" variant="line" onClick={() => update({ seed: Math.floor(Math.random() * 1e9) })}>Regenerate</Button>
              <Button size="sm" variant="line" onClick={() => { const r = randomPlanet(); setDef({ ...r, id: def.id, name: r.name }); }}>Random world</Button>
              <Button size="sm" variant="line" onClick={() => { void navigator.clipboard?.writeText(String(def.seed)); bus.emit('toast', { text: 'Seed copied' }); }}>Copy seed</Button>
              <Button size="sm" variant="line" onClick={() => { const s = prompt('Seed', String(def.seed)); if (s) update({ seed: parseInt(s, 10) || def.seed }); }}>Set seed</Button>
            </div>
            <div className="grid grid-cols-3 gap-2 py-1 border-y hairline"><Stat label="Gravity" value={st.gravity.toFixed(2)} unit="m/s²" /><Stat label="Density" value={st.density.toFixed(2)} unit="g/cm³" /><Stat label="Escape" value={st.escape.toFixed(1)} unit="km/s" /></div>
            <div className="label">Body</div>
            <Slider label="Radius" min={1000} max={90000} step={50} value={def.radius} onChange={(v) => update({ radius: v })} unit="km" format={fmt.km} />
            <Slider label="Mass" min={0.01} max={400} step={0.01} value={def.mass} onChange={(v) => update({ mass: v })} unit="M⊕" format={fmt.mass} />
            <Slider label="Rotation period" min={-120} max={240} step={0.5} value={def.rotationPeriod} onChange={(v) => update({ rotationPeriod: Math.abs(v) < 1 ? (v < 0 ? -1 : 1) : v })} unit="h" />
            <Slider label="Axial tilt" min={0} max={90} step={0.5} value={def.axialTilt} onChange={(v) => update({ axialTilt: v })} unit="°" />
            <Slider label="Temperature" min={40} max={2600} step={5} value={def.temperature} onChange={(v) => update({ temperature: v })} unit="K" />
            <Slider label="Magnetic field" min={0} max={1} step={0.01} value={def.magneticField} onChange={(v) => update({ magneticField: v })} />
            <div className="label mt-2">Surface (regenerates)</div>
            <Slider label="Ocean coverage" min={0} max={0.98} step={0.01} value={def.oceanCoverage} onChange={(v) => update({ oceanCoverage: v })} format={fmt.pct} disabled={def.type === 'gas'} />
            <Slider label="Terrain roughness" min={0.05} max={1} step={0.01} value={def.terrainRoughness} onChange={(v) => update({ terrainRoughness: v })} />
            <Slider label="Mountain frequency" min={0} max={1} step={0.01} value={def.mountainFrequency} onChange={(v) => update({ mountainFrequency: v })} />
            <Slider label="Crater density" min={0} max={1} step={0.01} value={def.craterDensity} onChange={(v) => update({ craterDensity: v })} disabled={def.type === 'gas'} />
            <div className="label mt-2">Environment (live)</div>
            <Slider label="Atmosphere density" min={0} max={1} step={0.01} value={def.atmosphereDensity} onChange={(v) => update({ atmosphereDensity: v })} format={fmt.pct} />
            <Slider label="Ice coverage" min={0} max={1} step={0.01} value={def.iceCoverage} onChange={(v) => update({ iceCoverage: v })} format={fmt.pct} />
            <Slider label="Cloud coverage" min={0} max={1} step={0.01} value={def.cloudCoverage} onChange={(v) => update({ cloudCoverage: v })} format={fmt.pct} />
            <Toggle label="Ring system" value={def.hasRings} onChange={(v) => update({ hasRings: v })} />
            <Toggle label="Night-side lights" value={def.cityLights} onChange={(v) => update({ cityLights: v })} />
            <div className="label mt-2">Palette (live)</div>
            <div className="grid grid-cols-4 gap-1">
              {(Object.keys(def.palette) as (keyof PlanetPalette)[]).map((k) => <label key={k} className="flex flex-col items-center gap-0.5 text-[0.6em] text-[var(--ink-faint)] uppercase tracking-wider"><input type="color" aria-label={`${k} colour`} value={def.palette[k]} onChange={(e) => setPal(k, e.target.value)} className="w-full h-6 bg-transparent border border-[var(--line)] cursor-pointer" />{k}</label>)}
            </div>
            <textarea aria-label="Description" className="text-[0.8em] bg-white/5 border border-[var(--line)] p-2 h-16" value={def.description} onChange={(e) => update({ description: e.target.value })} />
            <div className="flex gap-2 pt-2 border-t hairline">
              <Button variant="solid" className="flex-1" onClick={() => { const saved = { ...def, id: def.id.startsWith('lab-') || def.id.startsWith('w-') ? def.id : `w-${Date.now()}`, handcrafted: false }; saveWorld(saved); setLabPlanet(saved); bus.emit('toast', { text: `Saved "${def.name}"` }); }}>Save world</Button>
              <Button variant="line" className="flex-1" onClick={() => { setSelectedPlanet({ ...def, handcrafted: false }); setScreen('smash'); }}>Smash it</Button>
            </div>
            <Button size="sm" onClick={() => { const blob = new Blob([JSON.stringify(def, null, 2)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${def.name.replace(/\s+/g, '_')}.world.json`; a.click(); }}>Export JSON</Button>
          </div>
        </Panel>
      </div>
    </div>
  );
}
