import { useMemo, useState } from 'react';
import { PLANET_PRESETS, TYPE_LABEL, planetStats, randomPlanet } from '../engine/planets';
import type { PlanetDef, PlanetType } from '../engine/types';
import { useStore } from '../state/store';
import { Button, cx, fmt } from './common';

/** CSS-only preview disc built from the world's palette (the real one is rendered once you enter). */
export function PlanetDisc({ p, size = 96, className }: { p: PlanetDef; size?: number; className?: string }) {
  const pal = p.palette;
  const gas = p.type === 'gas';
  const bg = gas
    ? `repeating-linear-gradient(175deg, ${pal.land} 0 9%, ${pal.highland} 9% 16%, ${pal.ocean} 16% 22%, ${pal.shallow} 22% 31%)`
    : `radial-gradient(circle at 30% 28%, ${pal.ice} 0 ${p.iceCoverage * 12}%, transparent ${p.iceCoverage * 12 + 6}%), radial-gradient(ellipse 60% 40% at 62% 60%, ${pal.land} 0 40%, transparent 60%), radial-gradient(ellipse 30% 50% at 30% 62%, ${pal.highland} 0 45%, transparent 65%), radial-gradient(circle at 50% 50%, ${p.oceanCoverage > 0.3 ? pal.ocean : pal.land}, ${pal.crust})`;
  return (
    <div className={cx('relative rounded-full shrink-0', className)} style={{ width: size, height: size, boxShadow: `inset -${size * 0.28}px -${size * 0.16}px ${size * 0.35}px rgba(0,0,0,0.85), 0 0 ${size * 0.25}px ${pal.atmosphere}${p.atmosphereDensity > 0.3 ? '55' : '11'}` }}>
      <div className="absolute inset-0 rounded-full" style={{ background: bg }} />
      {p.hasRings && <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border" style={{ width: size * 1.9, height: size * 0.5, borderColor: `${pal.highland}aa`, borderWidth: size * 0.05, transform: 'translate(-50%,-50%) rotate(-18deg)' }} />}
    </div>
  );
}

const FILTERS: (PlanetType | 'all')[] = ['all', 'rocky', 'ocean', 'desert', 'ice', 'gas', 'lava', 'alien', 'custom'];

export function PlanetSelect() {
  const { setScreen, setSelectedPlanet, customWorlds, setLabPlanet } = useStore();
  const [filter, setFilter] = useState<PlanetType | 'all'>('all');
  const [seedInput, setSeedInput] = useState('');
  const [randoms, setRandoms] = useState<PlanetDef[]>(() => [randomPlanet(1234), randomPlanet(98765), randomPlanet(424242)]);
  const [hover, setHover] = useState<PlanetDef | null>(null);
  const all = useMemo(() => [...PLANET_PRESETS, ...customWorlds.map((w) => ({ ...w, type: w.type === 'custom' ? w.type : w.type })), ...randoms], [customWorlds, randoms]);
  const list = all.filter((p) => filter === 'all' || p.type === filter || (filter === 'custom' && !p.handcrafted));
  const enter = (p: PlanetDef) => { setSelectedPlanet(p); setScreen('smash'); };
  const focus = hover ?? list[0];
  const st = focus ? planetStats(focus) : null;
  return (
    <div className="absolute inset-0 flex flex-col bg-[var(--bg)]">
      <header className="flex items-center justify-between px-5 py-3 border-b hairline">
        <div className="flex items-center gap-4"><Button size="sm" onClick={() => setScreen('menu')}>← Menu</Button><h2 className="label text-[var(--ink)]">Select celestial body</h2></div>
        <div className="flex items-center gap-2">
          <input type="text" value={seedInput} onChange={(e) => setSeedInput(e.target.value)} placeholder="seed" className="mono w-28 text-[0.8em]" aria-label="Seed" />
          <Button size="sm" variant="line" onClick={() => { const s = seedInput.trim() ? (parseInt(seedInput, 10) || Array.from(seedInput).reduce((a, c) => a * 31 + c.charCodeAt(0), 7) >>> 0) : Math.floor(Math.random() * 1e9); setRandoms((r) => [randomPlanet(s), ...r].slice(0, 9)); setFilter('all'); }}>Randomize world</Button>
        </div>
      </header>
      <div className="flex-1 flex min-h-0">
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex gap-1 px-5 py-2 overflow-x-auto" role="tablist">
            {FILTERS.map((f) => <Button key={f} size="sm" active={filter === f} onClick={() => setFilter(f)}>{f === 'all' ? 'All' : TYPE_LABEL[f]}</Button>)}
          </div>
          <div className="flex-1 overflow-y-auto px-5 pb-6">
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))' }}>
              {list.map((p, i) => (
                <button key={p.id} onMouseEnter={() => setHover(p)} onFocus={() => setHover(p)} onClick={() => enter(p)} className="group text-left panel p-4 hover:border-[var(--line-strong)] transition-colors fade-up flex flex-col gap-3" style={{ animationDelay: `${Math.min(i, 12) * 0.04}s` }}>
                  <div className="flex items-start justify-between"><PlanetDisc p={p} size={72} /><span className="label">{TYPE_LABEL[p.type]}</span></div>
                  <div>
                    <div className="text-[1.05em] group-hover:text-[var(--accent)] transition-colors">{p.name}</div>
                    <div className="mono text-[0.7em] text-[var(--ink-faint)] mt-0.5">R {fmt.km(p.radius)} km · {p.mass.toFixed(2)} M⊕ · {p.temperature.toFixed(0)} K</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
        {focus && st && (
          <aside className="hidden lg:flex w-[340px] border-l hairline flex-col p-6 gap-5 overflow-y-auto">
            <div className="flex justify-center py-4"><PlanetDisc p={focus} size={180} /></div>
            <div><div className="label mb-1">{TYPE_LABEL[focus.type]} · {focus.system}</div><h3 className="text-2xl font-light">{focus.name}</h3><p className="text-[0.85em] text-[var(--ink-dim)] mt-2">{focus.description}</p></div>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-[0.85em]">
              {([['Radius', `${fmt.km(focus.radius)} km`], ['Mass', `${fmt.mass(focus.mass)} M⊕`], ['Gravity', `${st.gravity.toFixed(1)} m/s²`], ['Density', `${st.density.toFixed(2)} g/cm³`], ['Rotation', `${Math.abs(focus.rotationPeriod).toFixed(1)} h${focus.rotationPeriod < 0 ? ' (retro)' : ''}`], ['Axial tilt', `${focus.axialTilt.toFixed(1)}°`], ['Temperature', `${focus.temperature.toFixed(0)} K`], ['Atmosphere', fmt.pct(focus.atmosphereDensity)], ['Oceans', fmt.pct(focus.oceanCoverage)], ['Satellites', focus.satellites], ['Seed', focus.seed], ['Orbit', `${focus.orbit.toFixed(2)} AU`]] as [string, string | number][]).map(([k, v]) => <div key={k}><dt className="label">{k}</dt><dd className="mono">{v}</dd></div>)}
            </dl>
            <div className="text-[0.75em] text-[var(--ink-faint)]">Composition: {focus.composition}</div>
            <div className="flex gap-2 mt-auto"><Button variant="solid" size="lg" className="flex-1" onClick={() => enter(focus)}>Enter orbit</Button><Button variant="line" size="lg" onClick={() => { setLabPlanet(focus); setScreen('lab'); }}>Lab</Button></div>
            <div className="flex gap-2"><Button size="sm" onClick={() => { void navigator.clipboard?.writeText(String(focus.seed)); }}>Copy seed</Button><Button size="sm" onClick={() => { const s = { ...focus, id: `w-${Date.now()}` }; useStore.getState().saveWorld(s); }}>Save to custom worlds</Button></div>
          </aside>
        )}
      </div>
    </div>
  );
}
