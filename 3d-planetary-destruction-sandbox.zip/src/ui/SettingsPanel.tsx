import { useState } from 'react';
import { audio } from '../audio/AudioEngine';
import type { Quality } from '../engine/types';
import { DEFAULT_SETTINGS, detectQuality, useStore } from '../state/store';
import { Button, Kbd, Slider, Toggle, cx } from './common';

const QUALITIES: { id: Quality; label: string; desc: string }[] = [
  { id: 'cinematic', label: 'Cinematic', desc: '1536×768 terrain, 327k-tri planet LOD, 60k particles, strong bloom + chromatic fringe, 2× DPR' },
  { id: 'high', label: 'High', desc: '1280×640 terrain, 82k-tri LOD, 40k particles, bloom, 1.75× DPR' },
  { id: 'balanced', label: 'Balanced', desc: '1024×512 terrain, 82k-tri LOD, 24k particles, 1.5× DPR' },
  { id: 'performance', label: 'Performance', desc: '768×384 terrain, 20k-tri LOD, 10k particles, reduced background, 1× DPR' },
];

export function SettingsPanel() {
  const { settings, updateSettings, setScreen } = useStore();
  const [tab, setTab] = useState<'graphics' | 'audio' | 'controls' | 'access'>('graphics');
  const s = settings;
  return (
    <div className={cx('absolute inset-0 flex flex-col bg-[var(--bg)]', s.highContrast && 'hc')} style={{ ['--ui-scale' as string]: s.uiScale }}>
      <header className="flex items-center justify-between px-5 py-3 border-b hairline">
        <div className="flex items-center gap-4"><Button size="sm" onClick={() => setScreen('menu')}>← Back</Button><h2 className="label text-[var(--ink)]">Settings</h2></div>
        <div className="flex gap-1" role="tablist">{(['graphics', 'audio', 'controls', 'access'] as const).map((t) => <Button key={t} size="sm" active={tab === t} onClick={() => setTab(t)}>{t === 'access' ? 'Accessibility' : t[0].toUpperCase() + t.slice(1)}</Button>)}</div>
      </header>
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-xl mx-auto flex flex-col gap-6">
          {tab === 'graphics' && (
            <>
              <section><div className="label mb-2">Quality preset</div>
                <div className="grid gap-2">{QUALITIES.map((q) => <button key={q.id} onClick={() => updateSettings({ quality: q.id })} className={cx('text-left panel p-3 hover:border-[var(--line-strong)]', s.quality === q.id && '!border-[var(--accent)]')}><div className="flex justify-between"><span>{q.label}</span>{s.quality === q.id && <span className="label text-[var(--accent)]">active</span>}</div><div className="text-[0.72em] text-[var(--ink-faint)] mt-0.5">{q.desc}</div></button>)}</div>
                <div className="flex gap-2 mt-2"><Button size="sm" onClick={() => updateSettings({ quality: detectQuality() })}>Auto-detect ({detectQuality()})</Button></div>
              </section>
              <section className="flex flex-col gap-3">
                <Slider label="Particle & debris density" min={0.25} max={2} step={0.05} value={s.particleScale} onChange={(v) => updateSettings({ particleScale: v })} format={(v) => `${v.toFixed(2)}×`} />
                <Toggle label="Cloud shadows & terrain shading" hint="Shadows cast by the cloud deck onto terrain" value={s.shadows} onChange={(v) => updateSettings({ shadows: v })} />
                <Toggle label="Post-processing" hint="Bloom, spatial distortion, tone mapping pass" value={s.postProcessing} onChange={(v) => updateSettings({ postProcessing: v })} />
                <Slider label="Camera shake intensity" min={0} max={1} step={0.05} value={s.cameraShake} onChange={(v) => updateSettings({ cameraShake: v })} />
              </section>
            </>
          )}
          {tab === 'audio' && (
            <section className="flex flex-col gap-3">
              <p className="text-[0.8em] text-[var(--ink-dim)]">All audio is synthesised in real time (no samples). Music tension follows planetary integrity.</p>
              <Slider label="Master" min={0} max={1} step={0.01} value={s.masterVolume} onChange={(v) => { updateSettings({ masterVolume: v }); audio.setVolumes({ master: v }); }} />
              <Slider label="Music" min={0} max={1} step={0.01} value={s.musicVolume} onChange={(v) => { updateSettings({ musicVolume: v }); audio.setVolumes({ music: v }); }} />
              <Slider label="Effects" min={0} max={1} step={0.01} value={s.sfxVolume} onChange={(v) => { updateSettings({ sfxVolume: v }); audio.setVolumes({ sfx: v }); }} />
              <div className="flex gap-2"><Button size="sm" variant="line" onClick={() => { audio.start(); audio.play('impact', 0.7); }}>Test impact</Button><Button size="sm" variant="line" onClick={() => { audio.start(); audio.play('collision', 1); }}>Test collision</Button></div>
            </section>
          )}
          {tab === 'controls' && (
            <section className="flex flex-col gap-3">
              <Toggle label="Invert zoom direction" value={s.invertZoom} onChange={(v) => updateSettings({ invertZoom: v })} />
              <Toggle label="Show control hints" value={s.showHints} onChange={(v) => updateSettings({ showHints: v })} />
              <div className="label mt-2">Desktop</div>
              <table className="text-[0.8em] w-full"><tbody>
                {[['Left drag', 'Orbit'], ['Right / middle drag, Shift+drag', 'Pan'], ['Wheel', 'Continuous zoom (system → surface)'], ['Click surface', 'Trigger selected event'], ['Space', 'Pause / play'], ['[ ]', 'Slower / faster'], ['R', 'Reset world'], ['F', 'Focus / follow largest fragment'], ['C', 'Cinematic camera'], ['M', 'Measure'], ['H', 'Hide UI'], ['1–9, 0', 'Select tool'], ['Ctrl+S', 'Save experiment state'], ['F3', 'Developer overlay'], ['Esc', 'Back']].map(([k, v]) => <tr key={k} className="border-b hairline"><td className="py-1.5 pr-4"><Kbd>{k}</Kbd></td><td className="text-[var(--ink-dim)]">{v}</td></tr>)}
              </tbody></table>
              <div className="label mt-2">Touch</div>
              <table className="text-[0.8em] w-full"><tbody>
                {[['One finger drag', 'Orbit'], ['Two finger pinch', 'Zoom'], ['Two finger drag', 'Pan'], ['Tap surface', 'Trigger selected event']].map(([k, v]) => <tr key={k} className="border-b hairline"><td className="py-1.5 pr-4">{k}</td><td className="text-[var(--ink-dim)]">{v}</td></tr>)}
              </tbody></table>
            </section>
          )}
          {tab === 'access' && (
            <section className="flex flex-col gap-3">
              <Toggle label="Reduced motion" hint="Disables camera shake, inertia and slow auto-motion; shortens UI animations" value={s.reducedMotion} onChange={(v) => updateSettings({ reducedMotion: v })} />
              <Toggle label="Reduced flashing" hint="Dims impact flashes, heat glow and shock fronts" value={s.reducedFlashing} onChange={(v) => updateSettings({ reducedFlashing: v })} />
              <Toggle label="High contrast interface" value={s.highContrast} onChange={(v) => updateSettings({ highContrast: v })} />
              <Slider label="Interface scale" min={0.85} max={1.4} step={0.05} value={s.uiScale} onChange={(v) => updateSettings({ uiScale: v })} format={(v) => `${Math.round(v * 100)}%`} />
              <Toggle label="Scientific mode" hint="Show simulation assumptions and approximations in the inspector" value={s.scientificMode} onChange={(v) => updateSettings({ scientificMode: v })} />
              <p className="text-[0.75em] text-[var(--ink-faint)]">All controls are keyboard reachable; panels use ARIA roles and live regions for the timeline. The simulation can always be paused with <Kbd>Space</Kbd>.</p>
            </section>
          )}
          <div className="pt-4 border-t hairline flex justify-between"><Button size="sm" variant="danger" onClick={() => updateSettings({ ...DEFAULT_SETTINGS, quality: detectQuality() })}>Restore defaults</Button><span className="label self-center">Settings persist locally</span></div>
        </div>
      </div>
    </div>
  );
}
