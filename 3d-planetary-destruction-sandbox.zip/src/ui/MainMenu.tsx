import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { SpaceBackground, StarObject } from '../engine/Space';
import { BODY_FRAG, BODY_VERT } from '../engine/shaders/effects';
import { STAR_CLASSES } from '../engine/planets';
import { useStore, type Screen } from '../state/store';
import { audio } from '../audio/AudioEngine';
import { Kbd } from './common';

/** Lightweight live 3D backdrop: parallax starfield, nebula, a drifting lit planet and its star. */
function MenuBackground({ reducedMotion }: { reducedMotion: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current!;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'low-power' }); } catch { return; }
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 5000);
    const space = new SpaceBackground(31337, '#2a1a4a', '#0c2440', 0.8);
    scene.add(space.group);
    const star = new StarObject(STAR_CLASSES['sun-like'], 3);
    star.group.position.set(60, 14, -40); scene.add(star.group);
    const mat = new THREE.ShaderMaterial({ vertexShader: BODY_VERT, fragmentShader: BODY_FRAG, uniforms: { uSun: { value: star.group.position }, uSunColor: { value: new THREE.Color(1, 0.97, 0.9) }, uColorA: { value: new THREE.Color('#1c3f6e') }, uColorB: { value: new THREE.Color('#5a7a4a') }, uSeed: { value: 3.7 }, uEmissive: { value: 0 }, uGas: { value: 0 }, uTime: { value: 0 }, uOccluders: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) }, uOccCount: { value: 0 }, uAtmo: { value: 1.2 } } });
    const planet = new THREE.Mesh(new THREE.SphereGeometry(4, 96, 64), mat);
    planet.position.set(5.5, -3.2, -6); scene.add(planet);
    const moonMat = mat.clone(); moonMat.uniforms.uColorA.value = new THREE.Color('#7a746c'); moonMat.uniforms.uColorB.value = new THREE.Color('#4a4640'); moonMat.uniforms.uAtmo.value = 0; moonMat.uniforms.uSun = mat.uniforms.uSun;
    const moon = new THREE.Mesh(new THREE.SphereGeometry(0.7, 32, 16), moonMat); scene.add(moon);
    const resize = () => { const w = el.clientWidth, h = el.clientHeight; renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); space.setPixelRatio(Math.min(devicePixelRatio, 1.5)); };
    resize(); const ro = new ResizeObserver(resize); ro.observe(el);
    let raf = 0; const t0 = performance.now(); let alive = true;
    const loop = () => { if (!alive) return; raf = requestAnimationFrame(loop); const t = (performance.now() - t0) / 1000; const k = reducedMotion ? 0.15 : 1; camera.position.set(Math.sin(t * 0.03 * k) * 1.5, Math.cos(t * 0.021 * k) * 0.8 + 0.5, 12); camera.lookAt(3, -1.5, -6); planet.rotation.y = t * 0.03 * k; moon.position.set(planet.position.x + Math.cos(t * 0.12 * k) * 7, planet.position.y + 1.2, planet.position.z + Math.sin(t * 0.12 * k) * 7); const occ = mat.uniforms.uOccluders.value as THREE.Vector4[]; occ[0].set(moon.position.x, moon.position.y, moon.position.z, 0.7); mat.uniforms.uOccCount.value = 1; const mo = moonMat.uniforms.uOccluders.value as THREE.Vector4[]; mo[0].set(planet.position.x, planet.position.y, planet.position.z, 4); moonMat.uniforms.uOccCount.value = 1; space.update(t); star.update(t); renderer.render(scene, camera); };
    loop();
    return () => { alive = false; cancelAnimationFrame(raf); ro.disconnect(); space.dispose(); star.dispose(); planet.geometry.dispose(); mat.dispose(); moon.geometry.dispose(); moonMat.dispose(); renderer.dispose(); renderer.domElement.remove(); };
  }, [reducedMotion]);
  return <div ref={ref} className="absolute inset-0" aria-hidden />;
}

const ITEMS: { screen: Screen; title: string; sub: string; key: string }[] = [
  { screen: 'select', title: 'Planet Smash', sub: 'Choose a world. Deform it, crack it open, break it apart.', key: '1' },
  { screen: 'system', title: 'System Smash', sub: 'Real-time N-body star systems. Nudge, collide, destabilise.', key: '2' },
  { screen: 'lab', title: 'Planet Lab', sub: 'Shape a world parameter by parameter and watch it respond.', key: '3' },
  { screen: 'galaxy', title: 'Galaxy View', sub: 'Pick a system from the spiral and drop into it.', key: '4' },
  { screen: 'worlds', title: 'Custom Worlds', sub: 'Saved planets, systems and event replays.', key: '5' },
  { screen: 'settings', title: 'Settings', sub: 'Graphics, audio, controls, accessibility.', key: '6' },
];

export function MainMenu() {
  const setScreen = useStore((s) => s.setScreen);
  const settings = useStore((s) => s.settings);
  const worlds = useStore((s) => s.customWorlds.length);
  const go = (s: Screen) => { audio.start(); useStore.getState().setAudioStarted(); setScreen(s); };
  useEffect(() => { const h = (e: KeyboardEvent) => { const it = ITEMS.find((i) => i.key === e.key); if (it) go(it.screen); }; window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, []); // eslint-disable-line
  return (
    <div className="absolute inset-0 overflow-hidden">
      <MenuBackground reducedMotion={settings.reducedMotion} />
      <div className="absolute inset-0 bg-gradient-to-r from-[rgba(4,6,11,0.85)] via-[rgba(4,6,11,0.35)] to-transparent" />
      <div className="relative h-full flex flex-col justify-between p-6 sm:p-10 md:p-14 max-w-[720px]">
        <header className="fade-up">
          <div className="label mb-3 flex items-center gap-3"><span className="w-8 h-px bg-[var(--accent)]" />Celestial destruction sandbox · simulation</div>
          <h1 className="text-[2.6rem] sm:text-[3.6rem] leading-[0.95] font-light tracking-tight">Orrery<span className="text-[var(--accent)]">/</span>Null</h1>
          <p className="mt-4 text-[var(--ink-dim)] max-w-md text-[0.95em]">Real 3D worlds with destructible terrain, molten interiors, orbital debris and N-body star systems. Every event is a fictional phenomenon inside a visual simulation.</p>
        </header>
        <nav className="my-6 flex flex-col" aria-label="Main menu">
          {ITEMS.map((it, i) => (
            <button key={it.screen} onClick={() => go(it.screen)} className="group text-left flex items-baseline gap-5 py-3 border-b hairline hover:border-[var(--line-strong)] transition-colors fade-up" style={{ animationDelay: `${0.08 * i + 0.1}s` }}>
              <span className="mono text-[0.7em] text-[var(--ink-faint)] w-4">0{it.key}</span>
              <span className="flex-1">
                <span className="block text-[1.35em] sm:text-[1.6em] font-light tracking-tight group-hover:text-[var(--accent)] transition-colors">{it.title}{it.screen === 'worlds' && worlds > 0 && <span className="mono text-[0.5em] align-top ml-2 text-[var(--ink-dim)]">{worlds}</span>}</span>
                <span className="block text-[0.8em] text-[var(--ink-dim)] mt-0.5">{it.sub}</span>
              </span>
              <span className="text-[var(--ink-faint)] group-hover:text-[var(--accent)] group-hover:translate-x-1 transition-transform">→</span>
            </button>
          ))}
        </nav>
        <footer className="label flex flex-wrap gap-x-6 gap-y-2 fade-up" style={{ animationDelay: '0.7s' }}>
          <span>Drag to orbit</span><span>Wheel / pinch to zoom</span><span><Kbd>Space</Kbd> pause</span><span><Kbd>R</Kbd> reset</span><span><Kbd>Esc</Kbd> menu</span><span><Kbd>F3</Kbd> developer</span>
        </footer>
      </div>
    </div>
  );
}
