import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { audio } from '../audio/AudioEngine';
import { commands } from '../engine/commands';
import { bus } from '../engine/EventBus';
import { PlanetScene, SIM_SPEEDS } from '../engine/PlanetScene';
import { TYPE_LABEL, planetStats } from '../engine/planets';
import { CATEGORY_LABEL, TOOLS, TOOL_BY_ID, defaultParams } from '../engine/tools';
import type { DebugInfo, PlanetDef, PlanetStats, SimEvent, ToolId } from '../engine/types';
import { useStore } from '../state/store';
import { Bar, Button, DebugOverlay, Kbd, LoadingScreen, Panel, Slider, Stat, Toggle, cx, fmt } from './common';

const CATEGORIES = ['impact', 'energy', 'gravity', 'space', 'cosmic', 'anomaly', 'special'] as const;

const SHOWCASES: { name: string; run: (s: PlanetScene) => void }[] = [
  { name: 'Massive asteroid event', run: (s) => s.trigger('asteroid', { size: 420, speed: 60, angle: 25 }, randomDir()) },
  { name: 'Meteor storm', run: (s) => s.trigger('meteor-swarm', { count: 60, size: 30, spread: 30, duration: 6 }, randomDir()) },
  { name: 'Gravity anomaly', run: (s) => s.trigger('gravity-anomaly', { strength: 0.9, radius: 1800, duration: 9 }, randomDir()) },
  { name: 'Core bore', run: (s) => s.trigger('matter-displacement', { radius: 700, depth: 2.1 }, randomDir()) },
  { name: 'Atmospheric disturbance', run: (s) => { s.trigger('stellar-flare', { power: 0.9, duration: 7 }, randomDir()); setTimeout(() => s.trigger('plasma-burst', { radius: 2500, power: 0.8 }, randomDir()), 1500); } },
  { name: 'Ring disruption', run: (s) => s.trigger('cosmic-shockwave', { power: 1, speed: 1.4, reach: 180 }, new THREE.Vector3(0.2, 0.95, 0.1).normalize()) },
  { name: 'Planetary fragmentation', run: (s) => s.trigger('exotic-strike', { power: 1, size: 3000, charge: 2.5 }, randomDir()) },
];
function randomDir() { const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u); return new THREE.Vector3(s * Math.cos(th), u, s * Math.sin(th)); }

export function PlanetSmash({ planet, lab }: { planet: PlanetDef; lab?: { onScene: (s: PlanetScene) => void } }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<PlanetScene | null>(null);
  const { setScreen, settings, updateSettings, debug, toggleDebug, saveReplay, replays, saveBookmark, bookmarks, deleteBookmark } = useStore();
  const [loading, setLoading] = useState({ label: 'Initializing engine', progress: 0, done: false });
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<PlanetStats | null>(null);
  const [dbg, setDbg] = useState<DebugInfo | null>(null);
  const [paused, setPaused] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(4);
  const [toolId, setToolId] = useState<ToolId>('asteroid');
  const [params, setParams] = useState<Record<string, Record<string, number>>>(() => Object.fromEntries(TOOLS.map((t) => [t.id, defaultParams(t)])));
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>('impact');
  const [events, setEvents] = useState<SimEvent[]>([]);
  const [hover, setHover] = useState<{ lat: number; lon: number; height: number; damage: number; water: boolean } | null>(null);
  const [panel, setPanel] = useState<'info' | 'timeline' | 'states' | 'replay' | 'camera' | null>(lab || window.innerWidth < 900 ? null : 'info');
  const [hideUI, setHideUI] = useState(false);
  const [cinematic, setCinematic] = useState(false);
  const [simTime, setSimTime] = useState(0);
  const [measure, setMeasure] = useState<{ a?: THREE.Vector3; b?: THREE.Vector3; km?: number } | null>(null);
  const [snapshotsV, setSnapshotsV] = useState(0);
  const [toolOpen, setToolOpen] = useState(true);
  const [magField, setMagField] = useState(false);
  const st = useMemo(() => planetStats(planet), [planet]);
  const tool = TOOL_BY_ID[toolId];

  // ---------- engine lifecycle ----------
  useEffect(() => {
    const host = hostRef.current!;
    let scene: PlanetScene;
    try { scene = new PlanetScene(host, useStore.getState().settings); } catch (e) { setError((e as Error).message); return; }
    sceneRef.current = scene; commands.planetScene = scene;
    scene.onStats = (s) => setStats(s);
    scene.onDebug = (d) => { setDbg(d); setSimTime(d.simTime); };
    let lastHover = 0;
    scene.onHover = (h) => { const now = performance.now(); if (h && now - lastHover < 90) return; lastHover = now; setHover(h ? { lat: h.lat, lon: h.lon, height: h.height, damage: h.damage, water: h.height < scene.planet!.field.seaLevel && h.damage < 0.002 } : null); };
    scene.toolId = toolId; scene.toolParams = params[toolId];
    setLoading({ label: 'Initializing engine', progress: 0, done: false });
    void scene.loadPlanet(planet, (label, progress) => setLoading({ label, progress, done: progress >= 1 })).then(() => { setLoading((l) => ({ ...l, done: true })); lab?.onScene(scene); const pr = useStore.getState().pendingReplay; if (pr && pr.planetId === planet.id) { useStore.getState().setPendingReplay(null); setPanel('replay'); scene.playReplay(pr); } });
    const unsub = bus.on('sim', (ev) => {
      setEvents((e) => [...e.slice(-79), ev]);
      if (ev.type === 'RESET' || ev.type === 'WORLD_CREATED') setEvents([ev]);
      if (ev.type === 'SNAPSHOT') setSnapshotsV((v) => v + 1);
      // cinematic auto-framing of major events
      if (scene.rig.mode === 'cinematic') {
        if (ev.type === 'PLANET_IMPACT' && ev.data && typeof ev.data.lat === 'number' && (ev.data.intensity as number) > 0.5) { const lat = ev.data.lat as number, lon = ev.data.lon as number; scene.focusImpactSite(new THREE.Vector3(Math.cos(lat) * Math.cos(lon), Math.sin(lat), Math.cos(lat) * Math.sin(lon)), 1.6 + Math.random() * 0.8); }
        if (ev.type === 'BODY_FRAGMENTED') scene.rig.zoomTo(4.2);
      }
    });
    const unsubStats = bus.on('sim', (ev) => { if (ev.type === 'BODY_FRAGMENTED') audio.setIntensity(1); });
    return () => { unsub(); unsubStats(); scene.dispose(); if (commands.planetScene === scene) commands.planetScene = null; audio.setIntensity(0); };
  }, [planet]); // eslint-disable-line

  useEffect(() => { sceneRef.current?.applySettings(settings); audio.setVolumes({ master: settings.masterVolume, music: settings.musicVolume, sfx: settings.sfxVolume }); }, [settings]);
  useEffect(() => { const s = sceneRef.current; if (s) { s.toolId = toolId; s.toolParams = params[toolId]; } }, [toolId, params]);
  useEffect(() => { if (stats) audio.setIntensity(Math.max(1 - stats.integrity, stats.broken ? 1 : 0) * 0.8 + Math.min(stats.atmosphereDisturbance, 1) * 0.2); }, [stats]);

  const setSpeed = useCallback((i: number) => { const idx = Math.max(0, Math.min(SIM_SPEEDS.length - 1, i)); setSpeedIdx(idx); commands.dispatch({ type: 'SET_SIMULATION_SPEED', speed: SIM_SPEEDS[idx] }); }, []);
  const togglePause = useCallback(() => { setPaused((p) => { commands.dispatch({ type: 'PAUSE_SIMULATION', paused: !p }); return !p; }); }, []);
  const reset = useCallback(() => { commands.dispatch({ type: 'RESET_WORLD' }); setMeasure(null); }, []);
  const toggleCinematic = useCallback(() => { const s = sceneRef.current; if (!s) return; setCinematic((c) => { const n = !c; s.rig.mode = n ? 'cinematic' : 'orbit'; if (n) s.rig.zoomTo(Math.max(s.rig.zoomGoal, 2.6)); setHideUI(n); return n; }); }, []);

  // ---------- keyboard ----------
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      const s = sceneRef.current;
      switch (e.key) {
        case ' ': e.preventDefault(); togglePause(); break;
        case 'r': case 'R': reset(); break;
        case 'Escape': if (cinematic) toggleCinematic(); else if (hideUI) setHideUI(false); else setScreen(lab ? 'menu' : 'select'); break;
        case '[': setSpeed(speedIdx - 1); break;
        case ']': setSpeed(speedIdx + 1); break;
        case 'c': case 'C': toggleCinematic(); break;
        case 'f': case 'F': if (s) { if (!s.followLargestFragment()) { s.stopFollow(); s.rig.zoomTo(3.2); } } break;
        case 'h': case 'H': setHideUI((v) => !v); break;
        case 'F3': e.preventDefault(); toggleDebug(); break;
        case 'm': case 'M': setMeasure((m) => (m ? null : {})); break;
        case 's': case 'S': if (e.ctrlKey || e.metaKey) { e.preventDefault(); s?.saveSnapshot(); } break;
        default: { const n = parseInt(e.key, 10); if (!Number.isNaN(n) && n >= 1 && n <= TOOLS.length) { const t = TOOLS[n - 1]; setToolId(t.id); setCategory(t.category); } }
      }
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, [togglePause, reset, setSpeed, speedIdx, toggleCinematic, cinematic, hideUI, setScreen, toggleDebug, lab]);

  // ---------- pointer targeting ----------
  const onMove = (e: React.PointerEvent) => { if (e.pointerType === 'mouse') sceneRef.current?.setHover(e.clientX, e.clientY); };
  const onLeave = () => sceneRef.current?.setHover(null, null);
  const onUp = (e: React.PointerEvent) => {
    const s = sceneRef.current; if (!s || !s.rig.wasClick() || e.button !== 0) return;
    const h = s.pickScreen(e.clientX, e.clientY);
    if (!h) return;
    if (measure) {
      setMeasure((m) => {
        if (!m?.a) return { a: h.dir };
        const ang = Math.acos(THREE.MathUtils.clamp(m.a.dot(h.dir), -1, 1));
        s.measureArc(m.a, h.dir);
        return { a: m.a, b: h.dir, km: ang * planet.radius };
      });
      return;
    }
    s.trigger(toolId, params[toolId], h.dir);
    if (e.pointerType !== 'mouse') s.setHover(null, null);
  };

  const hudHidden = hideUI || cinematic;
  const integrity = stats?.integrity ?? 1;
  const condition = stats?.broken ? 'Fragmented' : integrity > 0.85 ? 'Stable' : integrity > 0.5 ? 'Damaged' : integrity > 0.2 ? 'Critical' : 'Destabilised';
  const previewKm = tool.previewRadius(params[toolId]);
  const snaps = sceneRef.current?.snapshots ?? [];
  void snapshotsV;

  return (
    <div className={cx('absolute inset-0 overflow-hidden select-none', settings.highContrast && 'hc', settings.reducedMotion && 'reduced-motion')} style={{ ['--ui-scale' as string]: settings.uiScale }}>
      <div ref={hostRef} className="absolute inset-0" onPointerMove={onMove} onPointerLeave={onLeave} onPointerUp={onUp} role="application" aria-label={`3D view of ${planet.name}. Click the surface to trigger ${tool.name}.`} />
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-[var(--bg)] z-50"><div className="panel p-6 max-w-md"><div className="label text-[var(--danger)] mb-2">Renderer unavailable</div><p className="text-sm text-[var(--ink-dim)]">{error}</p><p className="text-xs text-[var(--ink-faint)] mt-2 mb-4">The simulation needs WebGL2. Update your browser or enable hardware acceleration.</p><Button variant="solid" onClick={() => setScreen('menu')}>Back to menu</Button></div></div>
      )}
      {!loading.done && !error && <LoadingScreen label={loading.label} progress={loading.progress} />}
      {debug && <DebugOverlay info={dbg} />}

      {/* ---------- TOP BAR ---------- */}
      <div className={cx('absolute top-0 inset-x-0 z-30 flex flex-wrap items-start justify-between p-3 gap-2 pointer-events-none transition-opacity duration-500', hudHidden && 'opacity-0')}>
        <div className="flex items-center gap-2 pointer-events-auto">
          <Button size="sm" onClick={() => setScreen(lab ? 'menu' : 'select')} ariaLabel="Back">←</Button>
          <div className="panel px-3 py-1.5 flex items-center gap-3">
            <div><div className="text-[0.95em] leading-tight">{planet.name}</div><div className="label">{TYPE_LABEL[planet.type]} · {condition}</div></div>
            <div className="w-16"><Bar value={integrity} color={integrity > 0.5 ? 'var(--accent)' : 'var(--accent-2)'} /></div>
          </div>
        </div>
        <div className="panel flex items-center gap-1 px-1.5 py-1 pointer-events-auto" role="toolbar" aria-label="Simulation time">
          <Button size="sm" onClick={togglePause} ariaLabel={paused ? 'Play' : 'Pause'} title="Space">{paused ? '▶' : '❚❚'}</Button>
          <Button size="sm" onClick={() => setSpeed(speedIdx - 1)} ariaLabel="Slower" title="[">◂</Button>
          <select aria-label="Simulation speed" className="mono text-[0.75em] !py-0.5 !px-1 !border-transparent bg-transparent" value={speedIdx} onChange={(e) => setSpeed(parseInt(e.target.value, 10))}>{SIM_SPEEDS.map((s, i) => <option key={s} value={i} className="bg-black">{s}×</option>)}</select>
          <Button size="sm" onClick={() => setSpeed(speedIdx + 1)} ariaLabel="Faster" title="]">▸</Button>
          <span className="mono text-[0.72em] text-[var(--ink-dim)] w-16 text-center">{fmt.time(simTime)}</span>
          <span className="w-px h-4 bg-[var(--line)]" />
          <Button size="sm" onClick={reset} title="R">Reset</Button>
        </div>
        <div className="flex items-center gap-1 pointer-events-auto">
          <div className="panel flex items-center gap-1 px-1.5 py-1">
            <Button size="sm" active={cinematic} onClick={toggleCinematic} title="C · cinematic camera">Cinematic</Button>
            <Button size="sm" onClick={() => { const s = sceneRef.current; if (s && !s.followLargestFragment()) { s.stopFollow(); s.rig.zoomTo(3.2); } }} title="F · focus / follow fragment">Focus</Button>
            <Button size="sm" onClick={() => sceneRef.current?.rig.zoomTo(sceneRef.current.rig.minDist + 0.02)} title="Descend to the surface">Surface</Button>
            <Button size="sm" active={!!measure} onClick={() => setMeasure((m) => (m ? null : {}))} title="M · measure surface distance">Measure</Button>
          </div>
          <div className="panel flex items-center gap-1 px-1.5 py-1">
            <Button size="sm" active={panel === 'info'} onClick={() => setPanel(panel === 'info' ? null : 'info')}>Inspect</Button>
            <Button size="sm" active={panel === 'timeline'} onClick={() => setPanel(panel === 'timeline' ? null : 'timeline')}>Timeline</Button>
            <Button size="sm" active={panel === 'states'} onClick={() => setPanel(panel === 'states' ? null : 'states')}>States</Button>
            <Button size="sm" active={panel === 'replay'} onClick={() => setPanel(panel === 'replay' ? null : 'replay')}>Replay</Button>
            <Button size="sm" active={panel === 'camera'} onClick={() => setPanel(panel === 'camera' ? null : 'camera')}>Camera</Button>
            <Button size="sm" onClick={() => setScreen('settings')} ariaLabel="Settings">⚙</Button>
          </div>
        </div>
      </div>

      {/* ---------- TOOL SELECTOR (left) ---------- */}
      <div className={cx('absolute left-3 top-16 bottom-28 z-20 flex gap-2 pointer-events-none transition-opacity duration-500', hudHidden && 'opacity-0 pointer-events-none')}>
        <div className="panel flex flex-col py-1 pointer-events-auto w-11 sm:w-auto" role="tablist" aria-label="Tool categories">
          {CATEGORIES.map((c) => <button key={c} role="tab" aria-selected={category === c} onClick={() => { setCategory(c); setToolOpen(true); }} className={cx('label px-2 sm:px-3 py-2 text-left hover:text-[var(--ink)] transition-colors border-l-2', category === c ? 'text-[var(--ink)] border-[var(--accent)]' : 'border-transparent')}><span className="hidden sm:inline">{CATEGORY_LABEL[c]}</span><span className="sm:hidden">{CATEGORY_LABEL[c][0]}</span></button>)}
        </div>
        {toolOpen && (
          <div className="flex flex-col gap-2 w-[228px] sm:w-[260px] max-h-full overflow-y-auto pointer-events-auto">
            <div className="panel p-1.5 flex flex-col gap-1" role="listbox" aria-label="Tools">
              {TOOLS.filter((t) => t.category === category).map((t) => (
                <button key={t.id} role="option" aria-selected={toolId === t.id} data-active={toolId === t.id} onClick={() => setToolId(t.id)} className={cx('tool-btn flex items-center gap-3 p-2 text-left border transition-colors', toolId === t.id ? 'border-[var(--line-strong)] bg-white/5' : 'border-transparent hover:bg-white/5')} style={{ ['--tool' as string]: t.color }}>
                  <span className="tool-preview w-10 h-10 shrink-0 border border-[var(--line)] flex items-center justify-center relative"><span className="preview-ring absolute inset-2 rounded-full border" style={{ borderColor: t.color }} /><span className="relative text-lg" style={{ color: t.color }}>{t.glyph}</span></span>
                  <span className="min-w-0"><span className="block text-[0.85em] leading-tight">{t.name}</span><span className="block text-[0.68em] text-[var(--ink-faint)] leading-snug mt-0.5 line-clamp-2">{t.description}</span></span>
                </button>
              ))}
            </div>
            <Panel title={<span style={{ color: tool.color }}>{tool.name}</span>} right={<span className="mono text-[0.65em] text-[var(--ink-faint)]">{TOOLS.indexOf(tool) + 1}</span>}>
              <div className="flex flex-col gap-2">
                {tool.params.map((pd) => <Slider key={pd.key} label={pd.label} unit={pd.unit} min={pd.min} max={pd.max} step={pd.step} value={params[toolId][pd.key]} onChange={(v) => setParams((p) => ({ ...p, [toolId]: { ...p[toolId], [pd.key]: v } }))} />)}
                <div className="flex justify-between items-baseline mt-1 pt-2 border-t hairline">
                  <span className="label">Affected radius</span>
                  <span className="mono text-[0.78em]">{previewKm > 0 ? `≈ ${fmt.km(Math.min(previewKm, planet.radius * Math.PI))} km` : 'hemisphere'}</span>
                </div>
                <Button size="sm" variant="line" onClick={() => setParams((p) => ({ ...p, [toolId]: defaultParams(tool) }))}>Reset parameters</Button>
              </div>
            </Panel>
            <Panel title="Showcase events">
              <div className="flex flex-col gap-1">{SHOWCASES.filter((sc) => sc.name !== 'Ring disruption' || planet.hasRings).map((sc) => <Button key={sc.name} size="sm" className="justify-start" onClick={() => { const s = sceneRef.current; if (s) { sc.run(s); if (!cinematic) toggleCinematic(); } }}>{sc.name}</Button>)}</div>
            </Panel>
          </div>
        )}
        <button className="pointer-events-auto self-start panel px-1.5 py-2 text-[var(--ink-dim)] hover:text-[var(--ink)]" onClick={() => setToolOpen((v) => !v)} aria-label={toolOpen ? 'Collapse tools' : 'Expand tools'}>{toolOpen ? '‹' : '›'}</button>
      </div>

      {/* ---------- RIGHT PANELS ---------- */}
      <div className={cx('absolute right-3 top-16 bottom-28 z-20 w-[300px] max-w-[calc(100vw-1.5rem)] flex flex-col gap-2 pointer-events-none transition-opacity duration-500 overflow-hidden', hudHidden && 'opacity-0', !panel && 'hidden')}>
        {panel === 'info' && stats && (
          <Panel title="Inspection" onClose={() => setPanel(null)} className="overflow-y-auto">
            <div className="grid grid-cols-2 gap-x-3 gap-y-3">
              <Stat label="Surface integrity" value={fmt.pct(stats.integrity)} warn={stats.integrity < 0.5} />
              <Stat label="Condition" value={condition} warn={condition !== 'Stable'} />
              <Stat label="Terrain removed" value={(stats.removedVolume * 100).toFixed(3)} unit="% vol" />
              <Stat label="Interior exposure" value={fmt.pct(stats.interiorExposure)} />
              <Stat label="Atmos. disturbance" value={fmt.pct(stats.atmosphereDisturbance)} />
              <Stat label="Tracked debris" value={stats.debrisCount} />
              <Stat label="Surface temp." value={stats.surfaceTemperature.toFixed(0)} unit="K" warn={stats.surfaceTemperature > planet.temperature + 20} />
              <Stat label="Fragmentation" value={fmt.pct(stats.fragmentation)} />
            </div>
            <div className="mt-3"><Bar value={stats.integrity} color={stats.integrity > 0.5 ? 'var(--accent)' : 'var(--danger)'} /></div>
            <div className="border-t hairline mt-4 pt-3 grid grid-cols-2 gap-x-3 gap-y-3">
              <Stat label="Name" value={planet.name} /><Stat label="Type" value={TYPE_LABEL[planet.type]} />
              <Stat label="Radius" value={fmt.km(planet.radius)} unit="km" /><Stat label="Mass" value={fmt.mass(planet.mass)} unit="M⊕" />
              <Stat label="Gravity" value={st.gravity.toFixed(2)} unit="m/s²" /><Stat label="Escape vel." value={st.escape.toFixed(1)} unit="km/s" />
              <Stat label="Rotation" value={Math.abs(planet.rotationPeriod).toFixed(1)} unit={planet.rotationPeriod < 0 ? 'h retro' : 'h'} /><Stat label="Axial tilt" value={`${planet.axialTilt.toFixed(1)}°`} />
              <Stat label="Temperature" value={planet.temperature.toFixed(0)} unit="K" /><Stat label="Atmosphere" value={fmt.pct(planet.atmosphereDensity)} />
              <Stat label="Satellites" value={planet.satellites} /><Stat label="Orbit" value={planet.orbit.toFixed(2)} unit="AU" />
              <Stat label="Magnetic field" value={fmt.pct(planet.magneticField)} /><Stat label="Seed" value={planet.seed} />
            </div>
            <p className="text-[0.75em] text-[var(--ink-dim)] mt-3 leading-snug">{planet.description}</p>
            <div className="border-t hairline mt-3 pt-2"><Toggle label="Magnetic field lines" hint={planet.magneticField > 0.02 ? `Dipole visualization · strength ${Math.round(planet.magneticField * 100)}%` : 'This body has no significant field'} value={magField} onChange={(v) => { setMagField(v); sceneRef.current?.planet?.setMagneticField(v); }} /><Toggle label="Scientific mode" hint="Show assumptions & approximations" value={settings.scientificMode} onChange={(v) => updateSettings({ scientificMode: v })} /></div>
            {settings.scientificMode && (
              <ul className="text-[0.7em] text-[var(--ink-faint)] leading-relaxed list-disc pl-4 mt-1">
                <li>VISUAL MODEL: terrain relief is exaggerated ({(sceneRef.current?.planet?.amp ?? 0.03).toFixed(3)} R) for legibility.</li>
                <li>APPROXIMATION: 1 simulation second advances rotation by 2 minutes of world time.</li>
                <li>APPROXIMATION: integrity = removed volume vs a 2% budget plus fracture load; breakup is a game rule, not a physical threshold.</li>
                <li>SIMULATION: debris obeys central gravity (GM scaled from surface gravity) with no drag; particles are purely visual.</li>
                <li>FICTIONAL PHENOMENA: all toolkit events are invented; none model real weapons or physics.</li>
                <li>Surface area {fmt.km(st.surfaceArea)} km² · density {st.density.toFixed(2)} g/cm³ · escape {st.escape.toFixed(2)} km/s.</li>
              </ul>
            )}
          </Panel>
        )}
        {panel === 'timeline' && (
          <Panel title="Timeline" onClose={() => setPanel(null)} className="flex-1 min-h-0 flex flex-col [&>div]:flex-1 [&>div]:min-h-0 [&>div]:overflow-y-auto">
            <TimelineStrip events={events} now={simTime} />
            <ol className="mt-3 flex flex-col-reverse gap-1.5" aria-live="polite">
              {events.map((ev) => <li key={ev.id} className="flex gap-2 text-[0.75em] leading-snug"><span className="mono text-[var(--ink-faint)] shrink-0 w-12">{fmt.time(ev.time)}</span><span><span className="label block" style={{ color: EVENT_COLORS[ev.type] }}>{ev.type.replace(/_/g, ' ')}</span>{ev.label}</span></li>)}
            </ol>
          </Panel>
        )}
        {panel === 'states' && (
          <Panel title="Experiment states" onClose={() => setPanel(null)} right={<Button size="sm" variant="line" onClick={() => { sceneRef.current?.saveSnapshot(); setSnapshotsV((v) => v + 1); }}>Save state</Button>} className="overflow-y-auto">
            <p className="text-[0.72em] text-[var(--ink-faint)] mb-2">Branch experiments from any saved state. <Kbd>Ctrl</Kbd>+<Kbd>S</Kbd> saves.</p>
            <StateTree scene={sceneRef.current} onChange={() => setSnapshotsV((v) => v + 1)} />
            {snaps.length === 0 && <div className="text-[0.8em] text-[var(--ink-dim)]">No saved states yet.</div>}
          </Panel>
        )}
        {panel === 'replay' && (
          <Panel title="Event replay" onClose={() => setPanel(null)} className="overflow-y-auto">
            <p className="text-[0.72em] text-[var(--ink-faint)] mb-2">Events and camera motion are recorded continuously since the last reset. Saved replays re-run the exact events with the same seeds.</p>
            <div className="flex gap-2 mb-3"><Button size="sm" variant="line" className="flex-1" onClick={() => { const r = sceneRef.current?.buildReplay(`${planet.name} · ${new Date().toLocaleTimeString()}`); if (r) { saveReplay(r); bus.emit('toast', { text: 'Replay saved' }); } else bus.emit('toast', { text: 'Nothing recorded yet', kind: 'warn' }); }}>Save replay ({sceneRef.current?.recording.actions.length ?? 0} events)</Button>{sceneRef.current?.isReplaying && <Button size="sm" variant="danger" onClick={() => sceneRef.current?.stopReplay()}>Stop</Button>}</div>
            <ul className="flex flex-col gap-1">
              {replays.filter((r) => r.planetId === planet.id).map((r) => <li key={r.id} className="flex items-center gap-2 text-[0.78em]"><span className="flex-1 truncate">{r.name}<span className="text-[var(--ink-faint)] ml-1">· {r.actions.length} ev · {fmt.time(r.duration)}</span></span><Button size="sm" onClick={() => { sceneRef.current?.playReplay(r); setPaused(false); }}>Play</Button><Button size="sm" variant="danger" onClick={() => useStore.getState().deleteReplay(r.id)}>✕</Button></li>)}
              {replays.filter((r) => r.planetId === planet.id).length === 0 && <li className="text-[0.78em] text-[var(--ink-dim)]">No replays for this world.</li>}
            </ul>
          </Panel>
        )}
        {panel === 'camera' && (
          <Panel title="Camera" onClose={() => setPanel(null)} className="overflow-y-auto">
            <div className="grid grid-cols-2 gap-1 mb-3">
              <Button size="sm" variant="line" onClick={() => { const s = sceneRef.current; if (s) { s.stopFollow(); s.rig.mode = 'orbit'; setCinematic(false); } }}>Orbit</Button>
              <Button size="sm" variant="line" onClick={toggleCinematic}>Cinematic</Button>
              <Button size="sm" variant="line" onClick={() => sceneRef.current?.rig.zoomTo(3.4)}>Auto-frame</Button>
              <Button size="sm" variant="line" onClick={() => sceneRef.current?.rig.zoomTo(sceneRef.current.rig.minDist + 0.01)}>Surface approach</Button>
              <Button size="sm" variant="line" onClick={() => sceneRef.current?.rig.lookFromDirection(new THREE.Vector3(1, 0.15, 0.35), 3)}>Day side</Button>
              <Button size="sm" variant="line" onClick={() => sceneRef.current?.rig.lookFromDirection(new THREE.Vector3(-1, -0.15, -0.35), 3)}>Night side</Button>
            </div>
            <Slider label="Zoom" min={sceneRef.current?.rig.minDist ?? 1.05} max={40} step={0.01} value={sceneRef.current?.rig.zoomGoal ?? 3} onChange={(v) => sceneRef.current?.rig.zoomTo(v)} format={(v) => `${v.toFixed(2)} R`} />
            <div className="flex justify-between items-center mt-3 mb-1"><span className="label">Saved positions</span><Button size="sm" onClick={() => { const v = sceneRef.current?.rig.getView(); if (v) saveBookmark({ id: `b${Date.now()}`, name: `View ${bookmarks.length + 1}`, planetId: planet.id, ...v }); }}>Save current</Button></div>
            <ul className="flex flex-col gap-1">{bookmarks.filter((b) => b.planetId === planet.id).map((b) => <li key={b.id} className="flex items-center gap-2 text-[0.78em]"><span className="flex-1">{b.name} <span className="mono text-[var(--ink-faint)]">{b.dist.toFixed(2)} R</span></span><Button size="sm" onClick={() => sceneRef.current?.rig.setView(b.theta, b.phi, b.dist)}>Go</Button><Button size="sm" variant="danger" onClick={() => deleteBookmark(b.id)}>✕</Button></li>)}</ul>
          </Panel>
        )}
      </div>

      {/* ---------- BOTTOM: target readout + scale + hints ---------- */}
      <div className={cx('absolute bottom-3 inset-x-3 z-20 flex items-end justify-between gap-3 pointer-events-none transition-opacity duration-500', hudHidden && 'opacity-0')}>
        <div className="panel px-3 py-2 mono text-[0.72em] min-w-[220px]">
          {measure ? (
            <div><div className="label mb-1">Measure · click two surface points</div>{measure.km !== undefined ? <div>Great-circle distance <span className="text-[var(--accent)]">{fmt.km(measure.km)} km</span> · {(measure.km / planet.radius).toFixed(3)} R</div> : <div className="text-[var(--ink-dim)]">{measure.a ? 'Second point…' : 'First point…'}</div>}</div>
          ) : hover ? (
            <div><div className="label mb-1">Target</div><div>{fmtLatLon(hover.lat, hover.lon)} · {hover.water ? 'ocean' : hover.damage > 0.002 ? `crater floor −${(hover.damage * planet.radius).toFixed(0)} km` : `elev ${((hover.height) * (sceneRef.current?.planet?.amp ?? 0.03) * planet.radius).toFixed(0)} km`}</div><div className="text-[var(--ink-faint)]">{tool.name} · {previewKm > 0 ? `${fmt.km(Math.min(previewKm, planet.radius * 3.14))} km radius` : 'day-side hemisphere'}</div></div>
          ) : (
            <div className="text-[var(--ink-dim)]"><div className="label mb-1">Target</div>Point at the surface · click to trigger {tool.name}</div>
          )}
        </div>
        <div className="hidden md:flex flex-col items-end gap-1 pointer-events-none">
          <ScaleBar scene={sceneRef.current} planet={planet} dist={dbg?.camDist ?? 3.4} />
          {settings.showHints && <div className="label flex gap-4"><span>Drag orbit</span><span>Right-drag / 2-finger pan</span><span>Wheel / pinch zoom</span><span><Kbd>1</Kbd>–<Kbd>9</Kbd> tools</span><span><Kbd>H</Kbd> hide UI</span></div>}
        </div>
      </div>
      {hudHidden && <button className="absolute bottom-3 right-3 z-30 label px-2 py-1 opacity-40 hover:opacity-100 pointer-events-auto" onClick={() => { if (cinematic) toggleCinematic(); else setHideUI(false); }}>{cinematic ? 'Exit cinematic (Esc)' : 'Show UI (H)'}</button>}
      {stats?.broken && !hudHidden && <div className="absolute left-1/2 -translate-x-1/2 top-16 z-20 panel px-4 py-2 text-center fade-up pointer-events-auto"><div className="label text-[var(--danger)]">Body fragmented</div><div className="text-[0.8em] text-[var(--ink-dim)]">Press <Kbd>F</Kbd> to follow the largest fragment · <Kbd>R</Kbd> to restore</div></div>}
    </div>
  );
}

const EVENT_COLORS: Record<string, string> = { WORLD_CREATED: '#9fd3ff', EVENT_TRIGGERED: '#e6edf5', PLANET_IMPACT: '#ffb36b', TERRAIN_DAMAGED: '#d9a066', ATMOSPHERE_DISTURBED: '#8fd0ff', DEBRIS_GENERATED: '#bbb', BODY_FRAGMENTED: '#ff6a5a', COLLISION: '#ff8a5a', RESET: '#9fd3ff', SNAPSHOT: '#b48cff', REPLAY: '#8fffe0', BODY_ADDED: '#9fd3ff', BODY_REMOVED: '#ff6a5a' };

function fmtLatLon(lat: number, lon: number) { const la = THREE.MathUtils.radToDeg(lat), lo = THREE.MathUtils.radToDeg(lon); return `${Math.abs(la).toFixed(1)}°${la >= 0 ? 'N' : 'S'} ${Math.abs(lo).toFixed(1)}°${lo >= 0 ? 'E' : 'W'}`; }

function TimelineStrip({ events, now }: { events: SimEvent[]; now: number }) {
  const max = Math.max(now, 1);
  return (
    <div className="relative h-8 border-b hairline" aria-hidden>
      <div className="absolute left-0 right-0 top-1/2 h-px bg-[var(--line-strong)]" />
      {events.map((e) => <span key={e.id} title={e.label} className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rotate-45" style={{ left: `${(e.time / max) * 100}%`, background: EVENT_COLORS[e.type] ?? '#fff', opacity: 0.9 }} />)}
      <span className="absolute right-0 top-0 mono text-[0.65em] text-[var(--ink-faint)]">{fmt.time(now)}</span>
    </div>
  );
}

function StateTree({ scene, onChange }: { scene: PlanetScene | null; onChange: () => void }) {
  if (!scene) return null;
  const snaps = scene.snapshots;
  const roots = snaps.filter((s) => !s.parent || !snaps.some((x) => x.id === s.parent));
  const render = (id: string | null, depth: number): React.ReactNode => snaps.filter((s) => (depth === 0 ? roots.includes(s) : s.parent === id)).map((s) => (
    <li key={s.id}>
      <div className={cx('flex items-center gap-1.5 py-1 text-[0.78em]', scene.currentSnapshot === s.id && 'text-[var(--accent)]')} style={{ paddingLeft: depth * 12 }}>
        <span className="mono text-[var(--ink-faint)]">{depth ? '└' : '■'}</span>
        <span className="flex-1 truncate">{s.name}</span>
        <span className="mono text-[var(--ink-faint)] text-[0.85em]">{fmt.pct(s.integrity)} · {fmt.time(s.time)}</span>
        <Button size="sm" onClick={() => { scene.restoreSnapshot(s.id); onChange(); }} title="Restore">↺</Button>
        <Button size="sm" onClick={() => { scene.duplicateSnapshot(s.id); onChange(); }} title="Duplicate">⧉</Button>
        <Button size="sm" variant="danger" onClick={() => { scene.deleteSnapshot(s.id); onChange(); }} title="Delete">✕</Button>
      </div>
      <ul>{render(s.id, depth + 1)}</ul>
    </li>
  ));
  const cur = snaps.find((s) => s.id === scene.currentSnapshot);
  const live = scene.stats();
  return (
    <div>
      <ul>{render(null, 0)}</ul>
      {cur && <div className="mt-2 pt-2 border-t hairline text-[0.72em] text-[var(--ink-dim)]">Compare · <span className="text-[var(--ink)]">{cur.name}</span> {fmt.pct(cur.integrity)} → live {fmt.pct(live.integrity)} ({live.integrity - cur.integrity >= 0 ? '+' : ''}{((live.integrity - cur.integrity) * 100).toFixed(1)} pts)</div>}
    </div>
  );
}

function ScaleBar({ planet, dist }: { scene: PlanetScene | null; planet: PlanetDef; dist: number }) {
  // approximate km per 100px at the planet's distance
  const fovH = 42 * (Math.PI / 180);
  const kmPerPx = ((2 * Math.max(dist - 1, 0.02) * Math.tan(fovH / 2)) / Math.max(window.innerHeight, 1)) * planet.radius;
  const target = kmPerPx * 120;
  const nice = Math.pow(10, Math.floor(Math.log10(target))) * (target / Math.pow(10, Math.floor(Math.log10(target))) < 2 ? 1 : target / Math.pow(10, Math.floor(Math.log10(target))) < 5 ? 2 : 5);
  const px = nice / kmPerPx;
  return <div className="flex items-center gap-2 mono text-[0.65em] text-[var(--ink-dim)]"><span>{fmt.km(nice)} km</span><span className="h-2 border-b border-l border-r border-[var(--line-strong)]" style={{ width: Math.min(Math.max(px, 20), 300) }} /><span className="text-[var(--ink-faint)]">alt {fmt.km(Math.max(dist - 1, 0) * planet.radius)} km</span></div>;
}
