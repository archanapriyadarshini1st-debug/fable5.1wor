import React, { Component, useEffect, useState, type ReactNode } from 'react';
import { bus } from '../engine/EventBus';
import type { DebugInfo } from '../engine/types';
import { audio } from '../audio/AudioEngine';

export function cx(...c: (string | false | null | undefined)[]) { return c.filter(Boolean).join(' '); }

export function Button({ children, onClick, variant = 'ghost', className, disabled, title, active, size = 'md', ariaLabel }: { children: ReactNode; onClick?: () => void; variant?: 'ghost' | 'solid' | 'danger' | 'line'; className?: string; disabled?: boolean; title?: string; active?: boolean; size?: 'sm' | 'md' | 'lg'; ariaLabel?: string }) {
  const base = 'inline-flex items-center justify-center gap-2 select-none transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed';
  const sizes = { sm: 'px-2 py-1 text-[0.72em] tracking-wider', md: 'px-3 py-1.5 text-[0.82em] tracking-wide', lg: 'px-5 py-2.5 text-[0.95em] tracking-wide' }[size];
  const variants = {
    ghost: cx('border border-transparent hover:border-[var(--line-strong)] hover:bg-white/5', active && 'bg-white/10 border-[var(--line-strong)]'),
    line: cx('border border-[var(--line)] hover:border-[var(--line-strong)] hover:bg-white/5', active && 'bg-white/10 border-[var(--accent)] text-[var(--accent)]'),
    solid: 'bg-[var(--ink)] text-black hover:bg-white border border-transparent',
    danger: 'border border-[rgba(255,106,90,0.4)] text-[var(--danger)] hover:bg-[rgba(255,106,90,0.12)]',
  }[variant];
  return (
    <button type="button" aria-label={ariaLabel} aria-pressed={active} title={title} disabled={disabled} className={cx(base, sizes, variants, className)} onClick={() => { audio.play('ui', 0.3); onClick?.(); }}>
      {children}
    </button>
  );
}

export function Slider({ label, value, min, max, step, onChange, unit, format, disabled }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; unit?: string; format?: (v: number) => string; disabled?: boolean }) {
  const id = React.useId();
  return (
    <div className={cx('flex flex-col gap-0.5', disabled && 'opacity-40')}>
      <div className="flex justify-between items-baseline">
        <label htmlFor={id} className="label">{label}</label>
        <span className="mono text-[0.78em] text-[var(--ink)]">{format ? format(value) : (Number.isInteger(step) ? value.toFixed(0) : value.toFixed(step < 0.1 ? 2 : 1))}{unit ? <span className="text-[var(--ink-faint)] ml-0.5">{unit}</span> : null}</span>
      </div>
      <input id={id} type="range" min={min} max={max} step={step} value={value} disabled={disabled} onChange={(e) => onChange(parseFloat(e.target.value))} aria-label={label} />
    </div>
  );
}

export function Toggle({ label, value, onChange, hint }: { label: string; value: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <button type="button" role="switch" aria-checked={value} onClick={() => { audio.play('ui', 0.3); onChange(!value); }} className="flex items-center justify-between gap-3 w-full py-1.5 text-left group">
      <span className="flex flex-col"><span className="text-[0.85em]">{label}</span>{hint && <span className="text-[0.7em] text-[var(--ink-faint)]">{hint}</span>}</span>
      <span className={cx('relative w-8 h-4 border transition-colors shrink-0', value ? 'border-[var(--accent)] bg-[rgba(159,211,255,0.2)]' : 'border-[var(--line-strong)]')}>
        <span className={cx('absolute top-0.5 w-2.5 h-2.5 transition-all', value ? 'left-[18px] bg-[var(--accent)]' : 'left-0.5 bg-[var(--ink-dim)]')} />
      </span>
    </button>
  );
}

export function Panel({ title, children, className, right, onClose }: { title?: ReactNode; children: ReactNode; className?: string; right?: ReactNode; onClose?: () => void }) {
  return (
    <section className={cx('panel fade-up pointer-events-auto', className)} aria-label={typeof title === 'string' ? title : undefined}>
      {(title || onClose) && (
        <header className="flex items-center justify-between px-3 py-2 border-b hairline">
          <div className="label text-[var(--ink)]">{title}</div>
          <div className="flex items-center gap-1">{right}{onClose && <button aria-label="Close" onClick={onClose} className="text-[var(--ink-dim)] hover:text-[var(--ink)] px-1">✕</button>}</div>
        </header>
      )}
      <div className="p-3">{children}</div>
    </section>
  );
}

export function Kbd({ children }: { children: ReactNode }) { return <kbd className="mono inline-block min-w-[1.4em] text-center px-1 py-px border border-[var(--line-strong)] text-[0.7em] text-[var(--ink-dim)]">{children}</kbd>; }

export function Stat({ label, value, unit, warn }: { label: string; value: ReactNode; unit?: string; warn?: boolean }) {
  return (
    <div className="flex flex-col gap-0.5 min-w-0">
      <span className="label truncate">{label}</span>
      <span className={cx('mono text-[0.9em] truncate', warn ? 'text-[var(--accent-2)]' : 'text-[var(--ink)]')}>{value}{unit && <span className="text-[var(--ink-faint)] ml-1 text-[0.8em]">{unit}</span>}</span>
    </div>
  );
}

export function Bar({ value, color }: { value: number; color?: string }) {
  return <div className="h-[3px] w-full bg-white/10"><div className="h-full transition-[width] duration-300" style={{ width: `${Math.round(Math.max(0, Math.min(1, value)) * 100)}%`, background: color ?? 'var(--accent)' }} /></div>;
}

export function LoadingScreen({ label, progress }: { label: string; progress: number }) {
  const stages = ['Initializing engine', 'Building terrain', 'Generating planet', 'Initializing atmosphere', 'Initializing particles', 'Ready'];
  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-[var(--bg)] fade-in" role="status" aria-live="polite">
      <div className="relative w-40 h-40 mb-10">
        <div className="absolute inset-0 rounded-full border border-[var(--line-strong)]" />
        <div className="absolute inset-3 rounded-full border border-[var(--line)] animate-[spin_6s_linear_infinite]" style={{ borderTopColor: 'var(--accent)' }} />
        <div className="absolute inset-[38%] rounded-full" style={{ background: 'radial-gradient(circle at 35% 35%, #cfe8ff, #2a4a7a 60%, #060a12)' }} />
      </div>
      <div className="w-72">
        <div className="flex justify-between label mb-2"><span>{label}</span><span className="mono">{Math.round(progress * 100)}%</span></div>
        <div className="h-px bg-white/10 relative overflow-hidden"><div className="absolute left-0 top-0 h-full bg-[var(--accent)] transition-[width] duration-300" style={{ width: `${progress * 100}%` }} /></div>
        <ul className="mt-5 space-y-1">
          {stages.map((s, i) => { const done = progress >= (i + 1) / stages.length - 0.001 || label === s && i === stages.length - 1; const cur = label === s; return <li key={s} className={cx('label flex items-center gap-2 transition-colors', done ? 'text-[var(--ink)]' : cur ? 'text-[var(--accent)]' : 'text-[var(--ink-faint)]')}><span className="mono w-3">{done ? '■' : cur ? '▸' : '·'}</span>{s}</li>; })}
        </ul>
      </div>
    </div>
  );
}

export function Toasts() {
  const [items, setItems] = useState<{ id: number; text: string; kind: string }[]>([]);
  useEffect(() => bus.on('toast', ({ text, kind }) => { const id = Date.now() + Math.random(); setItems((s) => [...s.slice(-3), { id, text, kind: kind ?? 'info' }]); setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), 3200); }), []);
  return (
    <div className="absolute left-1/2 -translate-x-1/2 bottom-24 z-50 flex flex-col gap-1 items-center pointer-events-none" aria-live="polite">
      {items.map((i) => <div key={i.id} className={cx('panel px-3 py-1.5 text-[0.8em] fade-up', i.kind === 'error' && 'border-[var(--danger)] text-[var(--danger)]', i.kind === 'warn' && 'text-[var(--accent-2)]')}>{i.text}</div>)}
    </div>
  );
}

export function DebugOverlay({ info }: { info: DebugInfo | null }) {
  if (!info) return null;
  const rows: [string, string | number][] = [['FPS', info.fps], ['Frame', `${info.frameMs} ms`], ['Draw calls', info.drawCalls], ['Triangles', info.triangles.toLocaleString()], ['Particles', info.particles.toLocaleString()], ['Debris', info.debris], ['Fragments', info.fragments], ['Chunks/LOD', `${info.chunks} · ${info.lod}`], ['Sim time', `${info.simTime.toFixed(1)} s`], ['Physics', `${info.physicsMs} ms`], ['Cam dist', `${info.camDist} R`], ['GPU', info.gpu], ['Quality', info.quality]];
  return (
    <div className="absolute top-14 left-3 z-40 panel px-3 py-2 mono text-[0.68em] leading-5 pointer-events-none w-48" aria-label="Debug overlay">
      <div className="label mb-1">Developer</div>
      {rows.map(([k, v]) => <div key={k} className="flex justify-between gap-3"><span className="text-[var(--ink-faint)]">{k}</span><span>{v}</span></div>)}
    </div>
  );
}

export class ErrorBoundary extends Component<{ children: ReactNode; onReset?: () => void }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(e: Error) { console.error(e); }
  render() {
    if (this.state.error) {
      return (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-[var(--bg)] p-6">
          <div className="panel max-w-md p-6">
            <div className="label text-[var(--danger)] mb-2">Simulation error</div>
            <p className="text-sm text-[var(--ink-dim)] mb-4">{this.state.error.message}</p>
            <p className="text-xs text-[var(--ink-faint)] mb-4">This usually means the graphics device ran out of resources or the browser does not support WebGL2. Try the Performance quality mode or a different browser.</p>
            <Button variant="solid" onClick={() => { this.setState({ error: null }); this.props.onReset?.(); }}>Return to menu</Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export function useAnimatedNumber(v: number, ms = 300) {
  const [d, setD] = useState(v);
  useEffect(() => { const start = d, t0 = performance.now(); let raf = 0; const tick = () => { const k = Math.min(1, (performance.now() - t0) / ms); setD(start + (v - start) * k); if (k < 1) raf = requestAnimationFrame(tick); }; raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf); }, [v]); // eslint-disable-line
  return d;
}

export const fmt = {
  km: (v: number) => (v >= 1e6 ? `${(v / 1e6).toFixed(2)}M` : v >= 1e4 ? `${(v / 1e3).toFixed(1)}k` : v.toFixed(0)),
  pct: (v: number) => `${Math.round(v * 100)}%`,
  time: (s: number) => { if (s < 60) return `${s.toFixed(1)} s`; const m = Math.floor(s / 60); const sec = Math.floor(s % 60); if (m < 60) return `${m}m ${sec.toString().padStart(2, '0')}s`; return `${Math.floor(m / 60)}h ${(m % 60).toString().padStart(2, '0')}m`; },
  mass: (m: number) => (m >= 100 ? `${m.toFixed(0)}` : m >= 1 ? m.toFixed(2) : m.toFixed(3)),
};
