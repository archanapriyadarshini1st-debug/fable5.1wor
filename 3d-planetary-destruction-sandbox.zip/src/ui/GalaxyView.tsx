import { useEffect, useRef, useState } from 'react';
import { GalaxyScene, type GalaxySystem } from '../engine/GalaxyScene';
import { STAR_CLASSES } from '../engine/planets';
import { generateSystem } from '../engine/SystemScene';
import type { StarClass } from '../engine/types';
import { useStore } from '../state/store';
import { Button, Panel, cx } from './common';

export function GalaxyView() {
  const hostRef = useRef<HTMLDivElement>(null);
  const labelsRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<GalaxyScene | null>(null);
  const { setScreen, setSelectedSystem, settings } = useStore();
  const [hover, setHover] = useState<GalaxySystem | null>(null);
  const [selected, setSelected] = useState<GalaxySystem | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let scene: GalaxyScene;
    try { scene = new GalaxyScene(hostRef.current!, useStore.getState().settings); } catch (e) { setError((e as Error).message); return; }
    sceneRef.current = scene;
    const nodes = new Map<string, HTMLSpanElement>();
    scene.onLabels = (list) => {
      const c = labelsRef.current; if (!c) return;
      for (const l of list) {
        let n = nodes.get(l.id);
        if (!n) { n = document.createElement('span'); n.className = 'absolute mono text-[0.6em] tracking-widest text-[var(--ink-faint)] pointer-events-none'; c.appendChild(n); nodes.set(l.id, n); }
        n.textContent = l.name.replace(' System', '').toUpperCase();
        n.style.transform = `translate(${l.x + 8}px, ${l.y - 6}px)`;
        n.style.display = l.visible && scene.rig.dist < 70 ? 'block' : 'none';
      }
    };
    return () => { scene.dispose(); nodes.forEach((n) => n.remove()); };
  }, []);
  const onMove = (e: React.PointerEvent) => { const s = sceneRef.current; if (!s) return; const h = s.pick(e.clientX, e.clientY); s.setHover(h); setHover(h); };
  const onUp = (e: React.PointerEvent) => { const s = sceneRef.current; if (!s || !s.rig.wasClick()) return; const h = s.pick(e.clientX, e.clientY); if (h) { setSelected(h); s.focusSystem(h); } };
  useEffect(() => { const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setScreen('menu'); }; window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [setScreen]);
  const focus = selected ?? hover;
  return (
    <div className={cx('absolute inset-0 overflow-hidden', settings.highContrast && 'hc')}>
      <div ref={hostRef} className="absolute inset-0" onPointerMove={onMove} onPointerUp={onUp} role="application" aria-label="Galaxy map" />
      <div ref={labelsRef} className="absolute inset-0 pointer-events-none" aria-hidden />
      {error && <div className="absolute inset-0 flex items-center justify-center"><div className="panel p-6">{error}</div></div>}
      <div className="absolute top-3 left-3 z-20 flex items-center gap-2"><Button size="sm" onClick={() => setScreen('menu')}>← Menu</Button><div className="panel px-3 py-1.5"><div className="text-[0.95em]">Galaxy view</div><div className="label">30 charted systems · click a marker</div></div></div>
      <div className="absolute bottom-3 left-3 label">Drag to orbit · wheel to zoom · the spiral rotates slowly (visual model)</div>
      {focus && (
        <div className="absolute right-3 top-3 z-20 w-[300px]">
          <Panel title={focus.name} onClose={selected ? () => { setSelected(null); sceneRef.current?.unfocus(); } : undefined}>
            <div className="text-[0.85em] text-[var(--ink-dim)]">Primary: {STAR_CLASSES[focus.starClass as StarClass].name} · {STAR_CLASSES[focus.starClass as StarClass].temperature} K</div>
            <div className="mono text-[0.7em] text-[var(--ink-faint)] mt-1">seed {focus.seed}</div>
            <div className="flex gap-2 mt-3"><Button variant="solid" className="flex-1" onClick={() => { const sys = generateSystem(focus.seed, focus.name); sys.bodies[0].starClass = focus.starClass as StarClass; sys.bodies[0].color = STAR_CLASSES[focus.starClass as StarClass].color; setSelectedSystem(sys); setScreen('system'); }}>Enter system</Button></div>
          </Panel>
        </div>
      )}
    </div>
  );
}
