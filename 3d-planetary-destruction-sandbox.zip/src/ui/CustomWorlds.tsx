import { useRef, useState } from 'react';
import { bus } from '../engine/EventBus';
import { TYPE_LABEL, randomPlanet } from '../engine/planets';
import type { PlanetDef } from '../engine/types';
import { useStore } from '../state/store';
import { Button, cx, fmt } from './common';
import { PlanetDisc } from './PlanetSelect';

function validWorld(w: unknown): w is PlanetDef {
  const o = w as PlanetDef;
  return !!o && typeof o === 'object' && typeof o.name === 'string' && typeof o.radius === 'number' && typeof o.seed === 'number' && !!o.palette && typeof o.palette.land === 'string' && typeof o.type === 'string';
}

export function CustomWorlds() {
  const { customWorlds, customSystems, replays, deleteWorld, deleteSystem, deleteReplay, saveWorld, setScreen, setSelectedPlanet, setLabPlanet, setSelectedSystem } = useStore();
  const [tab, setTab] = useState<'worlds' | 'systems' | 'replays'>('worlds');
  const fileRef = useRef<HTMLInputElement>(null);
  const importFile = (f: File) => {
    f.text().then((t) => {
      try {
        const j = JSON.parse(t);
        const list = Array.isArray(j) ? j : [j];
        let n = 0;
        for (const w of list) if (validWorld(w)) { saveWorld({ ...w, id: `w-${Date.now()}-${n}`, handcrafted: false }); n++; }
        bus.emit('toast', n ? { text: `Imported ${n} world${n > 1 ? 's' : ''}` } : { text: 'File did not contain a valid world', kind: 'error' });
      } catch { bus.emit('toast', { text: 'Invalid JSON file', kind: 'error' }); }
    });
  };
  const exportAll = () => { const blob = new Blob([JSON.stringify(customWorlds, null, 2)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'custom-worlds.json'; a.click(); };
  return (
    <div className="absolute inset-0 flex flex-col bg-[var(--bg)]">
      <header className="flex items-center justify-between px-5 py-3 border-b hairline">
        <div className="flex items-center gap-4"><Button size="sm" onClick={() => setScreen('menu')}>← Menu</Button><h2 className="label text-[var(--ink)]">Custom worlds</h2></div>
        <div className="flex gap-1" role="tablist">{(['worlds', 'systems', 'replays'] as const).map((t) => <Button key={t} size="sm" active={tab === t} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)} <span className="mono text-[var(--ink-faint)]">{t === 'worlds' ? customWorlds.length : t === 'systems' ? customSystems.length : replays.length}</span></Button>)}</div>
      </header>
      <div className="flex-1 overflow-y-auto p-5">
        {tab === 'worlds' && (
          <>
            <div className="flex flex-wrap gap-2 mb-4">
              <Button variant="solid" onClick={() => { setLabPlanet(null); setScreen('lab'); }}>New world in Lab</Button>
              <Button variant="line" onClick={() => { const r = randomPlanet(); saveWorld({ ...r, id: `w-${Date.now()}` }); }}>Generate random world</Button>
              <Button variant="line" onClick={() => fileRef.current?.click()}>Import JSON</Button>
              <Button variant="line" onClick={exportAll} disabled={!customWorlds.length}>Export all</Button>
              <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) importFile(f); e.target.value = ''; }} />
            </div>
            {customWorlds.length === 0 && <div className="text-[var(--ink-dim)] text-sm">No saved worlds yet. Build one in the Planet Lab or save a random world.</div>}
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
              {customWorlds.map((w) => (
                <div key={w.id} className="panel p-4 flex flex-col gap-3 fade-up">
                  <div className="flex gap-4 items-start"><PlanetDisc p={w} size={64} /><div className="min-w-0"><div className="truncate">{w.name}</div><div className="label mt-0.5">{TYPE_LABEL[w.type]}</div><div className="mono text-[0.68em] text-[var(--ink-faint)] mt-1">R {fmt.km(w.radius)} km · seed {w.seed}</div></div></div>
                  <div className="flex flex-wrap gap-1">
                    <Button size="sm" variant="solid" onClick={() => { setSelectedPlanet(w); setScreen('smash'); }}>Smash</Button>
                    <Button size="sm" variant="line" onClick={() => { setLabPlanet(w); setScreen('lab'); }}>Edit</Button>
                    <Button size="sm" onClick={() => { const blob = new Blob([JSON.stringify(w, null, 2)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${w.name.replace(/\s+/g, '_')}.world.json`; a.click(); }}>Export</Button>
                    <Button size="sm" variant="danger" onClick={() => deleteWorld(w.id)}>Delete</Button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
        {tab === 'systems' && (
          <div className={cx('grid gap-3')} style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
            {customSystems.length === 0 && <div className="text-[var(--ink-dim)] text-sm">No saved systems. In System Smash, edit bodies and press “Save system”.</div>}
            {customSystems.map((s) => (
              <div key={s.id} className="panel p-4 flex flex-col gap-2 fade-up">
                <div>{s.name}</div>
                <div className="mono text-[0.68em] text-[var(--ink-faint)]">{s.bodies.length} bodies · {s.bodies.filter((b) => b.kind === 'planet').length} planets · {s.bodies.filter((b) => b.kind === 'moon').length} moons</div>
                <div className="flex gap-1"><Button size="sm" variant="solid" onClick={() => { setSelectedSystem(s); setScreen('system'); }}>Run</Button><Button size="sm" variant="danger" onClick={() => deleteSystem(s.id)}>Delete</Button></div>
              </div>
            ))}
          </div>
        )}
        {tab === 'replays' && (
          <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))' }}>
            {replays.length === 0 && <div className="text-[var(--ink-dim)] text-sm">No replays saved. In Planet Smash open the Replay panel after triggering events.</div>}
            {replays.map((r) => (
              <div key={r.id} className="panel p-4 flex flex-col gap-2 fade-up">
                <div className="truncate">{r.name}</div>
                <div className="mono text-[0.68em] text-[var(--ink-faint)]">{r.planet.name} · {r.actions.length} events · {fmt.time(r.duration)} · {new Date(r.createdAt).toLocaleString()}</div>
                <div className="flex gap-1"><Button size="sm" variant="solid" onClick={() => { setSelectedPlanet({ ...r.planet, id: r.planetId }); useStore.getState().setPendingReplay(r); setScreen('smash'); }}>Open world</Button><Button size="sm" variant="danger" onClick={() => deleteReplay(r.id)}>Delete</Button></div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
