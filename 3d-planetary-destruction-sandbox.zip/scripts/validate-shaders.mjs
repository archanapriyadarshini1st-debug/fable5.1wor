// Offline GLSL validation: emulates three.js's ShaderMaterial prefix (GLSL ES 3.0) and runs glslangValidator.
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { build } from 'esbuild';

const bin = 'node_modules/glslang-validator-prebuilt-predownloaded/bin/glslangValidator.linux';
const out = await build({ entryPoints: ['src/engine/shaders/planet.ts', 'src/engine/shaders/effects.ts'], bundle: true, write: false, format: 'esm', platform: 'neutral', outdir: 'x' });
const dir = mkdtempSync(join(tmpdir(), 'glsl-'));
const mods = {};
for (const f of out.outputFiles) { const p = join(dir, f.path.split('/').pop().replace(/\.js$/, '.mjs')); writeFileSync(p, f.text); mods[p] = await import(p); }
const all = Object.assign({}, ...Object.values(mods));

const VERT_PREFIX = `#version 300 es
precision highp float; precision highp int;
#define attribute in
#define varying out
#define texture2D texture
uniform mat4 modelMatrix; uniform mat4 modelViewMatrix; uniform mat4 projectionMatrix; uniform mat4 viewMatrix; uniform mat3 normalMatrix; uniform vec3 cameraPosition; uniform bool isOrthographic;
attribute vec3 position; attribute vec3 normal; attribute vec2 uv;
#ifdef USE_INSTANCING
attribute mat4 instanceMatrix;
#endif
`;
const FRAG_PREFIX = `#version 300 es
precision highp float; precision highp int;
#define varying in
#define texture2D texture
layout(location = 0) out highp vec4 pc_fragColor;
#define gl_FragColor pc_fragColor
uniform mat4 viewMatrix; uniform vec3 cameraPosition; uniform bool isOrthographic;
vec4 linearToOutputTexel(vec4 v){ return v; }
`;
const strip = (s) => s.replace(/#include <[^>]+>/g, '');
const pairs = [
  ['planet', all.PLANET_VERT, all.PLANET_FRAG],
  ['atmo', all.ATMO_VERT, all.ATMO_FRAG],
  ['cloud', all.CLOUD_VERT, all.CLOUD_FRAG],
  ['star', all.STAR_VERT, all.STAR_FRAG],
  ['corona', all.BILLBOARD_VERT, all.CORONA_FRAG],
  ['particle', all.PARTICLE_VERT, all.PARTICLE_FRAG],
  ['debris', all.DEBRIS_VERT, all.DEBRIS_FRAG, true],
  ['ring', all.RING_VERT, all.RING_FRAG],
  ['nebula', all.NEBULA_VERT, all.NEBULA_FRAG],
  ['stars', all.STARS_VERT, all.STARS_FRAG],
  ['distort', all.DISTORT_SHADER.vertexShader, all.DISTORT_SHADER.fragmentShader],
  ['body', all.BODY_VERT, all.BODY_FRAG],
  ['grid', all.GRID_VERT, all.GRID_FRAG],
];
let fail = 0;
for (const [name, v, f, inst] of pairs) {
  for (const [stage, src, ext] of [['vert', (inst ? '#define USE_INSTANCING\n' : '') + VERT_PREFIX + strip(v), 'vert'], ['frag', FRAG_PREFIX + strip(f), 'frag']]) {
    const p = join(dir, `${name}.${ext}`);
    // move #version to top if we prepended defines
    let code = src; if (inst && stage === 'vert') code = code.replace('#define USE_INSTANCING\n', '').replace('#version 300 es\n', '#version 300 es\n#define USE_INSTANCING\n');
    writeFileSync(p, code);
    try { execFileSync(bin, [p], { stdio: 'pipe' }); console.log(`ok   ${name}.${stage}`); }
    catch (e) { fail++; console.log(`FAIL ${name}.${stage}\n${e.stdout?.toString()}`); }
  }
}
process.exit(fail ? 1 : 0);
